# Cacti OS 1.17.18 source
- `app/` the Electron front end (also the web, SteamOS, Pi and portable builds)
- `buildroot-kit/` the Buildroot kit for the PC and Raspberry Pi images (includes its own copy of the app)
- `android/` the Android project
- `tools/` release scripts (the private signing key is NOT included)
