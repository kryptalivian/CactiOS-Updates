// runs inside the page, right after the normal web preload: connects the app to Android
(function(){
  if (!window.api || !window.AndroidBridge) return;
  [200, 800, 2000, 5000].forEach(t => setTimeout(() => window.dispatchEvent(new Event('resize')), t)); if (window.visualViewport) visualViewport.addEventListener('resize', () => window.dispatchEvent(new Event('resize')));
  const A = window.AndroidBridge, api = window.api; let N = 0; const P = {}, L = {};
  window.__androidResolve = (id, json) => { const p = P[id]; if (!p) return; delete P[id]; try { const r = JSON.parse(json); if (r && r.err) p.rej(new Error(r.err)); else p.res(r ? r.v : null); } catch (e) { p.rej(e); } };
  window.__androidEmit = (ch, d) => (L[ch] || []).forEach(f => { try { f(d || {}); } catch {} });
  const J = (c, ...a) => new Promise((res, rej) => { const id = ++N; P[id] = { res, rej }; try { A.call(id, c, JSON.stringify(a)); } catch (e) { delete P[id]; rej(e); } });
  const hook = (name, ch) => { const o = api[name]; api[name] = cb => { if (o) o(cb); (L[ch] = L[ch] || []).push(cb); }; };
  hook('onGameExit', 'game-exit'); hook('onEmuProgress', 'emu-progress');
  api.launch = o => J('launch', o);
  api.installRetroArch = () => J('retroarch:install');
  const oc = api.check; api.check = async () => { const r = await oc(); try { const j = await J('check'); if (j && j.retroarch) r.retroarch = j.retroarch; } catch {} r.android = true; return r; };
  const oq = api.getConfig, os_ = api.setConfig; const noLinux = c => { if (c) c.linux = false; return c; };
  api.getConfig = async () => noLinux(await oq()); api.setConfig = async p => noLinux(await os_(p));
  api.wifi = () => J('wifi'); api.wifiPower = async () => { await J('settings', 'wifi'); return J('wifi'); }; api.wifiOpen = () => J('settings', 'wifi');
  api.btSettings = () => J('settings', 'bt'); api.dispSystem = () => J('settings', 'display');
  api.dispInfo = async () => ({ platform: 'android', modes: [] });
  api.pick = t => t === 'folder' ? J('pick') : Promise.resolve(null);
  const EMU_CARDS = async () => { let ok = false, dol = false; try { const c = await J('check'); ok = !!(c && c.retroarch && c.retroarch.ok); } catch {} try { dol = !!(await J('dolphin:status')); } catch {}
    return [{ id: 'retroarch', name: 'RetroArch', blurb: 'Plays every retro system in your library.', systems: ['All systems'], color: '#3a4a8c', letter: 'R', ra: true, canAuto: true, busy: false, status: ok ? 'installed' : 'none', label: ok ? 'Installed' : 'Not installed' },
      { id: 'dolphin', name: 'Dolphin', blurb: 'GameCube and Wii. Installs the official Dolphin app; your games open in it.', systems: ['Nintendo GameCube', 'Nintendo Wii'], color: '#2aa7e0', letter: 'DOL', ra: false, canAuto: true, busy: false, status: dol ? 'installed' : 'none', label: dol ? 'Installed' : 'Not installed' }]; };
  api.emuList = EMU_CARDS; api.emuRefresh = EMU_CARDS; api.emuPage = async () => false; api.emuBrowse = async () => null; api.biosOpen = async () => false;
  api.emuInstall = async id => { try { if (id === 'dolphin') { const r = await J('dolphin:install'); if (r && r.needPermission) return { error: 'Allow installs from Cacti OS in the settings that just opened, then press Install again.' }; return { ok: true, version: 'confirm the install on screen' }; } await J('retroarch:install'); return { ok: true, version: 'confirm the install on screen' }; } catch (e) { return { error: String(e.message || e) }; } };
  api.installCores = async () => { const ok = await J('retroarch:open'); return { ok: 0, fail: [ok ? 'In RetroArch choose Load Core, then Download a Core' : 'Install RetroArch first'] }; };
  const ochk = api.check; api.check = async () => { const r = await ochk(); try { if (r && r.systems) r.systems.forEach(s => { s.coreOk = ['FCEUmm','Genesis Plus GX','mGBA','Snes9x'].includes(s.core); }); r.coresDirOk = true; } catch {} return r; };
  // ---- app updates: node downloads and checks the signed APK, Android installs it ----
  const ous = api.updStart; api.updStart = async () => { const r = await ous(); if (r && r.apk) { try { const x = await J('apk:install', r.apk); if (x && x.needPermission) return { error: 'Allow installs from Cacti OS in the settings that just opened, then press Update again.' }; } catch (e) { return { error: String(e.message || e) }; } } return r; };
  api.fullscreen = () => {}; api.quit = () => {};

  // ---- play time -> "Last played" ----
  let cur = null; const olaunch = api.launch;
  api.launch = async o => { const r = await olaunch(o); if (r && !r.error) cur = { file: o.file, title: o.title, system: o.system, t: Date.now() }; return r; };
  window.addEventListener('beforeunload', () => {});
  (L['game-exit'] = L['game-exit'] || []).unshift(() => { if (!cur) return; const c = cur; cur = null; try { api.playRecord({ file: c.file, title: c.title, system: c.system, secs: Math.round((Date.now() - c.t) / 1000) }); } catch {} });

  // ---- wallpaper fills the whole screen, whatever its shape ----
  const fillBg = () => {
    if (document.getElementById('bgx')) return; const st = document.getElementById('stage'); if (!st) return;
    const bx = document.createElement('div'); bx.id = 'bgx'; bx.style.cssText = 'position:fixed;inset:0;overflow:hidden;pointer-events:none;z-index:0';
    const pos = { b1: 'left:-8%;top:-20%;width:52%;height:66%', b2: 'right:-7%;top:14%;width:44%;height:56%', b3: 'left:20%;bottom:-26%;width:55%;height:52%' };
    ['b1', 'b2', 'b3', 'pat'].forEach(id => { const e = document.getElementById(id); if (!e) return; if (pos[id]) { e.style.cssText = 'position:absolute;' + pos[id]; e.style.filter = 'blur(9vmin)'; } bx.appendChild(e); });
    document.body.insertBefore(bx, st);
    const sx = document.createElement('style'); sx.textContent = '*{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none}#stage{overflow:clip!important;overflow-clip-margin:150vmax}#tscroll{overflow-x:auto!important;scrollbar-width:none;touch-action:pan-x}#tscroll::-webkit-scrollbar{display:none}#lib,#elib,#po,#avl,#fx.fullv{box-shadow:0 0 0 150vmax var(--bg1)}.dscrim{box-shadow:0 0 0 150vmax rgba(0,0,0,.6)}#fx.menuv{box-shadow:0 0 0 150vmax rgba(10,12,28,.45)}'; document.head.appendChild(sx);
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fillBg); else fillBg();

  // ---- store: no desktop ports; achievement popup preview shown in the page ----
  api.storeList = async () => []; api.storeLinks = async () => [];
  api.achPreview = async (style) => {
    try {
      let k = 0.6; try { const c = await api.getConfig(); k = String(c && c.achSize) === '1' ? 0.4 : String(c && c.achSize) === '3' ? 0.8 : 0.6; } catch {}
      const old = document.getElementById('achprev'); if (old) old.remove();
      const e = document.createElement('div'); e.id = 'achprev';
      e.style.cssText = 'transform-origin:50% 0;position:fixed;top:4vh;left:50%;transform:translate(-50%,-30px);z-index:99999;display:flex;align-items:center;gap:14px;background:rgba(27,24,48,.94);color:#fff;border:2px solid #7c6cff;border-radius:40px;padding:10px 26px 10px 12px;font-family:system-ui,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.45);opacity:0;transition:all .3s';
      e.innerHTML = '<div style="width:48px;height:48px;border-radius:50%;background:linear-gradient(150deg,#f2b33d,#e0841a);display:flex;align-items:center;justify-content:center;font-size:26px">🏆</div><div><div style="font-weight:700;font-size:17px">Achievement unlocked</div><div style="color:#c9c4f5;font-size:13px">This is how achievement popups look · 10 pts</div></div>';
      document.body.appendChild(e); requestAnimationFrame(() => { e.style.opacity = '1'; e.style.transform = 'translate(-50%,0) scale(' + (k * 1.25) + ')'; });
      setTimeout(() => { e.style.opacity = '0'; e.style.transform = 'translate(-50%,-30px) scale(' + (k * 1.25) + ')'; setTimeout(() => e.remove(), 400); }, 3500);
    } catch {}
    return true;
  };

  // Tap outside an open panel/menu closes it (same as pressing B / Escape).
  let swallow = false;
  document.addEventListener('pointerdown', (e) => {
    try {
      swallow = false;
      const open = document.querySelectorAll('.pop:not(.hid)'); if (!open.length) return;
      const t = e.target; if (!t || !t.closest || t.closest('.pop') || t.closest('#top') || t.closest('.dp')) return;
      swallow = true;
      const ev = (type) => new KeyboardEvent(type, { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true });
      document.body.dispatchEvent(ev('keydown')); document.body.dispatchEvent(ev('keyup'));
    } catch {}
  }, true);
  document.addEventListener('click', (e) => { if (swallow) { swallow = false; e.stopPropagation(); e.preventDefault(); } }, true);
})();
