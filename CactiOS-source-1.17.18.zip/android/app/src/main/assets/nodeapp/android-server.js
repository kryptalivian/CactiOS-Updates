// Starts the Cacti OS web edition inside the Android app (Node.js for Android).
Object.defineProperty(process, 'platform', { value: 'linux' });
process.env.NO_OPEN = '1';
if (typeof Intl === 'undefined') { // this Node build has no ICU: simple stand-ins
  const cmp = (a, b, o) => { a = String(a); b = String(b); if (o && o.numeric) { const re = /(\d+)|(\D+)/g, x = a.match(re) || [], y = b.match(re) || []; for (let i = 0; i < Math.min(x.length, y.length); i++) { const p = x[i], q = y[i]; if (/^\d/.test(p) && /^\d/.test(q)) { if (+p !== +q) return +p < +q ? -1 : 1; } else if (p !== q) return p < q ? -1 : 1; } return x.length - y.length; } return a < b ? -1 : a > b ? 1 : 0; };
  global.Intl = { Collator: class { constructor(l, o) { this.o = o; this.compare = (a, b) => cmp(a, b, this.o); } }, DateTimeFormat: class { format(d) { return new Date(d).toISOString(); } resolvedOptions() { return { timeZone: 'UTC', locale: 'en-US' }; } }, NumberFormat: class { format(n) { return String(n); } } };
}
const lc = String.prototype.localeCompare; String.prototype.localeCompare = function (b, l, o) { try { return lc.call(this, b, l, o); } catch { return cmp0(this, b); } }; const cmp0 = (a, b) => (String(a) < String(b) ? -1 : String(a) > String(b) ? 1 : 0);
const os = require('os');
const ni = os.networkInterfaces; os.networkInterfaces = () => { try { return ni.call(os); } catch { return {}; } };
const hn = os.hostname; os.hostname = () => { try { return hn.call(os); } catch { return 'android'; } };
process.on('uncaughtException', e => console.error('uncaught', e && e.stack || e));
process.on('unhandledRejection', e => console.error('unhandled', e && e.stack || e));
// first run: point the games folder at the shared storage folder if there is one
try {
  const fs = require('fs'), path = require('path'), cf = path.join(process.env.RETROOS_DATA, 'config.json');
  if (!fs.existsSync(cf)) { const ok = p => { try { return fs.readdirSync(p).length > 0; } catch { return false; } }; let r = ['/storage/emulated/0/ROMs', '/storage/emulated/0/Roms', '/storage/emulated/0/roms'].find(ok); if (!r) { r = path.join(process.env.HOME, 'ROMs'); fs.mkdirSync(r, { recursive: true }); } fs.writeFileSync(cf, JSON.stringify({ romRoot: r })); }
} catch {}
require('./server.js');
require('./android-update.js');
