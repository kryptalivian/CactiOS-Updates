// Android updates: the whole app (engine, player and screens) comes as one signed APK listed in the same manifest.json
// the other versions use, under "android". Nothing unsigned or altered is ever installed.
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const DATA = process.env.RETROOS_DATA || '.', VC = parseInt(process.env.APP_VERCODE || '0', 10) || 0, VN = process.env.APP_VERNAME || '?';
const PUB = '1400638b7110379dd2a57a66d7f72a24fbea3febef192694ba3ba7b99d6ae68f';
const DEFAULT = 'https://github.com/kryptalivian/CactiOS-Updates/releases/latest/download/manifest.json';
const STATE = path.join(DATA, 'android-upd.json');
const rj = f => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
const cfg = () => rj(path.join(DATA, 'config.json')) || {};
// plain http is only allowed on your own network (the signature still has to match); everything else must be https
const addrOk = u => /^https:\/\//i.test(u) || /^http:\/\/(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/i.test(u);
function sigOk(a) {
  try {
    if (!a || !/^[\w.\-]{1,40}$/.test(String(a.versionName)) || !Number.isInteger(a.versionCode) || !/^[0-9a-f]{64}$/.test(String(a.sha256)) || !Number.isInteger(a.size) || a.size <= 0 || !Array.isArray(a.notes) || typeof a.sig !== 'string') return false;
    const key = crypto.createPublicKey({ key: Buffer.concat([Buffer.from('302a300506032b6570032100', 'hex'), Buffer.from(PUB, 'hex')]), format: 'der', type: 'spki' });
    return crypto.verify(null, Buffer.from(JSON.stringify(['cacti-os-android', a.versionName, a.versionCode, a.sha256, a.size, a.notes])), key, Buffer.from(a.sig, 'base64'));
  } catch { return false; }
}
let PEND = null; // verified entry from the last check
async function check(auto) {
  const c = cfg(), u = String(c.updateUrl || DEFAULT).trim();
  if (!addrOk(u)) return { error: auto ? '' : 'The update address must start with https://' };
  try {
    const hd = { 'User-Agent': 'CactiOS-Updater', 'Cache-Control': 'no-cache' };
    let r = await fetch(u, { signal: AbortSignal.timeout(15000), headers: hd }), mu = u;
    if (r.status === 404) {
      const g = /^https:\/\/github\.com\/([\w.-]+)\/([\w.-]+)\/releases\/latest\/download\//i.exec(u);
      if (g) {
        const a = await fetch(`https://api.github.com/repos/${g[1]}/${g[2]}/releases/latest`, { signal: AbortSignal.timeout(15000), headers: { ...hd, Accept: 'application/vnd.github+json' } });
        if (a.ok) { const j = await a.json(), f = (j.assets || []).find(x => /manifest.*\.json$/i.test(x.name || '')); if (f && /^https:\/\/github\.com\//i.test(f.browser_download_url || '')) { mu = f.browser_download_url; r = await fetch(mu, { signal: AbortSignal.timeout(15000), headers: hd }); } else throw new Error('the latest release (' + (j.tag_name || '?') + ') has no manifest.json file attached'); }
      }
    }
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const txt = await r.text(); if (txt.length > 65536) throw new Error('manifest too large');
    const a = (JSON.parse(txt) || {}).android;
    try { fs.writeFileSync(path.join(DATA, 'config.json'), JSON.stringify({ ...cfg(), updLast: Date.now() })); } catch {}
    if (!a) { PEND = null; return { ok: true, current: VN, latest: VN, available: false }; } // this release has no Android build yet
    if (!sigOk(a)) return { error: 'The update information is not signed correctly, so it was ignored.' };
    if (a.versionCode <= VC) { PEND = null; return { ok: true, current: VN, latest: a.versionName, available: false }; }
    const url = new URL(String(a.url), mu).href; if (!addrOk(url)) throw new Error('bad download address');
    PEND = { ...a, url };
    return { ok: true, current: VN, latest: a.versionName, available: true, version: a.versionName, notes: a.notes.map(String).slice(0, 12) };
  } catch (e) { return { error: auto ? '' : 'Could not check for updates: ' + (e.message || e) }; }
}
async function start() {
  const m = PEND; if (!m) return { error: 'Check for updates first.' };
  try {
    const out = path.join(process.env.TMPDIR || DATA, 'CactiOS-update.apk');
    const r = await fetch(m.url, { signal: AbortSignal.timeout(600000), headers: { 'User-Agent': 'CactiOS-Updater' } });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const buf = Buffer.from(await r.arrayBuffer());
    if (buf.length !== m.size || crypto.createHash('sha256').update(buf).digest('hex') !== m.sha256) return { error: 'The download did not match its signature, so it was not installed.' };
    fs.writeFileSync(out, buf);
    const st = rj(STATE) || {}; st.pending = { versionCode: m.versionCode, version: m.versionName, notes: m.notes }; fs.writeFileSync(STATE, JSON.stringify(st));
    return { ok: true, apk: out, version: m.versionName, manual: false, msg: 'Downloaded. Confirm the install on screen and Cacti OS will reopen.' };
  } catch (e) { return { error: 'Download failed: ' + (e.message || e) }; }
}
function info() {
  const st = rj(STATE) || {}; st.applied = st.applied || [];
  if (st.pending && VC >= st.pending.versionCode) { st.applied.unshift({ version: st.pending.version, notes: st.pending.notes, when: Date.now() }); st.applied = st.applied.slice(0, 10); delete st.pending; try { fs.writeFileSync(STATE, JSON.stringify(st)); } catch {} }
  return { version: VN, backups: [], applied: st.applied, bkNote: 'Android keeps one version. To go back, install an older Cacti OS APK.' };
}
const iv = setInterval(() => {
  const H = global.__cactiHandlers; if (!H || !H.has('upd:check')) return; clearInterval(iv);
  H.set('upd:info', async () => info());
  H.set('upd:check', async (_e, auto) => check(!!auto));
  H.set('upd:start', async () => start());
  H.set('upd:restore', async () => ({ error: 'Android keeps one version. To go back, install an older Cacti OS APK.' }));
}, 300);
module.exports = { check, start, info, sigOk };
