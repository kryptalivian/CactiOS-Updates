// Standalone emulators for systems RetroArch handles poorly: recipes (data), version checks, install, launch commands and BIOS checks.
// Recipes only describe where an emulator comes from and how to start it. Release files are matched by keywords at install time, so a renamed
// download never breaks anything: Cacti OS just opens the emulator's download page instead.
const fs = require('fs'), path = require('path'), os = require('os');
const { execFile } = require('child_process');

module.exports = function ({ app, shell, send, MAC, WIN, LINUX, PORT }) {
  const OS = MAC ? 'mac' : WIN ? 'win' : 'linux', ARM = process.arch === 'arm64', HOME = os.homedir();
  const ROOT = () => path.join(app.getPath('userData'), 'emulators'), STATE = () => path.join(app.getPath('userData'), 'emulators.json'), CACHE = () => path.join(app.getPath('userData'), 'emulators-latest.json');
  const APPDATA = process.env.APPDATA || path.join(HOME, 'AppData', 'Roaming'), LOCAL = process.env.LOCALAPPDATA || path.join(HOME, 'AppData', 'Local'), PF = process.env.ProgramFiles || 'C:\\Program Files';
  const SUPPORT = path.join(HOME, 'Library', 'Application Support');

  // Systems added by the standalone emulators. `emu` is the recipe that runs them.
  const XSYS = [
    { id: 'ps2', tab: 'PLAYSTATION 2', name: 'PlayStation 2', folder: ['ps2'], ext: ['.iso', '.chd', '.cso', '.bin'], lr: 'Sony - PlayStation 2', emu: 'pcsx2', cores: [], desc: 'The best-selling console ever: huge libraries of action, RPGs and racers on DVD.' },
    { id: 'gamecube', tab: 'GAMECUBE', name: 'Nintendo GameCube', folder: ['gamecube', 'gc'], ext: ['.iso', '.gcm', '.rvz', '.ciso', '.gcz', '.wia'], lr: 'Nintendo - GameCube', emu: 'dolphin', cores: [], desc: 'Compact discs, loud colors and some of Nintendo\'s boldest experiments.' },
    { id: 'wii', tab: 'WII', name: 'Nintendo Wii', folder: ['wii'], ext: ['.iso', '.wbfs', '.rvz', '.ciso', '.gcz', '.wia'], lr: 'Nintendo - Wii', emu: 'dolphin', cores: [], desc: 'Motion-controlled party games and family adventures.' },
    { id: 'psp', tab: 'PSP', name: 'PlayStation Portable', folder: ['psp'], ext: ['.iso', '.cso', '.pbp'], lr: 'Sony - PlayStation Portable', emu: 'ppsspp', rcore: { id: 'ppsspp_libretro', name: 'PPSSPP (RetroArch core)', ra: true }, cores: [], desc: 'Console-sized games in your pocket.' },
    { id: 'dreamcast', tab: 'DREAMCAST', name: 'Sega Dreamcast', folder: ['dreamcast', 'dc'], ext: ['.gdi', '.cdi', '.chd', '.cue'], lr: 'Sega - Dreamcast', emu: 'flycast', rcore: { id: 'flycast_libretro', name: 'Flycast (RetroArch core)', ra: true }, cores: [], desc: 'Sega\'s last console: arcade-sharp action and wild creativity.' },
    { id: 'nds', tab: 'NINTENDO DS', name: 'Nintendo DS', folder: ['nds', 'ds'], ext: ['.nds', '.dsi'], lr: 'Nintendo - Nintendo DS', emu: 'melonds', rcore: { id: 'melonds_libretro', name: 'melonDS (RetroArch core)', ra: true }, cores: [], desc: 'Two screens, a stylus and a mountain of great games.' },
    { id: '3ds', tab: 'NINTENDO 3DS', name: 'Nintendo 3DS', folder: ['3ds'], ext: ['.3ds', '.cci', '.cxi'], lr: 'Nintendo - Nintendo 3DS', emu: 'azahar', cores: [], desc: 'Handheld depth, upgraded classics and new adventures.' },
    { id: 'xbox', tab: 'XBOX', name: 'Microsoft Xbox', folder: ['xbox'], ext: ['.iso', '.xiso'], lr: 'Microsoft - Xbox', emu: 'xemu', cores: [], desc: 'The original Xbox: Halo, Fable and the birth of online console play.' },
    { id: 'xbox360', tab: 'XBOX 360', name: 'Microsoft Xbox 360', folder: ['xbox360', 'x360'], ext: ['.iso', '.xex', '.zar', '.god'], lr: 'Microsoft - Xbox 360', emu: 'xenia', cores: [], desc: 'HD shooters, arcade hits and a generation of online gaming.' },
    { id: 'ps3', tab: 'PLAYSTATION 3', name: 'PlayStation 3', folder: ['ps3'], ext: ['.iso', '.pkg', '.ps3'], lr: 'Sony - PlayStation 3', emu: 'rpcs3', cores: [], desc: 'Cinematic exclusives and the Cell processor era. Game folders (with PS3_GAME) work too.' },
    { id: 'wiiu', tab: 'WII U', name: 'Nintendo Wii U', folder: ['wiiu', 'wii u'], ext: ['.wua', '.wud', '.wux', '.rpx'], lr: 'Nintendo - Wii U', emu: 'cemu', cores: [], desc: 'Nintendo\'s two-screen HD console, home of Mario Kart 8 and Breath of the Wild.' },
    { id: 'switch', tab: 'SWITCH', name: 'Nintendo Switch', folder: ['switch', 'nsw'], ext: ['.nsp', '.xci', '.nsz', '.xcz'], lr: 'Nintendo - Switch', emu: 'eden', cores: [], desc: 'Console power you can take anywhere.' }
  ];
  const XUNIQ = { '.gdi': 'dreamcast', '.cdi': 'dreamcast', '.nds': 'nds', '.dsi': 'nds', '.3ds': '3ds', '.cci': '3ds', '.cxi': '3ds', '.wbfs': 'wii', '.gcm': 'gamecube', '.xiso': 'xbox', '.xex': 'xbox360', '.zar': 'xbox360', '.ps3': 'ps3', '.wua': 'wiiu', '.wud': 'wiiu', '.wux': 'wiiu', '.nsp': 'switch', '.xci': 'switch', '.nsz': 'switch', '.xcz': 'switch' };
  const XALIAS = { ps2: ['ps2', 'playstation2', 'sonyplaystation2'], gamecube: ['gamecube', 'gc', 'ngc'], wii: ['wii'], psp: ['psp', 'playstationportable'], dreamcast: ['dreamcast', 'dc', 'segadreamcast'], nds: ['nds', 'ds', 'nintendods'], '3ds': ['3ds', 'nintendo3ds'], xbox: ['xbox', 'microsoftxbox', 'originalxbox'], xbox360: ['xbox360', 'x360', 'microsoftxbox360'], ps3: ['ps3', 'playstation3', 'sonyplaystation3'], wiiu: ['wiiu', 'nintendowiiu'], switch: ['switch', 'nsw', 'nintendoswitch'] };

  // `exe` finds the program inside an install (Windows). `detect` lists places where a manual install is commonly found.
  const RECIPES = [
    { id: 'pcsx2', fp: 'net.pcsx2.PCSX2', name: 'PCSX2', blurb: 'PlayStation 2', systems: ['ps2'], repo: 'PCSX2/pcsx2', page: 'https://pcsx2.net/downloads', ra: true, heavy: true, color: '#2f6bff', letter: 'PS2',
      exe: { win: /^pcsx2-qt\.exe$/i }, detect: { mac: ['/Applications/PCSX2.app'], win: [path.join(PF, 'PCSX2', 'pcsx2-qt.exe')] }, prefer: /avx2/i,
      args: f => ['-batch', '-fullscreen', '--', f],
      bios: { label: 'PS2 BIOS', optional: false, files: /\.(bin|rom\d?)$/i, dirs: { win: [path.join(HOME, 'Documents', 'PCSX2', 'bios')], mac: [path.join(SUPPORT, 'PCSX2', 'bios')], linux: [path.join(HOME, '.config', 'PCSX2', 'bios')] } } },
    { id: 'dolphin', fp: 'org.DolphinEmu.dolphin-emu', winget: 'DolphinEmulator.Dolphin', cask: 'dolphin', name: 'Dolphin', blurb: 'GameCube and Wii', systems: ['gamecube', 'wii'], repo: null, page: 'https://dolphin-emu.org/download/', ra: true, heavy: true, color: '#2aa7e0', letter: 'DOL',
      detect: { mac: ['/Applications/Dolphin.app'], win: [path.join(PF, 'Dolphin-x64', 'Dolphin.exe'), path.join(PF, 'Dolphin', 'Dolphin.exe'), path.join(LOCAL, 'Programs', 'Dolphin', 'Dolphin.exe'), path.join(LOCAL, 'Dolphin-x64', 'Dolphin.exe')], linux: ['/usr/bin/dolphin-emu', '/usr/bin/dolphin-emu-nogui'] },
      args: f => [...(process.env.RETRO_OS_DOLPHIN_V ? ['-v', process.env.RETRO_OS_DOLPHIN_V] : []), '-b', '-e', f] },
    { id: 'ppsspp', fp: 'org.ppsspp.PPSSPP', name: 'PPSSPP', blurb: 'PlayStation Portable', systems: ['psp'], repo: 'hrydgard/ppsspp', page: 'https://www.ppsspp.org/download', ra: true, color: '#6a5acd', letter: 'PSP',
      exe: { win: /^PPSSPPWindows(64)?\.exe$/i }, detect: { mac: ['/Applications/PPSSPP.app'], win: [path.join(PF, 'PPSSPP', 'PPSSPPWindows64.exe')], linux: ['/usr/bin/ppsspp', '/usr/bin/PPSSPPSDL'] },
      args: f => ['--fullscreen', '--pause-menu-exit', f] },
    { id: 'flycast', fp: 'org.flycast.Flycast', name: 'Flycast', blurb: 'Sega Dreamcast', systems: ['dreamcast'], repo: 'flyinghead/flycast', page: 'https://flyinghead.github.io/flycast-builds/', ra: true, color: '#f08a1c', letter: 'DC',
      exe: { win: /^flycast\.exe$/i }, detect: { mac: ['/Applications/Flycast.app'], win: [path.join(PF, 'Flycast', 'flycast.exe')], linux: ['/usr/bin/flycast'] },
      args: f => [f],
      bios: { label: 'Dreamcast BIOS (dc_boot.bin, dc_flash.bin)', optional: true, files: /^dc_(boot|flash)\.bin$/i, dirs: { win: [path.join(APPDATA, 'flycast', 'data'), path.join(HOME, 'Documents', 'flycast', 'data')], mac: [path.join(SUPPORT, 'Flycast', 'data'), path.join(HOME, '.local', 'share', 'flycast', 'data')], linux: [path.join(HOME, '.local', 'share', 'flycast', 'data')] } } },
    { id: 'melonds', fp: 'net.kuribo64.melonDS', name: 'melonDS', blurb: 'Nintendo DS', systems: ['nds'], repo: 'melonDS-emu/melonDS', page: 'https://melonds.kuribo64.net/downloads.php', ra: true, color: '#d6407a', letter: 'DS',
      exe: { win: /^melonDS\.exe$/i }, detect: { mac: ['/Applications/melonDS.app'], win: [path.join(PF, 'melonDS', 'melonDS.exe')], linux: ['/usr/bin/melonDS'] },
      args: f => [f],
      bios: { label: 'DS BIOS (bios7.bin, bios9.bin, firmware.bin)', optional: true, files: /^(bios7|bios9|firmware)\.bin$/i, dirs: { win: [path.join(APPDATA, 'melonDS')], mac: [path.join(SUPPORT, 'melonDS')], linux: [path.join(HOME, '.config', 'melonDS')] } } },
    { id: 'xemu', fp: 'app.xemu.xemu', name: 'xemu', blurb: 'Original Xbox', systems: ['xbox'], repo: 'xemu-project/xemu', page: 'https://xemu.app/', ra: false, heavy: true, color: '#52b043', letter: 'XB',
      exe: { win: /^xemu\.exe$/i }, detect: { mac: ['/Applications/xemu.app'], win: [path.join(PF, 'xemu', 'xemu.exe')], linux: ['/usr/bin/xemu'] },
      args: f => ['-dvd_path', f],
      bios: { label: 'Xbox BIOS, MCPX boot ROM and hard disk image', optional: false, files: /\.(bin|rom|qcow2)$/i, dirs: { win: [path.join(APPDATA, 'xemu', 'xemu')], mac: [path.join(SUPPORT, 'xemu', 'xemu')], linux: [path.join(HOME, '.local', 'share', 'xemu', 'xemu')] } } },
    { id: 'xenia', name: 'Xenia Canary', blurb: 'Xbox 360 (Windows only)', systems: ['xbox360'], repo: 'xenia-canary/xenia-canary-releases', only: ['win'], page: 'https://github.com/xenia-canary/xenia-canary/releases', ra: false, heavy: true, color: '#3fae49', letter: '360',
      exe: { win: /^xenia_canary\.exe$/i }, detect: { win: [path.join(PF, 'Xenia', 'xenia_canary.exe'), path.join(HOME, 'xenia', 'xenia_canary.exe'), path.join(HOME, 'Documents', 'xenia', 'xenia_canary.exe')] },
      args: f => [f] },
    { id: 'rpcs3', fp: 'net.rpcs3.RPCS3', cask: 'rpcs3', name: 'RPCS3', blurb: 'PlayStation 3', systems: ['ps3'], repo: null, page: 'https://rpcs3.net/download', ra: false, heavy: true, color: '#1f6feb', letter: 'PS3',
      exe: { win: /^rpcs3\.exe$/i }, detect: { mac: ['/Applications/RPCS3.app'], win: [path.join(PF, 'RPCS3', 'rpcs3.exe'), path.join(HOME, 'RPCS3', 'rpcs3.exe')], linux: ['/usr/bin/rpcs3'] },
      args: f => ['--no-gui', f] },
    { id: 'cemu', fp: 'info.cemu.Cemu', name: 'Cemu', blurb: 'Nintendo Wii U', systems: ['wiiu'], repo: 'cemu-project/Cemu', page: 'https://cemu.info/', ra: false, heavy: true, color: '#14a6e5', letter: 'WiiU',
      exe: { win: /^Cemu\.exe$/i }, detect: { mac: ['/Applications/Cemu.app'], win: [path.join(PF, 'Cemu', 'Cemu.exe'), path.join(HOME, 'Cemu', 'Cemu.exe')], linux: ['/usr/bin/cemu'] },
      args: f => ['-g', f, '-f'] },
    { id: 'eden', name: 'Eden', blurb: 'Nintendo Switch', systems: ['switch'], repo: 'eden-emulator/Releases', prefer: /msvc/i, page: 'https://eden-emu.dev/download', ra: false, heavy: true, color: '#e60012', letter: 'NSW',
      exe: { win: /^eden\.exe$/i }, detect: { mac: ['/Applications/Eden.app'], win: [path.join(PF, 'Eden', 'eden.exe'), path.join(LOCAL, 'Programs', 'Eden', 'eden.exe'), path.join(HOME, 'Eden', 'eden.exe')], linux: ['/usr/bin/eden'] },
      args: f => ['-f', '-g', f],
      bios: { label: 'Switch keys (prod.keys)', optional: false, files: /^(prod|title)\.keys$/i, dirs: { win: [path.join(APPDATA, 'eden', 'keys')], mac: [path.join(SUPPORT, 'eden', 'keys')], linux: [path.join(HOME, '.local', 'share', 'eden', 'keys')] } } },
    { id: 'azahar', fp: 'org.azahar_emu.Azahar', name: 'Azahar', blurb: 'Nintendo 3DS', systems: ['3ds'], repo: 'azahar-emu/azahar', page: 'https://azahar-emu.org/pages/download/', ra: false, heavy: true, color: '#e04b4b', letter: '3DS',
      exe: { win: /^azahar(-qt)?\.exe$/i }, detect: { mac: ['/Applications/Azahar.app'], win: [path.join(PF, 'Azahar', 'azahar.exe')] },
      args: f => [f] }
  ];
  const recipe = id => RECIPES.find(r => r.id === id);

  const PT = PORT || { root: null, dec: v => v, enc: v => v };
  const jr = (f, d) => { try { return PT.dec(JSON.parse(fs.readFileSync(f(), 'utf8'))); } catch { return d; } };
  const jw = (f, v) => { try { fs.mkdirSync(path.dirname(f()), { recursive: true }); fs.writeFileSync(f(), JSON.stringify(PT.enc(v))); } catch {} };
  const run = (cmd, args, ms = 300000) => new Promise((res, rej) => execFile(cmd, args, { timeout: ms, maxBuffer: 1 << 24 }, (e, o) => (e ? rej(e) : res(String(o).trim()))));
  // ----- Flatpak (SteamOS and other Linux): one click installs straight from Flathub, no root needed -----
  const hasFp = () => LINUX && ['/usr/bin/flatpak', '/usr/local/bin/flatpak'].some(p => fs.existsSync(p));
  const fpHas = id => [path.join(HOME, '.local/share/flatpak/app', id), path.join('/var/lib/flatpak/app', id)].some(p => fs.existsSync(p));
  const fpWrap = r => { const f = path.join(ROOT(), r.id, 'flatpak-run.sh'); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, `#!/bin/sh\nexec flatpak run ${r.fp} "$@"\n`); fs.chmodSync(f, 0o755); return f; };
  const fpCmd = (args, ms = 1800000) => new Promise((res, rej) => execFile('flatpak', args, { timeout: ms, maxBuffer: 1 << 24 }, (e, o, se) => e ? rej(new Error(String(se || e.message).trim().split('\n').filter(Boolean).pop().slice(0, 160))) : res(String(o))));
  const brewBin = () => ['/opt/homebrew/bin/brew', '/usr/local/bin/brew'].find(p => fs.existsSync(p));
  const canAuto = r => !!(r.repo || (!PT.root && ((LINUX && r.fp && hasFp()) || (WIN && r.winget) || (MAC && r.cask))));
  const busy = new Set(), prog = (id, msg, pct) => { try { send('emu-progress', { id, msg, pct }); } catch {} };

  // ----- latest release (GitHub API, cached 12 hours, ETag so an unchanged answer is free) -----
  async function latest(id, force) {
    const r = recipe(id); if (!r || !r.repo) return null;
    const cache = jr(CACHE, {}), e = cache[id];
    if (e && !force && Date.now() - e.t < 12 * 3600e3) return e;
    try {
      const res = await fetch(`https://api.github.com/repos/${r.repo}/releases/latest`, { headers: { 'User-Agent': 'RetroOS', Accept: 'application/vnd.github+json', ...(e && e.etag ? { 'If-None-Match': e.etag } : {}) }, signal: AbortSignal.timeout(20000) });
      if (res.status === 304 && e) { cache[id] = { ...e, t: Date.now() }; jw(CACHE, cache); return cache[id]; }
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const j = await res.json();
      cache[id] = { t: Date.now(), etag: res.headers.get('etag') || '', tag: String(j.tag_name || j.name || ''), assets: (j.assets || []).map(a => ({ name: a.name, url: a.browser_download_url, size: a.size })) };
      jw(CACHE, cache); return cache[id];
    } catch { return e || null; }
  }
  const BAD = /debug|symbols|\.pdb|source|\bsrc\b|android|\.apk|flatpak|snap|\.msi|setup|installer|\.sig$|\.sha|\.txt$|\.json$|wayland|\.exe$/i;
  function pickAsset(r, assets) {
    const W = { win: { ext: /\.(zip|7z)$/i, os: /win/i }, mac: { ext: /\.(zip|tar\.xz|tar\.gz|tgz|dmg)$/i, os: /mac|osx|darwin/i }, linux: { ext: /\.appimage$/i, os: /linux|appimage|\.appimage$/i } }[OS];
    const armRx = /arm64|aarch64/i, uniRx = /universal/i; let best = null, bs = -1;
    for (const a of assets) {
      const n = a.name; if (!W.ext.test(n) || !W.os.test(n) || (BAD.test(n) && !(OS === 'linux' && /\.appimage$/i.test(n)))) continue;
      const isArm = armRx.test(n), isUni = uniRx.test(n); let s = 1;
      if (OS === 'mac') { if (isUni) s += 3; else if (isArm === ARM) s += 3; else continue; if (/\.zip$/i.test(n)) s += 1; }
      else if (ARM !== isArm) continue; else s += 3;
      if (r.prefer && r.prefer.test(n)) s += 1;
      if (s > bs) { best = a; bs = s; }
    }
    return best;
  }

  // ----- install, extract and locate the program -----
  async function download(url, dest, id, anyHost) {
    if (!anyHost && new URL(url).hostname !== 'github.com') throw new Error('Refusing a download from ' + new URL(url).hostname);
    const res = await fetch(url, { redirect: 'follow', signal: AbortSignal.timeout(900000) }); if (!res.ok) throw new Error('Download failed: HTTP ' + res.status);
    const total = Number(res.headers.get('content-length')) || 0; let got = 0, last = 0; const ws = fs.createWriteStream(dest);
    for await (const chunk of res.body) { if (!ws.write(chunk)) await new Promise(r => ws.once('drain', r)); got += chunk.length; if (Date.now() - last > 400) { last = Date.now(); prog(id, 'Downloading…', total ? Math.round(100 * got / total) : undefined); } }
    await new Promise(r => ws.end(r));
  }
  async function extract(file, dir) {
    fs.mkdirSync(dir, { recursive: true });
    if (/\.appimage$/i.test(file)) { const d = path.join(dir, path.basename(file).replace(/^retroos-[a-z0-9]+-\d+-/i, '')); fs.copyFileSync(file, d); fs.chmodSync(d, 0o755); return; }
    if (/\.dmg$/i.test(file)) {
      const mnt = fs.mkdtempSync(path.join(os.tmpdir(), 'retroos-dmg-'));
      try { await run('/usr/bin/hdiutil', ['attach', '-nobrowse', '-readonly', '-mountpoint', mnt, file], 120000);
        const apps = fs.readdirSync(mnt).filter(x => x.endsWith('.app')); if (!apps.length) throw new Error('No app inside the disk image');
        await run('/usr/bin/ditto', [path.join(mnt, apps[0]), path.join(dir, apps[0])], 300000);
      } finally { try { await run('/usr/bin/hdiutil', ['detach', mnt, '-force'], 60000); } catch {} try { fs.rmdirSync(mnt); } catch {} }
      return;
    }
    if (/\.zip$/i.test(file)) {
      if (MAC) await run('/usr/bin/ditto', ['-x', '-k', file, dir]);
      else if (WIN) await run('tar', ['-xf', file, '-C', dir]);
      else await run('unzip', ['-o', '-q', file, '-d', dir]);
      return;
    }
    try { await run('tar', ['-xf', file, '-C', dir]); } catch (e) { if (/\.7z$/i.test(file)) await run('7z', ['x', '-y', '-o' + dir, file]); else throw e; }
  }
  function walk(dir, depth, test, out = []) {
    let es = []; try { es = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
    for (const e of es) { const p = path.join(dir, e.name); if (test(e, p)) out.push(p); if (e.isDirectory() && depth > 0 && !(MAC && e.name.endsWith('.app'))) walk(p, depth - 1, test, out); }
    return out;
  }
  async function macExe(appPath) {
    try { const n = await run('/usr/bin/plutil', ['-extract', 'CFBundleExecutable', 'raw', '-o', '-', path.join(appPath, 'Contents', 'Info.plist')], 10000); const p = path.join(appPath, 'Contents', 'MacOS', n); if (fs.existsSync(p)) return p; } catch {}
    try { const d = path.join(appPath, 'Contents', 'MacOS'); const f = fs.readdirSync(d)[0]; return f ? path.join(d, f) : null; } catch { return null; }
  }
  async function findExe(r, dir) {
    if (MAC) { const a = walk(dir, 2, e => e.isDirectory() && e.name.endsWith('.app'))[0]; return a ? macExe(a) : null; }
    if (WIN) { const rx = r.exe && r.exe.win, a = walk(dir, 3, e => e.isFile() && rx && rx.test(e.name)); return a.sort((x, y) => x.length - y.length)[0] || null; }
    return walk(dir, 2, e => e.isFile() && /\.appimage$/i.test(e.name))[0] || null;
  }
  async function resolveApp(p) { if (MAC && p.endsWith('.app')) return macExe(p); return fs.existsSync(p) ? p : null; }

  async function install(id) {
    const r = recipe(id); if (!r) return { error: 'Unknown emulator.' };
    if (!r.exe && WIN && !r.winget) return { error: 'Not set up for this system.' };
    if (r.heavy && LINUX && ARM) return { error: 'This emulator is too demanding for this device.' };
    if (busy.has(id)) return { error: 'Already installing.' };
    if (LINUX && r.fp && hasFp()) { // Flatpak route
      busy.add(id);
      try {
        prog(id, 'Connecting to Flathub…'); await fpCmd(['remote-add', '--user', '--if-not-exists', 'flathub', 'https://dl.flathub.org/repo/flathub.flatpakrepo'], 60000).catch(() => {});
        prog(id, 'Installing (a few minutes the first time)…'); await fpCmd(['install', '--user', '-y', '--noninteractive', 'flathub', r.fp]);
        await fpCmd(['override', '--user', '--filesystem=host', '--filesystem=/run/media', r.fp]).catch(() => {}); // let it see your games
        const exe = fpWrap(r), st = jr(STATE, {}); st[id] = { ...(st[id] || {}), exe, flatpak: true, version: '', at: Date.now() }; jw(STATE, st);
        return { ok: true, version: 'Flatpak' };
      } catch (e) { return { error: String(e.message || e).slice(0, 160) }; } finally { busy.delete(id); prog(id, ''); }
    }
    if (WIN && r.winget && !r.repo && !PT.root) { // Windows package manager
      busy.add(id);
      try { prog(id, 'Installing with winget…'); await run('winget', ['install', '-e', '--id', r.winget, '--silent', '--accept-package-agreements', '--accept-source-agreements'], 1800000);
        const have = await exeOf(r); return have ? { ok: true, version: '' } : { error: `${r.name} installed, but Cacti OS could not find it. Open Emulator Library and press Y to point at it.` };
      } catch (e) { return { fallback: true, page: r.page, error: `Could not install ${r.name} automatically. Opening its download page.` }; } finally { busy.delete(id); prog(id, ''); }
    }
    if (MAC && r.cask && !r.repo && !PT.root && brewBin()) { // Homebrew
      busy.add(id);
      try { prog(id, 'Installing with Homebrew…'); await run(brewBin(), ['install', '--cask', r.cask], 1800000); const have = await exeOf(r); return have ? { ok: true, version: '' } : { error: `${r.name} installed, but Cacti OS could not find it.` };
      } catch (e) { return { fallback: true, page: r.page, error: `Could not install ${r.name} automatically. Opening its download page.` }; } finally { busy.delete(id); prog(id, ''); }
    }
    if (MAC && r.cask && !r.repo) { // no Homebrew: take the same download Homebrew would, from its public cask listing, and install it ourselves
      busy.add(id); prog(id, 'Finding the latest version…'); let tmp = '';
      try {
        const j = await (await fetch('https://formulae.brew.sh/api/cask/' + r.cask + '.json', { signal: AbortSignal.timeout(30000) })).json();
        if (!j || !/^https:\/\//.test(j.url || '')) throw new Error('no download');
        tmp = path.join(os.tmpdir(), 'retroos-' + id + '-' + Date.now() + (/\.zip(\?|$)/i.test(j.url) ? '.zip' : '.dmg'));
        await download(j.url, tmp, id, true);
        if (j.sha256 && j.sha256 !== 'no_check' && require('crypto').createHash('sha256').update(fs.readFileSync(tmp)).digest('hex') !== j.sha256) throw new Error('The download did not match its checksum.');
        prog(id, 'Installing…');
        const dir = path.join(ROOT(), id, String(j.version || 'latest').replace(/[^\w.\-]/g, '_'));
        fs.rmSync(dir, { recursive: true, force: true }); await extract(tmp, dir);
        const exe = await findExe(r, dir); if (!exe) throw new Error('The program was not found inside the download.');
        try { await run('/usr/bin/xattr', ['-cr', dir], 60000); } catch {}
        try { fs.chmodSync(exe, 0o755); } catch {}
        portableMark(id, exe);
        const st = jr(STATE, {}); const old = st[id] && st[id].dir; st[id] = { ...(st[id] || {}), version: String(j.version || ''), dir, exe, at: Date.now() }; jw(STATE, st);
        if (old && old !== dir && old.startsWith(ROOT())) fs.rmSync(old, { recursive: true, force: true });
        return { ok: true, version: String(j.version || '') };
      } catch (e) { return { fallback: true, page: r.page, error: `Could not install ${r.name} automatically (${String(e.message || e).slice(0, 80)}). Opening its download page.` }; }
      finally { busy.delete(id); try { if (tmp) fs.rmSync(tmp, { force: true }); } catch {} prog(id, ''); }
    }
    if (!r.repo) return { fallback: true, page: r.page, error: `${r.name} has no automatic download here. Opening its download page.` };
    busy.add(id); prog(id, 'Checking the latest release…');
    let tmp = '';
    try {
      const lat = await latest(id, true), a = lat && lat.assets ? pickAsset(r, lat.assets) : null;
      if (a) tmp = path.join(os.tmpdir(), 'retroos-' + id + '-' + Date.now() + '-' + a.name.replace(/[^\w.\-]/g, '_'));
      if (!a) return { fallback: true, page: r.page, error: `No matching download was found for this computer. Opening the ${r.name} download page.` };
      await download(a.url, tmp, id); prog(id, 'Installing…');
      const dir = path.join(ROOT(), id, (lat.tag || 'latest').replace(/[^\w.\-]/g, '_'));
      fs.rmSync(dir, { recursive: true, force: true }); await extract(tmp, dir);
      const exe = await findExe(r, dir); if (!exe) throw new Error('Installed, but the program was not found inside the download.');
      if (MAC) { try { await run('/usr/bin/xattr', ['-cr', dir], 60000); } catch {} }
      if (!WIN) { try { fs.chmodSync(exe, 0o755); } catch {} }
      portableMark(id, exe);
      const st = jr(STATE, {}); const old = st[id] && st[id].dir; st[id] = { ...(st[id] || {}), version: lat.tag, dir, exe, at: Date.now(), asset: a.name }; jw(STATE, st);
      if (old && old !== dir && old.startsWith(ROOT())) fs.rmSync(old, { recursive: true, force: true });
      return { ok: true, version: lat.tag };
    } catch (e) { return { error: String(e.message || e).slice(0, 160) }; }
    finally { busy.delete(id); try { if (tmp) fs.rmSync(tmp, { force: true }); } catch {} prog(id, ''); }
  }
  // In portable mode, tell each emulator to keep its own settings beside its program instead of in the PC's profile.
  function portableMark(id, exe) {
    if (!PT.root) return; const d = path.dirname(exe), mk = (f, txt = '') => { try { fs.mkdirSync(path.dirname(path.join(d, f)), { recursive: true }); if (!fs.existsSync(path.join(d, f)) || !txt) fs.writeFileSync(path.join(d, f), txt); } catch {} };
    if (id === 'pcsx2') mk('portable.ini'); else if (id === 'dolphin') mk('portable.txt'); else if (id === 'xenia') mk('portable.txt');
    else if (id === 'cemu') mk('portable/.keep'); else if (id === 'eden' || id === 'azahar') mk('user/.keep');
    else if (id === 'flycast') mk('data/.keep'); else if (id === 'ppsspp') mk('memstick/.keep'); else if (id === 'melonds') mk('melonDS.ini');
  }
  // Point Cacti OS at an emulator the user installed by hand (the browser fallback).
  async function setPath(id, p) {
    const r = recipe(id); if (!r || !p || !fs.existsSync(p)) return { error: 'That file was not found.' };
    const exe = await resolveApp(String(p)); if (!exe) return { error: 'Could not find the program inside that.' };
    const st = jr(STATE, {}); st[id] = { ...(st[id] || {}), custom: exe, at: Date.now() }; jw(STATE, st); return { ok: true };
  }
  async function exeOf(r) {
    const st = jr(STATE, {})[r.id] || {};
    if (st.exe && fs.existsSync(st.exe)) return { exe: st.exe, via: st.flatpak ? 'flatpak' : 'retroos', version: st.version || '' };
    if (st.custom && fs.existsSync(st.custom)) return { exe: st.custom, via: 'custom', version: '' };
    if (LINUX && r.fp && hasFp() && fpHas(r.fp)) { try { return { exe: fpWrap(r), via: 'flatpak', version: '' }; } catch {} }
    for (const p of (r.detect && r.detect[OS]) || []) if (fs.existsSync(p)) { const x = await resolveApp(p); if (x) return { exe: x, via: 'found', version: '' }; }
    if (MAC) { // a manual install can have any capitalisation or a version in its name, and may sit in ~/Applications, a subfolder or Downloads
      const key = x => String(x).toLowerCase().replace(/[^a-z0-9]/g, ''), want = key(r.id), dirs = ['/Applications', path.join(HOME, 'Applications'), path.join(HOME, 'Downloads'), path.join(HOME, 'Desktop')];
      for (const d of dirs) {
        let es = []; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch { continue; }
        for (const e of es) {
          if (e.name.endsWith('.app') && key(e.name.slice(0, -4)).startsWith(want)) { const x = await macExe(path.join(d, e.name)); if (x) return { exe: x, via: 'found', version: '' }; }
          if (e.isDirectory() && !e.name.endsWith('.app') && d !== path.join(HOME, 'Downloads') && d !== path.join(HOME, 'Desktop')) { let sub = []; try { sub = fs.readdirSync(path.join(d, e.name)); } catch {} for (const f of sub) if (f.endsWith('.app') && key(f.slice(0, -4)).startsWith(want)) { const x = await macExe(path.join(d, e.name, f)); if (x) return { exe: x, via: 'found', version: '' }; } }
        }
      }
    }
    return null;
  }

  // ----- list for the Emulator Library screen -----
  async function list() {
    const cache = jr(CACHE, {}), out = [];
    for (const r of RECIPES) {
      const base = { id: r.id, name: r.name, blurb: r.blurb, systems: r.systems.map(s => (XSYS.find(x => x.id === s) || {}).name), color: r.color, letter: r.letter, ra: r.ra, canAuto: canAuto(r), busy: busy.has(r.id) };
      if (r.only && !r.only.includes(OS)) { out.push({ ...base, status: 'unsupported', label: 'Windows only' }); continue; }
      if (r.heavy && LINUX && ARM) { out.push({ ...base, status: 'unsupported', label: 'Not supported on this device' }); continue; }
      const have = await exeOf(r), lat = cache[r.id];
      if (!have) { out.push({ ...base, status: 'none', label: 'Not installed', latest: lat ? lat.tag : '' }); continue; }
      if (have.via !== 'retroos') { out.push({ ...base, status: 'installed', label: have.via === 'custom' ? 'Installed (your copy)' : have.via === 'flatpak' ? 'Installed (Flatpak)' : 'Installed (found on this computer)' }); continue; }
      const up = lat && lat.tag && have.version && lat.tag !== have.version;
      out.push({ ...base, status: up ? 'update' : 'uptodate', label: up ? 'Update available' : 'Up to date', version: have.version, latest: lat ? lat.tag : '' });
    }
    return out;
  }
  async function refresh(force) { for (const r of RECIPES) if (r.repo && !(r.heavy && LINUX && ARM)) { await latest(r.id, !!force); } return list(); }
  const openPage = id => { const r = recipe(id); if (r) shell.openExternal(r.page); return !!r; };

  // ----- launch + BIOS -----
  async function launchInfo(emuId, file) {
    const r = recipe(emuId); if (!r) return { error: 'Unknown emulator.' };
    const have = await exeOf(r); if (!have) return { error: `${r.name} is not installed. Open Menu > Emulator Library.` };
    let args = r.args(file);
    return { exe: have.exe, args, cwd: path.dirname(have.exe), name: r.name };
  }
  function biosStatus() {
    return RECIPES.filter(r => r.bios).map(r => { const dirs = r.bios.dirs[OS] || []; let found = 0, dir = dirs[0] || '';
      for (const d of dirs) { try { const n = fs.readdirSync(d).filter(f => r.bios.files.test(f)).length; if (n > found) { found = n; dir = d; } } catch {} }
      return { id: r.id, name: r.name, label: r.bios.label, optional: r.bios.optional, ok: found > 0, found, dir }; });
  }
  function openBios(id) { const r = recipe(id), d = r && r.bios && (r.bios.dirs[OS] || [])[0]; if (!d) return false; try { fs.mkdirSync(d, { recursive: true }); } catch {} shell.openPath(d); return true; }

  return { RECIPES, XSYS, XUNIQ, XALIAS, list, refresh, install, setPath, launchInfo, biosStatus, openBios, openPage, pickAsset, extract, findExe };
};
