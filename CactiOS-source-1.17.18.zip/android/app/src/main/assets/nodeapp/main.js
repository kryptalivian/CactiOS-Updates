process.env.UV_THREADPOOL_SIZE = process.env.UV_THREADPOOL_SIZE || '16'; // joystick devices on Linux block a worker each
const { app, BrowserWindow, ipcMain, dialog, Menu, safeStorage, shell, screen, globalShortcut, clipboard } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os');
const { spawn, execFile, execFileSync } = require('child_process');
const { pathToFileURL, fileURLToPath } = require('url');
const crypto = require('crypto');
const zlib = require('zlib');
// a short in-memory log of what the app did, shown on the web admin page (never written to disk, never sent anywhere)
const LOGBUF = []; const logEv = m => { LOGBUF.push(new Date().toISOString().replace('T', ' ').slice(0, 19) + '  ' + String(m).slice(0, 400)); if (LOGBUF.length > 400) LOGBUF.shift(); };
for (const k of ['log', 'warn', 'error']) { const o = console[k].bind(console); console[k] = (...a) => { try { logEv(k + ' ' + a.map(x => typeof x === 'string' ? x : (x && x.stack) || JSON.stringify(x)).join(' ')); } catch {} o(...a); }; }

// startup diagnostics: a small startup.log in the data folder says why the app closed (written only to the local disk)
// Rebrand: carry settings over from the old "Retro OS" data folder
try { const ad = app.getPath('appData'), o = path.join(ad, 'Retro OS'), n = path.join(ad, 'Cacti OS'); if (fs.existsSync(o) && !fs.existsSync(n)) fs.renameSync(o, n); } catch {}
const SLOG = (() => { try { return path.join(app.getPath('userData'), 'startup.log'); } catch { return ''; } })();
const slog = m => { try { if (SLOG) fs.appendFileSync(SLOG, new Date().toISOString() + '  ' + String(m).slice(0, 600) + '\n'); } catch {} };
try { if (SLOG && fs.existsSync(SLOG) && fs.statSync(SLOG).size > 200000) fs.writeFileSync(SLOG, ''); } catch {}
slog('start v' + (() => { try { return app.getVersion(); } catch { return '?'; } })() + ' ' + process.platform + '/' + process.arch + ' argv=' + process.argv.slice(1).join(' '));
process.on('uncaughtException', e => { slog('uncaughtException ' + ((e && e.stack) || e)); });
process.on('unhandledRejection', e => { slog('unhandledRejection ' + ((e && e.stack) || e)); });
app.on('before-quit', () => slog('before-quit'));
app.on('will-quit', () => slog('will-quit'));
app.on('render-process-gone', (_e, wc, d) => slog('render-process-gone ' + JSON.stringify(d)));
app.on('child-process-gone', (_e, d) => slog('child-process-gone ' + JSON.stringify(d)));
// ---------- portable drive mode: a portable.flag file in the folder above the program keeps everything inside that folder ----------
const PORT = (() => {
const TOKEN = '{CACTI}';
let proot = null;
try {
  const env = process.env.CACTI_PORTABLE;
  if (env && fs.existsSync(env)) proot = path.resolve(env);
  else { const exe = process.execPath, r = path.resolve(path.dirname(exe), '..'); if (!/^(electron|node)(\.exe)?$/i.test(path.basename(exe)) && fs.existsSync(path.join(r, 'portable.flag'))) proot = r; }
} catch {}
const norm = p => String(p).replace(/\//g, path.sep).toLowerCase();
const dec1 = s => (typeof s === 'string' && proot && s.startsWith(TOKEN)) ? path.join(proot, s.slice(TOKEN.length).replace(/^[\\/]+/, '')) : s;
const enc1 = s => {
  if (typeof s !== 'string' || !proot || s.length < proot.length) return s;
  const n = norm(s), r = norm(proot);
  if (n === r) return TOKEN;
  if (n.startsWith(r + path.sep)) return TOKEN + path.sep + s.slice(proot.length + 1);
  return s;
};
const walk = (v, f) => Array.isArray(v) ? v.map(x => walk(x, f)) : (v && typeof v === 'object') ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, walk(x, f)])) : f(v);

  return { root: proot, TOKEN, dec: v => proot ? walk(v, dec1) : v, enc: v => proot ? walk(v, enc1) : v };
})();
if (PORT.root) { const d = path.join(PORT.root, 'data'); try { fs.mkdirSync(path.join(d, 'tmp'), { recursive: true }); } catch {} app.setPath('userData', d); try { app.setPath('sessionData', path.join(d, 'session')); app.setPath('logs', path.join(d, 'logs')); app.setPath('crashDumps', path.join(d, 'crashes')); } catch {} process.env.TEMP = process.env.TMP = process.env.TMPDIR = path.join(d, 'tmp'); }
const MAC = process.platform === 'darwin', LINUX = process.platform === 'linux', HOME = os.homedir(), WIN = process.platform === 'win32', EXT = MAC ? '.dylib' : LINUX ? '.so' : '.dll';

// ---------- config: <userData>/config.json (secrets are encrypted with the OS keychain) ----------
const FPRA = 'org.libretro.RetroArch', RAWRAP = path.join(HOME, '.local/share/cacti-os/retroarch-flatpak');
function writeWrap(file, id) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, `#!/bin/sh\nexec flatpak run --filesystem=host --filesystem=/run/media ${id} "$@"\n`); fs.chmodSync(file, 0o755); }
const CFG = () => path.join(app.getPath('userData'), 'config.json');
const RA_CANDS = MAC ? ['/Applications/RetroArch.app/Contents/MacOS/RetroArch', path.join(HOME, 'Applications/RetroArch.app/Contents/MacOS/RetroArch')] : LINUX ? ['/usr/bin/retroarch', '/usr/games/retroarch', '/usr/local/bin/retroarch', path.join(HOME, '.local/share/cacti-os/retroarch-flatpak')] : [...(PORT.root ? [path.join(PORT.root, 'data', 'RetroArch', 'retroarch.exe'), path.join(PORT.root, 'data', 'RetroArch', 'RetroArch-Win64', 'retroarch.exe')] : []), 'C:\\RetroArch-Win64\\retroarch.exe', 'C:\\RetroArch\\retroarch.exe', path.join(process.env.LOCALAPPDATA || HOME, 'RetroArch', 'retroarch.exe'), path.join(process.env.ProgramFiles || 'C:\\Program Files', 'RetroArch', 'retroarch.exe'), path.join(HOME, 'RetroArch-Win64', 'retroarch.exe')];
const DEF = () => ({ shareMeta: true, shareSaves: false, profile: '', profAsk: true, visual: 'off', visFx: true, raUser: '', raKey: '', raPass: '', hardcore: false, tgdbKey: '', igdbId: '', igdbSecret: '', ssUser: '', ssPass: '', ssDevId: '', ssDevPass: '', syncDir: '', syncPeer: '', syncCode: '', syncAuto: false, syncLast: 0, updatePopups: true, szPreset: 'auto', szHeader: '100', szTile: '100', szText: '100', szPrompt: '100', dedupe: true, gameInt: false, gameAspect: 'core', gameSmooth: false, updateUrl: '', updMode: 'manual', updLast: 0, splash: true, cores: {}, romRoot: fs.existsSync(path.join(HOME, 'ROMs')) ? path.join(HOME, 'ROMs') : fs.existsSync(path.join(HOME, 'Emulation/roms')) ? path.join(HOME, 'Emulation/roms') : '', retroarch: RA_CANDS.find(p => fs.existsSync(p)) || RA_CANDS[0], fullscreen: LINUX, dark: false, theme: 'classic', skins: true, achStyle: 'pill', achSize: '2', achSound: true, navSounds: true, showFav: true, showLast: true, showAll: false, avatar: '', quitCombo: '2', musicDir: '', musicVol: '70', musicShuffle: false, musicAuto: false, trophy: true, lvIntro: false, upload: LINUX, uploadCode: '', padMap: {}, scrapeEngines: {}, scrapeFirst: 'libretro', prompts: 'Xbox', raOnly: false, raGames: false, autoLoad: false, autoSave: false, saveDir: '', backupAuto: true, backupKeep: '10', backupDir: '', declutter: false, layout: 'classic', discord: false, setupDone: false });
const KEYS = ['emuScale', 'emuRA', 'shareMeta', 'shareSaves', 'profile', 'profAsk', 'dedupe', 'visual', 'visFx', 'syncDir', 'syncPeer', 'syncCode', 'syncAuto', 'syncLast', 'tgdbKey', 'igdbId', 'igdbSecret', 'ssUser', 'ssPass', 'szPreset', 'szHeader', 'szTile', 'szText', 'szPrompt', 'gameInt', 'gameAspect', 'gameSmooth', 'updatePopups', 'updateUrl', 'updMode', 'updLast', 'raUser', 'romRoot', 'retroarch', 'fullscreen', 'dark', 'theme', 'skins', 'achStyle', 'achSize', 'achSound', 'navSounds', 'showFav', 'showLast', 'showAll', 'trophy', 'upload', 'prompts', 'scrapeFirst', 'raOnly', 'raGames', 'autoLoad', 'autoSave', 'saveDir', 'backupAuto', 'backupKeep', 'backupDir', 'declutter', 'layout', 'dashTiles', 'updatePopups', 'splash', 'discord', 'setupDone', 'hardcore', 'avatar', 'quitCombo', 'musicDir', 'musicVol', 'musicShuffle', 'musicAuto'];
const SECRETS = ['syncCode', 'raKey', 'raPass', 'raToken', 'tgdbKey', 'igdbSecret', 'ssPass', 'ssDevPass'], MASKED = ['syncCode', 'tgdbKey', 'igdbSecret', 'ssPass', 'ssDevPass'];
function load() {
  let c = DEF();
  try { c = { ...c, ...PORT.dec(JSON.parse(fs.readFileSync(CFG(), 'utf8'))) }; } catch {}
  if (PORT.root && (!c.romRoot || !fs.existsSync(c.romRoot))) c.romRoot = path.join(PORT.root, 'roms');
  for (const k of SECRETS) { if (c[k + 'Enc']) { try { c[k] = safeStorage.decryptString(Buffer.from(c[k + 'Enc'], 'base64')); } catch { c[k] = ''; c['_nd_' + k] = 1; } } else if (c[k + 'Plain']) { try { c[k] = Buffer.from(c[k + 'Plain'], 'base64').toString('utf8'); } catch { c[k] = ''; } } }
  c.updateUrl = UPD_DEFAULT; // everyone checks the official Cacti OS update list; the address can no longer be changed
  if (!c.lvIntro) { c.trophy = true; c.lvIntro = true; } // Cacti Level: show the achievement icon once for everyone, after that their own choice stands
  if (LINUX && !RA_CANDS.slice(0, 3).some(p => fs.existsSync(p)) && fs.existsSync(path.join(HOME, '.var/app', FPRA))) { try { writeWrap(RAWRAP, FPRA); } catch {} } // RetroArch installed through Flatpak (SteamOS, EmuDeck)
  if (!fs.existsSync(c.retroarch)) { const f = RA_CANDS.find(p => fs.existsSync(p)); if (f) c.retroarch = f; }
  return c;
}
function save(c) {
  const o = { ...c };
  for (const k of SECRETS) { // no system keyring on the Pi kiosk: keep the value in the settings file (readable only by this user) so it is not lost
    let enc = false;
    if (o[k]) { try { if (!PORT.root && safeStorage.isEncryptionAvailable()) { o[k + 'Enc'] = safeStorage.encryptString(o[k]).toString('base64'); delete o[k + 'Plain']; enc = true; } } catch {} if (!enc) { o[k + 'Plain'] = Buffer.from(o[k], 'utf8').toString('base64'); delete o[k + 'Enc']; } }
    else if (!o['_nd_' + k]) { delete o[k + 'Enc']; delete o[k + 'Plain']; }
    delete o[k]; delete o['_nd_' + k];
  }
  fs.mkdirSync(path.dirname(CFG()), { recursive: true });
  fs.writeFileSync(CFG(), JSON.stringify(PORT.enc(o), null, 2), { mode: 0o600 }); try { fs.chmodSync(CFG(), 0o600); } catch {}
}
const UPD_DEFAULT = 'https://github.com/kryptalivian/CactiOS-Updates/releases/latest/download/manifest.json';
const LAYOUTS = ['classic', 'compact', 'flow', 'side', 'spot', 'wall', 'rails', 'cols', 'detail', 'covers', 'timeline', 'dash', 'custom'];
const pub = c => ({ ...Object.fromEntries(KEYS.map(k => [k, MASKED.includes(k) && c[k] ? '••••••' : c[k]])), padMap: c.padMap || {}, scrapeEngines: c.scrapeEngines || {}, trophy: c.trophy === true || c.trophy === 'true', declutter: c.declutter === true || c.declutter === 'true', discord: c.discord === true || c.discord === 'true', setupDone: c.setupDone === true || c.setupDone === 'true', layout: LAYOUTS.includes(c.layout) ? c.layout : 'classic', cores: c.cores || {}, linux: LINUX, hasKey: !!c.raKey, hasPass: !!c.raPass, hasToken: !!c.raToken, mac: MAC });
const coresDir = c => MAC ? path.join(HOME, 'Library/Application Support/RetroArch/cores') : LINUX ? (String(c.retroarch).endsWith('retroarch-flatpak') ? path.join(HOME, '.var/app', FPRA, 'config/retroarch/cores') : path.join(HOME, '.config/retroarch/cores')) : path.join(path.dirname(c.retroarch), 'cores');
// Cores can live in more than one place. The Flatpak RetroArch (SteamOS, EmuDeck) ships many of them inside the app itself, and Linux distro packages put them in /usr/lib/libretro. RetroArch counts those as installed, so Cacti OS has to look there too.
const coreDirs = c => { const d = [coresDir(c)]; if (LINUX) d.push(path.join(HOME, '.local/share/flatpak/app', FPRA, 'current/active/files/lib/libretro'), '/var/lib/flatpak/app/' + FPRA + '/current/active/files/lib/libretro', '/usr/lib/libretro', '/usr/lib64/libretro', '/usr/lib/x86_64-linux-gnu/libretro', '/usr/lib/aarch64-linux-gnu/libretro', '/usr/local/lib/libretro'); return d; };
const coreFile = (c, id) => { for (const d of coreDirs(c)) { const f = path.join(d, id + EXT); try { if (fs.existsSync(f)) return f; } catch {} } return null; };
const sh = (cmd, args, t = 5000) => new Promise(r => execFile(cmd, args, { timeout: t }, (e, o) => r(e ? '' : String(o))));
const ST = () => path.join(app.getPath('userData'), 'stats.json');
const getStats = () => { try { return JSON.parse(fs.readFileSync(ST(), 'utf8')); } catch { return {}; } };
const LOG = () => path.join(app.getPath('userData'), 'retroarch.log');

// ---------- systems and emulators ----------
// ra:true = the core is on RetroAchievements' supported-emulator list. Defaults are only ever chosen from ra:true cores.
const SYSTEMS = [
  { id: 'gba', tab: 'GAME BOY ADVANCE', name: 'Game Boy Advance', folder: ['gba'], ext: ['.gba', '.zip', '.7z'], lr: 'Nintendo - Game Boy Advance', cores: [{ id: 'mgba_libretro', name: 'mGBA', ra: true }], desc: 'Handheld powerhouses with deep RPGs, sharp action and console-quality adventures.' },
  { id: 'gbc', tab: 'GAME BOY COLOR', name: 'Game Boy Color', folder: ['gbc'], ext: ['.gbc', '.zip', '.7z'], lr: 'Nintendo - Game Boy Color', cores: [{ id: 'gambatte_libretro', name: 'Gambatte', ra: true }, { id: 'mgba_libretro', name: 'mGBA', ra: true }], desc: 'Colorful pocket classics with huge adventures in a tiny cartridge.' },
  { id: 'gb', tab: 'GAME BOY', name: 'Game Boy', folder: ['gb'], ext: ['.gb', '.zip', '.7z'], lr: 'Nintendo - Game Boy', cores: [{ id: 'gambatte_libretro', name: 'Gambatte', ra: true }, { id: 'mgba_libretro', name: 'mGBA', ra: true }], desc: 'Where portable gaming began: four shades of green and endless replay value.' },
  { id: 'nes', tab: 'NES', name: 'Nintendo Entertainment System', folder: ['nes'], ext: ['.nes', '.zip', '.7z'], lr: 'Nintendo - Nintendo Entertainment System', cores: [{ id: 'fceumm_libretro', name: 'FCEUmm', ra: true }, { id: 'nestopia_libretro', name: 'Nestopia UE', ra: true }, { id: 'mesen_libretro', name: 'Mesen', ra: false }], desc: '8-bit icons that started it all: tight platforming, bold adventures and a legendary library.' },
  { id: 'snes', tab: 'SUPER NINTENDO', name: 'Super Nintendo', folder: ['snes'], ext: ['.sfc', '.smc', '.zip', '.7z'], lr: 'Nintendo - Super Nintendo Entertainment System', cores: [{ id: 'snes9x_libretro', name: 'Snes9x', ra: true }, { id: 'bsnes_libretro', name: 'bsnes', ra: true }], desc: '16-bit classics with unforgettable worlds, timeless gameplay and a legendary library of adventures, RPGs and action games.' },
  { id: 'genesis', tab: 'GENESIS', name: 'Sega Genesis', folder: ['megadrive', 'genesis'], ext: ['.md', '.gen', '.smd', '.bin', '.zip', '.7z'], lr: 'Sega - Mega Drive - Genesis', cores: [{ id: 'genesis_plus_gx_libretro', name: 'Genesis Plus GX', ra: true }, { id: 'picodrive_libretro', name: 'PicoDrive', ra: true }], desc: 'Fast, loud and stylish: arcade action and attitude from the 16-bit rival.' },
  { id: 'mastersystem', tab: 'MASTER SYSTEM', name: 'Sega Master System', folder: ['mastersystem'], ext: ['.sms', '.zip', '.7z'], lr: 'Sega - Master System - Mark III', cores: [{ id: 'genesis_plus_gx_libretro', name: 'Genesis Plus GX', ra: true }], desc: 'Sega\'s 8-bit challenger with arcade ports and one-of-a-kind classics.' },
  { id: 'psx', tab: 'PLAYSTATION', name: 'PlayStation', folder: ['psx'], ext: ['.cue', '.chd', '.pbp', '.m3u'], lr: 'Sony - PlayStation', cores: [{ id: 'pcsx_rearmed_libretro', name: 'PCSX ReARMed', ra: true }, { id: 'swanstation_libretro', name: 'SwanStation', ra: true }], desc: 'The 3D leap: cinematic epics, racing and genre-defining adventures on disc.' },
  { id: 'n64', tab: 'NINTENDO 64', name: 'Nintendo 64', folder: ['n64'], ext: ['.n64', '.z64', '.v64', '.zip', '.7z'], lr: 'Nintendo - Nintendo 64', cores: [{ id: 'mupen64plus_next_libretro', name: 'Mupen64Plus-Next', ra: true }, { id: 'parallel_n64_libretro', name: 'ParaLLEl N64', ra: true }], desc: 'The jump to 3D: sprawling worlds, four-player showdowns and a controller with a stick that changed gaming.' },
  { id: 'pcengine', tab: 'PC ENGINE', name: 'PC Engine / TurboGrafx-16', folder: ['pcengine', 'tg16', 'pce'], ext: ['.pce', '.sgx', '.zip', '.7z'], lr: 'NEC - PC Engine - TurboGrafx 16', cores: [{ id: 'mednafen_pce_fast_libretro', name: 'Beetle PCE Fast', ra: true }, { id: 'mednafen_supergrafx_libretro', name: 'Beetle SuperGrafx', ra: true }], desc: 'Tiny cards, big shooters: an arcade-minded console with a devoted following.' },
  { id: 'pcenginecd', tab: 'PC ENGINE CD', name: 'PC Engine CD / TurboGrafx-CD', folder: ['pcenginecd', 'pcecd', 'tg16cd', 'turbografxcd'], ext: ['.chd', '.cue', '.ccd'], lr: 'NEC - PC Engine CD - TurboGrafx-CD', cores: [{ id: 'mednafen_pce_fast_libretro', name: 'Beetle PCE Fast', ra: true }, { id: 'mednafen_pce_libretro', name: 'Beetle PCE', ra: true }, { id: 'mednafen_supergrafx_libretro', name: 'Beetle SuperGrafx', ra: true }], desc: 'CD-ROM shooters, RPGs and anime cut-scenes for the PC Engine. Needs the Super System Card BIOS (syscard3.pce).' },
  { id: 'gamegear', tab: 'GAME GEAR', name: 'Sega Game Gear', folder: ['gamegear'], ext: ['.gg', '.zip', '.7z'], lr: 'Sega - Game Gear', cores: [{ id: 'genesis_plus_gx_libretro', name: 'Genesis Plus GX', ra: true }, { id: 'gearsystem_libretro', name: 'Gearsystem', ra: true }], desc: 'Sega\'s full-color handheld, with arcade-style ports in your pocket.' },
  { id: 'segacd', tab: 'SEGA CD', name: 'Sega CD', folder: ['segacd', 'megacd'], ext: ['.cue', '.chd', '.iso'], lr: 'Sega - Mega-CD - Sega CD', cores: [{ id: 'genesis_plus_gx_libretro', name: 'Genesis Plus GX', ra: true }, { id: 'picodrive_libretro', name: 'PicoDrive', ra: true }], desc: 'Full-motion video and CD soundtracks bolted onto the Genesis. Needs the Sega CD BIOS.' },
  { id: 'sega32x', tab: 'SEGA 32X', name: 'Sega 32X', folder: ['sega32x', '32x'], ext: ['.32x', '.zip', '.7z'], lr: 'Sega - 32X', cores: [{ id: 'picodrive_libretro', name: 'PicoDrive', ra: true }], desc: 'The add-on that pushed the Genesis into 32-bit territory.' },
  { id: 'saturn', tab: 'SATURN', name: 'Sega Saturn', folder: ['saturn'], ext: ['.cue', '.chd', '.m3u'], lr: 'Sega - Saturn', cores: [{ id: 'mednafen_saturn_libretro', name: 'Beetle Saturn', ra: true }, { id: 'yabause_libretro', name: 'Yabause', ra: false }], desc: 'Sega\'s dual-CPU disc console, home to arcade ports and cult RPGs. Needs the Saturn BIOS.' },
  { id: 'atari2600', tab: 'ATARI 2600', name: 'Atari 2600', folder: ['atari2600'], ext: ['.a26', '.zip', '.7z'], lr: 'Atari - 2600', cores: [{ id: 'stella_libretro', name: 'Stella', ra: true }, { id: 'stella2014_libretro', name: 'Stella 2014', ra: true }], desc: 'Where home gaming took off: blocky, brilliant and endlessly replayable.' },
  { id: 'atari7800', tab: 'ATARI 7800', name: 'Atari 7800', folder: ['atari7800'], ext: ['.a78', '.zip', '.7z'], lr: 'Atari - 7800', cores: [{ id: 'prosystem_libretro', name: 'ProSystem', ra: true }], desc: 'Atari\'s late-80s arcade-port machine, backward compatible with the 2600.' },
  { id: 'lynx', tab: 'ATARI LYNX', name: 'Atari Lynx', folder: ['atarilynx', 'lynx'], ext: ['.lnx', '.zip', '.7z'], lr: 'Atari - Lynx', cores: [{ id: 'handy_libretro', name: 'Handy', ra: true }, { id: 'mednafen_lynx_libretro', name: 'Beetle Lynx', ra: true }], desc: 'The first color handheld, with a backlit screen and big ideas.' },
  { id: 'jaguar', tab: 'ATARI JAGUAR', name: 'Atari Jaguar', folder: ['atarijaguar', 'jaguar'], ext: ['.j64', '.jag', '.zip', '.7z'], lr: 'Atari - Jaguar', cores: [{ id: 'virtualjaguar_libretro', name: 'Virtual Jaguar', ra: true }], desc: '64-bit marketing and rough edges: a cult favorite.' },
  { id: 'ngp', tab: 'NEO GEO POCKET', name: 'Neo Geo Pocket', folder: ['ngp', 'ngpc', 'neogeopocket'], ext: ['.ngp', '.ngc', '.zip', '.7z'], lr: 'SNK - Neo Geo Pocket Color', cores: [{ id: 'mednafen_ngp_libretro', name: 'Beetle NeoPop', ra: true }], desc: 'SNK\'s crisp handheld fighters and clicky stick.' },
  { id: 'wonderswan', tab: 'WONDERSWAN', name: 'WonderSwan', folder: ['wonderswan', 'wonderswancolor', 'ws', 'wsc'], ext: ['.ws', '.wsc', '.zip', '.7z'], lr: 'Bandai - WonderSwan', cores: [{ id: 'mednafen_wswan_libretro', name: 'Beetle WonderSwan', ra: true }], desc: 'Gunpei Yokoi\'s last handheld, played either way up.' },
  { id: 'virtualboy', tab: 'VIRTUAL BOY', name: 'Virtual Boy', folder: ['virtualboy', 'vb'], ext: ['.vb', '.zip', '.7z'], lr: 'Nintendo - Virtual Boy', cores: [{ id: 'mednafen_vb_libretro', name: 'Beetle VB', ra: true }], desc: 'Red-and-black 3D that was ahead of its time.' },
  { id: 'arcade', tab: 'ARCADE', name: 'Arcade', folder: ['arcade', 'fbneo', 'mame', 'neogeo'], ext: ['.zip', '.7z'], lr: 'FBNeo - Arcade Games', cores: [{ id: 'fbneo_libretro', name: 'FinalBurn Neo', ra: true }], desc: 'Coin-op classics, ready to play. Use ROM sets that match the FinalBurn Neo version.' },
  { id: '3do', tab: '3DO', name: '3DO', folder: ['3do'], ext: ['.iso', '.cue', '.chd'], lr: 'The 3DO Company - 3DO', cores: [{ id: 'opera_libretro', name: 'Opera', ra: true }], desc: 'The ambitious multimedia console of the early CD era. Needs the 3DO BIOS.' },
  { id: 'msx', tab: 'MSX', name: 'MSX', folder: ['msx', 'msx2'], ext: ['.rom', '.mx1', '.mx2', '.dsk', '.cas', '.zip', '.7z'], lr: 'Microsoft - MSX', cores: [{ id: 'bluemsx_libretro', name: 'blueMSX', ra: true }], desc: 'The home computer standard behind a generation of Japanese classics.' }
];
const RC = { gba: 5, gbc: 6, gb: 4, nes: 7, snes: 3, genesis: 1, mastersystem: 11, psx: 12, ps2: 21, gamecube: 16, wii: 19, psp: 41, dreamcast: 40, nds: 18, '3ds': 62, n64: 2, pcengine: 8, pcenginecd: 76, segacd: 9, sega32x: 10, lynx: 13, ngp: 14, gamegear: 15, jaguar: 17, atari2600: 25, arcade: 27, virtualboy: 28, msx: 29, saturn: 39, '3do': 43, atari7800: 51, wonderswan: 53 }; // RetroAchievements console ids
// Standalone emulators (emus.js): extra systems that Cacti OS lists and launches but RetroArch does not run.
const EMU = require('./emus.js')({ PORT, app, shell, send: (a, b) => send(a, b), MAC, WIN, LINUX });
// Game Store (store.js): freely released PC ports and recompilations, downloaded straight from the authors' GitHub pages.
const STORE = require('./store.js')({ app, shell, send: (a, b) => send(a, b), MAC, WIN, LINUX, extract: EMU.extract });
const ALL = SYSTEMS.concat(EMU.XSYS);
const coreFor = (c, s) => { const pick = s.cores.find(x => x.id === (c.cores || {})[s.id]); if (pick) return pick; const have = x => { try { return !!coreFile(c, x.id); } catch { return false; } }; return s.cores.find(x => x.ra && have(x)) || s.cores.find(have) || s.cores.find(x => x.ra) || s.cores[0]; }; // default: an installed core beats one that is not downloaded yet
// Standalone-emulator systems that also have a RetroArch core (Dreamcast, PSP, DS): the core is used once it is installed, unless 'standalone' is chosen.
const viaCore = (c, s) => { if (!s || !s.emu || !s.rcore) return false; const ch = (c.cores || {})[s.id]; if (ch === 'standalone') return false; if (ch === s.rcore.id) return true; try { return !!coreFile(c, s.rcore.id); } catch { return false; } };
const sysMeta = c => SYSTEMS.map(s => { const ch = coreFor(c, s); return { id: s.id, name: s.name, cores: s.cores, choice: ch.id }; }).concat(EMU.XSYS.filter(s => s.rcore).map(s => { const r = EMU.RECIPES.find(x => x.id === s.emu) || {}; return { id: s.id, name: s.name, cores: [{ id: 'standalone', name: (r.name || 'Standalone') + ' (standalone)', ra: !!r.ra }, s.rcore], choice: viaCore(c, s) ? s.rcore.id : 'standalone' }; }));

const clean = f => path.parse(f).name.replace(/_/g, ' ').replace(/\s*[\(\[][^\)\]]*[\)\]]/g, '').replace(/\s+/g, ' ').trim();
const IMG = /\.(png|jpe?g|webp)$/i;
const artCache = id => path.join(app.getPath('userData'), 'art', id);
// Wide banner art for the game info card: screenshots, title screens, fan art or marquees, in the ROM folder or saved by the scraper.
// Directory listings for the art folders. On a network share each readdir is a slow round trip, so a scan reads them all in parallel up front (prefetchLists) and the sync builders below only ever hit this cache.
let LSC = new Map(), M3C = new Map();
const lsSync = d => { if (LSC.has(d)) return LSC.get(d); let fl = []; try { fl = fs.readdirSync(d); } catch {} LSC.set(d, fl); return fl; };
const HERO_SUB = ['media/fanart', 'media/screenshot', 'media/screenshots', 'media/titlescreen', 'media/marquee', 'fanart', 'snaps'], ART_SUB = ['media/box2dfront', 'media/covers', 'boxart', 'images'];
async function pool(items, n, fn) { let i = 0; await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => { while (i < items.length) { const x = items[i++]; try { await fn(x); } catch {} } })); }
async function prefetchLists(by, onStep) {
  LSC = new Map(); M3C = new Map(); const dirs = new Set(), m3us = [];
  for (const [sid, files] of Object.entries(by)) { for (const f of files) { if (/\.m3u$/i.test(f.name)) m3us.push(f.p); const d = path.dirname(f.p); for (const sub of HERO_SUB.concat(ART_SUB)) dirs.add(path.join(d, sub)); } dirs.add(artCache(sid)); dirs.add(path.join(artCache(sid), 'hero')); }
  const list = [...dirs]; let k = 0;
  await pool(m3us, 12, async p => { let s = ''; try { s = await fs.promises.readFile(p, 'utf8'); } catch {} M3C.set(p, s); });
  await pool(list, 12, async d => { let fl = []; try { fl = await fs.promises.readdir(d); } catch {} LSC.set(d, fl); if (onStep && (++k & 15) === 0) onStep(k, list.length); });
}
function heroMap(dir, extra) {
  const m = new Map();
  for (const d of HERO_SUB.map(x => path.join(dir, x)).concat(extra)) {
    const fl = lsSync(d);
    for (const f of fl) { if (!IMG.test(f)) continue; const k = path.parse(f).name.toLowerCase().replace(/-(image|thumb)$/, ''); if (!m.has(k)) m.set(k, path.join(d, f)); }
  }
  return m;
}
function artMap(dir, extra) {
  const m = new Map();
  // Box art first, then art the scraper saved; 'images' folders usually hold gameplay screenshots, so they are the last resort.
  for (const d of ['media/box2dfront', 'media/covers', 'boxart'].map(x => path.join(dir, x)).concat(extra, [path.join(dir, 'images')])) {
    const fl = lsSync(d);
    for (const f of fl) {
      if (!IMG.test(f)) continue;
      const k = path.parse(f).name.toLowerCase().replace(/-(image|thumb)$/, '');
      if (!m.has(k)) m.set(k, path.join(d, f));
    }
  }
  return m;
}
// File types that identify one system on their own. Ambiguous ones (.zip, .7z, .bin, .iso) only count inside a system folder.
const UNIQ = { '.sfc': 'snes', '.smc': 'snes', '.nes': 'nes', '.gba': 'gba', '.gbc': 'gbc', '.gb': 'gb', '.md': 'genesis', '.gen': 'genesis', '.smd': 'genesis', '.sms': 'mastersystem', '.cue': 'psx', '.chd': 'psx', '.pbp': 'psx', '.m3u': 'psx', '.n64': 'n64', '.z64': 'n64', '.v64': 'n64', '.pce': 'pcengine', '.sgx': 'pcengine', '.gg': 'gamegear', '.32x': 'sega32x', '.a26': 'atari2600', '.a78': 'atari7800', '.lnx': 'lynx', '.j64': 'jaguar', '.jag': 'jaguar', '.ngp': 'ngp', '.ngc': 'ngp', '.ws': 'wonderswan', '.wsc': 'wonderswan', '.vb': 'virtualboy', '.mx1': 'msx', '.mx2': 'msx', ...EMU.XUNIQ };
const ALIAS = { snes: ['snes', 'sfc', 'supernintendo', 'supernes', 'superfamicom'], nes: ['nes', 'famicom', 'nintendo'], gba: ['gba', 'gameboyadvance'], gbc: ['gbc', 'gameboycolor'], gb: ['gb', 'gameboy'], genesis: ['genesis', 'megadrive', 'md', 'segagenesis'], mastersystem: ['mastersystem', 'sms', 'segamastersystem'], psx: ['psx', 'ps1', 'playstation', 'psone'], n64: ['n64', 'nintendo64'], pcengine: ['pcengine', 'tg16', 'pce', 'turbografx16', 'turbografx'], pcenginecd: ['pcenginecd', 'pcecd', 'tg16cd', 'turbografxcd', 'turbografx16cd'], gamegear: ['gamegear', 'gg', 'segagamegear'], segacd: ['segacd', 'megacd'], sega32x: ['sega32x', '32x'], saturn: ['saturn', 'segasaturn'], atari2600: ['atari2600', 'a2600'], atari7800: ['atari7800', 'a7800'], lynx: ['lynx', 'atarilynx'], jaguar: ['jaguar', 'atarijaguar'], ngp: ['ngp', 'ngpc', 'neogeopocket', 'neogeopocketcolor'], wonderswan: ['wonderswan', 'wonderswancolor', 'ws', 'wsc'], virtualboy: ['virtualboy', 'vb'], arcade: ['arcade', 'fbneo', 'mame', 'neogeo', 'fba'], '3do': ['3do'], msx: ['msx', 'msx2'], ...EMU.XALIAS };
const dirSystem = name => { const k = name.toLowerCase().replace(/[^a-z0-9]/g, ''); return Object.keys(ALIAS).find(id => ALIAS[id].includes(k)) || null; };
const COLL = new Intl.Collator(undefined, { numeric: false, sensitivity: 'variant' });
const ALLBY = {}; for (const x of ALL) ALLBY[x.id] = x;
// Walk the ROM folder. Async so a big library never freezes the window; yields to the event loop between folders.
async function walkRoms(root, onFile, onTop) {
  const seen = new Set();
  const walk = async (d, depth, hint) => {
    let es = []; try { es = await fs.promises.readdir(d, { withFileTypes: true }); } catch { return; }
    const topN = depth === 0 ? es.filter(x => x.isDirectory() && x.name.charCodeAt(0) !== 46).length : 0; let topI = 0; const subs = [];
    if (depth === 0 && onTop) onTop(0, topN, '');
    for (const e of es) {
      const n = e.name;
      if (n.charCodeAt(0) === 46 || n === 'images' || n === 'media' || n === 'boxart' || n === 'cores' || n === 'Cacti Saves') continue;
      const p = path.join(d, n);
      if (e.isDirectory()) { if (depth < 4) subs.push([p, depth + 1, dirSystem(n) || hint, depth === 0 ? n : '']); else if (depth === 0 && onTop) onTop(++topI, topN, n); continue; }
      if (!e.isFile() || seen.has(p)) continue;
      const ext = path.extname(n).toLowerCase(), hs = hint && ALLBY[hint];
      const id = hs && hs.ext.includes(ext) ? hint : (UNIQ[ext] || null);
      if (!id) continue;
      seen.add(p); onFile(id, p, n);
    }
    // sub folders are read several at a time: on a network share the wait is the round trip, not the work
    await pool(subs, depth === 0 ? 6 : 4, async s => { await walk(s[0], s[1], s[2]); if (depth === 0 && onTop) onTop(++topI, topN, s[3]); });
  };
  await walk(root, 0, null);
}

// ---------- Tidy library: move loose ROMs into their console folder, with their saves and scraped art ----------
const TIDY_SKIP = new Set(['.cue', '.chd', '.m3u', '.pbp', ...Object.keys(EMU.XUNIQ || {})]); // ambiguous types stay put
const TIDY_ART = ['images', 'boxart', 'media'];
const TIDY_SIDE = /\.(srm|rtc|sav|mcr|mcd|eep|sra|fla|dsv|nv|bsv|state\d*|state\.auto|png|jpe?g|webp)$/i;
async function tidyPlan(c) {
  const root = c.romRoot; if (!root || !fs.existsSync(root)) return { error: 'Choose a ROMs folder first.' };
  const top = {}; try { for (const e of fs.readdirSync(root, { withFileTypes: true })) if (e.isDirectory()) { const id = dirSystem(e.name); if (id && !top[id]) top[id] = e.name; } } catch {}
  const moves = [], skipped = []; const taken = new Set();
  await walkRoms(root, (id, p, name) => {
    const ext = path.extname(name).toLowerCase(); if (TIDY_SKIP.has(ext) || !UNIQ[ext] || UNIQ[ext] !== id) return;
    const rel = path.relative(root, path.dirname(p)).split(path.sep).filter(Boolean);
    if (rel.some(seg => dirSystem(seg) === id)) return; // already in its console's folder
    const s = ALLBY[id]; if (!s) return;
    const folder = top[id] || s.id.toUpperCase(), dest = path.join(root, folder, name);
    if (fs.existsSync(dest) || taken.has(dest.toLowerCase())) { skipped.push({ file: name, why: 'a file with that name is already in ' + folder }); return; }
    taken.add(dest.toLowerCase()); moves.push({ from: p, to: dest, sys: id, folder });
  });
  return { moves, skipped };
}
function tidyCompanions(from, to) {
  const out = [], sd = path.dirname(from), dd = path.dirname(to), base = path.parse(from).name.toLowerCase(), nb = path.parse(to).name;
  const same = f => { const b = path.parse(f).name.toLowerCase().replace(/-(image|thumb)$/, ''); return b === base; };
  try { for (const f of fs.readdirSync(sd)) { if (path.join(sd, f) === from || !same(f) || !TIDY_SIDE.test(f)) continue; if (/\.(png|jpe?g|webp)$/i.test(f)) continue; out.push([path.join(sd, f), path.join(dd, f)]); } } catch {}
  const walk = (rel, depth) => {
    let es = []; try { es = fs.readdirSync(path.join(sd, rel), { withFileTypes: true }); } catch { return; }
    for (const e of es) { const r = path.join(rel, e.name); if (e.isDirectory()) { if (depth < 3) walk(r, depth + 1); } else if (IMG.test(e.name) && same(e.name)) out.push([path.join(sd, r), path.join(dd, r)]); }
  };
  for (const a of TIDY_ART) walk(a, 0);
  return out;
}
function tidyMove(a, b) {
  fs.mkdirSync(path.dirname(b), { recursive: true });
  try { fs.renameSync(a, b); } catch (e) { if (e.code !== 'EXDEV') throw e; fs.copyFileSync(a, b); fs.unlinkSync(a); }
}
async function tidyRun(c) {
  if (child) return { ok: false, error: 'Close the running game first.' };
  const pl = await tidyPlan(c); if (pl.error) return { ok: false, error: pl.error };
  const remap = {}, st = getStats(); let n = 0, extra = 0, failed = 0;
  for (const mv of pl.moves) {
    try {
      const comps = tidyCompanions(mv.from, mv.to); tidyMove(mv.from, mv.to); n++; remap[mv.from] = mv.to;
      for (const [a, b] of comps) { if (fs.existsSync(b)) continue; try { tidyMove(a, b); extra++; } catch {} }
      if (st[mv.from]) { st[mv.to] = st[mv.from]; delete st[mv.from]; }
    } catch { failed++; }
  }
  try { fs.writeFileSync(ST(), JSON.stringify(st)); } catch {}
  scanCache = null; logEv(`tidy library: moved ${n} games, ${extra} companion files, ${failed} failed`);
  return { ok: true, moved: n, extra, failed, skipped: pl.skipped.length, remap };
}
// ---------- duplicate regions + multi-disc games ----------
// Rule: with several copies of one game, keep the copy that has RetroAchievements support; otherwise prefer USA / English, then World, then UK, then the rest.
// A game that exists only once is always kept, whatever its region. Disc 1/2/3 files become one entry that launches an auto-made M3U playlist.
const DISC_RE = /[\(\[]\s*(?:dis[ck]|cd)\s*(\d+)\b[^\)\]]*[\)\]]/i;
const M3UDIR = () => path.join(app.getPath('userData'), 'm3u');
function fileInfo(name) {
  const base = path.parse(name).name, dm = DISC_RE.exec(base);
  const setName = base.replace(DISC_RE, '').replace(/\s+/g, ' ').trim();
  const tags = [...base.matchAll(/[\(\[]([^\)\]]*)[\)\]]/g)].map(x => x[1].toLowerCase().trim());
  const toks = tags.flatMap(t => t.split(/[,\/&+]/).map(s => s.trim()));
  const has = (...a) => a.some(x => toks.includes(x));
  const rank = has('usa', 'us', 'u', 'ntsc-u') ? 5 : has('en', 'english', 'en-us', 'en-gb') ? 4 : has('world', 'w') ? 3 : has('uk', 'united kingdom', 'great britain') ? 2 : has('europe', 'eu', 'e', 'australia', 'canada') ? 1 : 0;
  const pen = tags.some(t => /^(beta|proto|prototype|demo|sample|promo|unl|pirate|hack|bad dump)\b/.test(t)) || tags.includes('b') ? 1 : 0;
  const rv = tags.map(t => /^rev\s*(\w+)$/.exec(t)).find(Boolean); const rev = rv ? (parseInt(rv[1], 10) || rv[1].charCodeAt(0) - 64 || 0) : 0;
  return { base, setName, disc: dm ? +dm[1] : 0, rank, pen, rev, key: norm(clean(setName + '.x')) };
}
const RAOKF = () => path.join(app.getPath('userData'), 'ra-hash-cache.json');
const RAOK = new Map(); // file path -> true/false: does RetroAchievements know this exact file (remembered between runs so a share is not re-read)
try { for (const [k, v] of Object.entries(JSON.parse(fs.readFileSync(RAOKF(), 'utf8')))) RAOK.set(k, !!v); } catch {}
let raokDirty = false; const raokSave = () => { if (!raokDirty) return; raokDirty = false; try { fs.writeFileSync(RAOKF() + '.tmp', JSON.stringify(Object.fromEntries(RAOK))); fs.renameSync(RAOKF() + '.tmp', RAOKF()); } catch {} };
// Work out, for one system, which entries to show. Returns [{ title, files:[{p,name,disc}], rank... }]
function planSystem(sid, files, c) {
  const refd = new Set();
  for (const f of files) if (/\.m3u$/i.test(f.name)) { try { for (const ln of (M3C.has(f.p) ? M3C.get(f.p) : fs.readFileSync(f.p, 'utf8')).split(/\r?\n/)) { const t = ln.trim(); if (t && t[0] !== '#') refd.add(path.resolve(path.dirname(f.p), t).toLowerCase()); } } catch {} }
  const sets = new Map();
  for (const f of files) {
    if (refd.has(path.resolve(f.p).toLowerCase())) continue;
    const i = fileInfo(f.name), sk = path.dirname(f.p) + '|' + i.setName.toLowerCase();
    let s = sets.get(sk); if (!s) sets.set(sk, s = { ...i, files: [] });
    s.files.push({ p: f.p, name: f.name, disc: i.disc });
  }
  const arr = [...sets.values()]; for (const s of arr) s.files.sort((a, b) => a.disc - b.disc || a.p.localeCompare(b.p));
  if (c.dedupe === false) return arr;
  const groups = new Map(); for (const s of arr) (groups.get(s.key) || groups.set(s.key, []).get(s.key)).push(s);
  const out = [];
  for (const g of groups.values()) {
    if (g.length === 1) { out.push(g[0]); continue; }
    const sc = s => (RAOK.get(s.files[0].p) ? 1000 : 0) - s.pen * 100 + s.rank * 10 + s.rev;
    g.sort((a, b) => sc(b) - sc(a) || a.setName.localeCompare(b.setName)); out.push(g[0]);
  }
  return out;
}
function buildScan(by, stats) {
  const out = [], c = load();
  for (const s of ALL) {
    const files = by[s.id]; if (!files || !files.length) continue;
    const maps = {}, hmaps = {}, artFor = dir => maps[dir] || (maps[dir] = artMap(dir, [artCache(s.id)])), heroFor = dir => hmaps[dir] || (hmaps[dir] = heroMap(dir, [path.join(artCache(s.id), 'hero')]));
    const games = planSystem(s.id, files, c).map(set => {
      let file = set.files[0].p, nm = set.files[0].name;
      if (set.files.length > 1 && set.files.every(f => f.disc)) { // several discs: one playlist entry
        try { const dir = path.join(M3UDIR(), s.id); fs.mkdirSync(dir, { recursive: true }); const mp = path.join(dir, set.setName.replace(/[\\/:*?"<>|]/g, '_') + '.m3u'), body = set.files.map(f => f.p).join('\n') + '\n'; let cur = ''; try { cur = fs.readFileSync(mp, 'utf8'); } catch {} if (cur !== body) fs.writeFileSync(mp, body); file = mp; } catch {}
      }
      const dir0 = path.dirname(set.files[0].p), k1 = path.parse(nm).name.toLowerCase(), k2 = set.setName.toLowerCase();
      const a = artFor(dir0).get(k1) || artFor(dir0).get(k2), h = heroFor(dir0).get(k1) || heroFor(dir0).get(k2);
      return { title: clean(set.setName + '.x'), file, sys: s.id, discs: file !== set.files[0].p || set.files.length > 1 ? set.files.length : 0, hero: h ? pathToFileURL(h).href.replace(/'/g, '%27') : null, art: a ? pathToFileURL(a).href.replace(/'/g, '%27') : null, shot: !!(a && path.basename(path.dirname(a)) === 'images'), stats: stats[file] || null, meta: META.get(s.id, clean(set.setName + '.x')) };
    });
    games.sort((x, y) => COLL.compare(x.title, y.title));
    out.push({ id: s.id, name: s.name, tab: s.tab, desc: s.desc, games, ...(s.emu ? { ra: EMU.RECIPES.some(r => r.id === s.emu && !!r.ra) } : {}) });
  }
  try { // Recomps: the PC ports installed from the Game Store, launched through the store
    const rc = STORE.installedSync();
    if (rc.length) out.push({ id: 'recomps', name: 'Recomps', tab: 'RECOMPS', desc: 'Native PC ports and recompilations of classic games, installed from the Game Store.', games: rc.map(r => ({ title: r.game || r.name, file: 'store:' + r.id, sys: 'recomps', discs: 0, hero: null, art: null, desc: r.blurb || '' })) });
  } catch {}
  return out;
}
// Hash the competing copies of each duplicated game and remember which ones RetroAchievements recognises (needs the console's hash list from raList).
const HASHSYS = new Set(['gb', 'gbc', 'gba', 'nes', 'snes', 'genesis', 'mastersystem', 'gamegear', 'pcengine', 'n64']);
const hsets = {};
async function md5Rom(file, sid) {
  try {
    const st = await fs.promises.stat(file); if (st.size > 16 * 1048576) return ''; await new Promise(r => setTimeout(r, 15)); // small cartridge files only, with a short pause between files so the app stays responsive
    const ext = path.extname(file).toLowerCase(); if (['.zip', '.7z', '.rar', '.chd'].includes(ext) || (sid === 'n64' && ext !== '.z64') || (sid === 'genesis' && ext === '.smd')) return '';
    let b = await fs.promises.readFile(file);
    if (sid === 'nes' && b.length > 16 && b[0] === 0x4e && b[1] === 0x45 && b[2] === 0x53 && b[3] === 0x1a) b = b.subarray(16);
    if (sid === 'snes' && b.length % 1024 === 512) b = b.subarray(512);
    return crypto.createHash('md5').update(b).digest('hex');
  } catch { return ''; }
}
async function raHashPass(by, onSys, cap = 1e9) {
  let hashed = 0; const c = load(); if (c.dedupe === false) return; const d = rlLoad();
  const sids = Object.keys(by); let si = 0;
  for (const sid of sids) {
    if (onSys) onSys(si++, sids.length, sid);
    const rc = RC[sid], e = rc && d[rc]; if (!e || e.v !== 2 || !HASHSYS.has(sid)) continue;
    const hs = hsets[rc] && hsets[rc].src === e ? hsets[rc].set : (hsets[rc] = { src: e, set: new Set(e.games.flatMap(g => g[3] || [])) }).set; if (!hs.size) continue;
    const g = new Map(); for (const s of planSystem(sid, by[sid], { ...c, dedupe: false })) (g.get(s.key) || g.set(s.key, []).get(s.key)).push(s);
    for (const arr of g.values()) { if (arr.length < 2) continue; for (const s of arr) { const p = s.files[0].p; if (!RAOK.has(p)) { if (hashed >= cap) return; hashed++; RAOK.set(p, hs.has(await md5Rom(p, sid))); raokDirty = true; } } }
  }
}
let scanCache = null, scanBusy = null;
// the last library is kept on disk so the app opens instantly even when the games live on a slow network share; a fresh scan then runs in the background
const LIBC = () => path.join(app.getPath('userData'), 'library-cache.json');
function libSave(root, out) { setImmediate(() => { try { fs.writeFileSync(LIBC() + '.tmp', JSON.stringify({ root, t: Date.now(), out })); fs.renameSync(LIBC() + '.tmp', LIBC()); } catch {} }); }
function libLoad(root) { try { const j = JSON.parse(fs.readFileSync(LIBC(), 'utf8')); return j && j.root === root && Array.isArray(j.out) && j.out.length ? j.out : null; } catch { return null; } }
const rootThere = (root, ms = 8000) => Promise.race([fs.promises.access(root).then(() => true, () => false), new Promise(r => setTimeout(() => r(false), ms))]); // never blocks on a share that is asleep or offline
function scanQuick(c) { const root = c.romRoot; if (!root) return null; if (scanCache && scanCache.root === root) return scanCache.out; const o = libLoad(root); if (o) scanCache = { root, t: 0, out: o, disk: true }; return o; }
async function scanAsync(c, fresh) {
  const root = c.romRoot;
  if (!root || !(await rootThere(root))) return (root && scanQuick(c)) || [];
  if (!fresh && scanCache && scanCache.root === root && Date.now() - scanCache.t < 60000) return scanCache.out;
  if (scanBusy && scanBusy.root === root) return scanBusy.p;
  const p = (async () => {
    const by = {}; let found = 0, lastT = 0, cur = 0, curMsg = 'Looking for games';
    const prog = (pct, msg, force) => { if (pct != null) { cur = pct; curMsg = msg; } const t = Date.now(); if (!force && t - lastT < 120) return; lastT = t; try { if (win && !win.isDestroyed()) win.webContents.send('scan:progress', { pct: Math.min(99, Math.round(cur)), found, msg: curMsg }); } catch {} };
    await walkRoms(root, (id, p, name) => { (by[id] = by[id] || []).push({ p, name }); found++; prog(null, null, false); }, (i, n, name) => prog(n ? (i / n) * 70 : 35, name ? 'Reading ' + name : 'Looking for games', true));
    await new Promise(r => setImmediate(r));
    prog(75, 'Reading artwork folders', true);
    await prefetchLists(by, (i, n) => prog(75 + (i / n) * 20, 'Reading artwork folders', false));
    prog(97, 'Building your library', true);
    const out = buildScan(by, getStats());
    try { if (win && !win.isDestroyed()) win.webContents.send('scan:progress', { done: true, pct: 100, found }); } catch {}
    scanCache = { root, t: Date.now(), out };
    libSave(root, out);
    setTimeout(() => { adoptShared(out).catch(() => {}); }, 2500);
    // Checking which copy of a duplicated game RetroAchievements knows means reading ROM files, which is slow on a share. It runs after the library is already shown, a few hundred files per scan, and only changes the list if it finds something new.
    setTimeout(async () => {
      try { const before = RAOK.size; await raHashPass(by, null, 250); raokSave(); if (RAOK.size !== before) { const o2 = buildScan(by, getStats()); if (JSON.stringify(o2.map(s => s.games.map(g => g.file))) !== JSON.stringify(out.map(s => s.games.map(g => g.file)))) { scanCache = { root, t: Date.now(), out: o2 }; libSave(root, o2); try { if (win && !win.isDestroyed()) win.webContents.send('scan:updated'); } catch {} } } } catch {}
    }, 4000);
    return out;
  })();
  scanBusy = { root, p }; const done = () => { if (scanBusy && scanBusy.p === p) scanBusy = null; };
  p.then(done, done);
  return p;
}
// Sync callers (system check, scraper, cores) reuse the cache the home-screen scan just filled; only a cold start walks synchronously.
function scan(c) {
  if (scanCache && scanCache.root === c.romRoot && Date.now() - scanCache.t < 300000) return scanCache.out;
  const old = c.romRoot && scanQuick(c); // anything already known is used right away, never a slow walk of the share on the main thread
  if (old) { if (!scanBusy) scanAsync(c, true).catch(() => {}); return old; }
  if (!c.romRoot || !fs.existsSync(c.romRoot)) return [];
  LSC = new Map();
  const by = {}, seen = new Set();
  const walk = (d, depth, hint) => {
    let es = []; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of es) {
      const n = e.name;
      if (n.charCodeAt(0) === 46 || n === 'images' || n === 'media' || n === 'boxart' || n === 'cores' || n === 'Cacti Saves') continue;
      const p = path.join(d, n);
      if (e.isDirectory()) { if (depth < 4) walk(p, depth + 1, dirSystem(n) || hint); continue; }
      if (!e.isFile() || seen.has(p)) continue;
      const ext = path.extname(n).toLowerCase(), hs = hint && ALLBY[hint];
      const id = hs && hs.ext.includes(ext) ? hint : (UNIQ[ext] || null);
      if (!id) continue;
      seen.add(p); (by[id] = by[id] || []).push({ p, name: n });
    }
  };
  walk(c.romRoot, 0, null);
  const out = buildScan(by, getStats());
  scanCache = { root: c.romRoot, t: Date.now(), out };
  return out;
}

// ---------- scraper: box art from the libretro thumbnails server ----------
let scrapeStop = false;
const safe = n => n.replace(/[&*\/:`<>?\\|"]/g, '_');
// Art is saved next to the games (media/covers and media/fanart, the layout EmulationStation-DE and Pegasus use), so every device that opens the same ROM folder, such as an SMB share, shares one scrape. Read-only folders fall back to this device.
const SHAREBAD = new Set();
function mediaTarget(s, g, kind) {
  const c = load(), f = g && g.file ? String(g.file) : '';
  if (c.shareMeta !== false && f && !f.startsWith('store:') && !f.startsWith(M3UDIR())) {
    const root = path.dirname(f), d = path.join(root, 'media', kind);
    if (!SHAREBAD.has(root)) { try { fs.mkdirSync(d, { recursive: true }); fs.accessSync(d, fs.constants.W_OK); return d; } catch { SHAREBAD.add(root); } }
  }
  return kind === 'fanart' ? path.join(artCache(s.id), 'hero') : artCache(s.id);
}
async function fetchArt(s, g) {
  const base = path.parse(g.file).name, t = clean(g.file);
  const names = [...new Set([base, `${t} (USA)`, `${t} (Europe)`, `${t} (Japan)`])];
  for (const n of names) {
    try {
      const r = await fetch(`https://thumbnails.libretro.com/${encodeURIComponent(s.lr)}/Named_Boxarts/${encodeURIComponent(safe(n))}.png`, { signal: AbortSignal.timeout(12000) });
      if (!r.ok) continue;
      const dd = mediaTarget(s, g, 'covers'); fs.mkdirSync(dd, { recursive: true });
      fs.writeFileSync(path.join(dd, base + '.png'), Buffer.from(await r.arrayBuffer()));
      return true;
    } catch {}
  }
  try { // fallback: the LaunchBox box picture, only for games the libretro thumbnails do not have
    if (((load().scrapeEngines || {}).launchbox !== false) && !g.art) {
      const u = MT.lbBox(path.join(app.getPath('userData'), 'meta-cache'), s.id, t);
      if (u) { const r = await fetch(u, { signal: AbortSignal.timeout(15000) }); if (r.ok) { const dd = mediaTarget(s, g, 'covers'); fs.mkdirSync(dd, { recursive: true }); fs.writeFileSync(path.join(dd, base + '.png'), Buffer.from(await r.arrayBuffer())); return true; } }
    }
  } catch {}
  return false;
}
// ---------- launch screen backgrounds: fan art / screenshot / title screen, fetched on first use and cached ----------
const bgDir = sid => path.join(artCache(sid), 'hero');
const bgHave = (sid, base, file) => { const dirs = [bgDir(sid)]; if (file && !String(file).startsWith('store:')) dirs.unshift(path.join(path.dirname(String(file)), 'media', 'fanart')); for (const d of dirs) for (const e of ['.jpg', '.jpeg', '.png', '.webp']) { const f = path.join(d, base + e); if (fs.existsSync(f)) return f; } return null; };
async function fetchBg(s, g) {
  const base = path.parse(g.file).name, t = g.title || clean(g.file); if (bgHave(s.id, base, g.file)) return true;
  const save = async (r, ext) => { const b = Buffer.from(await r.arrayBuffer()); if (b.length < 2000 || b.length > 8e6) return false; const dd = mediaTarget(s, g, 'fanart'); fs.mkdirSync(dd, { recursive: true }); fs.writeFileSync(path.join(dd, base + ext), b); return true; };
  try { if ((load().scrapeEngines || {}).launchbox !== false) { const u = MT.lbFan(path.join(app.getPath('userData'), 'meta-cache'), s.id, t); if (u) { const r = await fetch(u, { signal: AbortSignal.timeout(20000) }); if (r.ok && await save(r, (path.extname(u.split('?')[0]).toLowerCase() || '.jpg'))) return true; } } } catch {}
  const names = [...new Set([base, `${clean(g.file)} (USA)`, `${clean(g.file)} (Europe)`, `${clean(g.file)} (Japan)`])];
  if (s.lr) for (const kind of ['Named_Snaps', 'Named_Titles']) for (const n of names) { try { const r = await fetch(`https://thumbnails.libretro.com/${encodeURIComponent(s.lr)}/${kind}/${encodeURIComponent(safe(n))}.png`, { signal: AbortSignal.timeout(12000) }); if (r.ok && await save(r, '.png')) return true; } catch {} }
  return false;
}
// ---------- share the library: art and descriptions live in the ROM folders, so each device reads what another already scraped ----------
const inLocalCache = f => { try { return decodeURIComponent(String(f)).replace(/^file:\/\//, '').includes(path.join(app.getPath('userData'), 'art')); } catch { return false; } };
const ADOPTED = new Map();
async function adoptShared(sc) { // read each system folder's gamelist.xml (written by Cacti on any device, or by another frontend) into the details store
  const c = load(); if (c.shareMeta === false) return 0; let n = 0;
  for (const sys of sc) {
    const byDir = new Map(); for (const g of sys.games) { const f = String(g.file || ''); if (!f || f.startsWith('store:') || f.startsWith(M3UDIR())) continue; const d = path.dirname(f); (byDir.get(d) || byDir.set(d, []).get(d)).push(g); }
    for (const [d, games] of byDir) {
      try { const st = await fs.promises.stat(path.join(d, 'gamelist.xml')), key = d + '|' + st.mtimeMs; if (ADOPTED.get(d) === key) continue; n += MT.applyGamelist(META, sys.id, games, d); ADOPTED.set(d, key); } catch {}
      await new Promise(r => setImmediate(r));
    }
  }
  if (n) logEv('shared details adopted: ' + n);
  return n;
}
async function exportShared(sc, say) { // copy this device's art into the ROM folders and write descriptions to gamelist.xml there
  const c = load(); if (c.shareMeta === false) return { art: 0, lists: 0, tags: 0 };
  let art = 0, lists = 0, tags = 0, i = 0;
  for (const sys of sc) {
    if (say) say(`Saving to the ROM folders · ${sys.name || sys.id}`);
    const byDir = new Map();
    for (const g of sys.games) {
      const f = String(g.file || ''); if (!f || f.startsWith('store:') || f.startsWith(M3UDIR())) continue;
      const d = path.dirname(f), base = path.parse(f).name; (byDir.get(d) || byDir.set(d, []).get(d)).push(g);
      for (const [url, kind] of [[g.art, 'covers'], [g.hero, 'fanart']]) {
        if (!url || !inLocalCache(url)) continue;
        try { const src = fileURLToPath(url), dd = mediaTarget({ id: sys.id }, g, kind); if (dd.includes(path.join('media', kind))) { fs.mkdirSync(dd, { recursive: true }); const dst = path.join(dd, base + path.extname(src)); if (!fs.existsSync(dst)) { fs.copyFileSync(src, dst); art++; } } } catch {}
      }
      if (++i % 40 === 0) await new Promise(r => setImmediate(r));
    }
    for (const [d, games] of byDir) {
      const entries = []; for (const g of games) { const m = META.get(sys.id, g.title); if (m) entries.push({ file: g.file, name: g.title, desc: m.desc, genre: m.genre, year: m.year, dev: m.dev, pub: m.pub, players: m.players, rating: m.rating }); }
      if (!entries.length) continue;
      const r = MT.writeGamelist(d, entries); if (r > 0) { lists++; tags += r; ADOPTED.delete(d); }
      await new Promise(r2 => setImmediate(r2));
    }
  }
  return { art, lists, tags };
}
let bgBusy = false;
async function scrapeBg(id) {
  if (bgBusy) return; bgBusy = true; scrapeStop = false;
  try {
    const todo = []; for (const s of scan(load())) if (s.id !== 'recomps' && (!id || s.id === id)) for (const g of s.games) if (!g.hero && !bgHave(s.id, path.parse(g.file).name, g.file)) todo.push({ s: ALL.find(x => x.id === s.id), g });
    const total = todo.length; let done = 0, got = 0, last = 0;
    const upd = (run, force) => { const n = Date.now(); if (!force && n - last < 250) return; last = n; send('scrape', { run, done, total, found: got, msg: `Backgrounds ${got}/${total}` }); };
    upd(true, true);
    const worker = async () => { while (todo.length && !scrapeStop) { const { s, g } = todo.shift(); try { if (s && await fetchBg(s, g)) got++; } catch {} done++; upd(true); } };
    await Promise.all([worker(), worker(), worker(), worker()]);
    scanCache = null; const msg = `Backgrounds: ${got} of ${total} pulled`; logEv('scrape: ' + msg);
    send('scrape', { run: false, done, total, found: got, msg, res: { bgGot: got, bgTotal: total, per: {}, notes: total && !got ? ['No backgrounds were found. Run a normal scrape first so LaunchBox data is loaded, and check the internet connection'] : [], stopped: scrapeStop } });
  } finally { bgBusy = false; }
}
const SCRAPE_IDS = ['libretro', 'libretrodb', 'launchbox', 'hasheous', 'gamelist', 'screenscraper', 'thegamesdb', 'igdb'];
// ---------- game metadata (description, genre, year, developer, players): engines tried in order, each fills only what is still empty ----------
const META = require('./meta.js').createStore(path.join(app.getPath('userData'), 'meta.json'));
const MT = require('./meta.js');
const FREE_ENG = ['hasheous', 'libretrodb', 'launchbox', 'gamelist', 'screenscraper']; // ScreenScraper works with Cacti OS's own developer login; a personal login is optional. TheGamesDB and IGDB need the user's own key and are not offered
const engOn = (c, id) => FREE_ENG.includes(id) && (c.scrapeEngines || {})[id] !== false;
const engOrder = c => { const ids = FREE_ENG.slice().sort((a, b) => ['gamelist', 'launchbox', 'screenscraper', 'libretrodb', 'hasheous'].indexOf(a) - ['gamelist', 'launchbox', 'screenscraper', 'libretrodb', 'hasheous'].indexOf(b)).filter(i => engOn(c, i)); const f = c.scrapeFirst; return f && ids.includes(f) ? [f, ...ids.filter(i => i !== f)] : ids; };
const md5File = (file, max) => new Promise(res => { try { if (fs.statSync(file).size > max) return res(''); const h = crypto.createHash('md5'); fs.createReadStream(file).on('data', d => h.update(d)).on('end', () => res(h.digest('hex'))).on('error', () => res('')); } catch { res(''); } });
let metaStop = false, metaBusy = false, metaSince = 0;
async function scrapeMeta(id, onMsg) {
  if (metaBusy && Date.now() - metaSince < 20 * 60e3) return { busy: true }; metaBusy = true; metaSince = Date.now(); metaStop = false; MT.resetCaches();
  const c = load(), order = engOrder(c), down = new Set(), notes = []; let filled = 0, doneN = 0, total = 0, needN = 0; const per = {};
  const ctx = { fetch, dir: path.join(app.getPath('userData'), 'meta-cache'), say: onMsg, md5: md5File, creds: c, raId: (sysId, g) => g.gameId ? Number(g.gameId) : raGameId(c, sysId, g.title), raCall: (ep, p) => ra(ep, p, c) };
  try {
    const systems = scan(c).filter(s => !id || s.id === id);
    total = systems.reduce((n, s) => n + s.games.length, 0);
    const need = needN = systems.reduce((n, s) => n + s.games.filter(g => !MT.complete(META.get(s.id, g.title))).length, 0);
    let resolved = 0;
    const downWhy = {}, fails = {};
    const say = m => onMsg(m + (Object.keys(downWhy).length ? ' · skipped: ' + Object.entries(downWhy).map(([k, v]) => `${MT.ENGINES[k].name} (${v})`).join(', ') : ''), { done: Math.min(resolved, need), total: need });
    say(need ? `${need} of ${total} games still need details` : 'Every game already has its details');
    for (const sc of systems) {
      const S = ALL.find(x => x.id === sc.id); if (!S) continue;
      if (order.includes('gamelist')) { for (const d of new Set(sc.games.map(g => path.dirname(g.file)))) { const n = MT.applyGamelist(META, sc.id, sc.games.filter(g => path.dirname(g.file) === d), d); filled += n; per.gamelist = (per.gamelist || 0) + n; } }
      // game by game: the first engine tries it, the next one only takes over if details are still missing
      for (const g of sc.games) {
        if (metaStop) break;
        const had = MT.complete(META.get(sc.id, g.title));
        try {
        for (const eid of order) {
          if (eid === 'gamelist' || down.has(eid)) continue;
          if (MT.complete(META.get(sc.id, g.title))) break;
          const E = MT.ENGINES[eid];
          try {
            say(`${S.name}: ${E.name} - ${g.title}`);
            let n = 0;
            if (eid === 'launchbox') n = await MT.launchbox(META, S, [g], ctx);
            else if (eid === 'libretrodb') n = await MT.libretrodb(META, S, [g], ctx);
            else { const r = await E.one(sc.id, g, ctx); n = META.merge(sc.id, g.title, r || {}, eid); META.markTried(eid + (E.ver || ''), sc.id, g.title); }
            filled += n; per[eid] = (per[eid] || 0) + n; fails[eid] = 0;
          } catch (e) {
            fails[eid] = (fails[eid] || 0) + 1;
            const why = e.status === 429 ? 'limit reached' : e.status >= 500 ? 'server error ' + e.status : e.name === 'TimeoutError' ? 'not responding' : String(e.message || 'failed').slice(0, 60);
            const lim = e.status === 429 || e.status === 401 || e.status === 403 ? 1 : eid === 'launchbox' ? 2 : eid === 'libretrodb' ? 4 : 5;
            logEv(`scrape: ${E.name} failed on ${g.title}: ${why} (${fails[eid]}/${lim})`);
            if (fails[eid] >= lim) { down.add(eid); downWhy[eid] = why; notes.push(`${E.name}: ${why}, skipped for the rest of this run`); }
          }
          if (E.gap) await new Promise(r => setTimeout(r, E.gap));
        }
        } catch (e) { logEv('scrape: skipped ' + g.title + ': ' + (e.message || e)); }
        if (!had) resolved++;
        doneN++;
      }
    }
  } finally { metaBusy = false; META.flush(); }
  scanCache = null;
  return { filled, notes, total, per, need: needN, stopped: metaStop };
}
let LASTRUN = null;
async function engineStatus() { const rows = await MT.engineStatus({ fetch, dir: path.join(app.getPath('userData'), 'meta-cache') }); const c = load(); try { const t = await MT.testLogin('screenscraper', c, { fetch }); rows.splice(1, 0, { id: 'screenscraper', name: 'ScreenScraper', state: t.ok ? 'ok' : 'down', text: t.ok ? 'Online' : 'Problem', extra: t.msg || '' }); } catch {} for (const r of rows) { if (r.id !== 'libretro' && r.id !== 'gamelist' && !engOn(c, r.id)) { r.extra = 'Turned off. ' + r.extra; } if (LASTRUN) { const n = (LASTRUN.per || {})[r.id]; const note = (LASTRUN.notes || []).find(x => x.startsWith((MT.ENGINES[r.id] || {}).name || '\0')); if (n !== undefined || note) r.extra = (r.extra ? r.extra + '. ' : '') + 'Last scrape: ' + (n || 0) + ' filled' + (note ? ' (' + note.replace(/^[^:]*: /, '') + ')' : ''); } } return { rows, at: Date.now() }; }
async function scraperTest(eng) { const c = load(); return MT.testLogin(eng, c, { fetch }); }
async function scrape(id) {
  const artOn = (load().scrapeEngines || {}).libretro !== false;
  const todo = [];
  for (const s of scan(load())) if (s.id !== 'recomps' && (!id || s.id === id)) for (const g of s.games) if (artOn && (!g.art || g.shot)) todo.push({ s: ALL.find(x => x.id === s.id), g });
  let done = 0, found = 0; scrapeStop = false;
  const total = todo.length; let md = 0, mt = 0, mm = '', last = 0;
  const upd = (run, force) => { const n = Date.now(); if (!force && n - last < 250) return; last = n; send('scrape', { run, done: done + md, total: total + mt, found, msg: `Box art ${done}/${total}${mt ? ` · Details ${md}/${mt}` : ''}${mm ? ' · ' + mm : ''}` }); };
  upd(true, true);
  const worker = async () => { while (todo.length && !scrapeStop) { const { s, g } = todo.shift(); try { if (await fetchArt(s, g)) found++; } catch {} done++; upd(true); } };
  const art = Promise.all([worker(), worker(), worker(), worker()]);
  const metaP = scrapeMeta(id, (m, pr) => { if (pr) { md = pr.done; mt = pr.total; } mm = String(m || '').slice(0, 80); upd(true); }).catch(e => { logEv('scrape details failed: ' + (e && e.stack || e)); return { filled: 0, per: {}, notes: ['Details lookup stopped: ' + (e && e.message || e)] }; });
  const [, mr] = await Promise.all([art, metaP]);
  upd(true, true);
  const NM = { gamelist: 'gamelist.xml', launchbox: 'LaunchBox', hasheous: 'Hasheous', libretrodb: 'libretro database' };
  let msg, stillN, wd = 0, al = 0;
  if (mr && mr.busy) msg = 'A details lookup is already running. Press Stop, wait a moment and try again';
  else {
    const per = Object.entries((mr && mr.per) || {}).filter(([, n]) => n).map(([k, n]) => `${NM[k] || k} ${n}`).join(', ');
    const miss = []; let all = 0, withDesc = 0; for (const x of scan(load()).filter(x => !id || x.id === id)) for (const g of x.games) { all++; const m = META.get(x.id, g.title); if (m && m.desc) withDesc++; if (!MT.complete(m)) miss.push(x.id + ' | ' + g.title); }
    const still = stillN = miss.length; wd = withDesc; al = all; try { fs.writeFileSync(path.join(app.getPath('userData'), 'meta-cache', 'still-missing.txt'), miss.join('\n')); } catch {}
    msg = [`Box art: ${found} new`, mr && mr.filled ? `Details filled in this run: ${per || mr.filled}` : 'No new details this run', `${withDesc.toLocaleString()} of ${all.toLocaleString()} games have a description`, `${still} games still missing details${still ? ' (list saved in the meta-cache folder as still-missing.txt)' : ''}`, ...((mr && mr.notes) || [])].join(' · ');
  }
  try { if (!(mr && mr.busy)) { const shr = await exportShared(scan(load()).filter(x => !id || x.id === id), m => send('scrape', { run: true, done, total: Math.max(total, done), found, msg: m })); if (shr.art || shr.lists) msg += ` · Saved to the ROM folders: ${shr.art} images, details in ${shr.lists} gamelist file${shr.lists == 1 ? '' : 's'}`; } } catch (e) { logEv('share export: ' + (e && e.message)); }
  LASTRUN = { at: Date.now(), per: (mr && mr.per) || {}, notes: (mr && mr.notes) || [] };
  const res = (mr && mr.busy) ? null : { artGot: found, artTotal: total, detGot: Math.max(0, ((mr && mr.need) || 0) - (typeof stillN === 'number' ? stillN : 0)), detTotal: (mr && mr.need) || 0, per: (mr && mr.per) || {}, notes: (mr && mr.notes) || [], withDesc: wd, all: al, still: typeof stillN === 'number' ? stillN : 0, stopped: scrapeStop };
  logEv('scrape: ' + msg); send('scrape', { run: false, done, total: Math.max(total, done), found, msg, res });
  return { done, found, meta: mr };
}

// ---------- system check + installers ----------
const brew = () => ['/opt/homebrew/bin/brew', '/usr/local/bin/brew'].find(p => fs.existsSync(p));
function check() {
  const c = load(), dir = coresDir(c), sc = scan(c);
  return {
    mac: MAC, retroarch: { ok: fs.existsSync(c.retroarch), path: c.retroarch }, coresDir: dir, coresDirOk: fs.existsSync(dir) || coreDirs(c).some(d => { try { return fs.existsSync(d); } catch { return false; } }),
    romRoot: c.romRoot, romRootOk: !!c.romRoot && fs.existsSync(c.romRoot), brew: !!brew(), flatpak: LINUX && fs.existsSync('/usr/bin/flatpak'), win: WIN, ra: { user: !!c.raUser, key: !!c.raKey, pass: !!c.raPass },
    systems: SYSTEMS.map(s => { const f = sc.find(x => x.id === s.id), ch = coreFor(c, s); return { id: s.id, name: s.name, folders: s.folder.join(' or '), count: f ? f.games.length : 0, core: ch.name, ra: ch.ra, coreOk: !!coreFile(c, ch.id) }; }),
    bios: EMU.biosStatus(), standalone: EMU.XSYS.map(s => { const f = sc.find(x => x.id === s.id); return { id: s.id, name: s.name, folders: s.folder.join(' or '), count: f ? f.games.length : 0, emu: s.emu, via: (() => { try { const sy = ALL.find(a => a.id === s.id); return !!(sy && viaCore(c, sy)); } catch { return false; } })() }; })
  };
}
async function prepCore(file) { // clear quarantine and make sure the dylib has a valid signature (Apple Silicon refuses unsigned code)
  if (!MAC) return;
  await sh('/usr/bin/xattr', ['-cr', file], 15000);
  if (!(await new Promise(r => execFile('/usr/bin/codesign', ['--verify', file], { timeout: 15000 }, e => r(!e))))) await sh('/usr/bin/codesign', ['--force', '--sign', '-', file], 20000);
}
// A fresh RetroArch on macOS ships without controller profiles, so pads (and the hotkeys on them) do nothing: fetch the official set once
const RAAUTO = () => path.join(HOME, 'Library/Application Support/RetroArch/autoconfig');
let AUTOGET = false;
async function ensureAutoconfig() {
  if (!MAC || AUTOGET) return; const d = RAAUTO();
  try { if (fs.existsSync(d) && fs.readdirSync(d).length > 5) return; } catch {}
  AUTOGET = true;
  try {
    fs.mkdirSync(d, { recursive: true }); const z = path.join(os.tmpdir(), 'autoconfig.zip');
    await dlFile('https://buildbot.libretro.com/assets/frontend/autoconfig.zip', z);
    await sh('/usr/bin/unzip', ['-o', '-q', z, '-d', d], 120000); fs.rmSync(z, { force: true });
    logEv('autoconfig: controller profiles installed');
  } catch (e) { logEv('autoconfig: ' + e.message); AUTOGET = false; }
}
async function installCores() {
  const c = load(), dir = coresDir(c), raA = MAC ? macArchs(c.retroarch) : [], arch = raA.length ? (raA.includes('arm64') ? 'arm64' : 'x86_64') : (process.arch === 'arm64' ? 'arm64' : 'x86_64'), have = scan(c).map(s => s.id); // the cores must match RetroArch's own processor type, which is not always this app's
  fs.mkdirSync(dir, { recursive: true }); await ensureAutoconfig();
  const want = new Set(); // every core Cacti knows for every system, so switching a system's core never waits on a download
  for (const s of SYSTEMS) { want.add(coreFor(c, s).id); for (const x of s.cores) if (x.ra !== false) want.add(x.id); }
  for (const s of EMU.XSYS) if (s.rcore) want.add(s.rcore.id);
  let ok = 0; const fail = [];
  for (const core of want) {
    const f = core + EXT, dst = path.join(dir, f);
    if (fs.existsSync(dst) && MAC && raA.length) { const ca = macArchs(dst); if (ca.length && !ca.some(a => raA.includes(a))) { try { fs.rmSync(dst, { force: true }); } catch {} } } // a core built for the other processor type is replaced
    if (fs.existsSync(dst)) { await prepCore(dst); continue; }
    if (coreFile(c, core)) continue; // already provided by RetroArch itself (for example inside the Flatpak)
    try {
      const r = await fetch(MAC ? `https://buildbot.libretro.com/nightly/apple/osx/${arch}/latest/${f}.zip` : WIN ? `https://buildbot.libretro.com/nightly/windows/x86_64/latest/${f}.zip` : `https://buildbot.libretro.com/nightly/linux/${process.arch === 'arm64' ? 'aarch64' : 'x86_64'}/latest/${f}.zip`, { signal: AbortSignal.timeout(90000) });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const zip = path.join(os.tmpdir(), f + '.zip'); fs.writeFileSync(zip, Buffer.from(await r.arrayBuffer()));
      if (WIN) await sh('tar', ['-xf', zip, '-C', dir], 60000); else { for (const [cmd, args] of [['/usr/bin/unzip', ['-o', '-q', zip, '-d', dir]], ['unzip', ['-o', '-q', zip, '-d', dir]], ['bsdtar', ['-xf', zip, '-C', dir]], ['python3', ['-m', 'zipfile', '-e', zip, dir]]]) { await sh(cmd, args, 60000); if (fs.existsSync(dst)) break; } } fs.rmSync(zip, { force: true });
      if (!fs.existsSync(dst)) throw new Error('unzip failed');
      await prepCore(dst); ok++;
    } catch (e) { fail.push(`${core}: ${e.message}`); }
  }
  return { ok, fail };
}
const fpRun = (args, ms = 1800000) => new Promise((res, rej) => execFile('flatpak', args, { timeout: ms, maxBuffer: 1 << 24 }, (e, o, se) => e ? rej(new Error(String(se || e.message).trim().split('\n').filter(Boolean).pop().slice(0, 160))) : res(String(o))));
async function dlFile(url, dest) { // direct downloads only from the official libretro build server
  if (new URL(url).hostname !== 'buildbot.libretro.com') throw new Error('Refusing a download from ' + new URL(url).hostname);
  const r = await fetch(url, { redirect: 'follow', signal: AbortSignal.timeout(900000) }); if (!r.ok) throw new Error('Download failed: HTTP ' + r.status);
  fs.writeFileSync(dest, Buffer.from(await r.arrayBuffer()));
}
async function installRetroArch() {
  try {
    if (LINUX) {
      if (!fs.existsSync('/usr/bin/flatpak')) return { error: 'Flatpak is not installed on this system. Install RetroArch with your package manager.' };
      await fpRun(['remote-add', '--user', '--if-not-exists', 'flathub', 'https://dl.flathub.org/repo/flathub.flatpakrepo'], 60000).catch(() => {});
      await fpRun(['install', '--user', '-y', '--noninteractive', 'flathub', FPRA]);
      await fpRun(['override', '--user', '--filesystem=host', '--filesystem=/run/media', FPRA]).catch(() => {});
      writeWrap(RAWRAP, FPRA); const c = load(); c.retroarch = RAWRAP; save(c);
      return { installed: true };
    }
    if (WIN) {
      const dir = path.join(app.getPath('userData'), 'RetroArch'), z = path.join(os.tmpdir(), 'RetroArch.7z');
      await dlFile('https://buildbot.libretro.com/nightly/windows/x86_64/RetroArch.7z', z);
      fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
      await sh('tar', ['-xf', z, '-C', dir], 600000); fs.rmSync(z, { force: true });
      const find = (d, n) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isFile() && e.name.toLowerCase() === 'retroarch.exe') return p; if (e.isDirectory() && n > 0) { const f = find(p, n - 1); if (f) return f; } } return null; };
      const exe = find(dir, 2); if (!exe) return { error: 'Downloaded, but retroarch.exe was not found inside.' };
      const c = load(); c.retroarch = exe; save(c); return { installed: true };
    }
    const b = brew();
    if (b) return await new Promise(r => execFile(b, ['install', '--cask', 'retroarch'], { timeout: 900000 }, e => r(e ? { error: String(e.message).slice(0, 120) } : { installed: true })));
    const dmg = path.join(os.tmpdir(), 'RetroArch.dmg'), mnt = fs.mkdtempSync(path.join(os.tmpdir(), 'ra-dmg-')); await dlFile('https://buildbot.libretro.com/nightly/apple/osx/universal/RetroArch_Metal.dmg', dmg);
    try { await sh('/usr/bin/hdiutil', ['attach', '-nobrowse', '-readonly', '-mountpoint', mnt, dmg], 120000); const a = fs.readdirSync(mnt).find(x => x.endsWith('.app')); if (!a) throw new Error('No app inside the disk image'); fs.mkdirSync(path.join(HOME, 'Applications'), { recursive: true }); await sh('/usr/bin/ditto', [path.join(mnt, a), path.join(HOME, 'Applications', 'RetroArch.app')], 300000); }
    finally { await sh('/usr/bin/hdiutil', ['detach', mnt, '-force'], 60000); fs.rmSync(dmg, { force: true }); }
    return { installed: true };
  } catch (e) { return { error: String(e.message || e).slice(0, 160) }; }
}

// ---------- Wi-Fi / volume ----------
async function wifiLinux() { // Raspberry Pi OS / Linux via NetworkManager
  const en = (await sh('nmcli', ['radio', 'wifi'])).trim() === 'enabled';
  let ssid = null, sig = null, rate = null, ch = null, sec = null;
  if (en) {
    const row = (await sh('nmcli', ['-t', '-f', 'ACTIVE,SSID,SIGNAL,RATE,CHAN,SECURITY', 'dev', 'wifi'], 8000)).split('\n').find(l => l.startsWith('yes:'));
    if (row) { const p = row.replace(/\\:/g, '\u0000').split(':').map(x => x.replace(/\u0000/g, ':')); ssid = p[1] || null; sig = +p[2]; rate = (p[3] || '').replace(/[^\d.]/g, ''); ch = p[4]; sec = p[5]; }
  }
  const ip = ((await sh('hostname', ['-I'])).trim().split(/\s+/)[0]) || '';
  const wired = /ethernet:connected/.test(await sh('nmcli', ['-t', '-f', 'TYPE,STATE', 'dev']));
  return { supported: true, dev: 'wlan0', power: en, ip, ssid, rssi: sig ? Math.round(sig / 2 - 100) : null, rate: rate || null, channel: ch || null, security: sec || null, wired, wiredIf: wired ? 'Ethernet' : '', connected: !!ip || wired };
}
async function wifiWin() { // Windows via netsh
  const o = await sh('netsh', ['wlan', 'show', 'interfaces'], 8000), g = k => ((o.match(new RegExp('^\\s*' + k + '\\s*:\\s*(.+)$', 'mi')) || [])[1] || '').trim();
  const nets = os.networkInterfaces(); let ip = '', wired = false, wiredIf = '';
  for (const [n, a] of Object.entries(nets)) { const v4 = (a || []).find(x => x.family === 'IPv4' && !x.internal); if (!v4) continue; if (/wi-?fi|wlan|wireless/i.test(n)) ip = v4.address; else if (/ethernet/i.test(n)) { wired = true; wiredIf = n; if (!ip) ip = v4.address; } }
  const state = g('State'), ssid = state.toLowerCase() == 'connected' ? g('SSID') : '', sig = parseInt(g('Signal'), 10);
  return { supported: true, dev: g('Name') || 'Wi-Fi', power: !!o.trim() && !/disconnected|hardware off|software off/i.test(g('Radio status') || ''), ip, ssid: ssid || null, rssi: Number.isFinite(sig) ? Math.round(sig / 2 - 100) : null, rate: g('Receive rate \\(Mbps\\)') || null, channel: g('Channel') || null, security: g('Authentication') || null, wired, wiredIf, connected: !!ip || wired };
}
async function wifi() {
  if (LINUX) return wifiLinux();
  if (WIN) return wifiWin();
  if (!MAC) return { supported: false };
  const hp = await sh('/usr/sbin/networksetup', ['-listallhardwareports']);
  const dev = (hp.match(/Hardware Port: (?:Wi-Fi|AirPort)\s*\nDevice: (\w+)/) || [])[1] || 'en0';
  const power = /:\s*On/i.test(await sh('/usr/sbin/networksetup', ['-getairportpower', dev]));
  const ip = (await sh('/usr/sbin/ipconfig', ['getifaddr', dev])).trim();
  let ssid = '', rssi = null, rate = null, channel = null, security = null;
  if (power) {
    const a = (await sh('/usr/sbin/networksetup', ['-getairportnetwork', dev])).match(/Current Wi-Fi Network:\s*(.+)/); if (a) ssid = a[1].trim();
    if (ip) {
      const sp = await sh('/usr/sbin/system_profiler', ['SPAirPortDataType'], 15000);
      const blk = sp.match(/Current Network Information:\s*\n\s*(.+?):\s*\n([\s\S]*?)(?:\n\s*\n|\n\s*Other Local Wi-Fi Networks:|$)/);
      if (blk) {
        const n = blk[1].trim(); if (!ssid && !/redacted/i.test(n)) ssid = n;
        const b = blk[2];
        rssi = (b.match(/Signal \/ Noise:\s*(-?\d+)/) || [])[1]; rate = (b.match(/Transmit Rate:\s*(\d+)/) || [])[1];
        channel = (b.match(/Channel:\s*(.+)/) || [])[1]; security = (b.match(/Security:\s*(.+)/) || [])[1];
      }
      if (!ssid) { const s = (await sh('/usr/sbin/ipconfig', ['getsummary', dev])).match(/\bSSID\s*:\s*(.+)/); if (s && !/redacted/i.test(s[1])) ssid = s[1].trim(); }
    }
  }
  const ri = ((await sh('/sbin/route', ['-n', 'get', 'default'])).match(/interface:\s*(\w+)/) || [])[1];
  const wired = !!ri && ri !== dev;
  return { supported: true, dev, power, ip, ssid: ssid || null, rssi: rssi ? +rssi : null, rate: rate || null, channel: channel ? channel.trim() : null, security: security ? security.trim() : null, wired, wiredIf: wired ? ri : '', connected: !!ip || wired };
}

// ---------- RetroArch netplay lobbies ----------
const nk = t => String(t).toLowerCase().replace(/^the /, '').replace(/[^a-z0-9]/g, '');
async function lobbies() {
  let list = null, err = '';
  for (const u of ['https://lobby.libretro.com/list/', 'http://lobby.libretro.com/list/']) {
    try { const r = await fetch(u, { signal: AbortSignal.timeout(10000) }); if (r.ok) { list = await r.json(); break; } err = 'HTTP ' + r.status; } catch (e) { err = e.message; }
  }
  if (!Array.isArray(list)) return { error: 'Could not reach the lobby server (' + err + ')' };
  const c = load(), lib = scan(c);
  const rooms = list.map(e => e.fields || e).filter(f => f && f.game_name).map(f => {
    const mitm = f.host_method === 3 && f.mitm_ip;
    // Find the room's game in our library using the room's own emulator, so joining launches exactly what the host runs.
    const rc = nk(f.core_name || ''), gn = nk(f.game_name); let mine = null;
    if (rc) for (const sd of lib) {
      const core = ((SYSTEMS.find(x => x.id === sd.id) || {}).cores || []).find(x => rc.includes(nk(x.name)) || nk(x.name).includes(rc)); if (!core) continue;
      const g = sd.games.find(x => nk(x.title) === gn) || sd.games.find(x => nk(x.title).startsWith(gn) || gn.startsWith(nk(x.title)));
      if (g) { mine = { file: g.file, sys: sd.id, core: core.id }; break; }
    }
    const compat = !!mine;
    return { user: f.username || 'Player', game: f.game_name, core: f.core_name || '', country: (f.country || '').toUpperCase(), host: mitm ? f.mitm_ip : f.ip, port: mitm ? f.mitm_port : f.port, locked: !!f.has_password, ver: f.retroarch_version || '', mine, compat };
  });
  rooms.sort((a, b) => (b.mine ? 1 : 0) - (a.mine ? 1 : 0) || a.game.localeCompare(b.game));
  return { rooms };
}

// ---------- RetroAchievements Web API ----------
const RA = 'https://retroachievements.org/API/', MEDIA = 'https://media.retroachievements.org';
const norm = t => String(t).toLowerCase().replace(/^the /, '').replace(/[^a-z0-9]/g, '');
async function ra(ep, params, c) {
  const q = new URLSearchParams({ z: c.raUser, y: c.raKey, ...params });
  const r = await fetch(`${RA}${ep}.php?${q}`, { signal: AbortSignal.timeout(20000) });
  const t = await r.text(); let j; try { j = JSON.parse(t); } catch {}
  if (!r.ok || (j && !Array.isArray(j) && j.message && Object.keys(j).length <= 3)) throw new Error((j && j.message) || `HTTP ${r.status}`);
  return j;
}
async function completion(c, u = c.raUser) {
  try {
    let rows = [], o = 0, total = 1;
    while (o < total && o < 5000) { const j = await ra('API_GetUserCompletionProgress', { u, c: 500, o }, c); rows = rows.concat(j.Results || []); total = j.Total || 0; o += 500; }
    return rows;
  } catch { return await ra('API_GetUserCompletedGames', { u }, c); }
}
// ----- per-game achievement list (the X menu) -----
// Per-console lists of every game that has achievements (one request per console, cached on disk for 7 days).
const RLF = () => path.join(app.getPath('userData'), 'ra-lists.json');
let rlDisk = null, rlState = 'idle'; const rlIdx = {};
const rlLoad = () => { if (!rlDisk) { try { rlDisk = JSON.parse(fs.readFileSync(RLF(), 'utf8')); } catch { rlDisk = {}; } } return rlDisk; };
async function raList(c, rc) {
  const d = rlLoad(), e = d[rc]; if (e && e.v === 2 && Date.now() - e.t < 7 * 864e5) return e.games;
  const j = await ra('API_GetGameList', { i: rc, f: 1, h: 1 }, c);
  const games = (Array.isArray(j) ? j : []).map(g => [g.ID, g.Title, Number(g.NumAchievements) || 0, (Array.isArray(g.Hashes) ? g.Hashes : []).map(x => String(x).toLowerCase())]);
  d[rc] = { v: 2, t: Date.now(), games }; try { fs.writeFileSync(RLF(), JSON.stringify(d)); } catch {}
  return games;
}
function rlFind(rc, games, title) {
  let x = rlIdx[rc]; if (!x || x.games !== games) { const arr = games.map(g => ({ k: norm(g[1]), g })), map = new Map(); arr.forEach(o => { if (!map.has(o.k)) map.set(o.k, o.g); }); x = rlIdx[rc] = { games, arr, map }; }
  const k = norm(title); if (!k) return null;
  if (!x.miss) x.miss = new Map(); if (x.miss.has(k)) return x.miss.get(k);
  const hit = x.map.get(k) || (x.arr.find(o => o.k && (o.k.startsWith(k) || (k.length > 4 && k.startsWith(o.k)))) || {}).g;
  x.miss.set(k, hit || null); return hit || null;
}
const idMap = {};
async function raGameId(c, sysId, title) {
  const rc = RC[sysId], k = norm(title); if (!rc) return null;
  if (idMap[rc + ':' + k]) return idMap[rc + ':' + k];
  const m = rlFind(rc, await raList(c, rc), title);
  return m ? m[0] : null;
}
// Runs at start-up when signed in: fills the lists in the background, then tells the screen.
async function raWarm() {
  const c = load(); if (!c.raUser || !c.raKey) return;
  rlState = 'loading';
  try { const have = new Set(scan(c).map(x => x.id)); for (const rc of Object.keys(RC).filter(k => have.has(k) || SYSTEMS.some(x => x.id === k)).map(k => RC[k])) { const cached = rlLoad()[rc] && Date.now() - rlLoad()[rc].t < 7 * 864e5; await raList(c, rc); if (!cached) await new Promise(r => setTimeout(r, 400)); } rlState = 'ready'; }
  catch { rlState = 'failed'; }
  send('ra-lists', rlState);
}
// Totals for the games on screen, from the cached lists only (no network): n > 0 total, -1 no set, 0 set found but count unknown, null not loaded.
function raTotals(games) {
  const d = rlLoad();
  return { state: rlState, totals: (Array.isArray(games) ? games : []).map(g => { const rc = RC[g && g.sys], e = rc && d[rc]; if (!e) return null; const m = rlFind(rc, e.games, g.title); return m ? (m[2] > 0 ? m[2] : 0) : -1; }) };
}
async function raGame({ sys, title, gameId }) {
  const c = load();
  if (!c.raUser || !c.raKey) return { error: 'Add your RetroAchievements username and Web API key first (Menu > RetroAchievements).' };
  try {
    const id = gameId ? Number(gameId) : await raGameId(c, sys, title);
    if (!id) return { error: 'No RetroAchievements set was found for this game. Hacks and translations are not supported.' };
    const j = await ra('API_GetGameInfoAndUserProgress', { g: id, u: c.raUser }, c);
    const list = Object.values(j.Achievements || {}).map(a => {
      const date = a.DateEarnedHardcore || a.DateEarned || null;
      return { id: a.ID, title: a.Title, desc: a.Description, points: a.Points || 0, date, hard: !!a.DateEarnedHardcore, order: a.DisplayOrder || 0, badge: `${MEDIA}/Badge/${a.BadgeName}${date ? '' : '_lock'}.png` };
    }).sort((x, y) => x.order - y.order || x.id - y.id);
    const earned = list.filter(x => x.date);
    return { title: j.Title || title, icon: j.ImageIcon ? MEDIA + j.ImageIcon : '', total: list.length, earned: earned.length, points: list.reduce((n, x) => n + x.points, 0), earnedPoints: earned.reduce((n, x) => n + x.points, 0), list };
  } catch (e) { return { error: 'RetroAchievements: ' + e.message }; }
}

// Achievement totals for games with no progress yet, so the home screen can say "0 of 36". Cached on disk: one request per game, once.
const RCF = () => path.join(app.getPath('userData'), 'ra-counts.json');
let rcCache = null;
const rcLoad = () => { if (!rcCache) { try { rcCache = JSON.parse(fs.readFileSync(RCF(), 'utf8')); } catch { rcCache = {}; } } return rcCache; };
async function raCount({ sys, title, gameId }) {
  const c = load(); if (!c.raUser || !c.raKey) return { signedOut: true };
  const key = String(sys || '') + ':' + norm(title), cache = rcLoad(), e = cache[key], now = Date.now();
  if (e && now - e.t < (e.total ? 30 : 7) * 864e5) return { total: e.total, id: e.id };
  try {
    const id = gameId ? Number(gameId) : await raGameId(c, sys, title); let out;
    if (!id) out = { id: 0, total: 0 };
    else { const j = await ra('API_GetGameInfoAndUserProgress', { g: id, u: c.raUser }, c); out = { id, total: Object.keys(j.Achievements || {}).length }; }
    cache[key] = { ...out, t: now }; try { fs.writeFileSync(RCF(), JSON.stringify(cache)); } catch {}
    return out;
  } catch (err) { return { error: String(err.message || err) }; }
}
async function raRecentGames() {
  const c = load();
  if (!c.raUser || !c.raKey) return { error: 'Add your RetroAchievements username and Web API key first (Menu > RetroAchievements).' };
  try {
    const j = await ra('API_GetUserRecentlyPlayedGames', { u: c.raUser, c: 30 }, c);
    const games = (Array.isArray(j) ? j : []).map(g => ({ gameId: g.GameID, title: g.Title, console: g.ConsoleName || '', icon: g.ImageIcon ? MEDIA + g.ImageIcon : '', total: g.NumPossibleAchievements || 0, earned: g.NumAchieved || 0, last: g.LastPlayed || '' }));
    return { games };
  } catch (e) { return { error: 'RetroAchievements: ' + e.message }; }
}
// ---------- Profile Overview + Leaderboards (loaded only when the screen is opened; results are cached) ----------
const PL = () => path.join(app.getPath('userData'), 'playlog.json');
function logPlay(secs, title, sys) { try { const pn = !GUEST && load().profile; if (pn) { const f = path.join(app.getPath('userData'), 'prof-last.json'); let o = {}; try { o = JSON.parse(fs.readFileSync(f, 'utf8')); } catch {} o[pn] = { g: String(title || '').slice(0, 120), t: Date.now() }; fs.writeFileSync(f, JSON.stringify(o)); } } catch {} try { let l = []; try { l = JSON.parse(fs.readFileSync(PL(), 'utf8')); } catch {} l.push({ t: Date.now(), s: secs, g: String(title || '').slice(0, 120), y: sys || '' }); fs.writeFileSync(PL(), JSON.stringify(l.slice(-3000))); } catch {} }
function playHistory() { // local only: no network
  let log = []; try { log = JSON.parse(fs.readFileSync(PL(), 'utf8')); } catch {}
  const nm = id => (ALL.find(x => x.id === id) || {}).name || '';
  const sessions = log.slice(-60).reverse().map(e => ({ t: e.t, secs: e.s, title: e.g || 'Unknown game', sys: nm(e.y) }));
  const st = getStats(), top = Object.entries(st).map(([f, e]) => ({ title: clean(f), secs: e.secs || 0, plays: e.plays || 0, last: e.last || 0 })).sort((a, b) => b.secs - a.secs).slice(0, 8);
  const day = Date.now() - 7 * 864e5, week = log.filter(e => e.t >= day).reduce((n, e) => n + e.s, 0);
  return { sessions, top, weekSecs: week, totalSecs: Object.values(st).reduce((n, e) => n + (e.secs || 0), 0), totalPlays: Object.values(st).reduce((n, e) => n + (e.plays || 0), 0) };
}
// Casual (softcore) rank: the Web API's rank can be empty for softcore players, but the public profile page shows "Casual Rank: #49,060 of 209,190".
async function casualRank(c, p) {
  const num = x => parseInt(String(x).replace(/[^0-9]/g, ''), 10) || 0;
  try { // the profile summary carries Rank / TotalRanked too
    const j = await ra('API_GetUserSummary', { u: c.raUser, g: 0, a: 0 }, c);
    if (j && j.Rank > 0) return { rank: num(j.Rank), ranked: num(j.TotalRanked), kind: 'casual' };
  } catch {}
  try {
    const r = await fetch('https://retroachievements.org/user/' + encodeURIComponent(c.raUser), { signal: AbortSignal.timeout(15000), headers: { 'User-Agent': 'CactiOS' } });
    const t = (await r.text()).replace(/<[^>]+>/g, ' ').replace(/&nbsp;|\s+/g, ' ');
    const m = t.match(/(Casual|Softcore)\s+Rank:?\s*#?\s*([\d,]+)\s+of\s+([\d,]+)/i);
    if (m) return { rank: num(m[2]), ranked: num(m[3]), kind: 'casual' };
  } catch {}
  return null;
}
let ovCache = null;
async function raOverview(force) {
  const c = load();
  if (!c.raUser || !c.raKey) return { error: 'Add your RetroAchievements username and Web API key first (Menu > RetroAchievements).' };
  if (!force && ovCache && ovCache.user === c.raUser && Date.now() - ovCache.t < 30 * 60e3) return ovCache.d;
  try {
    const [p, cg, rk, ru] = await Promise.allSettled([ra('API_GetUserProfile', { u: c.raUser }, c), completion(c), ra('API_GetUserRankAndScore', { u: c.raUser }, c), ra('API_GetUserRecentAchievements', { u: c.raUser, m: 60 * 24 * 365 }, c)]);
    if (p.status === 'rejected') throw p.reason;
    const rows = Array.isArray(cg.value) ? cg.value : [], by = {}, kind = g => String(g.HighestAwardKind || '').toLowerCase();
    let unlocked = 0, totalAch = 0, mastered = 0, beaten = 0;
    for (const g of rows) {
      const e = Math.max(g.NumAwarded || 0, g.NumAwardedHardcore || 0); unlocked += e; totalAch += g.MaxPossible || 0;
      if (kind(g) === 'mastered') mastered++; else if (kind(g).startsWith('beaten')) beaten++;
      const k = g.ConsoleName || 'Other'; const b = by[k] || (by[k] = { name: k, games: 0, earned: 0, total: 0 }); b.games++; b.earned += e; b.total += g.MaxPossible || 0;
    }
    const consoles = Object.values(by).filter(b => b.total).sort((a, b) => b.games - a.games).slice(0, 6).map(b => ({ ...b, pct: Math.round(100 * b.earned / b.total) }));
    const byDate = (a, b) => String(b.MostRecentAwardedDate || b.HighestAwardDate || '').localeCompare(String(a.MostRecentAwardedDate || a.HighestAwardDate || ''));
    const medals = rows.filter(g => kind(g) === 'mastered').sort((a, b) => String(b.HighestAwardDate || '').localeCompare(String(a.HighestAwardDate || ''))).slice(0, 6).map(g => ({ gameId: g.GameID, title: g.Title, icon: g.ImageIcon ? MEDIA + g.ImageIcon : '' }));
    const recentRows = rows.slice().sort(byDate);
    const recent = recentRows.slice(0, 5).map(g => ({ title: g.Title, sub: `${Math.max(g.NumAwarded || 0, g.NumAwardedHardcore || 0)} of ${g.MaxPossible || 0} achievements`, when: String(g.MostRecentAwardedDate || '').slice(0, 10), kind: kind(g) }));
    const games = recentRows.slice(0, 12).map(g => ({ gameId: g.GameID, title: g.Title, console: g.ConsoleName || '', icon: g.ImageIcon ? MEDIA + g.ImageIcon : '' }));
    const seenA = new Set(), unlocks = (Array.isArray(ru.value) ? ru.value : []).sort((a, b) => String(b.Date).localeCompare(String(a.Date))).filter(r => !seenA.has(r.AchievementID) && seenA.add(r.AchievementID)).slice(0, 60).map(r => ({ id: r.AchievementID, title: r.Title || '', desc: r.Description || '', points: r.Points || 0, game: r.GameTitle || '', console: r.ConsoleName || '', when: String(r.Date || '').slice(0, 10), hard: !!r.HardcoreMode, badge: r.BadgeURL ? MEDIA + r.BadgeURL : (r.BadgeName ? `${MEDIA}/Badge/${r.BadgeName}.png` : '') }));
    const st = getStats(), secs = Object.values(st).reduce((n, e) => n + (e.secs || 0), 0);
    let log = []; try { log = JSON.parse(fs.readFileSync(PL(), 'utf8')); } catch {}
    const wk = 7 * 864e5, now = Date.now(), weeks = Array.from({ length: 12 }, (_, i) => ({ l: i === 11 ? 'Now' : (11 - i) + 'w', h: 0 }));
    for (const e of log) { const i = 11 - Math.floor((now - e.t) / wk); if (i >= 0 && i < 12) weeks[i].h += e.s / 3600; }
    weeks.forEach(w => { w.h = Math.round(w.h * 10) / 10; });
    const r = rk.status === 'fulfilled' && rk.value && !Array.isArray(rk.value) ? rk.value : {};
    let rank = r.Rank || 0, ranked = r.TotalRanked || 0, rkind = 'hardcore';
    if (!rank) { const cr = await casualRank(c, p.value); if (cr) { rank = cr.rank; ranked = cr.ranked; rkind = cr.kind; } }
    const d = { user: p.value.User || c.raUser, points: p.value.TotalPoints || 0, softPoints: p.value.TotalSoftcorePoints || 0, rank, ranked, rkind, hardcore: !!c.hardcore, unlocked, totalAch, played: rows.length, mastered, beaten, hours: Math.round(secs / 360) / 10, consoles, medals, recent, games, weeks, unlocks, logged: log.length };
    ovCache = { user: c.raUser, t: Date.now(), d }; return d;
  } catch (e) { return { error: 'RetroAchievements: ' + e.message }; }
}
const lbCache = new Map(); // key -> { t, v }
async function lbGet(key, ttl, fn) { const e = lbCache.get(key); if (e && Date.now() - e.t < ttl) return e.v; const v = await fn(); lbCache.set(key, { t: Date.now(), v }); return v; }
async function raBoards(gameId) {
  const c = load(); gameId = Number(gameId);
  if (!c.raUser || !c.raKey) return { error: 'Add your RetroAchievements username and Web API key first.' };
  if (!gameId) return { error: 'Pick a game.' };
  try {
    return await lbGet('b' + gameId, 3600e3, async () => {
      const [g, u] = await Promise.allSettled([ra('API_GetGameLeaderboards', { i: gameId, c: 100 }, c), ra('API_GetUserGameLeaderboards', { i: gameId, u: c.raUser, c: 100 }, c)]);
      if (g.status === 'rejected') throw g.reason;
      const list = j => (Array.isArray(j) ? j : (j && j.Results) || []), mine = {};
      if (u.status === 'fulfilled') for (const b of list(u.value)) if (b.UserEntry) mine[b.ID] = { rank: b.UserEntry.Rank, score: b.UserEntry.FormattedScore, date: String(b.UserEntry.DateUpdated || '').slice(0, 10) };
      return { boards: list(g.value).map(b => ({ id: b.ID, name: b.Title || 'Leaderboard', desc: b.Description || '', lowWins: !!b.RankAsc, top: b.TopEntry ? { user: b.TopEntry.User, score: b.TopEntry.FormattedScore } : null, mine: mine[b.ID] || null })) };
    });
  } catch (e) { return { error: 'RetroAchievements: ' + e.message }; }
}
const UNAME = /^[A-Za-z0-9_.\-]{2,32}$/;
async function followRows(c, force) { // the people you follow, shared by the leaderboard and the Friends panel (cached 30 min)
  const key = 'follow:' + c.raUser.toLowerCase(); if (force) lbCache.delete(key);
  return lbGet(key, 1800e3, async () => {
    const f = await ra('API_GetUsersIFollow', { c: 500 }, c), list = Array.isArray(f) ? f : (f && (f.Results || f.results)) || [], g = (o, ...k) => { for (const x of k) if (o && o[x] != null) return o[x]; return 0; };
    return list.map(e => ({ user: String(e.User || e.user || ''), points: Number(g(e, 'Points', 'points')), soft: Number(g(e, 'PointsSoftcore', 'pointsSoftcore')), back: !!(e.IsFollowingMe ?? e.isFollowingMe), me: false })).filter(p => UNAME.test(p.user));
  });
}
async function raTop(force) { // the people you follow, ranked by points, with you included
  const c = load();
  if (!c.raUser || !c.raKey) return { error: 'Add your RetroAchievements username and Web API key first.' };
  try {
    const [f, m] = await Promise.allSettled([followRows(c, force), lbGet('me:' + c.raUser.toLowerCase(), 600e3, () => ra('API_GetUserRankAndScore', { u: c.raUser }, c))]);
    if (f.status === 'rejected') throw f.reason;
    const g = (o, ...k) => { for (const x of k) if (o && o[x] != null) return o[x]; return 0; }, me = m.status === 'fulfilled' && m.value ? m.value : {};
    const meRow = { user: c.raUser, points: Number(g(me, 'Score', 'score')), soft: Number(g(me, 'SoftcoreScore', 'softcoreScore')), me: true, back: false };
    const players = [...f.value, meRow].sort((a, b) => b.points - a.points || b.soft - a.soft).map((p, i) => ({ ...p, rank: i + 1 }));
    return { players, following: f.value.length };
  } catch (e) { return { error: 'RetroAchievements: ' + e.message }; }
}
// ----- friends: followed players, their status, their achievements, and a comparison with yours -----
const pic = u => `${MEDIA}/UserPic/${encodeURIComponent(u)}.png`;
async function raFriends(force) {
  const c = load(); if (!c.raUser || !c.raKey) return { error: 'Add your RetroAchievements username and Web API key first (Menu > RetroAchievements).' };
  try { const rows = await followRows(c, !!force); return { friends: [...rows].sort((a, b) => b.points - a.points).map(r => ({ ...r, pic: pic(r.user) })) }; } catch (e) { return { error: 'RetroAchievements: ' + e.message }; }
}
async function raSummaries(users) { // rich presence + last game for a handful of friends (cached 5 min, four at a time)
  const c = load(); if (!c.raUser || !c.raKey) return {};
  users = (Array.isArray(users) ? users : []).map(String).filter(u => UNAME.test(u)).slice(0, 12); const out = {}; let i = 0;
  await Promise.all(Array.from({ length: 4 }, async () => { while (i < users.length) { const u = users[i++]; try { out[u] = await lbGet('sum:' + u.toLowerCase(), 300e3, async () => { const j = await ra('API_GetUserSummary', { u, g: 1, a: 0 }, c), lg = j.LastGame || {}; return { points: Number(j.TotalPoints) || 0, presence: String(j.RichPresenceMsg || ''), date: String(j.RichPresenceMsgDate || ''), game: String(lg.Title || ''), status: String(j.Status || '') }; }); } catch { out[u] = null; } } }));
  return out;
}
async function raFriendGames(user) {
  const c = load(); user = String(user || ''); if (!c.raUser || !c.raKey || !UNAME.test(user)) return { error: 'Not available.' };
  try {
    const [t, m] = await Promise.all([lbGet('cp:' + user.toLowerCase(), 600e3, () => completion(c, user)), lbGet('cp:' + c.raUser.toLowerCase(), 600e3, () => completion(c))]);
    const map = rows => (Array.isArray(rows) ? rows : []).map(g => ({ gameId: g.GameID, title: g.Title, console: g.ConsoleName || '', icon: g.ImageIcon ? MEDIA + g.ImageIcon : '', earned: Math.max(g.NumAwarded || 0, g.NumAwardedHardcore || 0), total: g.MaxPossible || 0, kind: String(g.HighestAwardKind || '').toLowerCase(), date: String(g.MostRecentAwardedDate || g.HighestAwardDate || '') }));
    const them = map(t).sort((a, b) => b.date.localeCompare(a.date)), me = map(m), mine = new Map(me.map(g => [g.gameId, g]));
    const sum = a => ({ games: a.length, achievements: a.reduce((n, g) => n + g.earned, 0), mastered: a.filter(g => g.kind === 'mastered').length, beaten: a.filter(g => g.kind.startsWith('beaten')).length });
    return { them: them.slice(0, 400), shared: them.filter(g => mine.has(g.gameId)).slice(0, 400).map(g => ({ ...g, mine: mine.get(g.gameId).earned })), sumThem: sum(them), sumMe: sum(me) };
  } catch (e) { return { error: 'RetroAchievements: ' + e.message }; }
}
async function raFriendGame({ user, gameId }) {
  const c = load(); user = String(user || ''); gameId = Number(gameId); if (!c.raUser || !c.raKey || !UNAME.test(user) || !gameId) return { error: 'Not available.' };
  try {
    const [t, m] = await Promise.all([ra('API_GetGameInfoAndUserProgress', { g: gameId, u: user }, c), ra('API_GetGameInfoAndUserProgress', { g: gameId, u: c.raUser }, c)]);
    const mine = m.Achievements || {}, d = x => (x && (x.DateEarnedHardcore || x.DateEarned)) || null;
    const list = Object.values(t.Achievements || {}).map(a => { const mm = mine[a.ID] || mine[String(a.ID)], them = d(a), me = d(mm); return { id: a.ID, title: a.Title, desc: a.Description, points: a.Points || 0, order: a.DisplayOrder || 0, badge: `${MEDIA}/Badge/${a.BadgeName}${them ? '' : '_lock'}.png`, them, me }; }).sort((x, y) => x.order - y.order || x.id - y.id);
    return { title: t.Title || '', icon: t.ImageIcon ? MEDIA + t.ImageIcon : '', total: list.length, themEarned: list.filter(x => x.them).length, meEarned: list.filter(x => x.me).length, list };
  } catch (e) { return { error: 'RetroAchievements: ' + e.message }; }
}
async function raFriendAdd(name) { // RetroAchievements has no follow call in its API, so we check the name and open their profile to press Follow
  const c = load(); name = String(name || '').trim(); if (!c.raUser || !c.raKey) return { error: 'Add your RetroAchievements username and Web API key first.' };
  if (!UNAME.test(name)) return { error: 'That does not look like a RetroAchievements username.' };
  try { const j = await ra('API_GetUserProfile', { u: name }, c), u = j && (j.User || j.user); if (!u) return { error: 'No RetroAchievements user with that name.' }; shell.openExternal('https://retroachievements.org/user/' + encodeURIComponent(u)); return { ok: true, user: u }; }
  catch (e) { return { error: /404|not found/i.test(e.message) ? 'No RetroAchievements user with that name.' : 'RetroAchievements: ' + e.message }; }
}
function raFriendOpen(user) { user = String(user || ''); if (!UNAME.test(user)) return false; shell.openExternal('https://retroachievements.org/user/' + encodeURIComponent(user)); return true; }
async function raEntries({ id, mode, rank }) {
  const c = load(); id = Number(id);
  if (!c.raUser || !c.raKey || !id) return { error: 'Not available.' };
  const near = mode === 'near' && Number(rank) > 0, off = near ? Math.max(0, Number(rank) - 6) : 0;
  try {
    return await lbGet(`e${id}:${off}`, 900e3, async () => {
      const j = await ra('API_GetLeaderboardEntries', { i: id, c: near ? 11 : 10, o: off }, c);
      return { total: j.Total || 0, entries: (j.Results || []).map(e => ({ rank: e.Rank, user: e.User, score: e.FormattedScore || String(e.Score), date: String(e.DateSubmitted || '').slice(0, 10), me: String(e.User).toLowerCase() === c.raUser.toLowerCase() })) };
    });
  } catch (e) { return { error: 'RetroAchievements: ' + e.message }; }
}

async function raRefresh() {
  const c = load();
  if (!c.raUser || !c.raKey) return { error: 'Add your RetroAchievements username and Web API key in Menu > RetroAchievements.' };
  try {
    const [p, cg, aw, rc] = await Promise.allSettled([ra('API_GetUserProfile', { u: c.raUser }, c), completion(c), ra('API_GetUserAwards', { u: c.raUser }, c), ra('API_GetUserRecentAchievements', { u: c.raUser, m: 60 * 24 * 30 }, c)]);
    if (p.status === 'rejected') throw p.reason;
    const progress = {}, best = {}; let unlocked = 0;
    for (const g of (cg.value || [])) {
      const e = Math.max(g.NumAwarded || 0, g.NumAwardedHardcore || 0);
      if (!best[g.GameID] || e > best[g.GameID]) { unlocked += e - (best[g.GameID] || 0); best[g.GameID] = e; }
      const k = norm(g.Title); if (!progress[k] || e > progress[k].earned) progress[k] = { earned: e, total: g.MaxPossible || 0 };
      idMap[(g.ConsoleID || '') + ':' + k] = g.GameID;
    }
    const recent = (rc.value || []).sort((a, b) => String(b.Date).localeCompare(String(a.Date))).slice(0, 8).map(r => ({ id: r.AchievementID, title: r.Title, game: r.GameTitle, points: r.Points, badge: r.BadgeURL ? MEDIA + r.BadgeURL : `${MEDIA}/Badge/${r.BadgeName}.png` }));
    const a = aw.value || {};
    return { user: p.value.User || c.raUser, pic: p.value.UserPic ? MEDIA + p.value.UserPic : '', points: p.value.TotalSoftcorePoints != null ? p.value.TotalSoftcorePoints : (p.value.TotalPoints || 0), hardPoints: p.value.TotalPoints || 0, softPoints: p.value.TotalSoftcorePoints || 0, unlocked, mastered: (a.MasteryAwardsCount || 0) + (a.CompletionAwardsCount || 0), recent, progress };
  } catch (e) { return { error: 'RetroAchievements: ' + e.message }; }
}

// ---------- launching RetroArch with a preconfigured, achievement-ready config ----------
let win, child = null;
const PREPPED = new Set();
const macArchs = f => { try { return String(execFileSync('/usr/bin/lipo', ['-archs', f], { timeout: 8000, stdio: ['ignore', 'pipe', 'ignore'] })).trim().split(/\s+/).filter(Boolean); } catch { return []; } };
// Full screen. On macOS the normal Space-based full screen can refuse (the window may be marked not full-screenable after popups change the app's process type), so make sure it is allowed, and if it still has not happened fall back to the simple full screen, which covers the display without a new Space.
const isFs = () => !!(win && !win.isDestroyed() && (win.isFullScreen() || (MAC && win.isSimpleFullScreen && win.isSimpleFullScreen())));
function setFs(v) {
  if (!win || win.isDestroyed()) return; v = !!v;
  if (!MAC) { win.setFullScreen(v); return; }
  try { win.setFullScreenable(true); if (!v && win.isSimpleFullScreen && win.isSimpleFullScreen()) { win.setSimpleFullScreen(false); return; } win.setFullScreen(v); } catch (e) { slog('fullscreen failed ' + e.message); }
  setTimeout(() => { try { if (win && !win.isDestroyed() && isFs() !== v) { if (v) win.setSimpleFullScreen(true); else if (win.isSimpleFullScreen && win.isSimpleFullScreen()) win.setSimpleFullScreen(false); } } catch (e) { slog('fullscreen fallback failed ' + e.message); } }, 1500);
}
const send = (ch, d) => { if (win && !win.isDestroyed()) win.webContents.send(ch, d); };

// ---------- controller mapping inside games: a RetroArch remap file built from the buttons you remapped in Controllers ----------
// Mapping describes which physical position acts as which button. With a normal controller profile every position already sends a known RetroPad button,
// so the remap says: "when position P sends RetroPad X, the core should see RetroPad Y". It works the same on every platform and driver.
const RP_NAMES = ['b', 'y', 'select', 'start', 'up', 'down', 'left', 'right', 'a', 'x', 'l', 'r', 'l2', 'r2', 'l3', 'r3'];
const STD2RP = [0, 8, 1, 9, 10, 11, 12, 13, 2, 3, 14, 15, 4, 5, 6, 7]; // standard button index (A,B,X,Y,LB,RB,LT,RT,Back,Start,L3,R3,Up,Down,Left,Right) -> RetroPad id
const remapDir = () => path.join(app.getPath('userData'), 'remaps');
function coreDisplayName(c, coreId) {
  const dirs = [path.join(coresDir(c), 'info'), path.join(path.dirname(c.retroarch || ''), 'info'), '/usr/share/libretro/info', path.join(HOME, '.config/retroarch/info'), path.join(HOME, 'Library/Application Support/RetroArch/info'), path.join(HOME, 'AppData/Roaming/RetroArch/info')];
  for (const d of dirs) { try { const m = fs.readFileSync(path.join(d, coreId + '.info'), 'utf8').match(/^\s*corename\s*=\s*"([^"]+)"/m); if (m) return m[1]; } catch {} }
  return '';
}
function remapLines(c, names) {
  const out = [];
  names.slice(0, 4).forEach((n, i) => {
    const m = (c.padMap || {})[n]; if (!m) return;
    for (const [l, p] of Object.entries(m)) {
      const d = LOGI.indexOf(l); if (d < 0 || d > 15 || !Number.isInteger(p) || p < 0 || p > 15 || p === d) continue;
      out.push(`input_player${i + 1}_btn_${RP_NAMES[STD2RP[p]]} = "${STD2RP[d]}"`);
    }
  });
  return out;
}
// returns extra lines for the append config (the remap folder) and writes or clears this core's remap file
function writeRemap(c, coreId, names) {
  const nm = coreDisplayName(c, coreId); if (!nm || /[\\/:*?"<>|]/.test(nm)) return [];
  const dir = path.join(remapDir(), nm), f = path.join(dir, nm + '.rmp'), lines = remapLines(c, names);
  try { if (!lines.length) { fs.rmSync(f, { force: true }); return []; } fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(f, lines.join('\n') + '\n'); logEv(`controller remap for ${nm}: ${lines.length} buttons`); return ['input_remapping_directory = "' + remapDir().replace(/"/g, '') + '"']; } catch { return []; }
}

// ---------- Visuals: play each system the way its original screen showed it ----------
const VIS_LCD = new Set(['gb', 'gbc', 'gba', 'gamegear', 'lynx', 'ngp', 'ngpc', 'wonderswan', 'wonderswancolor', 'psp', 'virtualboy']);
const VIS_CRT = new Set(['nes', 'snes', 'genesis', 'mastersystem', 'pcengine', 'n64', 'psx', 'saturn', 'dreamcast', 'atari2600', 'atari5200', 'atari7800', 'segacd', 'sega32x', 'neogeo', 'arcade', 'coleco', 'intellivision', 'colecovision', 'tg16', 'pcenginecd', 'fds', 'mame']);
function shaderDirs(c) {
  const d = [], ra = String(c.retroarch || '');
  if (MAC) d.push(path.join(HOME, 'Library/Application Support/RetroArch/shaders'));
  else if (LINUX) d.push(path.join(HOME, '.config/retroarch/shaders'), path.join(HOME, '.var/app', FPRA, 'config/retroarch/shaders'), '/usr/share/libretro/shaders');
  if (ra && path.isAbsolute(ra)) d.push(path.join(path.dirname(ra), 'shaders'));
  return d;
}
function findShader(c, names) {
  for (const base of shaderDirs(c)) for (const sub of ['shaders_glsl', 'shaders_slang', '']) for (const n of names) {
    const ext = sub === 'shaders_slang' ? '.slangp' : '.glslp', p = path.join(base, sub, n + ext); try { if (fs.existsSync(p)) return p; } catch {}
  }
  return '';
}
function visualLines(c, sid) {
  if (c.visual !== 'original' || !sid) return null;
  const lcd = VIS_LCD.has(sid), crt = VIS_CRT.has(sid) || !lcd;
  const o = { aspect: crt ? 0 : 21, int: lcd, smooth: false, shader: '' };
  if (c.visFx !== false) o.shader = lcd ? findShader(c, ['handheld/lcd3x', 'handheld/gameboy', 'handheld/lcd-grid-v2']) : (['ps2', 'gamecube', 'wii', 'psp', 'psx', 'n64', 'dreamcast', 'saturn'].includes(sid) ? '' : findShader(c, ['crt/crt-easymode', 'crt/crt-geom', 'crt/crt-lottes', 'scanlines/scanlines']));
  return o;
}
// Internal resolution for the cores that have a resolution setting. Returns an options file for RetroArch to use, or null for native.
const CORE_RES = {
  mupen64plus_next_libretro: ['mupen64plus-43screensize', n => ({ 2: '640x480', 3: '960x720', 4: '1280x960', 5: '1600x1200', 6: '1920x1440' })[n]],
  swanstation_libretro: ['swanstation_GPU_ResolutionScale', n => String(n)],
  ppsspp_libretro: ['ppsspp_internal_resolution', n => (480 * n) + 'x' + (272 * n)],
  flycast_libretro: ['flycast_internal_resolution', n => (640 * n) + 'x' + (480 * n)]
};
// Options a core needs on a given system to show a picture at all (the N64 core's threaded renderer gives sound and a black screen on macOS)
const CORE_FIX = { mupen64plus_next_libretro: MAC ? ['mupen64plus-ThreadedRenderer = "False"'] : [] };
function coreOptions(c, coreId) {
  const n = parseInt(c.emuScale, 10), r = CORE_RES[coreId], lines = [...(CORE_FIX[coreId] || [])];
  if (r && n > 1) { const v = r[1](n); if (v) lines.push(r[0] + ' = "' + v + '"'); }
  if (!lines.length) return null;
  const f = path.join(app.getPath('userData'), 'core-options-' + coreId + '.opt');
  try { fs.writeFileSync(f, lines.join('\n') + '\n'); return f; } catch { return null; }
}
// RetroArch's "system" folder (BIOS files and core assets). Cacti OS's own BIOS folder (next to the ROMs, where the upload page puts them) is used,
// and anything already sitting in RetroArch's own system folder is copied across the first time so nothing goes missing.
function sysDir(c) {
  try {
    const d = upBios(c); fs.mkdirSync(d, { recursive: true });
    if (!fs.readdirSync(d).length) {
      const ra = path.dirname(String(c.retroarch || '')), cands = [path.join(ra, 'system'), path.join(HOMEDIR, 'Library', 'Application Support', 'RetroArch', 'system'), path.join(HOMEDIR, 'Documents', 'RetroArch', 'system'), path.join(HOMEDIR, '.config', 'retroarch', 'system'), path.join(HOMEDIR, '.var', 'app', 'org.libretro.RetroArch', 'config', 'retroarch', 'system')];
      for (const k of cands) { try { if (fs.existsSync(k) && fs.readdirSync(k).length) { fs.cpSync(k, d, { recursive: true }); break; } } catch {} }
    }
    return d;
  } catch { return ''; }
}
const HOMEDIR = require('os').homedir();
// PPSSPP's core needs its asset pack (fonts, shaders) in the system folder: without it games fail to start.
async function ensureCoreAssets(c, coreId) {
  if (coreId !== 'ppsspp_libretro') return;
  const sd = sysDir(c); if (!sd || fs.existsSync(path.join(sd, 'PPSSPP', 'ppge_atlas.zim'))) return;
  const zip = path.join(require('os').tmpdir(), 'PPSSPP-assets.zip');
  const r = await fetch('https://buildbot.libretro.com/assets/system/PPSSPP.zip', { signal: AbortSignal.timeout(120000) }); if (!r.ok) throw new Error('PPSSPP assets: HTTP ' + r.status);
  fs.writeFileSync(zip, Buffer.from(await r.arrayBuffer()));
  if (WIN) await sh('tar', ['-xf', zip, '-C', sd], 60000); else await sh(MAC ? '/usr/bin/unzip' : 'unzip', ['-o', '-q', zip, '-d', sd], 60000);
  try { fs.rmSync(zip, { force: true }); } catch {}
}
function writeAppendConfig(c, extra, sid, coreId, extraCoreDir) {
  const q = v => '"' + String(v).replace(/"/g, '') + '"';
  const l = [
    ...(MAC ? ['video_driver = "glcore"', 'video_fullscreen_x = "0"', 'video_fullscreen_y = "0"', 'video_window_show_decorations = "false"', 'video_windowed_fullscreen = "false"', 'video_fullscreen = "true"'] : []), 'video_fullscreen = "true"', 'video_windowed_fullscreen = "true"', 'video_vsync = "true"',
    'pause_nonactive = "false"', 'input_autodetect_enable = "true"', ...(MAC ? ['joypad_autoconfig_dir = ' + q(RAAUTO())] : []), 'config_save_on_exit = "false"', 'input_menu_toggle_gamepad_combo = "4"', 'savestate_auto_save = "' + (c.autoSave ? 'true' : 'false') + '"', 'savestate_auto_load = "' + (c.autoLoad ? 'true' : 'false') + '"',
    'libretro_directory = ' + q(extraCoreDir || coresDir(c)), ...(sysDir(c) ? ['system_directory = ' + q(sysDir(c))] : []), 'cheevos_enable = "true"', 'cheevos_hardcore_mode_enable = "' + (c.hardcore ? 'true' : 'false') + '"',
    'video_scale_integer = "' + (c.gameInt ? 'true' : 'false') + '"', 'video_smooth = "' + (c.gameSmooth ? 'true' : 'false') + '"', 'aspect_ratio_index = "' + ({ core: 21, '4:3': 0, '16:9': 1, square: 20 }[c.gameAspect] ?? 21) + '"',
    ...[1, 2, 3, 4].map(n => 'input_player' + n + '_analog_dpad_mode = "1"'), // the left stick also moves on d-pad-only systems (NES, SNES, Game Boy...)
    ...(LINUX && (process.env.SteamDeck || process.env.SteamGameId || process.env.SteamAppId) ? ['input_exit_emulator = "nul"'] : []), // Steam Input can turn B into the Escape key, which would close the game
    'cheevos_start_active = "false"', 'quit_press_twice = "false"', 'input_quit_gamepad_combo = "' + (['0', '1', '2', '3'].includes(String(c.quitCombo)) ? c.quitCombo : '2') + '"'
  ];
  if (LINUX) { try { const cd = fs.readFileSync('/proc/asound/cards', 'utf8'); if (!/\d+\s+\[/.test(cd)) l.push('audio_driver = "null"'); } catch { l.push('audio_driver = "null"'); } } // no sound card: still run the game silently instead of exiting
  if (effSaveDir(c)) { const sd = path.join(effSaveDir(c), 'saves'), st = path.join(effSaveDir(c), 'states'); try { fs.mkdirSync(sd, { recursive: true }); fs.mkdirSync(st, { recursive: true }); l.push('savefile_directory = ' + q(sd), 'savestate_directory = ' + q(st)); } catch {} }
  { const v = visualLines(c, sid); if (v) { l.push('aspect_ratio_index = "' + v.aspect + '"', 'video_scale_integer = "' + (v.int ? 'true' : 'false') + '"', 'video_smooth = "false"'); if (v.shader) l.push('video_shader_enable = "true"', 'video_shader = "' + v.shader.replace(/"/g, '') + '"'); } }
  if (achStyle(c) !== 'retroarch') l.push('cheevos_visibility_unlock = "false"');
  if (c.raUser) { l.push('cheevos_username = ' + q(c.raUser), 'netplay_nickname = ' + q(c.raUser)); }
  if (c.raUser && c.raToken) l.push('cheevos_token = ' + q(c.raToken));
  else if (c.raUser && c.raPass) l.push('cheevos_password = ' + q(c.raPass));
  { const co = coreOptions(c, coreId); if (co) l.push('core_options_path = ' + q(co)); }
  if (extra && extra.length) l.push(...extra);
  const f = path.join(app.getPath('userData'), 'retroos-append.cfg');
  fs.writeFileSync(f, l.join('\n') + '\n', { mode: 0o600 });
  return f;
}
async function launchGame({ file, system, connect, core: coreId, title, gameId, pads }) {
  if (system === 'recomps' && String(file).startsWith('store:')) return storePlay(String(file).slice(6));
  const c = load(); let s = ALL.find(x => x.id === system);
  if (LINUX && path.basename(String(c.retroarch || '')) === 'flatpak' && fs.existsSync('/usr/bin/flatpak')) { try { writeWrap(RAWRAP, FPRA); c.retroarch = RAWRAP; save(c); } catch {} } // "flatpak" itself was saved as RetroArch: use the proper launcher instead
  if (LINUX && c.retroarch === RAWRAP) { try { writeWrap(RAWRAP, FPRA); } catch {} } // keep the launcher current
  // A standalone emulator that is already installed wins over the built-in core, unless the user picked the core for this system
  let preferSA = false; if (s && s.emu && s.rcore) { const ch = (c.cores || {})[s.id]; if (ch !== s.rcore.id && ch !== 'standalone') { try { preferSA = !(await EMU.launchInfo(s.emu, file)).error; } catch {} } }
  if (s && !preferSA && viaCore(c, s)) s = { ...s, emu: null, cores: [s.rcore] };
  if (child) return { ok: false, error: 'A game is already running.' };
  if (!s) return { ok: false, error: 'Unknown system.' };
  if (s.emu) return launchStandalone(s, file);
  if (!fs.existsSync(c.retroarch)) return { ok: false, error: 'RetroArch not found. Menu > System Check can install it.' };
  const ch = (coreId && s.cores.find(x => x.id === coreId)) || coreFor(c, s), core = coreFile(c, ch.id) || path.join(coresDir(c), ch.id + EXT);
  if (!fs.existsSync(core)) return { ok: false, error: `Core missing: ${ch.id + EXT}. Looked in ${coreDirs(c).filter(d => { try { return fs.existsSync(d); } catch { return false; } }).join(', ') || coresDir(c)}. Menu > System Check > Install all cores.` };
  if (!fs.existsSync(file)) return { ok: false, error: 'ROM file not found.' };
  try { await ensureCoreAssets(c, ch.id); } catch {}
  if (MAC) { // Apple Silicon refuses a core that is unsigned, quarantined or built for the other processor type: fix the first two, and say so for the third
    try {
      if (!PREPPED.has(core)) {
        try { execFileSync('/usr/bin/xattr', ['-cr', core], { timeout: 8000, stdio: 'ignore' }); } catch {}
        try { execFileSync('/usr/bin/codesign', ['--verify', core], { timeout: 8000, stdio: 'ignore' }); } catch { try { execFileSync('/usr/bin/codesign', ['--force', '--sign', '-', core], { timeout: 15000, stdio: 'ignore' }); } catch {} }
        PREPPED.add(core);
      }
      const ca = macArchs(core), ra = macArchs(c.retroarch);
      if (ca.length && ra.length && !ca.some(a => ra.includes(a))) return { ok: false, error: `${ch.id + EXT} is built for ${ca.join('/')} but this RetroArch is the ${ra.includes('arm64') ? 'Apple Silicon' : 'Intel'} version (${ra.join('/')}). Menu > System Check > Install all cores replaces it with a matching one.` };
    } catch {}
  }
  if (MAC) ensureAutoconfig();
  const t0 = Date.now(); let out = 'ignore';
  try { out = fs.openSync(LOG(), 'w'); } catch {}
  const padNames = Array.isArray(pads) && pads.length ? pads.map(x => String(x).slice(0, 200)) : [...EVD.devs.values()].map(d => d.name);
  const args = ['-v', '-f', '-L', core, '--appendconfig', writeAppendConfig(c, writeRemap(c, ch.id, padNames), s.id, ch.id, path.dirname(core))];
  if (connect && connect.host) args.push('-C', String(connect.host), '--port', String(connect.port || 55435));
  args.push(file);
  try { fs.writeSync(out, `Cacti OS launch\ncore: ${ch.name} (${core})\nrom: ${file}\n\n`); } catch {}
  { const sb = LINUX && ['/usr/bin/stdbuf', '/bin/stdbuf'].find(p => fs.existsSync(p)); // line-buffered log: popups see achievements at once, and a crash keeps its last lines
    child = sb ? spawn(sb, ['-oL', '-eL', c.retroarch, ...args], { cwd: path.dirname(c.retroarch), stdio: ['ignore', out, out] }) : spawn(c.retroarch, args, { cwd: path.dirname(c.retroarch), stdio: ['ignore', out, out] }); } padWatch(true);
  if (MAC) setTimeout(() => { try { if (child && win && !win.isDestroyed()) win.hide(); } catch {} }, 2500); // stop Cacti's animated screen competing with the game for the GPU
  achStart({ sys: system, title: String(title || path.basename(file, path.extname(file))), gameId });
  const finish = (d, code) => {
    if (!child) return; child = null; padWatch(false); achStop();
    try { if (typeof out === 'number') fs.closeSync(out); } catch {}
    try { fs.rmSync(path.join(app.getPath('userData'), 'retroos-append.cfg'), { force: true }); } catch {}
    const secs = Math.round((Date.now() - t0) / 1000);
    if (!d.error && secs < 8) {
      let tail = ''; try { tail = fs.readFileSync(LOG(), 'utf8').trim().split('\n').filter(x => x.trim()).slice(-5).join(' | '); } catch {}
      d = { error: 'RetroArch closed right after starting', log: tail.slice(0, 420) };
    }
    if (!d.error && secs >= 10) { const st = getStats(), e = st[file] || { plays: 0, secs: 0 }; st[file] = { plays: e.plays + 1, secs: e.secs + secs, last: Date.now() }; fs.writeFileSync(ST(), JSON.stringify(st)); logPlay(secs, title || clean(file), system); }
    if (win && !win.isDestroyed()) { win.show(); win.focus(); app.focus({ steal: true }); }
    setTimeout(() => { try { if (c.backupAuto) backupSaves(load(), false).catch(() => {}); if (c.syncAuto) autoSync(); } catch {} }, 8000); // after the window is back and responsive, not while it is coming up
    send('game-exit', d);
  };
  child.on('error', err => finish({ error: String(err.message || err) }));
  child.on('exit', code => finish({}, code));
  return { ok: true };
}



// Standalone emulators run the game themselves (their own RetroAchievements login and popups); Cacti OS waits for them to close.
async function launchStandalone(s, file) {
  if (!fs.existsSync(file)) return { ok: false, error: 'ROM file not found.' };
  const li = await EMU.launchInfo(s.emu, file); if (li.error) return { ok: false, error: li.error };
  if (child) return { ok: false, error: 'A game is already running.' };
  const t0 = Date.now(); try { const cc = load(); require('./renderer/emucfg').apply(s.emu, { scale: cc.emuScale, ra: cc.emuRA !== false, user: cc.raUser, token: cc.raToken }); } catch {}
  let sout = 'ignore'; try { sout = fs.openSync(path.join(app.getPath('userData'), 'standalone.log'), 'w'); fs.writeSync(sout, '$ ' + li.exe + ' ' + (li.args || []).join(' ') + '\n'); } catch {}
  const xenv = { ...process.env }; if (LINUX && !xenv.DISPLAY) { try { const xs = fs.readdirSync('/tmp/.X11-unix').filter(f => /^X\d+$/.test(f)); xenv.DISPLAY = ':' + (xs.length ? xs[0].slice(1) : '0'); } catch { xenv.DISPLAY = ':0'; } } // XWayland of the kiosk compositor, for emulators that only draw through X11
  if (LINUX && s.emu === 'dolphin') { const qpa = process.env.RETRO_OS_DOLPHIN_QPA || 'xcb'; xenv.QT_QPA_PLATFORM = qpa; if (qpa === 'xcb') xenv.EGL_PLATFORM = 'x11'; } // Dolphin draws through XWayland; without this Mesa guesses Wayland for its X11 display and eglInitialize crashes
  if (LINUX && !/utf-?8/i.test(xenv.LANG || '')) xenv.LANG = 'C.UTF-8'; // Qt emulators (Dolphin) draw through XWayland
  if (LINUX && process.env.RETRO_OS_STRACE && fs.existsSync('/usr/bin/strace')) { li.args = ['-f', '-o', path.join(app.getPath('userData'), 'strace.log'), li.exe, ...li.args]; li.exe = '/usr/bin/strace'; } // debugging aid: RETRO_OS_STRACE=1 in /userdata/system/retro-os.conf
  else if (LINUX && process.env.RETRO_OS_GDB && fs.existsSync('/usr/bin/gdb')) { li.args = ['-batch', '-ex', 'handle SIGPIPE nostop noprint', '-ex', 'run', '-ex', 'bt 25', '-ex', 'info registers rip', '-ex', 'x/6i $pc', '--args', li.exe, ...li.args]; li.exe = '/usr/bin/gdb'; } // debugging aid: RETRO_OS_GDB=1 prints a backtrace into standalone.log when an emulator crashes
  const sbx = LINUX && ['/usr/bin/stdbuf', '/bin/stdbuf'].find(p => fs.existsSync(p)); // line-buffered, so a crash still leaves its last lines in standalone.log
  child = sbx ? spawn(sbx, ['-oL', '-eL', li.exe, ...li.args], { cwd: li.cwd, stdio: ['ignore', sout, sout], env: xenv }) : spawn(li.exe, li.args, { cwd: li.cwd, stdio: ['ignore', sout, sout], env: xenv }); padWatch(true);
  const finish = d => {
    if (!child) return; child = null; padWatch(false);
    try { if (typeof sout === 'number') fs.closeSync(sout); } catch {}
    const secs = Math.round((Date.now() - t0) / 1000);
    if (!d.error && secs < 5) d = { error: li.name + ' closed right after starting. Open it once on its own to finish its first-time setup (BIOS, folders).' };
    if (!d.error && secs >= 10) { const st = getStats(), e = st[file] || { plays: 0, secs: 0 }; st[file] = { plays: e.plays + 1, secs: e.secs + secs, last: Date.now() }; fs.writeFileSync(ST(), JSON.stringify(st)); logPlay(secs, clean(file), s.id); }
    if (win && !win.isDestroyed()) { win.show(); win.focus(); app.focus({ steal: true }); }
    send('game-exit', d);
  };
  child.on('error', err => finish({ error: String(err.message || err) }));
  child.on('exit', (code, sig) => { try { fs.appendFileSync(path.join(app.getPath('userData'), 'standalone.log'), '\n[exit code=' + code + ' signal=' + sig + ' after ' + Math.round((Date.now() - t0) / 1000) + 's]\n'); } catch {} finish({}); });
  return { ok: true };
}

async function storePlay(id) {
  const li = STORE.launchInfo(id); if (li.error) return { ok: false, error: li.error };
  if (child) return { ok: false, error: 'A game is already running.' };
  const t0 = Date.now();
  child = spawn(li.exe, [], { cwd: li.cwd, stdio: 'ignore', env: { ...process.env, ...li.env } }); padWatch(true);
  const finish = d => {
    if (!child) return; child = null; padWatch(false);
    const secs = Math.round((Date.now() - t0) / 1000);
    if (!d.error && secs < 5) d = { error: li.name + ' closed right after starting. Open it once on its own to finish its first-time setup.' };
    if (win && !win.isDestroyed()) { win.show(); win.focus(); app.focus({ steal: true }); }
    send('game-exit', d);
  };
  child.on('error', err => finish({ error: String(err.message || err) }));
  child.on('exit', () => finish({}));
  return { ok: true };
}

// ---------- achievement popups: read RetroArch's local log (no extra traffic to retroachievements.org) and draw our own popup ----------
const ACH = ['retroarch', 'pill', 'banner', 'pixel', 'neon', 'medal', 'off'];
const achStyle = c => (ACH.includes(c.achStyle) ? c.achStyle : 'pill');
const ACH_W = { '1': 800, '2': 1000, '3': 1250 };
let awin = null, aReady = false, aQ = [], aBusy = false, aGen = 0, aTail = null, aGame = null, aInfo = null, aSeen = new Map();
// macOS gives every full-screen app its own Space. A window only shows over another app's full-screen Space when the app is not a regular Dock app, so the popups switch the process type (visibleOnFullScreen) and the Dock icon is put straight back.
function macAllSpaces(w) {
  try {
    if (MAC) { w.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true }); w.setFullScreenable(false); if (app.dock) app.dock.show(); }
    else w.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true, skipTransformProcessType: true });
  } catch {}
}
function createAch() {
  awin = new BrowserWindow({
    width: 1000, height: 260, show: false, frame: false, transparent: true, resizable: false, alwaysOnTop: true, focusable: false, skipTaskbar: true, hasShadow: false,
    webPreferences: { preload: path.join(__dirname, 'popup-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false, autoplayPolicy: 'no-user-gesture-required' }
  });
  awin.setAlwaysOnTop(true, 'screen-saver');
  macAllSpaces(awin);
  try { awin.setIgnoreMouseEvents(true); } catch {}
  awin.on('closed', () => { awin = null; aReady = false; });
  awin.webContents.on('did-finish-load', () => { aReady = true; achPump(); });
  awin.loadFile(path.join(__dirname, 'renderer', 'popup.html'));
}
function achPump() {
  const inl = LINUX && !child && win && !win.isDestroyed();
  if (aBusy || !aQ.length || (!inl && (!aReady || !awin || awin.isDestroyed()))) return;
  let p = aQ.shift(); const c = load(), gen = aGen; aBusy = true;
  const wa = screen.getPrimaryDisplay().workArea, W = Math.round((ACH_W[String(c.achSize)] || 1000) * (LINUX ? 1 : Math.min(2.5, Math.max(1, wa.height / 1080)))), H = Math.round(W * 0.26); // popups grow with the screen: 1440p and 4K get bigger pills, 1080p and below stay as before
  if (LINUX && !child && win && !win.isDestroyed()) { // in the menu: kiosk compositor (cage) forces extra windows to a corner and gives them focus: draw inside the main window instead
    win.webContents.send('ach:inline', { vw: Math.min(100, Math.round(650 * W / 1920) / 10), x: p.style === 'pixel' ? 'left' : (p.style === 'neon' || p.style === 'medal') ? 'right' : 'center', y: (p.style === 'pill' || p.style === 'pixel' || p.style === 'medal') ? 'bottom' : 'top', p: { ...p, sound: c.achSound !== false } });
    setTimeout(() => { if (gen !== aGen) return; try { win.webContents.send('ach:inline', { hide: true }); } catch {} aBusy = false; achPump(); }, 6300);
    return;
  }
  const x = p.style === 'pixel' ? wa.x : (p.style === 'neon' || p.style === 'medal') ? wa.x + wa.width - W : Math.round(wa.x + (wa.width - W) / 2);
  const y = (p.style === 'pill' || p.style === 'pixel' || p.style === 'medal') ? wa.y + wa.height - H : wa.y;
  if (LINUX) { // cage ignores window positions: cover the whole screen with a see-through window and place the popup inside it
    const db = screen.getPrimaryDisplay().bounds;
    p = { ...p, box: { vw: Math.min(100, Math.round(650 * W / 1920) / 10), x: p.style === 'pixel' ? 'left' : (p.style === 'neon' || p.style === 'medal') ? 'right' : 'center', y: (p.style === 'pill' || p.style === 'pixel' || p.style === 'medal') ? 'bottom' : 'top' } };
    awin.setBounds({ x: db.x, y: db.y, width: db.width, height: db.height });
  } else awin.setBounds({ x, y, width: W, height: H });
  awin.showInactive(); try { awin.moveTop(); } catch {}
  awin.webContents.send('ach:show', { ...p, sound: c.achSound !== false });
  setTimeout(() => { if (gen !== aGen) return; try { if (awin && !awin.isDestroyed()) awin.hide(); } catch {} aBusy = false; achPump(); }, 6300);
}
function achShow(p, replace) { if (!awin && !LINUX) createAch(); if (replace) { aQ = []; aGen++; aBusy = false; } aQ.push(p); achPump(); }
const AWARD = /award(?:ing|ed)?\s+achievement\s+(\d+)\s*[:\-]\s*(.+?)\s*$/i;
function parseAward(line) {
  const m = AWARD.exec(line); if (!m) return null;
  let title = m[2], desc = ''; const k = /^(.*?)\s+\((.*)\)$/.exec(title); if (k) { title = k[1]; desc = k[2]; }
  return { id: Number(m[1]), title, desc };
}
// One request per game, made only when the first achievement is unlocked: gives badge art, points and rarity.
async function achLoad(g) {
  const c = load(); if (!c.raUser || !c.raKey) return null;
  const id = g.gameId ? Number(g.gameId) : await raGameId(c, g.sys, g.title); if (!id) return null;
  const j = await ra('API_GetGameInfoAndUserProgress', { g: id, u: c.raUser }, c);
  const list = Object.values(j.Achievements || {}), players = Number(j.NumDistinctPlayers || j.NumDistinctPlayersCasual || 0), by = new Map(), done = new Set();
  for (const a of list) {
    const n = Math.max(Number(a.NumAwarded || 0), Number(a.NumAwardedHardcore || 0));
    by.set(Number(a.ID), { title: a.Title, desc: a.Description, points: a.Points || 0, badge: `${MEDIA}/Badge/${a.BadgeName}.png`, rare: players ? Math.round(1000 * n / players) / 10 : null });
    if (a.DateEarned || a.DateEarnedHardcore) done.add(Number(a.ID));
  }
  return { by, done, total: list.length };
}
async function achAward(a) {
  const c = load(), style = achStyle(c); if (style === 'retroarch' || style === 'off') return;
  const last = aSeen.get(a.id); if (last && Date.now() - last < 60000) return; aSeen.set(a.id, Date.now());
  if (!aInfo && aGame) aInfo = achLoad(aGame).catch(() => null);
  let info = null; try { info = await Promise.race([aInfo, new Promise(r => setTimeout(() => r(null), 2500))]); } catch {}
  const e = info && info.by.get(a.id); if (info) info.done.add(a.id);
  achShow({ style, title: (e && e.title) || a.title, desc: (e && e.desc) || a.desc, points: e ? e.points : 0, badge: e ? e.badge : '', rare: e ? e.rare : null, earned: info ? info.done.size : 0, total: info ? info.total : 0 });
}
function achStart(game) {
  achStop(); const c = load(); if (['retroarch', 'off'].includes(achStyle(c))) return;
  aGame = game; aInfo = null; aSeen.clear(); let pos = 0, rest = '';
  aTail = setInterval(() => {
    try {
      const st = fs.statSync(LOG()); if (st.size < pos) pos = 0; if (st.size === pos) return;
      const n = Math.min(st.size - pos, 262144), buf = Buffer.alloc(n), fd = fs.openSync(LOG(), 'r');
      try { fs.readSync(fd, buf, 0, n, pos); } finally { fs.closeSync(fd); }
      pos += n; const lines = (rest + buf.toString('utf8')).split('\n'); rest = lines.pop() || '';
      for (const ln of lines) { const a = parseAward(ln); if (a) achAward(a).catch(() => {}); }
    } catch {}
  }, 500);
}
function achStop() { if (aTail) clearInterval(aTail); aTail = null; aGame = null; aInfo = null; aQ = []; }

// ---------- music player: hidden engine window + small overlay shown over the running game ----------
let mwin = null, ovShown = false, ovTimer = null, mst = { playing: false, title: '', idx: -1, total: 0, vol: 70, shuffle: false, pos: 0, dur: 0, next: [], folder: '', mute: false };
const AUD = /\.(mp3|m4a|aac|ogg|oga|opus|flac|wav)$/i;
function scanMusic(dir) {
  const out = [];
  (function w(d, depth) {
    if (depth > 4 || out.length >= 5000) return;
    let es = []; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    es.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
    for (const e of es) {
      if (e.name.startsWith('.')) continue;
      const p = path.join(d, e.name);
      if (e.isDirectory()) w(p, depth + 1);
      else if (AUD.test(e.name)) out.push({ url: pathToFileURL(p).href, title: e.name.replace(AUD, '').replace(/_/g, ' '), folder: path.basename(d) });
    }
  })(dir, 0);
  return out;
}

// album art: embedded picture (ID3v2 APIC, FLAC PICTURE, MP4 covr) or a cover/folder image beside the song
const songArtCache = new Map();
function songArt(fileUrl) {
  if (!fileUrl) return '';
  if (songArtCache.has(fileUrl)) return songArtCache.get(fileUrl);
  let out = '';
  try {
    const p = require('url').fileURLToPath(fileUrl), ext = path.extname(p).toLowerCase(), mime = b => (b[0] === 0x89 ? 'image/png' : 'image/jpeg');
    const fd = fs.openSync(p, 'r'); const st = fs.fstatSync(fd);
    const rd = (pos, n) => { const b = Buffer.alloc(Math.max(0, Math.min(n, st.size - pos))); fs.readSync(fd, b, 0, b.length, pos); return b; };
    try {
      if (ext === '.mp3') {
        const h = rd(0, 10);
        if (h.slice(0, 3).toString() === 'ID3') {
          const ver = h[3], size = ((h[6] & 127) << 21) | ((h[7] & 127) << 14) | ((h[8] & 127) << 7) | (h[9] & 127), tag = rd(10, Math.min(size, 6 * 1024 * 1024));
          let o = 0;
          while (o + 10 < tag.length) {
            const id = tag.slice(o, o + 4).toString('latin1'); let sz = ver === 4 ? ((tag[o + 4] & 127) << 21) | ((tag[o + 5] & 127) << 14) | ((tag[o + 6] & 127) << 7) | (tag[o + 7] & 127) : tag.readUInt32BE(o + 4);
            if (!/^[A-Z0-9]{4}$/.test(id) || sz <= 0) break;
            if (id === 'APIC') {
              const f = tag.slice(o + 10, o + 10 + sz), enc = f[0]; let i = 1; while (i < f.length && f[i] !== 0) i++; i += 2; // mime, picture type
              if (enc === 1 || enc === 2) { while (i + 1 < f.length && !(f[i] === 0 && f[i + 1] === 0)) i += 2; i += 2; } else { while (i < f.length && f[i] !== 0) i++; i++; }
              const img = f.slice(i); if (img.length > 200) { out = 'data:' + mime(img) + ';base64,' + img.toString('base64'); } break;
            }
            o += 10 + sz;
          }
        }
      } else if (ext === '.flac') {
        let pos = 4;
        for (let n = 0; n < 40; n++) {
          const bh = rd(pos, 4); if (bh.length < 4) break; const last = bh[0] & 128, type = bh[0] & 127, len = (bh[1] << 16) | (bh[2] << 8) | bh[3];
          if (type === 6 && len < 8 * 1024 * 1024) {
            const b = rd(pos + 4, len); let i = 4; const ml = b.readUInt32BE(i); i += 4 + ml; const dl = b.readUInt32BE(i); i += 4 + dl + 16; const il = b.readUInt32BE(i); i += 4;
            const img = b.slice(i, i + il); if (img.length > 200) out = 'data:' + mime(img) + ';base64,' + img.toString('base64'); break;
          }
          pos += 4 + len; if (last) break;
        }
      } else if (ext === '.m4a' || ext === '.aac') {
        const b = rd(0, Math.min(st.size, 8 * 1024 * 1024)), i = b.indexOf('covr');
        if (i > 0) { const dl = b.readUInt32BE(i + 4); const img = b.slice(i + 4 + 16, i + 4 + dl); if (dl > 216 && img.length > 200 && (img[0] === 0xff || img[0] === 0x89)) out = 'data:' + mime(img) + ';base64,' + img.toString('base64'); }
      }
    } finally { fs.closeSync(fd); }
    if (!out) {
      const d = path.dirname(p), names = ['cover', 'folder', 'front', 'album', 'albumart', 'artwork'];
      for (const n of names) for (const e of ['.jpg', '.jpeg', '.png']) { const f = path.join(d, n + e); try { if (fs.existsSync(f) && fs.statSync(f).size < 4 * 1024 * 1024) { const img = fs.readFileSync(f); out = 'data:' + mime(img) + ';base64,' + img.toString('base64'); break; } } catch {} }
    }
  } catch {}
  if (out.length > 3.5 * 1024 * 1024) out = '';
  if (songArtCache.size > 30) songArtCache.delete(songArtCache.keys().next().value);
  songArtCache.set(fileUrl, out); return out;
}
function musicSync() {
  if (!mwin || mwin.isDestroyed()) return;
  const c = load(), files = c.musicDir && fs.existsSync(c.musicDir) ? scanMusic(c.musicDir) : [];
  mst.total = files.length;
  mwin.webContents.send('music:list', { files, vol: Number(c.musicVol) || 0, shuffle: !!c.musicShuffle, auto: !!c.musicAuto });
}
function createMusic() {
  mwin = new BrowserWindow({
    width: 440, height: 144, show: false, frame: false, transparent: true, resizable: false, alwaysOnTop: true, focusable: !LINUX, skipTaskbar: true, hasShadow: false,
    webPreferences: { preload: path.join(__dirname, 'music-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false, autoplayPolicy: 'no-user-gesture-required' }
  });
  mwin.setAlwaysOnTop(true, 'screen-saver');
  macAllSpaces(mwin);
  if (!fs.existsSync(path.join(__dirname, 'music-preload.js'))) console.error('music-preload.js is missing from the app folder');
  mwin.loadFile(path.join(__dirname, 'renderer', 'music.html'));
  mwin.webContents.on('did-finish-load', musicSync);
}
// If the built-in decoder cannot play a file (some FLAC variants), convert it to a temporary WAV with a system tool and play that.
function runTool(cmd, args) { return new Promise((res, rej) => execFile(cmd, args, { timeout: 180000 }, e => (e ? rej(e) : res()))); }
async function convertAudio(url) {
  try {
    const src = fileURLToPath(url); if (!AUD.test(src) || !fs.existsSync(src)) return null;
    const dir = path.join(app.getPath('userData'), 'music-cache'); fs.mkdirSync(dir, { recursive: true });
    const out = path.join(dir, crypto.createHash('md5').update(src).digest('hex') + '.wav');
    if (!fs.existsSync(out)) {
      const tries = MAC ? [['/usr/bin/afconvert', ['-f', 'WAVE', '-d', 'LEI16', src, out]], ['ffmpeg', ['-y', '-v', 'error', '-i', src, out]]]
        : [['ffmpeg', ['-y', '-v', 'error', '-i', src, out]], ['flac', ['-d', '-f', '-s', '-o', out, src]]];
      let ok = false;
      for (const [c, a] of tries) { try { await runTool(c, a); if (fs.existsSync(out)) { ok = true; break; } } catch {} }
      if (!ok) return null;
      const fl = fs.readdirSync(dir).map(f => ({ f, t: fs.statSync(path.join(dir, f)).mtimeMs })).sort((a, b) => b.t - a.t);
      for (const x of fl.slice(8)) { try { fs.rmSync(path.join(dir, x.f)); } catch {} }
    }
    return pathToFileURL(out).href;
  } catch { return null; }
}
const OVKEYS = { Left: 'prev', Right: 'next', Up: 'volup', Down: 'voldown', Space: 'toggle', S: 'shuffle', Escape: 'close' };
function ovBump() { clearTimeout(ovTimer); ovTimer = setTimeout(ovHide, 10000); }
function ovShow() {
  if (!mwin || mwin.isDestroyed()) return;
  const wa = screen.getPrimaryDisplay().workArea;
  mwin.setBounds({ width: 440, height: 144, x: Math.round(wa.x + (wa.width - 440) / 2), y: Math.round(wa.y + wa.height - 144 - 24) });
  if (LINUX) mwin.showInactive(); else { mwin.show(); mwin.focus(); try { app.focus({ steal: true }); } catch {} } // focused so it can read the controller
  mwin.moveTop(); ovShown = true; ovBump(); send('overlay', !!(mwin.isVisible && mwin.isVisible()));
  for (const [k, v] of Object.entries(OVKEYS)) { try { globalShortcut.register(k, () => musicCmd(v)); } catch {} }
}
function ovHide() {
  ovShown = false; clearTimeout(ovTimer); send('overlay', false);
  if (mwin && !mwin.isDestroyed()) mwin.hide();
  if (child && MAC) { try { app.hide(); } catch {} } // hand focus back to the game
  for (const k of Object.keys(OVKEYS)) { try { globalShortcut.unregister(k); } catch {} }
}
const ovToggle = () => (ovShown ? ovHide() : ovShow());
function musicCmd(c) {
  if (c === 'bump') { if (ovShown) ovBump(); return; }
  if (c === 'close') return ovHide();
  if (c === 'show') return ovShow();
  if (c === 'overlay') return ovToggle();
  if (mwin && !mwin.isDestroyed()) mwin.webContents.send('music:cmd', c);
  if (ovShown) ovBump();
}
// Linux (Raspberry Pi): the Guide/Home button toggles the player while a game runs; D-pad / A / B / X / LB / RB control it.
const jsb = {};
function jsEvent(t, num, v) {
  t &= 0x7f;
  // Start + D-pad Down (either order) opens or closes the player while a game runs
  if (t === 1 && num === 7) { jsb.start = !!v; if (v && jsb.down && child) return ovToggle(); }
  if (t === 2 && num === 7) { const d = v > 16000; if (d && !jsb.down) { jsb.down = true; if (jsb.start && child) return ovToggle(); } else if (!d) jsb.down = false; }
  if (t === 1) {
    if (v && num === 8) return ovToggle();
    if (!ovShown || !v) return;
    if (num === 0) musicCmd('toggle'); else if (num === 1) ovHide(); else if (num === 2) musicCmd('shuffle'); else if (num === 4) musicCmd('prev'); else if (num === 5) musicCmd('next');
  } else if (t === 2 && ovShown) {
    const dir = v > 16000 ? 1 : v < -16000 ? -1 : 0;
    if (jsb[num] === dir) return; jsb[num] = dir; if (!dir) return;
    if (num === 6 || num === 0) musicCmd(dir < 0 ? 'prev' : 'next'); else if (num === 7 || num === 1) musicCmd(dir < 0 ? 'volup' : 'voldown');
  }
}
// Windows: while a game runs, a tiny PowerShell helper watches Xbox-style controllers (XInput) for Start + D-pad Down.
let xw = null;
function padWatch(on) {
  if (!WIN) return;
  if (!on) { if (xw) { try { xw.kill(); } catch {} xw = null; } return; }
  if (xw) return;
  const ps = `Add-Type @"
using System; using System.Runtime.InteropServices;
[StructLayout(LayoutKind.Sequential)] public struct XST { public uint pk; public ushort b; public byte lt; public byte rt; public short lx; public short ly; public short rx; public short ry; }
public class XI { [DllImport("xinput1_4.dll")] public static extern int XInputGetState(int i, ref XST s); }
"@
$was = $false
while ($true) {
  $hit = $false
  for ($i = 0; $i -lt 4; $i++) { $s = New-Object XST; if ([XI]::XInputGetState($i, [ref]$s) -eq 0) { if (($s.b -band 18) -eq 18) { $hit = $true } } }
  if ($hit -and -not $was) { [Console]::Out.WriteLine('combo'); [Console]::Out.Flush() }
  $was = $hit
  Start-Sleep -Milliseconds 40
}`;
  try {
    xw = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', Buffer.from(ps, 'utf16le').toString('base64')], { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] });
    let buf = ''; xw.stdout.on('data', d => { buf += d; let i; while ((i = buf.indexOf('\n')) >= 0) { const l = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (l === 'combo' && child) ovToggle(); } });
    xw.on('exit', () => { xw = null; }); xw.on('error', () => { xw = null; });
  } catch { xw = null; }
}
const jsOpen = new Set();
function jsScan() {
  for (let n = 0; n < 4; n++) {
    const p = '/dev/input/js' + n;
    if (jsOpen.has(p) || !fs.existsSync(p)) continue;
    jsOpen.add(p);
    fs.open(p, 'r', (err, fd) => {
      if (err) { jsOpen.delete(p); return; }
      const st = fs.createReadStream(null, { fd, highWaterMark: 8 }); let buf = Buffer.alloc(0);
      st.on('data', d => { buf = Buffer.concat([buf, d]); while (buf.length >= 8) { const v = buf.readInt16LE(4), t = buf[6], num = buf[7]; buf = buf.subarray(8); jsEvent(t, num, v); } });
      const done = () => jsOpen.delete(p); st.on('close', done); st.on('error', done);
    });
  }
}


// ---------- Wi-Fi networks (NetworkManager, used on the Raspberry Pi image) ----------
function nmFields(line) { // nmcli -t output: ":" separates fields, and "\:" and "\\" are escapes
  const out = []; let cur = '';
  for (let i = 0; i < line.length; i++) { const ch = line[i]; if (ch === '\\' && i + 1 < line.length) cur += line[++i]; else if (ch === ':') { out.push(cur); cur = ''; } else cur += ch; }
  out.push(cur); return out;
}
const nmRun = (args, t = 45000) => new Promise(r => execFile('nmcli', args, { timeout: t }, (e, o, er) => r({ ok: !e, out: String(o || ''), err: String(er || o || (e && e.message) || '').trim() })));
async function wifiScan() {
  if (!LINUX) return { error: 'Choosing a network here is available on the Raspberry Pi image. On this computer, use the system Wi-Fi settings.' };
  const dev = await nmRun(['-t', '-f', 'DEVICE,TYPE,STATE', 'dev'], 8000);
  if (!dev.ok) return { error: 'The network service is not running yet. Wait a moment and try again.' };
  if (!/:wifi:/.test(dev.out)) return { error: 'No Wi-Fi adapter was found. Plug in a USB Wi-Fi adapter, or use an Ethernet cable.' };
  await nmRun(['radio', 'wifi', 'on'], 5000);
  const r = await nmRun(['-t', '-f', 'IN-USE,SSID,SIGNAL,SECURITY', 'dev', 'wifi', 'list', '--rescan', 'yes'], 25000);
  const sv = await nmRun(['-t', '-f', 'NAME,TYPE', 'con', 'show'], 8000);
  const saved = new Set(sv.out.split('\n').filter(Boolean).map(nmFields).filter(p => /wireless/.test(p[1] || '')).map(p => p[0]));
  const by = new Map();
  for (const l of r.out.split('\n')) {
    if (!l.trim()) continue; const p = nmFields(l), ssid = p[1]; if (!ssid) continue;
    const o = { ssid, signal: parseInt(p[2], 10) || 0, sec: p[3] && p[3] !== '--' ? p[3] : '', inUse: p[0] === '*', saved: saved.has(ssid) };
    const e = by.get(ssid); if (!e) by.set(ssid, o); else { if (o.signal > e.signal) e.signal = o.signal; if (o.inUse) e.inUse = true; }
  }
  return { nets: [...by.values()].sort((a, b) => (b.inUse - a.inUse) || (b.saved - a.saved) || (b.signal - a.signal)) };
}
async function wifiConnect(o) {
  if (!LINUX) return { ok: false, error: 'Not available on this system.' };
  const ssid = String((o && o.ssid) || ''), pw = String((o && o.password) || '');
  if (!ssid || Buffer.byteLength(ssid) > 32) return { ok: false, error: 'That network name is not valid.' };
  if (pw && (pw.length < 8 || pw.length > 63)) return { ok: false, error: 'Wi-Fi passwords are 8 to 63 characters.' };
  const had = (await nmRun(['-t', '-f', 'NAME,TYPE', 'con', 'show'], 8000)).out.split('\n').filter(Boolean).map(nmFields).some(p => p[0] === ssid && /wireless/.test(p[1] || ''));
  if (had && pw) await nmRun(['con', 'delete', 'id', ssid], 8000); // typing a new password replaces the saved one
  let r;
  if (had && !pw) r = await nmRun(['--wait', '30', 'con', 'up', 'id', ssid]);
  else { const a = ['--wait', '30', 'dev', 'wifi', 'connect', ssid]; if (pw) a.push('password', pw); if (o && o.hidden) a.push('hidden', 'yes'); r = await nmRun(a); }
  if (r.ok) return { ok: true };
  if (!had || pw) await nmRun(['con', 'delete', 'id', ssid], 8000); // a failed try leaves a broken profile behind
  const m = r.err;
  return { ok: false, error: /secrets were required|password|802-1x|auth/i.test(m) ? 'That password was not accepted.' : /no network with ssid|not found/i.test(m) ? 'That network is out of range.' : /timeout|timed out/i.test(m) ? 'The router did not answer in time. Check the password and try again.' : 'Could not connect. ' + m.replace(/^Error:\s*/, '').slice(0, 100) };
}

// ---------- Controllers on Linux: read the kernel's input devices directly so menus work with any pad ----------
const EVD = { devs: new Map(), tmr: null };
const EVKEY = { 304: 'a', 305: 'b', 307: 'x', 308: 'y', 310: 'lb', 311: 'rb', 312: 'jl', 313: 'jr', 314: 'sel', 315: 'start', 288: 'a', 289: 'b', 290: 'x', 291: 'y', 292: 'lb', 293: 'rb', 294: 'jl', 295: 'jr', 296: 'sel', 297: 'start', 317: 'l3', 318: 'r3', 316: 'mode', 544: 'up', 545: 'down', 546: 'left', 547: 'right' };
// Standard button numbers (same as the browser Gamepad API) so one saved map works on every platform
const LOGI = ['a', 'b', 'x', 'y', 'lb', 'rb', 'lt', 'rt', 'sel', 'start', 'l3', 'r3', 'up', 'down', 'left', 'right', 'home'];
const ACTN = { a: 'a', b: 'b', x: 'x', y: 'y', lb: 'lb', rb: 'rb', lt: 'jl', rt: 'jr', sel: 'sel', start: 'start', up: 'up', down: 'down', left: 'left', right: 'right' };
const EVSTD = { 304: 0, 305: 1, 307: 2, 308: 3, 310: 4, 311: 5, 312: 6, 313: 7, 314: 8, 315: 9, 317: 10, 318: 11, 316: 16, 544: 12, 545: 13, 546: 14, 547: 15, 288: 0, 289: 1, 290: 2, 291: 3, 292: 4, 293: 5, 294: 6, 295: 7, 296: 8, 297: 9 };
const DIRIDX = { up: 12, down: 13, left: 14, right: 15 };
let padCapture = false;
function padAction(name, idx) { // which menu action does this physical button trigger on this controller?
  const m = (load().padMap || {})[name] || {};
  for (const l of LOGI) { const phys = l in m ? m[l] : LOGI.indexOf(l); if (phys === idx) return ACTN[l] || ''; }
  return '';
}
function padPress(d, idx) { // a physical button was pressed
  send('pad:raw', { name: d.name, idx });
  if (padCapture) return;
  const a = padAction(d.name, idx); if (a) padEmit(a);
}
function padEmit(a) { if (child || padCapture) return; send('pad:act', a); }
function padDir(d, dir) { // direction with hold-to-repeat
  if (d.dir === dir) return; d.dir = dir; clearTimeout(d.t1); clearInterval(d.t2);
  if (!dir) return; padEmit(padAction(d.name, DIRIDX[dir]) || '');
  const act = padAction(d.name, DIRIDX[dir]); if (!act) return; d.t1 = setTimeout(() => { d.t2 = setInterval(() => padEmit(act), 90); }, 350);
}
function padScan() {
  let txt = ''; try { txt = fs.readFileSync('/proc/bus/input/devices', 'utf8'); } catch { return; }
  const live = new Set();
  for (const blk of txt.split('\n\n')) {
    const h = (blk.match(/^H: Handlers=(.*)$/m) || [])[1] || '', ev = h.match(/\bevent(\d+)\b/);
    if (!ev || !/\bjs\d+\b/.test(h)) continue;
    const p = '/dev/input/event' + ev[1]; live.add(p); if (EVD.devs.has(p)) continue;
    try { const fd = fs.openSync(p, fs.constants.O_RDONLY | fs.constants.O_NONBLOCK); EVD.devs.set(p, { fd, name: ((blk.match(/^N: Name="(.*)"$/m) || [])[1]) || 'Controller', dir: '', hat: { x: 0, y: 0 }, key: {}, ax: {}, stick: { x: 0, y: 0 } }); } catch {}
  }
  for (const [p, d] of EVD.devs) if (!live.has(p)) { try { fs.closeSync(d.fd); } catch {} clearTimeout(d.t1); clearInterval(d.t2); EVD.devs.delete(p); }
}
function padDirOf(d) {
  const k = d.key, h = d.hat, s = d.stick;
  const x = k.left ? -1 : k.right ? 1 : h.x || s.x, y = k.up ? -1 : k.down ? 1 : h.y || s.y;
  return x < 0 ? 'left' : x > 0 ? 'right' : y < 0 ? 'up' : y > 0 ? 'down' : '';
}
function padPoll() {
  const buf = Buffer.alloc(24 * 32);
  for (const [p, d] of EVD.devs) {
    let n = 0;
    try { n = fs.readSync(d.fd, buf, 0, buf.length, null); } catch (e) { if (e.code === 'ENODEV' || e.code === 'EBADF') { try { fs.closeSync(d.fd); } catch {} EVD.devs.delete(p); } continue; }
    for (let o = 0; o + 24 <= n; o += 24) {
      const type = buf.readUInt16LE(o + 16), code = buf.readUInt16LE(o + 18), v = buf.readInt32LE(o + 20);
      if (type === 1 && v !== 2) {
        const a = EVKEY[code]; if (!a) continue;
        if (a === 'up' || a === 'down' || a === 'left' || a === 'right') { d.key[a] = !!v; if (v === 1) send('pad:raw', { name: d.name, idx: DIRIDX[a] }); padDir(d, padDirOf(d)); }
        else if (v === 1 && EVSTD[code] !== undefined) padPress(d, EVSTD[code]);
      } else if (type === 3) {
        if (code === 16) { d.hat.x = v; if (v) send('pad:raw', { name: d.name, idx: v < 0 ? 14 : 15 }); padDir(d, padDirOf(d)); }
        else if (code === 17) { d.hat.y = v; if (v) send('pad:raw', { name: d.name, idx: v < 0 ? 12 : 13 }); padDir(d, padDirOf(d)); }
        else if (code === 0 || code === 1) {
          let a = d.ax[code]; if (!a) a = d.ax[code] = Math.abs(v - 128) < 40 ? { c: 128, t: 70 } : { c: 0, t: 16000 };
          const r = v - a.c, val = Math.abs(r) > a.t ? (r < 0 ? -1 : 1) : 0;
          if (code === 0) d.stick.x = val; else d.stick.y = val; padDir(d, padDirOf(d));
        }
      }
    }
  }
}
function padStart() { if (!LINUX || !process.versions.electron || EVD.tmr) return; padScan(); EVD.tmr = setInterval(padPoll, 20); setInterval(padScan, 3000); }



// ---------- save backups ----------
const SAVE_RE = /\.(srm|rtc|sav|mcr|mcd|mc|eep|sra|fla|dsv|nv|bsv|state\d*|state\.auto)$/i;
const PROF_RE = /^[A-Za-z0-9][A-Za-z0-9 _.\-]{0,31}$/;
const ANDH = process.env.APP_VERCODE && process.env.HOME; // Android: the app's own files folder, shared with the native player
const SHSAVES = c => (c.shareSaves && c.romRoot && !ANDH) ? path.join(c.romRoot, 'Cacti Saves') : ''; // saves kept in the ROM folder, shared by every device that opens it
const profBase = c => c.profilesDir || (SHSAVES(c) ? path.join(SHSAVES(c), 'players') : ANDH ? path.join(ANDH, 'profiles') : path.join(app.getPath('userData'), 'profiles'));
const profOk = n => typeof n === 'string' && PROF_RE.test(n) && !/\.\.|\s$/.test(n);
let GUEST = false; const guestDir = () => ANDH ? path.join(ANDH, 'guest-session') : path.join(app.getPath('userData'), 'guest-session');
const effSaveDir = c => GUEST ? guestDir() : (c.profile && profOk(c.profile) ? path.join(profBase(c), c.profile) : (SHSAVES(c) ? path.join(SHSAVES(c), 'everyone') : c.saveDir));
const bkBase = c => path.join(c.backupDir || path.join(app.getPath('userData'), 'save-backups'), c.profile && profOk(c.profile) ? c.profile : '');
const saveRoot = c => effSaveDir(c) || (process.env.NO_OPEN === '1' && process.env.HOME) || c.romRoot;
function saveFiles(c) {
  const root = saveRoot(c), base = path.resolve(bkBase(c)), skipD = [path.resolve(profBase(c)), path.resolve(guestDir())].filter(d => d !== path.resolve(root || '')), out = []; if (!root || !fs.existsSync(root)) return { root, files: out };
  const walk = (d, depth) => {
    if (out.length > 20000) return; let es = []; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of es) {
      const p = path.join(d, e.name); if (e.name[0] === '.' || path.resolve(p) === base || skipD.includes(path.resolve(p))) continue;
      if (e.isDirectory()) { if (depth < 5 && !['cores', 'images', 'media', 'boxart', 'assets', 'shaders', 'thumbnails', 'autoconfig', 'overlays', 'database', 'info', 'downloads', 'filters', 'cheats', 'playlists', 'logs', 'config', 'cache', 'meta-cache', 'art'].includes(e.name)) walk(p, depth + 1); continue; }
      if (e.isFile() && SAVE_RE.test(e.name)) { try { const st = fs.statSync(p); out.push({ rel: path.relative(root, p), abs: p, size: st.size, mtime: st.mtimeMs }); } catch {} }
    }
  };
  walk(root, 0); return { root, files: out };
}
function bkList(c) {
  const base = bkBase(c), out = [];
  try { for (const id of fs.readdirSync(base)) { try { const m = JSON.parse(fs.readFileSync(path.join(base, id, 'manifest.json'), 'utf8')); out.push({ id, when: m.t, files: m.n, bytes: m.bytes, why: m.why || '' }); } catch {} } } catch {}
  return out.sort((a, b) => b.when - a.when);
}
let bkBusy = false;
async function backupSaves(c, force, why) {
  if (GUEST) return { ok: true, skipped: true };
  if (bkBusy) return { ok: false, error: 'A backup is already running.' }; bkBusy = true;
  try {
    const { root, files } = saveFiles(c); if (!files.length) return { ok: false, error: 'No saves found yet. Play a game and save first.' };
    const list = bkList(c), last = list[0] ? list[0].when : 0;
    if (!force && !files.some(f => f.mtime > last)) return { ok: true, skipped: true };
    const id = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14) + (why ? '-' + why : ''), dest = path.join(bkBase(c), id);
    let bytes = 0; for (const f of files) { const t = path.join(dest, 'data', f.rel); await fs.promises.mkdir(path.dirname(t), { recursive: true }); await fs.promises.copyFile(f.abs, t); bytes += f.size; }
    try { // the player's profile and settings travel with the backup (never passwords, keys or tokens)
      const o = {}; for (const k of KEYS) if (!SECRETS.includes(k) && k !== 'syncLast') o[k] = c[k]; o.padMap = c.padMap || {}; o.scrapeEngines = c.scrapeEngines || {}; o.cores = c.cores || {};
      await fs.promises.mkdir(path.join(dest, 'profile'), { recursive: true }); await fs.promises.writeFile(path.join(dest, 'profile', 'settings.json'), JSON.stringify({ profile: c.profile || '', raUser: c.raUser || '', settings: o }, null, 1));
    } catch {}
    await fs.promises.writeFile(path.join(dest, 'manifest.json'), JSON.stringify({ t: Date.now(), root, n: files.length, bytes, why, rels: files.map(f => f.rel) }));
    const keep = Math.max(1, Math.min(100, parseInt(c.backupKeep, 10) || 10)), all = bkList(c).filter(b => !b.why);
    for (const b of all.slice(keep)) fs.rmSync(path.join(bkBase(c), b.id), { recursive: true, force: true });
    return { ok: true, files: files.length, bytes };
  } catch (e) { return { ok: false, error: 'Backup failed: ' + e.message }; } finally { bkBusy = false; }
}
async function restoreSaves(c, id, withSettings) {
  if (child) return { ok: false, error: 'Close the running game first.' };
  const dir = path.join(bkBase(c), String(id || '').replace(/[\\/]/g, '')); let m; try { m = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8')); } catch { return { ok: false, error: 'That backup is missing.' }; }
  const root = path.resolve(saveRoot(c)); if (path.resolve(m.root) !== root) return { ok: false, error: 'This backup was made for a different saves location.' };
  await backupSaves(c, true, 'before-restore');
  let n = 0; for (const rel of m.rels || []) { const t = path.resolve(root, rel); if (!t.startsWith(root + path.sep) || path.isAbsolute(rel)) continue; try { fs.mkdirSync(path.dirname(t), { recursive: true }); fs.copyFileSync(path.join(dir, 'data', rel), t); n++; } catch {} }
  let st = false; try { const j = JSON.parse(fs.readFileSync(path.join(dir, 'profile', 'settings.json'), 'utf8')), cur = load(); if (j && j.settings && withSettings) { const s = { ...j.settings }; delete s.profile; save({ ...cur, ...s }); st = true; } } catch {}
  scanCache = null; return { ok: true, files: n, settings: st };
}
// ---------- players: each one gets a folder for saves and save states ----------
function profList(c) { try { return fs.readdirSync(profBase(c), { withFileTypes: true }).filter(e => e.isDirectory() && profOk(e.name)).map(e => e.name).sort((a, b) => a.localeCompare(b)); } catch { return []; } }
function profCreate(name, adopt) {
  const c = load(); name = String(name || '').trim();
  if (!profOk(name)) return { ok: false, error: 'Use letters, numbers, spaces, dots, dashes or underscores (up to 32).' };
  if (profList(c).some(x => x.toLowerCase() === name.toLowerCase())) return { ok: false, error: 'That player already exists.' };
  const from = saveRoot(c), dest = path.join(profBase(c), name); let copied = 0;
  try {
    fs.mkdirSync(path.join(dest, 'saves'), { recursive: true }); fs.mkdirSync(path.join(dest, 'states'), { recursive: true });
    if (adopt && from && fs.existsSync(from)) for (const f of saveFiles(c).files) { const t = ANDH ? path.join(dest, f.rel) : path.join(dest, 'saves', path.basename(f.rel)); if (!fs.existsSync(t)) { fs.mkdirSync(path.dirname(t), { recursive: true }); fs.copyFileSync(f.abs, t); copied++; } }
  } catch (e) { return { ok: false, error: e.message }; }
  c.profile = name; save(c); scanCache = null; return { ok: true, copied };
}
function profRename(to) {
  const c = load(); to = String(to || '').trim();
  if (!c.profile) return { ok: false, error: 'No player is selected.' };
  if (!profOk(to)) return { ok: false, error: 'That name cannot be used as a folder name.' };
  if (to === c.profile) return { ok: true, same: true };
  if (child) return { ok: false, error: 'Close the running game first.' };
  const a = path.join(profBase(c), c.profile), b = path.join(profBase(c), to);
  if (fs.existsSync(b) && to.toLowerCase() !== c.profile.toLowerCase()) return { ok: false, error: 'A player called ' + to + ' already exists.' };
  try {
    if (to.toLowerCase() === c.profile.toLowerCase()) { const tmp = a + '.tmp-' + Date.now(); fs.renameSync(a, tmp); fs.renameSync(tmp, b); } else fs.renameSync(a, b);
    const bo = path.join(c.backupDir || path.join(app.getPath('userData'), 'save-backups'), c.profile), bn = path.join(c.backupDir || path.join(app.getPath('userData'), 'save-backups'), to);
    if (fs.existsSync(bo) && !fs.existsSync(bn)) { fs.renameSync(bo, bn); for (const id of fs.readdirSync(bn)) { const mp = path.join(bn, id, 'manifest.json'); try { const j = JSON.parse(fs.readFileSync(mp, 'utf8')); if (j.root) j.root = path.join(path.dirname(j.root), to); fs.writeFileSync(mp, JSON.stringify(j)); } catch {} } }
  } catch (e) { return { ok: false, error: 'Could not rename: ' + e.message }; }
  c.profile = to; save(c); scanCache = null; return { ok: true }; // RetroArch paths are rebuilt from the profile on every launch
}


// ---------- sync saves and save states between devices (never ROMs): through a shared folder, or straight to another Cacti OS on the network ----------
// Names are made system-neutral first (snes/Game.srm, whatever the folder is called on each device) so Windows, Mac and Pi line up.
const canonRel = rel => { const p = rel.split(path.sep).join('/').split('/'), s = SYSTEMS.find(x => x.folder && x.folder.some(f => f.toLowerCase() === p[0].toLowerCase())); if (s) p[0] = s.id; return p.join('/'); };
const localRel = (c, canon) => { const p = canon.split('/'), s = SYSTEMS.find(x => x.id === p[0] && x.folder); if (s && c.romRoot) p[0] = path.basename(upDir(c, s)); return p.join('/'); };
const relOk = (rel, root) => { if (!rel || rel.length > 400 || path.isAbsolute(rel) || rel.includes('\0') || rel.split(/[\\/]/).some(x => x === '..' || x === '' || x[0] === '.') || !SAVE_RE.test(rel)) return null; const t = path.resolve(root, rel); return t.startsWith(path.resolve(root) + path.sep) ? t : null; };
const SYNCST = () => path.join(app.getPath('userData'), 'sync-state.json');
const syncStLoad = () => { try { return JSON.parse(fs.readFileSync(SYNCST(), 'utf8')); } catch { return {}; } };
const SYNC_MAX = 256 * 1024 * 1024;
function syncList(c) { const { root, files } = saveFiles(c); return { root, files: files.filter(f => f.size <= SYNC_MAX).map(f => ({ rel: canonRel(f.rel), m: Math.round(f.mtime), size: f.size, abs: f.abs })) }; }
function syncPut(c, canon, buf, m) { const root = saveRoot(c), t = relOk(localRel(c, canon), root); if (!t) throw new Error('bad name'); fs.mkdirSync(path.dirname(t), { recursive: true }); const tmp = t + '.sync-part'; fs.writeFileSync(tmp, buf); fs.utimesSync(tmp, m / 1000, m / 1000); fs.renameSync(tmp, t); }
let syncBusy = false;
async function autoSync() { const c = load(); try { if (c.syncDir) await syncGo('folder'); if (c.syncPeer && c.syncCode) await syncGo('peer'); } catch {} }
async function syncRun(c, ad, tag) {
  if (syncBusy) return { error: 'A sync is already running.' }; if (child) return { error: 'Close the running game first.' };
  const root = saveRoot(c); if (!root || !fs.existsSync(root)) return { error: 'Set up your games or saves folder first.' };
  syncBusy = true;
  try {
    const loc = new Map(syncList(c).files.map(f => [f.rel, f])), rem = new Map((await ad.list()).map(f => [f.rel, f])), st = syncStLoad(), mine = st[tag] || (st[tag] = {}), plan = [];
    for (const rel of new Set([...loc.keys(), ...rem.keys()])) {
      const L = loc.get(rel), R = rem.get(rel), S = mine[rel];
      if (L && !R) plan.push(['push', rel]); else if (!L && R) plan.push(['pull', rel]);
      else if (L.size === R.size && Math.abs(L.m - R.m) < 2500) { mine[rel] = { m: Math.max(L.m, R.m) }; }
      else { const conflict = S && L.m > S.m + 2500 && R.m > S.m + 2500; plan.push([L.m >= R.m ? 'push' : 'pull', rel, conflict]); }
    }
    if (plan.some(p => p[0] === 'pull' && loc.has(p[1]))) await backupSaves(c, true, 'before-sync');
    let pushed = 0, pulled = 0, conflicts = 0; const confDir = path.join(root, '.sync-conflicts');
    for (const [act, rel, conflict] of plan) {
      if (act === 'push') { const L = loc.get(rel); await ad.put(rel, fs.readFileSync(L.abs), L.m); mine[rel] = { m: L.m }; pushed++; if (conflict) { conflicts++; } }
      else {
        const R = rem.get(rel), buf = await ad.get(rel), t = relOk(localRel(c, rel), root); if (!t) continue;
        if (conflict && fs.existsSync(t)) { fs.mkdirSync(confDir, { recursive: true }); fs.copyFileSync(t, path.join(confDir, `${Date.now()}-${path.basename(t)}`)); conflicts++; }
        syncPut(c, rel, buf, R.m); mine[rel] = { m: R.m }; pulled++;
      }
    }
    fs.writeFileSync(SYNCST(), JSON.stringify(st)); const cc = load(); save({ ...cc, syncLast: Date.now() }); scanCache = null;
    return { ok: true, pushed, pulled, conflicts, total: loc.size };
  } catch (e) { return { error: 'Sync stopped: ' + (e.message || e) }; } finally { syncBusy = false; }
}
function folderAdapter(c) {
  const base = path.join(c.syncDir, 'CactiOS-Sync', 'saves'); fs.mkdirSync(base, { recursive: true });
  return {
    list: async () => { const out = []; const walk = (d, rel) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { if (e.name[0] === '.') continue; const p = path.join(d, e.name), r = rel ? rel + '/' + e.name : e.name; if (e.isDirectory()) walk(p, r); else if (SAVE_RE.test(e.name)) { const st = fs.statSync(p); out.push({ rel: r, m: Math.round(st.mtimeMs), size: st.size }); } } }; walk(base, ''); return out; },
    get: async rel => { const t = relOk(rel, base); if (!t) throw new Error('bad name'); return fs.readFileSync(t); },
    put: async (rel, buf, m) => { const t = relOk(rel, base); if (!t) throw new Error('bad name'); fs.mkdirSync(path.dirname(t), { recursive: true }); fs.writeFileSync(t, buf); fs.utimesSync(t, m / 1000, m / 1000); }
  };
}
function peerAdapter(c) {
  const host = c.syncPeer.includes(':') ? c.syncPeer : c.syncPeer + ':8080', H = { 'X-Code': String(c.syncCode || '') }, u = p => `http://${host}/api/sync/${p}`;
  const chk = r => { if (r.status === 401) throw new Error('The other device did not accept the code.'); if (!r.ok) throw new Error('The other device answered ' + r.status); return r; };
  return {
    list: async () => (await (chk(await fetch(u('list'), { headers: H, signal: AbortSignal.timeout(15000) }))).json()).files,
    get: async rel => Buffer.from(await (chk(await fetch(u('file?rel=' + encodeURIComponent(rel)), { headers: H, signal: AbortSignal.timeout(60000) }))).arrayBuffer()),
    put: async (rel, buf, m) => { chk(await fetch(u(`file?rel=${encodeURIComponent(rel)}&m=${m}`), { method: 'POST', headers: H, body: buf, signal: AbortSignal.timeout(60000) })); }
  };
}
async function syncGo(kind) {
  const c = load();
  if (kind === 'folder') { if (!c.syncDir || !fs.existsSync(c.syncDir)) return { error: 'Choose your sync folder first.' }; try { return await syncRun(c, folderAdapter(c), 'folder'); } catch (e) { return { error: 'Sync stopped: ' + e.message }; } }
  if (!c.syncPeer || !c.syncCode) return { error: 'Enter the other device\'s address and code first.' };
  try { return await syncRun(c, peerAdapter(c), 'peer:' + c.syncPeer); } catch (e) { return { error: 'Could not reach the other device: ' + (e.message || e) }; }
}

// ---------- Bluetooth controllers (Raspberry Pi / Linux, through bluetoothctl) ----------
const MACRE = /^([0-9A-F]{2}:){5}[0-9A-F]{2}$/i;
const btRaw = (args, ms = 8000) => new Promise(res => { try { execFile('bluetoothctl', args, { timeout: ms }, (e, out, err) => res({ ok: !e, out: String(out || '') + String(err || ''), missing: e && e.code === 'ENOENT' })); } catch { res({ ok: false, out: '', missing: true }); } });
function btSession(cmds, ms, until) { // feed bluetoothctl a short script on stdin (an agent is needed to pair)
  return new Promise(res => {
    let p; try { p = spawn('bluetoothctl', [], { stdio: ['pipe', 'pipe', 'pipe'] }); } catch { return res({ ok: false, out: '', missing: true }); }
    let out = '', done = false;
    const end = () => { if (done) return; done = true; clearTimeout(t); try { p.stdin.write('quit\n'); } catch {} setTimeout(() => { try { p.kill(); } catch {} }, 400); res({ ok: true, out }); };
    const t = setTimeout(end, ms);
    p.on('error', e => { if (!done) { done = true; clearTimeout(t); res({ ok: false, out, missing: e.code === 'ENOENT' }); } });
    p.stdout.on('data', d => { out += d; if (until && until.test(out)) setTimeout(end, 600); }); p.stderr.on('data', d => { out += d; });
    let i = 0; const step = () => { if (done || i >= cmds.length) return; try { p.stdin.write(cmds[i++] + '\n'); } catch {} setTimeout(step, 900); }; step();
  });
}
let btTried = 0;
async function btEnsure() { // is there a Bluetooth adapter? If not, try to switch it on, and write down why in the log
  const has = async () => /^Controller /m.test((await btRaw(['list'], 4000)).out);
  if (!LINUX) return true;
  if (await has()) return true;
  if (Date.now() - btTried < 20000) return false; btTried = Date.now();
  await sh('rfkill', ['unblock', 'bluetooth']);
  if (await has()) return true;
  if (HOOKS.rootDo) { const r = await HOOKS.rootDo(['bt']); logEv('bluetooth helper: ' + (r.ok ? 'ran' : r.error)); await new Promise(r => setTimeout(r, 2500)); if (await has()) return true; }
  logEv('bluetooth: no adapter. rfkill: ' + (await sh('rfkill', ['list'])).replace(/\s+/g, ' ').slice(0, 200) + ' | /sys/class/bluetooth: ' + (fs.existsSync('/sys/class/bluetooth') ? fs.readdirSync('/sys/class/bluetooth').join(',') || 'empty' : 'missing'));
  return false;
}
const BT_NONE = 'No Bluetooth adapter was found on this device. Open Menu > Advanced > System Check and send the log if it should have one.';
async function btList() {
  if (!LINUX) return { supported: false, system: true, devices: [] };
  const r = await btRaw(['devices']);
  if (r.missing) { logEv('bluetooth: bluetoothctl not found. PATH=' + process.env.PATH + ' | ' + ['/usr/bin/bluetoothctl', '/usr/sbin/bluetoothd', '/usr/libexec/bluetooth/bluetoothd'].map(f => f + (fs.existsSync(f) ? ' yes' : ' no')).join(', ')); return { supported: false, devices: [], error: 'The Bluetooth tool (bluetoothctl) was not found on this system. Open Menu > Advanced > System Check and send the log, so the Bluetooth package can be fixed in the image.' }; }
  if (!(await btEnsure())) return { supported: false, devices: [], error: BT_NONE };
  const macs = [...r.out.matchAll(/^Device ([0-9A-F:]{17}) (.*)$/gim)].map(m => [m[1].toUpperCase(), m[2]]).slice(0, 40);
  const devices = (await Promise.all(macs.map(async ([mac, nm]) => {
    const i = (await btRaw(['info', mac], 4000)).out, g = k => ((i.match(new RegExp('^\\s*' + k + ': (.*)$', 'm')) || [])[1] || '').trim();
    const bat = (g('Battery Percentage').match(/\((\d+)\)/) || [])[1];
    return { mac, name: g('Alias') || g('Name') || nm, paired: g('Paired') === 'yes', connected: g('Connected') === 'yes', gaming: /gaming|joystick|gamepad/i.test(g('Icon')) || /controller|gamepad|pro 2|dualsense|dualshock|xbox|joy-?con|8bitdo|steam|vader|flydigi/i.test(nm), battery: bat ? +bat : null, near: g('RSSI') !== '' };
  }))).filter(d => d.paired || d.near);
  return { supported: true, devices: devices.sort((a, b) => (b.connected - a.connected) || (b.paired - a.paired) || (b.gaming - a.gaming) || a.name.localeCompare(b.name)) };
}
async function btScan() {
  if (!LINUX) return { supported: false, system: true, devices: [] };
  if (!(await btEnsure())) return { supported: false, devices: [], error: BT_NONE };
  const r = await btSession(['power on', 'scan on'], 7500);
  if (r.missing) return { supported: false, devices: [], error: 'The Bluetooth tool (bluetoothctl) was not found on this system. Open Menu > Advanced > System Check and send the log, so the Bluetooth package can be fixed in the image.' };
  return btList();
}
async function btPair(mac) {
  mac = String(mac || '').toUpperCase(); if (!MACRE.test(mac)) return { ok: false, error: 'Not a valid device.' };
  const r = await btSession(['power on', 'agent NoInputNoOutput', 'default-agent', 'scan on', `pair ${mac}`, `trust ${mac}`, `connect ${mac}`], 30000, /Connection successful|Failed to (pair|connect)|AuthenticationFailed|org\.bluez\.Error/i);
  if (r.missing) return { ok: false, error: 'Bluetooth is not available on this system.' };
  if (/Connection successful/i.test(r.out)) return { ok: true };
  const m = r.out.match(/(Failed to (?:pair|connect)[^\n]*|AuthenticationFailed|org\.bluez\.Error[^\n]*)/i);
  return { ok: false, error: m ? 'Could not pair. Put the controller in pairing mode again and retry. (' + m[1].replace(/\x1b\[[0-9;]*m/g, '').slice(0, 80) + ')' : 'No answer from the controller. Put it in pairing mode and retry.' };
}
async function btAct(cmd, mac) {
  mac = String(mac || '').toUpperCase(); if (!MACRE.test(mac) || !['connect', 'disconnect', 'remove'].includes(cmd)) return { ok: false, error: 'Not a valid device.' };
  const r = await btRaw([cmd, mac], 15000); return /Failed|not available|Error/i.test(r.out) && !/successful|removed/i.test(r.out) ? { ok: false, error: 'That did not work. Try again.' } : { ok: true };
}
function btSettings() { if (WIN) shell.openExternal('ms-settings:bluetooth'); else if (process.platform === 'darwin') shell.openExternal('x-apple.systempreferences:com.apple.BluetoothSettings'); return { ok: true }; }

// ---------- Upload ROMs from a browser on the same network ----------
const http = require('http');
let upSrv = null, upPort = 0; const upFails = new Map();
const UP_EXTRA = ['.zip', '.7z', '.bin', '.cue', '.iso', '.chd', '.m3u', '.img', '.sub', '.ccd', '.mds', '.mdf', '.pbp', '.ecm', '.rvz', '.gcz', '.wbfs'];
const upBios = c => { let r = c.romRoot; try { r = fs.realpathSync(r); } catch {} return path.join(path.dirname(r), 'bios'); };
const upDir = (c, s) => path.join(c.romRoot, s.folder.find(f => fs.existsSync(path.join(c.romRoot, f))) || s.folder[0]);
const upName = n => { n = path.basename(String(n || '').replace(/\\/g, '/')); return n && n.length <= 200 && !n.startsWith('.') && !/[\x00-\x1f<>:"|?*]/.test(n) ? n : ''; };
const upFiles = d => { try { return fs.readdirSync(d, { withFileTypes: true }).filter(e => e.isFile() && !e.name.startsWith('.')); } catch { return []; } };

// ---------- web admin (same page and code as the ROM uploader): library, settings, backups, logs, update upload, restart ----------
const HOOKS = {}; // filled in once the app is ready (update and restart code live inside that scope)
const CRED_TXT = ['raUser', 'igdbId', 'ssUser'], CRED_SECRET = ['raKey', 'raPass', 'tgdbKey', 'igdbSecret', 'ssPass'];
const ADMIN_BOOL = ['fullscreen', 'dark', 'navSounds', 'splash', 'showFav', 'showLast', 'showAll', 'raOnly', 'raGames', 'autoLoad', 'autoSave', 'backupAuto', 'hardcore', 'trophy', 'declutter', 'syncAuto'];
const ADMIN_TXT = { backupKeep: v => String(Math.max(1, Math.min(100, parseInt(v, 10) || 10))), prompts: v => ['Xbox', 'PlayStation', 'Nintendo'].includes(v) ? v : 'Xbox', layout: v => LAYOUTS.includes(v) ? v : 'classic', updMode: v => ['off', 'manual', 'startup', 'weekly'].includes(v) ? v : 'manual', quitCombo: v => ['0', '1', '2', '3'].includes(String(v)) ? String(v) : '2' };
let adminMan = null;
function adminApi(req, res, u, c, json) {
  const p = u.pathname.slice(11), get = req.method === 'GET', post = req.method === 'POST';
  const body = (max, cb) => { const ch = []; let n = 0, dead = false; req.on('data', d => { n += d.length; if (n > max) { dead = true; json(413, { error: 'Too big.' }); req.destroy(); } else ch.push(d); }); req.on('end', () => { if (!dead) cb(Buffer.concat(ch)); }); };
  if (get && p === 'status') {
    const sc = scan(c); return json(200, { version: HOOKS.appVer ? HOOKS.appVer() : '', platform: process.platform + '/' + process.arch, host: os.hostname(), uptime: Math.round(process.uptime()), romRoot: c.romRoot, games: sc.reduce((n, s) => n + s.games.length, 0), systems: sc.length, details: META.count(), gameRunning: !!child, updMode: c.updMode, updateUrl: c.updateUrl, canRestart: !!(HOOKS.restart && app.relaunch) });
  }
  if (get && p === 'library') { const sys = u.searchParams.get('sys'), sc = scan(c); if (!sys) return json(200, { systems: sc.map(s => ({ id: s.id, name: s.name, count: s.games.length, withArt: s.games.filter(g => g.art).length, withInfo: s.games.filter(g => g.meta && g.meta.desc).length })) }); const s = sc.find(x => x.id === sys); if (!s) return json(404, { error: 'Unknown system.' }); return json(200, { name: s.name, games: s.games.slice(0, 3000).map(g => ({ title: g.title, file: path.basename(g.file), art: !!g.art, year: g.meta && g.meta.year || '', genre: g.meta && g.meta.genre || '', dev: g.meta && g.meta.dev || '', favorite: false })) }); }
  if (get && p === 'settings') { const o = {}; for (const k of ADMIN_BOOL) o[k] = c[k] === true || c[k] === 'true'; for (const k of Object.keys(ADMIN_TXT)) o[k] = c[k]; return json(200, o); }
  if (post && p === 'settings') return body(8192, buf => {
    let j; try { j = JSON.parse(buf.toString('utf8')); } catch { return json(400, { error: 'Bad request.' }); }
    const cc = load(); for (const [k, v] of Object.entries(j || {})) { if (ADMIN_BOOL.includes(k)) cc[k] = !!v; else if (ADMIN_TXT[k]) cc[k] = ADMIN_TXT[k](String(v)); }
    save(cc); logEv('settings changed from the web page'); send('cfg:changed', 1); if ('fullscreen' in j && win) setFs(!!cc.fullscreen); json(200, { ok: true });
  });
  if (get && p === 'creds') { const o = { texts: {}, saved: {}, signedIn: !!c.raToken }; for (const k of CRED_TXT) o.texts[k] = c[k] || ''; for (const k of CRED_SECRET) o.saved[k] = !!c[k]; o.saved.raPass = !!c.raToken || !!c.raPass; return json(200, o); }
  if (post && p === 'creds') return body(16384, buf => {
    let j; try { j = JSON.parse(buf.toString('utf8')); } catch { return json(400, { error: 'Bad request.' }); }
    const set = {}, clear = Array.isArray(j.clear) ? j.clear.filter(k => CRED_TXT.includes(k) || CRED_SECRET.includes(k)) : [];
    for (const k of [...CRED_TXT, ...CRED_SECRET]) { const v = j.set && j.set[k]; if (typeof v === 'string' && v.trim() && v.length < 600) set[k] = v.trim(); }
    if (clear.length) { const cc = load(); for (const k of clear) { cc[k] = ''; if (k === 'raPass') { cc.raToken = ''; } } save(cc); }
    if (!HOOKS.cfgSet) return json(503, { error: 'Not ready yet.' });
    (Object.keys(set).length ? HOOKS.cfgSet(set) : Promise.resolve({ loginError: '' })).then(r => { logEv('account details changed from the web page (' + [...Object.keys(set), ...clear].join(', ') + ')'); send('cfg:changed', 1); json(200, { ok: true, loginError: r.loginError || '' }); }).catch(e => json(500, { error: String(e.message || e).slice(0, 120) }));
  });
  if (post && p === 'update-url') return json(403, { error: 'The update address is fixed.' });
  if (false) return body(4096, buf => {
    let j; try { j = JSON.parse(buf.toString('utf8')); } catch { return json(400, { error: 'Bad request.' }); }
    const v = String(j.url || '').trim(); if (v && !/^https:\/\/[^\s]+$/i.test(v)) return json(400, { error: 'The address must start with https://' });
    const cc = load(); cc.updateUrl = v; save(cc); logEv('update address ' + (v ? 'set' : 'cleared') + ' from the web page'); send('cfg:changed', 1); json(200, { ok: true });
  });
  if (post && p === 'update-check') { if (!HOOKS.updCheck) return json(503, { error: 'Not ready yet.' }); return HOOKS.updCheck(false).then(r => json(200, r)).catch(e => json(500, { error: String(e.message || e).slice(0, 120) })); }
  if (get && p === 'backups') return json(200, { backups: bkList(c), files: saveFiles(c).files.length });
  if (post && p === 'backup') return backupSaves(c, true, 'web').then(r => json(r.ok ? 200 : 409, r.ok ? r : { error: r.error }));
  if (post && p === 'restore') return restoreSaves(c, u.searchParams.get('id')).then(r => { logEv('restore from the web page: ' + (r.ok ? 'ok' : r.error)); json(r.ok ? 200 : 409, r.ok ? r : { error: r.error }); });
  if (get && p === 'log') return json(200, { lines: LOGBUF.slice(-300) });
  if (post && p === 'scraper-test') return body(2048, buf => { let j = {}; try { j = JSON.parse(buf.toString() || '{}'); } catch {} scraperTest(String(j.engine || '')).then(r => json(200, r)).catch(e => json(200, { ok: false, msg: e.message })); });
  if (post && p === 'scrape') { if (metaBusy) return json(409, { error: 'Already running.' }); scrape(null).catch(() => {}); return json(200, { ok: true }); }
  if (post && p === 'rescan') { scanCache = null; send('cfg:changed', 1); return json(200, { ok: true }); }
  if (post && p === 'update-manifest') return body(65536, buf => { try { const m = JSON.parse(buf.toString('utf8')); if (!HOOKS.updSigOk || !HOOKS.updSigOk(m)) return json(400, { error: 'That manifest is not signed correctly.' }); adminMan = m; json(200, { ok: true, version: m.version, notes: m.notes }); } catch { json(400, { error: 'That is not a manifest file.' }); } });
  if (post && p === 'update-bundle') return body(200 * 1024 * 1024, buf => {
    const m = adminMan; if (!m) return json(409, { error: 'Upload the manifest.json first.' });
    if (buf.length !== m.size || crypto.createHash('sha256').update(buf).digest('hex') !== m.sha256) return json(400, { error: 'The update file does not match the manifest, so it was not installed.' });
    if (child) return json(409, { error: 'Close the running game first.' });
    const r = HOOKS.updApply(buf, m.version); adminMan = null; if (!r.ok) return json(400, { error: r.error });
    logEv('update ' + m.version + ' installed from the web page'); json(200, { ok: true, version: m.version, restarting: !!(HOOKS.restart && app.relaunch) }); if (HOOKS.restart) HOOKS.restart({});
  });
  if (get && p === 'install') { if (!HOOKS.inst) return json(503, { error: 'Not ready yet.' }); return HOOKS.inst.info().then(r => json(200, r)).catch(e => json(500, { error: String(e.message || e).slice(0, 120) })); }
  if (get && p === 'install-status') return json(200, HOOKS.inst ? HOOKS.inst.status() : { state: 'none' });
  if (post && p === 'install-start') return body(2048, buf => {
    let j = {}; try { j = JSON.parse(buf.toString('utf8')); } catch { return json(400, { error: 'Bad request.' }); }
    if (!HOOKS.inst) return json(503, { error: 'Not ready yet.' });
    if (child) return json(409, { error: 'Close the running game first.' });
    if (!/^[a-z0-9]+$/.test(String(j.disk || '')) || j.confirm !== j.disk) return json(400, { error: 'Type the drive name to confirm.' });
    logEv('install to drive ' + j.disk + ' requested from the web page');
    HOOKS.inst.start(j.disk, !!j.keep).then(r => json(r.error ? 409 : 200, r)).catch(e => json(500, { error: String(e.message || e).slice(0, 120) }));
  });
  if (post && p === 'install-reboot') { if (!HOOKS.inst) return json(503, { error: 'Not ready yet.' }); logEv('restart of the computer requested from the web page'); return HOOKS.inst.reboot().then(r => json(r.error ? 409 : 200, r)); }
  if (post && p === 'restart') { if (!HOOKS.restart || !app.relaunch) return json(409, { error: 'Restart is not available in this edition. Stop it and start it again by hand.' }); logEv('restart requested from the web page'); json(200, { ok: true }); setTimeout(() => HOOKS.restart({}), 300); return; }
  return json(404, { error: 'Unknown request.' });
}
function upHandle(req, res) {
  const u = new URL(req.url, 'http://x'), ip = req.socket.remoteAddress || '';
  const json = (code, o) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(o)); };
  if (req.method === 'GET' && (u.pathname === '/' || u.pathname === '/index.html')) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; img-src data:" });
    fs.createReadStream(path.join(__dirname, 'renderer', 'upload.html')).pipe(res); return;
  }
  if (!u.pathname.startsWith('/api/')) { res.writeHead(404).end(); return; }
  const c = load(), f = upFails.get(ip) || { n: 0, t: Date.now() };
  if (Date.now() - f.t > 60000) { f.n = 0; f.t = Date.now(); }
  if (f.n >= 8) { json(429, { error: 'Too many wrong codes. Wait a minute and try again.' }); if (req.method === 'POST') req.destroy(); return; }
  const a = Buffer.from(String(req.headers['x-code'] || '')), b = Buffer.from(String(c.uploadCode || ''));
  if (!b.length || a.length !== b.length || !crypto.timingSafeEqual(a, b)) { f.n++; upFails.set(ip, f); json(401, { error: 'Wrong code.' }); if (req.method === 'POST') req.destroy(); return; }
  upFails.delete(ip);
  if (u.pathname === '/api/sync/list' && req.method === 'GET') return json(200, { files: syncList(c).files.map(({ rel, m, size }) => ({ rel, m, size })) });
  if (u.pathname === '/api/sync/file') {
    const rel = u.searchParams.get('rel') || '', root = saveRoot(c);
    if (!root || !fs.existsSync(root)) return json(409, { error: 'No saves folder.' });
    if (req.method === 'GET') { const t = relOk(localRel(c, rel), root); if (!t || !fs.existsSync(t)) return json(404, { error: 'No such save.' }); res.writeHead(200, { 'Content-Type': 'application/octet-stream' }); fs.createReadStream(t).pipe(res); return; }
    if (req.method === 'POST') {
      const m = Number(u.searchParams.get('m')) || Date.now(), chunks = []; let got = 0, dead = false;
      req.on('data', d => { got += d.length; if (got > SYNC_MAX) { dead = true; json(413, { error: 'Too big.' }); req.destroy(); } else chunks.push(d); });
      req.on('end', () => { if (dead) return; try { syncPut(c, rel, Buffer.concat(chunks), m); scanCache = null; json(200, { ok: true }); } catch { json(400, { error: 'Not allowed.' }); } });
      return;
    }
  }
  if (u.pathname.startsWith('/api/admin/')) { try { return adminApi(req, res, u, c, json); } catch (e) { console.error('admin api', e); if (!res.headersSent) return json(500, { error: 'Something went wrong.' }); return; } }
  const sysId = u.searchParams.get('sys') || '', def = SYSTEMS.find(x => x.id === sysId && x.folder), isBios = sysId === 'bios';
  if (req.method === 'GET' && u.pathname === '/api/systems') {
    const ok = !!c.romRoot && fs.existsSync(c.romRoot);
    return json(200, { ok, root: c.romRoot, systems: SYSTEMS.filter(x => x.folder).map(x => ({ id: x.id, name: x.name, exts: x.ext, count: ok ? upFiles(upDir(c, x)).length : 0 })), bios: { count: ok ? upFiles(upBios(c)).length : 0 } });
  }
  if (!def && !isBios) return json(404, { error: 'Unknown system.' });
  const dir = isBios ? upBios(c) : upDir(c, def);
  if (req.method === 'GET' && u.pathname === '/api/list') return json(200, { files: upFiles(dir).slice(0, 500).map(e => { let sz = 0; try { sz = fs.statSync(path.join(dir, e.name)).size; } catch {} return { name: e.name, size: sz }; }) });
  const name = upName(u.searchParams.get('name'));
  if (req.method === 'GET' && u.pathname === '/api/exists') return json(200, { exists: !!name && fs.existsSync(path.join(dir, name)) });
  if (req.method === 'POST' && u.pathname === '/api/upload') {
    if (!c.romRoot || !fs.existsSync(c.romRoot)) { json(409, { error: 'The games folder is not set up yet. Finish the setup on the screen first.' }); req.destroy(); return; }
    if (!name) { json(400, { error: 'That file name is not allowed.' }); req.destroy(); return; }
    const ext = path.extname(name).toLowerCase();
    if (!isBios && !new Set([...(def.ext || []), ...UP_EXTRA]).has(ext)) { json(415, { error: `${def.name} does not use ${ext || 'files without an extension'}.` }); req.destroy(); return; }
    const len = Number(req.headers['content-length'] || 0);
    if (!len || len > 8 * 2 ** 30) { json(len ? 413 : 411, { error: len ? 'That file is larger than 8 GB.' : 'Empty file.' }); req.destroy(); return; }
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) { json(500, { error: 'Could not create the folder: ' + e.code }); req.destroy(); return; }
    const dest = path.join(dir, name), tmp = path.join(dir, '.' + name + '.part');
    if (fs.existsSync(dest)) { json(409, { error: 'Already on the device.', exists: true }); req.destroy(); return; }
    const ws = fs.createWriteStream(tmp); let got = 0, dead = false;
    const fail = (code, msg) => { if (dead) return; dead = true; try { ws.destroy(); } catch {} try { fs.unlinkSync(tmp); } catch {} if (!res.headersSent) json(code, { error: msg }); };
    req.on('data', d => { got += d.length; }); req.on('aborted', () => fail(400, 'Upload was cancelled.')); req.on('error', () => fail(400, 'Upload was cut short.'));
    ws.on('error', e => fail(500, 'Could not save the file: ' + (e.code || e.message)));
    ws.on('finish', () => {
      if (dead) return;
      if (got !== len) return fail(400, 'Upload was cut short.');
      try { fs.renameSync(tmp, dest); } catch (e) { return fail(500, 'Could not save the file: ' + e.code); }
      scanCache = null; send('library-changed'); json(200, { ok: true, name, size: got });
    });
    req.pipe(ws); return;
  }
  json(404, { error: 'Not found.' });
}
function upStop() { if (upSrv) { try { upSrv.close(); if (upSrv.closeAllConnections) upSrv.closeAllConnections(); } catch {} upSrv = null; upPort = 0; } }
function upStart() {
  upStop(); if (!process.versions.electron) return;
  const c = load(); if (!c.upload) return;
  if (!c.uploadCode) { c.uploadCode = String(crypto.randomInt(100000, 1000000)); save(c); }
  let port = 8080; const srv = http.createServer(upHandle); srv.requestTimeout = 0; srv.headersTimeout = 30000;
  const go = () => srv.listen(port, '0.0.0.0');
  srv.on('error', e => { if (e.code === 'EADDRINUSE' && port < 8090) { port++; go(); } else { upSrv = null; upPort = 0; } });
  srv.on('listening', () => { upPort = port; });
  upSrv = srv; go();
}
function upInfo() {
  const c = load(), ips = [];
  for (const a of Object.values(os.networkInterfaces())) for (const x of a || []) if (x.family === 'IPv4' && !x.internal) ips.push(x.address);
  return { enabled: !!c.upload, on: !!upSrv && !!upPort, port: upPort, code: c.uploadCode || '', ips, host: os.hostname() };
}

// ---------- window + IPC ----------
function createWindow() {
  const c = load();
  win = new BrowserWindow({
    width: 1280, height: 720, minWidth: 800, minHeight: 450, fullscreen: MAC ? false : !!c.fullscreen, show: !MAC, backgroundColor: '#10142a', autoHideMenuBar: true, title: 'Cacti OS',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.on('before-input-event', (e, i) => { if (i.type === 'keyDown' && i.key === 'F11') { setFs(!isFs()); e.preventDefault(); } });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', e => e.preventDefault());
  win.webContents.on('did-fail-load', (_e, code, desc, url) => slog('window failed to load ' + code + ' ' + desc + ' ' + url));
  win.webContents.on('render-process-gone', (_e, d) => slog('window process gone ' + JSON.stringify(d)));
  win.webContents.on('console-message', (_e, lvl, msg, line, src) => { if (lvl >= 3) slog('page error: ' + msg + ' (' + String(src).split('/').pop() + ':' + line + ')'); });
  win.on('closed', () => slog('main window closed'));
  win.webContents.once('did-finish-load', () => slog('window loaded'));
  if (MAC) { // open normally first, then go full screen: a window born full screen can end up on a Space that is out of reach
    let shown = false;
    const showIt = () => { if (shown || !win || win.isDestroyed()) return; shown = true; slog('showing window'); win.show(); win.focus(); if (c.fullscreen) setTimeout(() => { try { if (win && !win.isDestroyed()) setFs(true); } catch (e) { slog('fullscreen failed ' + e.message); } }, 600); };
    win.once('ready-to-show', showIt);
    setTimeout(showIt, 4000);
  }
  win.on('closed', () => { if (mwin && !mwin.isDestroyed()) mwin.destroy(); });
}
if (!app.requestSingleInstanceLock()) { slog('another copy holds the single-instance lock, closing'); app.quit(); }
app.whenReady().then(() => {
  slog('app ready');
  if (PORT.root && process.argv.includes('--prepare')) { // one-time setup for the portable drive: download RetroArch, its cores and every emulator into the drive
    const LF = path.join(PORT.root, 'data', 'setup-log.txt'); try { fs.mkdirSync(path.dirname(LF), { recursive: true }); fs.writeFileSync(LF, ''); } catch {}
    const L = m => { try { fs.appendFileSync(LF, m + '\n'); } catch {} };
    (async () => {
      try {
        const c0 = load(); c0.romRoot = c0.romRoot || path.join(PORT.root, 'roms'); for (const d of ['roms', 'bios']) try { fs.mkdirSync(path.join(PORT.root, d), { recursive: true }); } catch {} save(c0);
        L('Installing RetroArch...'); const ra = await installRetroArch(); L(ra.error ? '  FAILED: ' + ra.error : '  done');
        L('Installing RetroArch cores (this takes a few minutes)...'); const k = await installCores(); L(`  ${k.ok} downloaded` + (k.fail.length ? `, ${k.fail.length} failed: ${k.fail.slice(0, 6).join('; ')}` : ''));
        for (const r of EMU.RECIPES) {
          if (r.only && !r.only.includes('win')) continue;
          L(`Installing ${r.name}...`); let res; try { res = await EMU.install(r.id); } catch (e) { res = { error: String(e.message || e) }; }
          L(res && res.ok ? `  done (${res.version})` : `  skipped: ${(res && res.error) || 'unknown problem'}`);
        }
        L('FINISHED');
      } catch (e) { L('STOPPED: ' + (e.stack || e.message)); }
      app.exit(0);
    })();
    return;
  }
  if (MAC) Menu.setApplicationMenu(Menu.buildFromTemplate([{ label: 'Cacti OS', submenu: [{ role: 'about' }, { type: 'separator' }, { role: 'hide' }, { role: 'quit' }] }, { label: 'Edit', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] }, { label: 'View', submenu: [{ role: 'togglefullscreen' }] }]));
  else Menu.setApplicationMenu(null);
  setTimeout(() => { try { if (load().syncAuto) autoSync(); } catch {} }, 20000);
  ipcMain.handle('cfg:get', () => pub(load()));
  ipcMain.handle('player:cfg', () => { const c = load(); return { raUser: c.raUser || '', raToken: c.raToken || '', raPass: c.raPass || '', hardcore: !!c.hardcore, achStyle: achStyle(c), achSize: String(c.achSize || '2'), gameInt: !!c.gameInt, gameAspect: c.gameAspect || 'core', gameSmooth: !!c.gameSmooth, visual: c.visual === 'original' ? 'original' : 'off', profDir: GUEST ? 'guest-session' : (c.profile && profOk(c.profile) ? 'profiles/' + c.profile : '') }; });
  const cfgSet = async p => {
    const c = load(); let loginError = '';
    const prevUser = c.raUser;
    for (const k of KEYS) if (k in p && !(MASKED.includes(k) && p[k] === '••••••')) c[k] = typeof DEF()[k] === 'boolean' ? !!p[k] : String(p[k]).trim();
    if (p.padMap && typeof p.padMap === 'object') { const pm = {}; for (const [n, m] of Object.entries(p.padMap).slice(0, 40)) { if (!m || typeof m !== 'object') continue; const o = {}; for (const [l, v] of Object.entries(m)) if (LOGI.includes(l) && Number.isInteger(v) && v >= 0 && v <= 16) o[l] = v; if (Object.keys(o).length) pm[String(n).slice(0, 80)] = o; } c.padMap = pm; }
    if (p.scrapeEngines && typeof p.scrapeEngines === 'object') { const o = {}; for (const id of SCRAPE_IDS) if (typeof p.scrapeEngines[id] === 'boolean') o[id] = p.scrapeEngines[id]; c.scrapeEngines = o; }
    if (!SCRAPE_IDS.includes(c.scrapeFirst)) c.scrapeFirst = 'libretro';
    if (!['Xbox', 'PlayStation', 'Nintendo'].includes(c.prompts)) c.prompts = 'Xbox';
    if (!['off', 'manual', 'startup', 'weekly'].includes(c.updMode)) c.updMode = 'manual';
    if (c.updateUrl && !/^(https:\/\/|http:\/\/(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.))[^\s]+$/i.test(c.updateUrl)) c.updateUrl = '';
    c.updLast = Number(c.updLast) || 0;
    if (c.syncPeer && !/^[\w.\-]+(:\d{2,5})?$/.test(c.syncPeer)) c.syncPeer = '';
    if (!['auto', 'small', 'normal', 'large', 'custom'].includes(c.szPreset)) c.szPreset = 'auto';
    for (const k of ['szHeader', 'szTile', 'szText', 'szPrompt']) c[k] = String(Math.max(70, Math.min(150, parseInt(c[k], 10) || 100)));
    if (!['core', '4:3', '16:9', 'square'].includes(c.gameAspect)) c.gameAspect = 'core';
    if (!LAYOUTS.includes(c.layout)) c.layout = 'classic';
    if (c.raUser !== prevUser) { c.raToken = ''; c.raPass = ''; }
    for (const k of ['raKey']) if (p[k]) c[k] = String(p[k]).trim();
    if (p.raPass) {
      // Sign in to RetroAchievements once; keep only the login token (RetroArch accepts it) and never store the password.
      if (!c.raUser) loginError = 'Enter your username first.';
      else {
        try {
          const r = await fetch('https://retroachievements.org/dorequest.php', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'RetroOS/1.1' }, body: new URLSearchParams({ r: 'login2', u: c.raUser, p: String(p.raPass) }) });
          const j = await r.json();
          if (j && j.Success && j.Token) { c.raToken = j.Token; c.raPass = ''; if (j.User) c.raUser = j.User; }
          else loginError = (j && j.Error) || 'Sign-in was rejected. Check your username and password.';
        } catch (e) { loginError = 'Could not reach RetroAchievements: ' + e.message; }
      }
    }
    if (p.cores && typeof p.cores === 'object') c.cores = { ...(c.cores || {}), ...p.cores };
    let saveError = ''; try { save(c); } catch (e) { saveError = (e.code || '') + ' ' + e.message; console.error('[cacti] settings could not be saved to', CFG(), '-', e.message); }
    if ('fullscreen' in p && win) setFs(!!c.fullscreen);
    if ('musicDir' in p) musicSync();
    if ('upload' in p) upStart();
    if ('raUser' in p || p.raKey) setTimeout(raWarm, 300);
    return { ...pub(c), loginError, saveError, cfgPath: saveError ? CFG() : undefined };
  };
  HOOKS.cfgSet = cfgSet;
  ipcMain.handle('cfg:set', (_e, p) => cfgSet(p));
  ipcMain.handle('wifi:scan', () => wifiScan());
  ipcMain.handle('wifi:connect', (_e, o) => wifiConnect(o));
  ipcMain.handle('wifi:forget', async (_e, ssid) => { const r = await nmRun(['con', 'delete', 'id', String(ssid || '')], 8000); return { ok: r.ok }; });
  // ---- shared saves: keep saves and save states in the ROM folder so every device sees the same ones ----
  const SAVEXT = /\.(srm|sav|rtc|mcr|mcd|mc|eep|fla|nv|dsv|bsv|sra|ss\d?|state\d*|state\.auto|auto|psv|mpk|ram|sf2|vms)$/i;
  const copyNew = (src, dst, deep, flat) => { let n = 0; let es = []; try { es = fs.readdirSync(src, { withFileTypes: true }); } catch { return 0; }
    for (const e of es) { if (e.name.charCodeAt(0) === 46) continue; const a = path.join(src, e.name);
      if (e.isDirectory()) { if (deep > 0 && e.name !== 'Cacti Saves') n += copyNew(a, flat ? dst : path.join(dst, e.name), deep - 1, flat); continue; }
      if (!e.isFile() || !SAVEXT.test(e.name)) continue;
      try { const st = fs.statSync(a); if (st.size > 64e6) continue; const b = path.join(dst, e.name); let go = true; try { go = fs.statSync(b).mtimeMs + 2000 < st.mtimeMs; } catch {} if (go) { fs.mkdirSync(dst, { recursive: true }); fs.copyFileSync(a, b); n++; } } catch {} }
    return n; };
  ipcMain.handle('share:saves', async (_e, on) => {
    const c = load(); on = !!on;
    if (ANDH) return { ok: false, error: 'Not available in the Android app.' };
    if (!on) { c.shareSaves = false; save(c); return { ok: true, off: true }; }
    if (!c.romRoot || !(await rootThere(c.romRoot))) return { ok: false, error: 'Choose a ROMs folder first.' };
    const before = effSaveDir(c); // where saves live now
    const next = { ...c, shareSaves: true, profile: '' }, root = SHSAVES(next), dst = path.join(root, 'everyone');
    try { fs.mkdirSync(path.join(dst, 'saves'), { recursive: true }); fs.mkdirSync(path.join(dst, 'states'), { recursive: true }); fs.accessSync(dst, fs.constants.W_OK); } catch (e) { return { ok: false, error: 'The ROM folder is read-only or not reachable, so saves cannot be kept there.' }; }
    let n = 0; const home = os.homedir();
    const ras = [before && path.resolve(before), c.retroarch && path.join(path.dirname(String(c.retroarch).replace(/\/Contents\/MacOS\/[^/]+$/, '')), 'saves'), MAC && path.join(home, 'Library', 'Application Support', 'RetroArch'), WIN && c.retroarch && path.dirname(c.retroarch), LINUX && path.join(home, '.config', 'retroarch'), LINUX && path.join(home, '.var/app/org.libretro.RetroArch/config/retroarch')].filter(Boolean);
    for (const r of new Set(ras)) { n += copyNew(path.join(r, 'saves'), path.join(dst, 'saves'), 2, false); n += copyNew(path.join(r, 'states'), path.join(dst, 'states'), 2, false); if (r === (before && path.resolve(before))) { n += copyNew(r, path.join(dst, 'saves'), 0, false); } }
    n += copyNew(c.romRoot, path.join(dst, 'saves'), 4, true); // saves RetroArch left next to the games
    c.shareSaves = true; save(c); logEv('shared saves on: ' + n + ' files copied to ' + root);
    return { ok: true, copied: n, dir: root };
  });
  ipcMain.handle('saves:info', () => { const c = load(), f = saveFiles(c); return { root: saveRoot(c), custom: !!c.saveDir, files: f.files.length, backups: bkList(c), base: bkBase(c) }; });
  ipcMain.handle('saves:backup', () => backupSaves(load(), true));
  ipcMain.handle('tidy:plan', async () => { const r = await tidyPlan(load()); return r.error ? r : { count: r.moves.length, skipped: r.skipped.slice(0, 5), sample: r.moves.slice(0, 8).map(x => path.basename(x.from) + '  →  ' + x.folder), bySys: r.moves.reduce((o, x) => (o[x.folder] = (o[x.folder] || 0) + 1, o), {}) }; });
  ipcMain.handle('tidy:run', () => tidyRun(load()));
  ipcMain.handle('prof:list', () => { const c = load(); return { current: c.profile || '', list: profList(c), ra: c.raUser || '', base: profBase(c), guest: GUEST }; });
  ipcMain.handle('prof:picker', async () => { const c = load(), list = profList(c); let last = {}; try { last = JSON.parse(fs.readFileSync(path.join(app.getPath('userData'), 'prof-last.json'), 'utf8')); } catch {} let sums = {}; try { if (c.raUser && c.raKey && list.length) sums = await Promise.race([raSummaries([...new Set([...list, c.raUser])]), new Promise(r => setTimeout(() => r({}), 3500))]); } catch {} const cnt = n => { let k = 0; const w = (d, dep) => { let es = []; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch { return; } for (const e of es) { if (e.isDirectory()) { if (dep < 4) w(path.join(d, e.name), dep + 1); } else if (SAVE_RE.test(e.name)) k++; } }; w(path.join(profBase(c), n), 0); return k; }; return { ask: c.profAsk !== false && list.length >= 2 && !GUEST, current: c.profile || '', ra: (c.raUser || '').toLowerCase(), players: list.map(n => ({ name: n, saves: cnt(n), points: (() => { const s = sums[n] || (n === c.profile && c.raUser ? sums[c.raUser] : null); return s && s.points ? s.points : 0; })(), last: last[n] || null })) }; });
  ipcMain.handle('prof:guest', () => { if (child) return { ok: false, error: 'Close the running game first.' }; try { fs.rmSync(guestDir(), { recursive: true, force: true }); } catch {} GUEST = true; scanCache = null; return { ok: true }; });
  ipcMain.handle('prof:create', (_e, n, adopt) => profCreate(n, !!adopt));
  ipcMain.handle('prof:rename', (_e, n) => profRename(n));
  ipcMain.handle('prof:use', (_e, n) => { GUEST = false; const c = load(); n = String(n || ''); if (n && !profList(c).includes(n)) return { ok: false, error: 'No such player.' }; if (child) return { ok: false, error: 'Close the running game first.' }; c.profile = n; save(c); scanCache = null; return { ok: true }; });
  ipcMain.handle('saves:restore', (_e, id) => restoreSaves(load(), id, true));
  ipcMain.handle('saves:open', () => { const c = load(); fs.mkdirSync(bkBase(c), { recursive: true }); return shell.openPath(bkBase(c)); });
  ipcMain.handle('bt:list', () => btList());
  ipcMain.handle('bt:scan', () => btScan());
  ipcMain.handle('bt:pair', (_e, mac) => btPair(mac));
  ipcMain.handle('bt:act', (_e, cmd, mac) => btAct(cmd, mac));
  ipcMain.handle('bt:settings', () => btSettings());
  ipcMain.handle('pad:capture', (_e, on) => { padCapture = !!on; return true; });
  ipcMain.handle('pad:status', () => ({ n: EVD.devs.size, names: [...EVD.devs.values()].map(d => d.name) }));
  ipcMain.handle('upload:info', () => upInfo());
  ipcMain.handle('upload:newcode', () => { const c = load(); c.uploadCode = String(crypto.randomInt(100000, 1000000)); save(c); return upInfo(); });
  ipcMain.handle('sys:get', () => sysMeta(load()));
  ipcMain.handle('scan', (_e, fresh) => scanAsync(load(), !!fresh));
  ipcMain.handle('scan:quick', () => scanQuick(load()));
  ipcMain.handle('share:export', async () => { const r = await exportShared(scan(load()), m => send('scrape', { run: true, done: 0, total: 0, found: 0, msg: m })); send('scrape', { run: false, done: 0, total: 0, found: 0, msg: `Saved to the ROM folders: ${r.art} images copied, details written to ${r.lists} gamelist file${r.lists == 1 ? '' : 's'}.` }); return r; });
  ipcMain.handle('ra', () => raRefresh());
  ipcMain.handle('lobbies', () => lobbies());
  ipcMain.handle('ra:game', (_e, o) => raGame(o));
  ipcMain.handle('history:get', () => playHistory());
  ipcMain.handle('ra:overview', (_e, f) => raOverview(!!f));
  ipcMain.handle('ra:top', () => raTop());
  ipcMain.handle('friends:list', (_e, f) => raFriends(!!f));
  ipcMain.handle('friends:sum', (_e, u) => raSummaries(u));
  ipcMain.handle('friends:games', (_e, u) => raFriendGames(u));
  ipcMain.handle('friends:game', (_e, o) => raFriendGame(o || {}));
  ipcMain.handle('friends:add', (_e, n) => raFriendAdd(n));
  ipcMain.handle('friends:open', (_e, u) => raFriendOpen(u));
  ipcMain.handle('ra:boards', (_e, id) => raBoards(id));
  ipcMain.handle('ra:entries', (_e, o) => raEntries(o || {}));
  ipcMain.handle('ra:recent', () => raRecentGames());
  ipcMain.handle('ra:count', (_e, o) => raCount(o || {}));
  ipcMain.handle('ra:totals', (_e, g) => raTotals(g));
  ipcMain.handle('ach:stop', () => { aQ = []; aGen++; aBusy = false; try { if (win && !win.isDestroyed()) win.webContents.send('ach:inline', { hide: true }); } catch {} try { if (awin && !awin.isDestroyed()) awin.hide(); } catch {} return true; });
  ipcMain.handle('ach:preview', (_e, st) => { const style = ACH.slice(1, 6).includes(st) ? st : (ACH.slice(1, 6).includes(achStyle(load())) ? achStyle(load()) : 'pill'); achShow({ style, title: 'Hidden in the Pipes', desc: 'Find the secret warp zone.', points: 10, badge: '', rare: 4.2, earned: 12, total: 40 }, true); return style; });
  const themesDir = () => { const d = path.join(app.getPath('userData'), 'themes'); try { fs.mkdirSync(d, { recursive: true }); } catch {} return d; };
  ipcMain.handle('themes:list', () => {
    const out = []; try { for (const f of fs.readdirSync(themesDir()).filter(x => x.toLowerCase().endsWith('.json')).sort().slice(0, 20)) {
      const fp = path.join(themesDir(), f); if (fs.statSync(fp).size > 16384) continue; try { out.push(JSON.parse(fs.readFileSync(fp, 'utf8'))); } catch {} } } catch {}
    return out;
  });
  ipcMain.handle('themes:dir', () => { const d = themesDir(); const ex = path.join(d, 'example-theme.json');
    if (!fs.existsSync(ex)) { try { fs.writeFileSync(ex, JSON.stringify({ name: 'My Theme (rename me)', dark: true, font: 'system', pattern: 'grid', vars: { bg1: '#101020', bg2: '#141428', bg3: '#1a1030', acc: '#ffb000', onacc: '#101020', b1: '#ff7a00', b2: '#6a3dff', b3: '#00b3a4' } }, null, 2)); } catch {} }
    shell.openPath(d); return d; });
  const themeSlug = n => String(n || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'theme';
  ipcMain.handle('themes:save', (_e, t) => { // written by Theme Studio; stored as plain JSON in the themes folder
    if (!t || typeof t !== 'object' || typeof t.name !== 'string') return { ok: false };
    const txt = JSON.stringify(t, null, 2); if (txt.length > 16000) return { ok: false, err: 'too big' };
    const fp = path.join(themesDir(), themeSlug(t.name) + '.json'); try { fs.writeFileSync(fp, txt); } catch (e) { return { ok: false, err: String(e.message || e) }; }
    if (win && !win.isDestroyed()) win.webContents.send('themes-changed'); return { ok: true, file: path.basename(fp) };
  });
  ipcMain.handle('themes:delete', (_e, name) => { try { fs.unlinkSync(path.join(themesDir(), themeSlug(name) + '.json')); } catch { return { ok: false }; } if (win && !win.isDestroyed()) win.webContents.send('themes-changed'); return { ok: true }; });
  let swin = null;
  ipcMain.handle('studio:open', () => {
    if (swin && !swin.isDestroyed()) { swin.focus(); return true; }
    swin = new BrowserWindow({ width: 1500, height: 900, minWidth: 1100, minHeight: 700, backgroundColor: '#14161f', autoHideMenuBar: true, title: 'Cacti OS Theme Studio',
      webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
    swin.loadFile(path.join(__dirname, 'renderer', 'studio.html'));
    swin.webContents.setWindowOpenHandler(() => ({ action: 'deny' })); swin.webContents.on('will-navigate', e => e.preventDefault());
    return true;
  });
  ipcMain.handle('check', () => check());
  ipcMain.handle('usage', () => { // memory the app uses right now and the size of its data folder
    let ram = 0, procs = 0; try { const m = app.getAppMetrics ? app.getAppMetrics() : []; procs = m.length; ram = m.reduce((n, p) => n + ((p.memory && p.memory.workingSetSize) || 0), 0) * 1024; } catch {}
    if (!ram) { ram = process.memoryUsage().rss; procs = procs || 1; }
    let files = 0; const du = d => { let n = 0; try { for (const e of fs.readdirSync(d, { withFileTypes: true })) { if (files > 40000) break; const p = path.join(d, e.name); if (e.isDirectory()) n += du(p); else if (e.isFile()) { files++; n += fs.statSync(p).size; } } } catch {} return n; };
    const ud = app.getPath('userData'), emu = du(path.join(ud, 'emulators')), cores = du(coresDir(load())), all = du(ud);
    return { ram, procs, data: all, emus: emu, cores };
  });
  ipcMain.handle('store:list', (_e, r) => STORE.list(!!r));
  ipcMain.handle('store:install', async (_e, id, rom) => { const r = await STORE.install(String(id), rom ? String(rom) : ''); if (r && r.fallback) STORE.openPage(String(id)); return r; });
  ipcMain.handle('store:rom', async (_e, id) => { const e = STORE.CATALOG.find(x => x.id === String(id)); if (!e) return { error: 'Unknown game.' }; const r = await dialog.showOpenDialog(win, { title: 'Choose your ' + e.romLabel, properties: ['openFile'], filters: [{ name: e.romLabel, extensions: e.romExt.map(x => x.slice(1)) }] }); return r.canceled ? { canceled: true } : STORE.addRom(String(id), r.filePaths[0]); });
  ipcMain.handle('store:pick', async (_e, id) => { const e = STORE.CATALOG.find(x => x.id === String(id)); if (!e) return { error: 'Unknown game.' }; const r = await dialog.showOpenDialog(win, { title: 'Choose your ' + e.romLabel, properties: ['openFile'], filters: [{ name: e.romLabel, extensions: e.romExt.map(x => x.slice(1)) }] }); return r.canceled ? { canceled: true } : { file: r.filePaths[0] }; });
  ipcMain.handle('store:play', (_e, id) => storePlay(String(id)));
  ipcMain.handle('store:remove', (_e, id) => STORE.remove(String(id)));
  ipcMain.handle('store:links', () => STORE.LINKS.map(l => ({ name: l.name, note: l.note })));
  ipcMain.handle('store:open', (_e, i) => STORE.openLink(i));
  ipcMain.handle('store:page', (_e, id) => STORE.openPage(String(id)));
  ipcMain.handle('emu:list', () => EMU.list());
  ipcMain.handle('emu:updateAll', async () => {
    const out = { updated: [], failed: [], current: 0, other: 0 };
    let l = await EMU.refresh(true);
    for (const e of l) {
      if (e.status === 'update') { const r = await EMU.install(e.id); if (r && r.ok) out.updated.push(e.name + (r.version ? ' ' + r.version : '')); else out.failed.push(e.name + (r && r.error ? ': ' + r.error : '')); }
      else if (e.status === 'uptodate') out.current++; else if (e.status === 'installed') out.other++;
    }
    return out;
  });
  ipcMain.handle('emu:refresh', (_e, f) => EMU.refresh(!!f));
  ipcMain.handle('emu:install', async (_e, id) => { const r = await EMU.install(String(id)); if (r && r.fallback) EMU.openPage(String(id)); return r; });
  ipcMain.handle('emu:page', (_e, id) => EMU.openPage(String(id)));
  ipcMain.handle('emu:browse', async (_e, id) => { const r = await dialog.showOpenDialog(win, { title: 'Choose the emulator you installed', properties: MAC ? ['openFile', 'openDirectory'] : ['openFile'] }); return r.canceled ? { canceled: true } : EMU.setPath(String(id), r.filePaths[0]); });
  ipcMain.handle('bios:open', (_e, id) => EMU.openBios(String(id)));
  ipcMain.handle('cores:install', () => installCores());
  ipcMain.handle('retroarch:install', async () => { const r = await installRetroArch(); if (r && !r.error) installCores().then(k => logEv('cores: ' + k.ok + ' downloaded' + (k.fail.length ? ', ' + k.fail.length + ' failed' : '')), () => {}); return r; });
  ipcMain.handle('log:open', async () => { if (!fs.existsSync(LOG())) return false; await shell.openPath(LOG()); return true; });
  ipcMain.handle('scrape', (_e, id) => scrape(id));
  ipcMain.handle('scrape:bg', (_e, id) => scrapeBg(id));
  ipcMain.handle('bg:get', async (_e, q) => { try { const s = ALL.find(x => x.id === q.sys); if (!s || !q.file) return null; const base = path.parse(q.file).name; let f = bgHave(s.id, base, q.file); if (!f && await fetchBg(s, { file: q.file, title: q.title })) f = bgHave(s.id, base, q.file); return f ? pathToFileURL(f).href.replace(/'/g, '%27') : null; } catch { return null; } });
  ipcMain.handle('scraper:status', () => engineStatus());
  ipcMain.handle('scraper:test', (_e, eng) => scraperTest(String(eng || '')));
  ipcMain.handle('scrape:stop', () => { scrapeStop = true; metaStop = true; });
  ipcMain.handle('meta:clear', () => { META.clear(); scanCache = null; return { ok: true }; });
  ipcMain.handle('meta:count', () => META.count());
  ipcMain.handle('wifi:get', () => wifi());
  ipcMain.handle('wifi:power', async (_e, on) => { if (LINUX) { await sh('nmcli', ['radio', 'wifi', on ? 'on' : 'off']); await new Promise(r => setTimeout(r, on ? 3000 : 600)); return wifi(); } if (MAC) { const hp = await sh('/usr/sbin/networksetup', ['-listallhardwareports']); const dev = (hp.match(/Hardware Port: (?:Wi-Fi|AirPort)\s*\nDevice: (\w+)/) || [])[1] || 'en0'; await sh('/usr/sbin/networksetup', ['-setairportpower', dev, on ? 'on' : 'off']); await new Promise(r => setTimeout(r, on ? 3500 : 800)); } return wifi(); });
  ipcMain.handle('wifi:open', async () => { if (WIN) { shell.openExternal('ms-settings:network-wifi'); return; } if (!MAC) return; const o = await sh('/usr/bin/open', ['x-apple.systempreferences:com.apple.wifi-settings-extension']); if (o === '') await sh('/usr/bin/open', ['/System/Library/PreferencePanes/Network.prefPane']); });
  ipcMain.handle('vol:get', async () => { if (LINUX) { const m = (await sh('wpctl', ['get-volume', '@DEFAULT_AUDIO_SINK@'])).match(/([\d.]+)/); return m ? Math.round(parseFloat(m[1]) * 100) : 50; } const v = parseInt(await sh('/usr/bin/osascript', ['-e', 'output volume of (get volume settings)']), 10); return Number.isFinite(v) ? v : 50; });
  ipcMain.handle('vol:set', (_e, v) => LINUX ? sh('wpctl', ['set-volume', '@DEFAULT_AUDIO_SINK@', String(Math.max(0, Math.min(100, Math.round(+v))) / 100)]) : sh('/usr/bin/osascript', ['-e', `set volume output volume ${Math.max(0, Math.min(100, Math.round(+v)))}`]));
  ipcMain.handle('fs', () => setFs(!isFs()));
  ipcMain.handle('pick', async (_e, t) => {
    const r = await dialog.showOpenDialog(win, t === 'folder' ? { properties: ['openDirectory'] } : { properties: ['openFile'] });
    return r.canceled ? null : r.filePaths[0];
  });
  // ---------- updates: offline update files swap in new app files; backups sit beside the app ----------
  const UFILES = ['main.js', 'preload.js', 'music-preload.js', 'popup-preload.js', 'emus.js', 'meta.js', 'store.js', 'package.json', 'server.js', 'renderer'];
  const BKDIR = () => path.join(path.basename(__dirname) == 'app' ? path.dirname(__dirname) : __dirname, 'app-backups');
  const readJ = f => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
  const appVer = () => (readJ(path.join(__dirname, 'package.json')) || {}).version || '?';
  const safeId = s => String(s || '').replace(/[^\w.\-]/g, '');
  function updInfo() {
    const d = BKDIR(), out = { version: appVer(), backups: [], applied: [] };
    try { for (const e of fs.readdirSync(d, { withFileTypes: true })) if (e.isDirectory() && e.name != 'applied') { const m = readJ(path.join(d, e.name, '.backup.json')) || {}; let w = m.when; if (!w) { try { w = fs.statSync(path.join(d, e.name)).mtimeMs; } catch {} } out.backups.push({ id: e.name, version: m.version || e.name.split('_')[0], when: Number(w) || 0 }); } } catch {}
    try { for (const e of fs.readdirSync(path.join(d, 'applied'))) if (/\.json$/.test(e)) { const f = path.join(d, 'applied', e), m = readJ(f); if (m) out.applied.push({ version: String(m.version || ''), notes: Array.isArray(m.notes) ? m.notes.map(String).slice(0, 12) : [], when: fs.statSync(f).mtimeMs }); } } catch {}
    out.backups.sort((a, b) => b.when - a.when); out.applied.sort((a, b) => b.when - a.when);
    return out;
  }
  function updCopy(from, to) { for (const f of UFILES) { const a = path.join(from, f), b = path.join(to, f); if (!fs.existsSync(a)) continue; fs.rmSync(b, { recursive: true, force: true }); fs.cpSync(a, b, { recursive: true }); } }
  function updRestore(id) {
    const bk = path.join(BKDIR(), safeId(id));
    if (!safeId(id) || !fs.existsSync(path.join(bk, 'package.json'))) return { error: 'That backup is not there any more.' };
    try {
      const keep = path.join(BKDIR(), `${appVer()}_${Date.now()}`); fs.mkdirSync(keep, { recursive: true }); // make this restore undoable too
      for (const f of UFILES) { const a = path.join(__dirname, f); if (fs.existsSync(a)) fs.cpSync(a, path.join(keep, f), { recursive: true }); }
      fs.writeFileSync(path.join(keep, '.backup.json'), JSON.stringify({ version: appVer(), when: Date.now() }));
      updCopy(bk, __dirname);
      return { ok: true, version: (readJ(path.join(bk, 'package.json')) || {}).version || '' };
    } catch (e) { return { error: 'Could not restore: ' + (e.message || e) }; }
  }
  ipcMain.handle('upd:info', () => updInfo());
  function restartApp(r) {
    const go = () => { if (app.relaunch && !process.env.INVOCATION_ID) app.relaunch(); (app.exit || app.quit)(0); };
    if (!app.relaunch) { r.manual = true; return r; } // web edition: the server has to be started again by hand
    setTimeout(() => { if (MAC) { const bundle = path.resolve(__dirname, '..', '..', '..'); if (/\.app$/.test(bundle)) return execFile('/usr/bin/codesign', ['--force', '--deep', '--sign', '-', bundle], () => go()); } go(); }, 900);
    return r;
  }
  ipcMain.handle('upd:restore', (_e, id) => { const r = updRestore(id); return r.ok ? restartApp(r) : r; });

  // ---------- online updates: a small signed manifest on GitHub points at a signed update bundle ----------
  // Manifest (JSON): { version, notes[], url, sha256, size, sig }. sig = ed25519 over JSON.stringify(['cacti-os-update', version, sha256, size, notes]).
  // The private key never ships; only this public key does. Nothing unsigned or altered is ever applied.
  const UPD_PUB = '1400638b7110379dd2a57a66d7f72a24fbea3febef192694ba3ba7b99d6ae68f';
  const vnum = v => String(v || '').split('.').map(n => parseInt(n, 10) || 0);
  const vNewer = (a, b) => { const x = vnum(a), y = vnum(b); for (let i = 0; i < 3; i++) { if ((x[i] || 0) > (y[i] || 0)) return true; if ((x[i] || 0) < (y[i] || 0)) return false; } return false; };
  function updSigOk(m) {
    try {
      if (!m || !/^\d+\.\d+\.\d+$/.test(String(m.version)) || !/^[0-9a-f]{64}$/.test(String(m.sha256)) || !Number.isInteger(m.size) || !Array.isArray(m.notes) || typeof m.sig !== 'string') return false;
      const key = crypto.createPublicKey({ key: Buffer.concat([Buffer.from('302a300506032b6570032100', 'hex'), Buffer.from(UPD_PUB, 'hex')]), format: 'der', type: 'spki' });
      return crypto.verify(null, Buffer.from(JSON.stringify(['cacti-os-update', m.version, m.sha256, m.size, m.notes])), key, Buffer.from(m.sig, 'base64'));
    } catch { return false; }
  }
  let UPEND = null; // the verified manifest from the last check
  async function updCheck(auto) {
    const c = load(), u = String(c.updateUrl || '').trim();
    if (!/^https:\/\//i.test(u)) return { error: auto ? '' : 'No update address is set yet. Open Menu > Updates.' };
    try {
      const hd = { 'User-Agent': 'CactiOS-Updater', 'Cache-Control': 'no-cache' };
      let r = await fetch(u, { signal: AbortSignal.timeout(15000), headers: hd }), mu = u;
      if (r.status === 404) { // GitHub "latest release" link with no file of that exact name: look through the release's attached files for the update list
        const g = /^https:\/\/github\.com\/([\w.-]+)\/([\w.-]+)\/releases\/latest\/download\//i.exec(u);
        if (g) {
          const a = await fetch(`https://api.github.com/repos/${g[1]}/${g[2]}/releases/latest`, { signal: AbortSignal.timeout(15000), headers: { ...hd, Accept: 'application/vnd.github+json' } });
          if (a.ok) { const j = await a.json(), f = (j.assets || []).find(x => /manifest.*\.json$/i.test(x.name || '')); if (f && /^https:\/\/github\.com\//i.test(f.browser_download_url || '')) { mu = f.browser_download_url; r = await fetch(mu, { signal: AbortSignal.timeout(15000), headers: hd }); } else throw new Error('the latest release (' + (j.tag_name || '?') + ') has no manifest.json file attached');
          }
        }
      }
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const txt = await r.text(); if (txt.length > 65536) throw new Error('manifest too large');
      const m = JSON.parse(txt);
      save({ ...c, updLast: Date.now() });
      if (!updSigOk(m)) return { error: 'The update information is not signed correctly, so it was ignored.' };
      const cur = appVer();
      if (!vNewer(m.version, cur)) { UPEND = null; return { ok: true, current: cur, latest: m.version, available: false }; }
      m.url = new URL(String(m.url), mu).href; if (!/^https:\/\//i.test(m.url)) throw new Error('bad download address');
      UPEND = m;
      return { ok: true, current: cur, latest: m.version, available: true, version: m.version, notes: m.notes.map(String).slice(0, 12) };
    } catch (e) { return { error: auto ? '' : 'Could not check for updates: ' + (e.message || e) }; }
  }
  // Apply a verified bundle buffer (gzip JSON {version, files:{path:base64}}). Takes a backup first.
  function updApply(buf, wantVer) {
    let b; try { b = JSON.parse(zlib.gunzipSync(buf, { maxOutputLength: 200 * 1024 * 1024 }).toString('utf8')); } catch { return { error: 'The update file is damaged.' }; }
    if (!b || b.version !== wantVer || !b.files || typeof b.files !== 'object') return { error: 'The update file does not match its signature.' };
    const top = new Set(UFILES), out = [];
    for (const [rel, data] of Object.entries(b.files)) {
      const p = path.posix.normalize(rel);
      if (typeof data !== 'string' || p.startsWith('..') || p.startsWith('/') || p.includes('\\') || !top.has(p.split('/')[0]) || (p.includes('/') && p.split('/')[0] !== 'renderer')) return { error: 'The update contains a file it should not.' };
      out.push([p, Buffer.from(data, 'base64')]);
    }
    if (!out.some(([p]) => p === 'package.json') || !out.some(([p]) => p === 'main.js')) return { error: 'The update file is incomplete.' };
    try {
      const keep = path.join(BKDIR(), `${appVer()}_${Date.now()}`); fs.mkdirSync(keep, { recursive: true });
      for (const f of UFILES) { const a = path.join(__dirname, f); if (fs.existsSync(a)) fs.cpSync(a, path.join(keep, f), { recursive: true }); }
      fs.writeFileSync(path.join(keep, '.backup.json'), JSON.stringify({ version: appVer(), when: Date.now() }));
      const stage = path.join(BKDIR(), '.stage'); fs.rmSync(stage, { recursive: true, force: true });
      for (const [p, d] of out) { const f = path.join(stage, p); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, d); }
      for (const f of UFILES) if (f === 'renderer' && out.some(([p]) => p.startsWith('renderer/'))) fs.rmSync(path.join(__dirname, 'renderer'), { recursive: true, force: true });
      for (const [p] of out) { const to = path.join(__dirname, p); fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(path.join(stage, p), to); }
      fs.rmSync(stage, { recursive: true, force: true });
      const ad = path.join(BKDIR(), 'applied'); fs.mkdirSync(ad, { recursive: true });
      fs.writeFileSync(path.join(ad, `${wantVer}.json`), JSON.stringify({ version: wantVer, notes: Array.isArray(b.notes) ? b.notes.map(String).slice(0, 12) : [] }));
      return { ok: true, version: wantVer };
    } catch (e) { return { error: 'Could not install the update: ' + (e.message || e) }; }
  }
  HOOKS.updCheck = updCheck; HOOKS.appVer = appVer; HOOKS.updSigOk = updSigOk; HOOKS.updApply = updApply; HOOKS.restart = r => restartApp(r || {});
  ipcMain.handle('upd:check', (_e, auto) => updCheck(!!auto));
  ipcMain.handle('upd:start', async () => {
    const m = UPEND; if (!m) return { error: 'Check for updates first.' };
    try {
      const r = await fetch(m.url, { signal: AbortSignal.timeout(120000), headers: { 'User-Agent': 'CactiOS-Updater' } });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const buf = Buffer.from(await r.arrayBuffer());
      if (buf.length !== m.size || crypto.createHash('sha256').update(buf).digest('hex') !== m.sha256) return { error: 'The download did not match its signature, so it was not installed.' };
      const res = updApply(buf, m.version); return res.ok ? restartApp(res) : res;
    } catch (e) { return { error: 'Download failed: ' + (e.message || e) }; }
  });


  // ---------- tasks that need root on the Pi image: the app asks a small root helper (systemd path unit) to do one allowed thing ----------
  const ROOTH = '/usr/lib/retro-os/rootd.sh', ROOTREQ = path.join(HOME, '.rootreq'), ROOTRES = '/run/retro-rootd/res';
  let rootQ = Promise.resolve(); // the helper answers one request at a time, so requests wait in line
  const rootDo = args => (rootQ = rootQ.then(() => rootDo1(args), () => rootDo1(args)));
  async function rootDo1(args) {
    if (!LINUX || !fs.existsSync(ROOTH)) return { error: 'This only works on the Cacti OS Raspberry Pi image.' };
    try { try { fs.rmSync(ROOTRES, { force: true }); } catch {} fs.writeFileSync(ROOTREQ + '.tmp', args.join(' ') + '\n'); fs.renameSync(ROOTREQ + '.tmp', ROOTREQ); } catch (e) { return { error: 'Could not send the request: ' + (e.message || e) }; }
    for (let i = 0; i < 60; i++) {
      await new Promise(r => setTimeout(r, 250));
      let t = ''; try { t = fs.readFileSync(ROOTRES, 'utf8').trim(); } catch {} if (!t) { if (i === 16 && /^(ext-|share-status)/.test(args[0])) { try { fs.writeFileSync(ROOTREQ + '.tmp', args.join(' ') + '\n'); fs.renameSync(ROOTREQ + '.tmp', ROOTREQ); } catch {} } continue; } // a request sent just as the helper was finishing can be missed: harmless ones are sent again once
      try { fs.rmSync(ROOTRES, { force: true }); } catch {}
      return t.startsWith('ok') ? { ok: true, out: t.slice(2).trim() } : { error: t.replace(/^err\s*/, '') || 'The system refused.' };
    }
    return { error: 'The system did not answer.' };
  }
  HOOKS.rootDo = rootDo;
  async function shareInfo() {
    const ips = []; for (const a of Object.values(os.networkInterfaces())) for (const x of a || []) if (x.family === 'IPv4' && !x.internal) ips.push(x.address);
    if (!LINUX || !fs.existsSync(ROOTH)) return { supported: false, on: false, ips, host: os.hostname(), root: load().romRoot || '' };
    const r = await rootDo(['share-status']); return { supported: true, on: !!(r.ok && r.out === 'on'), ips, host: 'cactios', root: load().romRoot || '' };
  }
  ipcMain.handle('share:get', () => shareInfo());
  ipcMain.handle('share:set', async (_e, on) => { const r = await rootDo([on ? 'share-on' : 'share-off']); return r.error ? { error: r.error } : shareInfo(); });
  // ---------- install Cacti OS onto an internal drive (PC image): list drives, start the copy, report progress ----------
  const INST_OK = () => LINUX && fs.existsSync(ROOTH) && fs.existsSync('/usr/lib/retro-os/install.sh');
  async function instInfo() {
    if (!INST_OK()) return { supported: false };
    const r = await rootDo(['install-list']); if (r.error) return { supported: false, error: r.error };
    const parts = String(r.out || '').split(';'), src = (parts.shift() || '').replace(/^SRC=/, '');
    const drives = parts.map(p => p.split(',')).filter(a => a.length >= 8).map(a => ({ name: a[0], size: +a[1] || 0, model: a[2].replace(/_+/g, ' ').trim() || 'Drive', bus: a[3], removable: a[4] === '1', busy: a[5] === '1', parts: +a[6] || 0, fits: a[7] === '1' }));
    let used = 0; try { const o = require('child_process').execFileSync('df', ['-P', '-B1', '/userdata'], { timeout: 4000 }).toString().split('\n')[1].trim().split(/\s+/); used = +o[2] || 0; } catch {}
    return { supported: true, src, drives, dataUsed: used };
  }
  async function instStart(disk, keep) { if (!INST_OK()) return { error: 'This only works on the Cacti OS PC image.' }; const r = await rootDo(['install-start', String(disk || ''), keep ? '1' : '0']); return r.error ? { error: r.error } : { ok: true }; }
  function instStatus() { try { const [state, pct, ...t] = fs.readFileSync('/run/retro-install/status', 'utf8').trim().split('|'); return { state, pct: +pct || 0, text: t.join('|') }; } catch { return { state: 'none' }; } }
  async function instReboot() { const r = await rootDo(['reboot']); return r.error ? { error: r.error } : { ok: true }; }
  HOOKS.inst = { info: instInfo, start: instStart, status: instStatus, reboot: instReboot };
  ipcMain.handle('inst:info', () => instInfo());
  ipcMain.handle('inst:start', (_e, disk, keep) => instStart(disk, keep));
  ipcMain.handle('inst:status', () => instStatus());
  ipcMain.handle('inst:reboot', () => instReboot());
  // ---------- other drives (USB sticks, external SSDs): list, connect, disconnect, and use one for the games ----------
  const EXT_OK = () => LINUX && fs.existsSync(ROOTH);
  const extParse = out => String(out || '').split(';').map(p => p.split(',')).filter(a => a.length >= 7).map(a => ({ name: a[0], size: +a[1] || 0, label: a[2].replace(/_+/g, ' ').trim() || 'Drive', fs: a[3], bus: a[4], mount: a[5] === '-' ? '' : a[5], free: +a[6] || 0 }));
  async function extList(connect) {
    if (!EXT_OK()) return { supported: false };
    if (connect) await rootDo(['ext-mount-all']);
    const r = await rootDo(['ext-list']); if (r.error) return { supported: true, error: r.error, drives: [] };
    const c = load(), drives = extParse(r.out).map(d => ({ ...d, games: !!(d.mount && c.romRoot && (c.romRoot === d.mount || c.romRoot.startsWith(d.mount + '/'))) }));
    return { supported: true, drives, romRoot: c.romRoot || '' };
  }
  ipcMain.handle('ext:list', (_e, connect) => extList(!!connect));
  ipcMain.handle('ext:mount', async (_e, name) => { if (!EXT_OK()) return { error: 'This only works on the Cacti OS PC image.' }; const r = await rootDo(['ext-mount', String(name || '')]); return r.error ? { error: r.error } : { ok: true, mount: r.out }; });
  ipcMain.handle('ext:umount', async (_e, name) => {
    if (!EXT_OK()) return { error: 'This only works on the Cacti OS PC image.' };
    const l = await extList(), d = (l.drives || []).find(x => x.name === String(name || '')); if (d && d.games) { const c = load(); c.romRoot = path.join(HOME, 'ROMs'); save(c); scanCache = null; send('cfg:changed', 1); }
    const r = await rootDo(['ext-umount', String(name || '')]); return r.error ? { error: r.error } : { ok: true };
  });
  ipcMain.handle('ext:use', async (_e, name) => {
    const l = await extList(), d = (l.drives || []).find(x => x.name === String(name || '')); if (!d || !d.mount) return { error: 'Connect the drive first.' };
    const dir = path.join(d.mount, 'ROMs'); try { fs.mkdirSync(dir, { recursive: true }); fs.accessSync(dir, fs.constants.W_OK); } catch (e) { return { error: 'Cannot write to that drive (' + (e.code || e.message) + '). If it is a Linux drive, its folders may belong to another user.' }; }
    const c = load(); c.romRoot = dir; save(c); scanCache = null; send('cfg:changed', 1); return { ok: true, folder: dir };
  });
  if (EXT_OK()) setTimeout(async () => { // connect whatever drives are plugged in, so a games folder on one is found after a restart
    try { await rootDo(['ext-mount-all']); const c = load(); if (c.romRoot && c.romRoot.startsWith('/run/media/') && fs.existsSync(c.romRoot)) { scanCache = null; send('cfg:changed', 1); } } catch {}
  }, 5000);

  // ---------- display: resolution on the Pi (wlr-randr when the compositor supports it, otherwise the boot command line), window size and system display settings elsewhere ----------
  const runOut = (cmd, args, t = 6000) => new Promise(res => execFile(cmd, args, { timeout: t }, (e, o, er) => res({ e, o: String(o || ''), er: String(er || '') })));
  const MODE_RE = /^\d{3,5}x\d{3,5}(@\d{1,3}(\.\d+)?)?$/, OUT_RE = /^[\w\-]+$/;
  let dispTimer = null, dispPrev = null;
  const CMDLINES = ['/boot/cmdline.txt', '/boot/firmware/cmdline.txt', '/mnt/boot/cmdline.txt'];
  async function dispInfo() {
    if (!LINUX) return { platform: WIN ? 'win' : 'mac', modes: [], method: 'none', fullscreen: isFs(), size: win ? win.getSize() : [0, 0] };
    const r = await runOut('wlr-randr', []);
    if (!r.e && /\bModes:/.test(r.o)) {
      const outs = []; let cur = null, inModes = false;
      for (const line of r.o.split('\n')) {
        let m = line.match(/^(\S+) "/); if (m) { cur = { name: m[1], modes: [], current: '' }; outs.push(cur); inModes = false; continue; }
        if (/^\s+Modes:/.test(line)) { inModes = true; continue; } if (/^\s+\S+:/.test(line) && !/px,/.test(line)) inModes = false;
        m = line.match(/^\s+(\d+)x(\d+) px, ([\d.]+) Hz(.*)/);
        if (cur && inModes && m) { const hz = Math.round(parseFloat(m[3]) * 100) / 100, id = `${m[1]}x${m[2]}@${hz}`, isCur = /current/.test(m[4]); cur.modes.push({ id, w: +m[1], h: +m[2], hz, current: isCur, preferred: /preferred/.test(m[4]) }); if (isCur) cur.current = id; }
      }
      const o = outs.find(x => x.modes.length); if (o) return { platform: 'linux', method: 'live', output: o.name, modes: o.modes, current: o.current };
    }
    // fallback: the kernel's list of modes for the connected display; changing it needs a restart
    try {
      const cons = []; for (const d of fs.readdirSync('/sys/class/drm')) { const m = d.match(/^card\d+-([A-Za-z0-9-]+)$/); if (!m) continue; let st = ''; try { st = fs.readFileSync(`/sys/class/drm/${d}/status`, 'utf8').trim(); } catch {} cons.push({ d, name: m[1], st }); }
      const con = cons.find(x => x.st === 'connected') || null, seen = new Set(), modes = [];
      if (con) for (const l of fs.readFileSync(`/sys/class/drm/${con.d}/modes`, 'utf8').split('\n')) { const t = l.trim(); if (/^\d+x\d+$/.test(t) && !seen.has(t)) { seen.add(t); const [w, h] = t.split('x').map(Number); modes.push({ id: t, w, h, hz: 0, current: false, preferred: !modes.length }); } }
      const maxW = modes.reduce((a, m) => Math.max(a, m.w), 0);
      for (const t of ['1920x1080', '2560x1440', '3840x2160']) { const [w, h] = t.split('x').map(Number); if (!seen.has(t) && (!maxW || w <= maxW)) { seen.add(t); modes.push({ id: t, w, h, hz: 0, current: false, preferred: false }); } } // 1080p, 1440p and 4K are always offered (up to what the screen can show)
      modes.sort((a, b) => b.w * b.h - a.w * a.h || b.hz - a.hz);
      const out = con ? con.name : 'all';
      let cur = ''; try { const mm = fs.readFileSync('/proc/cmdline', 'utf8').match(new RegExp('video=' + (con ? con.name : '[A-Za-z0-9-]+') + ':(\\d+x\\d+)')); if (mm) cur = mm[1]; } catch {}
      if (!cur) { try { cur = fs.readFileSync('/sys/class/graphics/fb0/virtual_size', 'utf8').trim().replace(',', 'x'); } catch {} }
      const cl = CMDLINES.find(f => fs.existsSync(f));
      return { platform: 'linux', method: cl || fs.existsSync(ROOTH) ? 'boot' : 'none', output: out, modes, current: cur, diag: cons.map(x => x.name + ' ' + x.st).join(', ') || 'no display connectors found' };
    } catch {}
    return { platform: 'linux', method: fs.existsSync(ROOTH) ? 'boot' : 'none', output: 'all', modes: ['1920x1080', '2560x1440', '3840x2160'].map((t, i) => { const [w, h] = t.split('x').map(Number); return { id: t, w, h, hz: 0, current: false, preferred: false }; }), current: '', diag: 'could not read the display list' };
  }
  async function dispApply(output, mode) {
    if (!OUT_RE.test(output) || !MODE_RE.test(mode)) return { error: 'That display mode is not valid.' };
    const r = await runOut('wlr-randr', ['--output', output, '--mode', mode]); return r.e ? { error: (r.er || r.e.message || 'The display refused that mode').split('\n')[0] } : { ok: true };
  }
  ipcMain.handle('disp:info', () => dispInfo());
  ipcMain.handle('disp:set', async (_e, output, mode) => {
    const info = await dispInfo(); output = String(output || ''); mode = String(mode || '');
    if (!OUT_RE.test(output) || !MODE_RE.test(mode)) return { error: 'That display mode is not valid.' };
    if (info.method === 'live') {
      if (dispTimer) return { error: 'Confirm or cancel the current test first.' };
      const prev = info.current; const r = await dispApply(output, mode); if (r.error) return r;
      dispPrev = { output, prev }; dispTimer = setTimeout(() => { dispTimer = null; if (dispPrev && dispPrev.prev) dispApply(dispPrev.output, dispPrev.prev); dispPrev = null; }, 10500);
      return { ok: true, test: true, seconds: 10 };
    }
    if (info.method === 'boot') { // takes effect after a restart; the old boot line is kept as cmdline.txt.cacti-bak so it can be undone
      if (fs.existsSync(ROOTH)) { const r = await rootDo(['video', output, mode]); return r.ok ? { ok: true, reboot: true } : r; }
      const cl = CMDLINES.find(f => fs.existsSync(f)); if (!cl) return { error: 'Could not find the boot settings file.' };
      try {
        const old = fs.readFileSync(cl, 'utf8'); if (!fs.existsSync(cl + '.cacti-bak')) fs.writeFileSync(cl + '.cacti-bak', old);
        const parts = old.trim().split(/\s+/).filter(t => !t.startsWith('video=' + output + ':')); parts.push(`video=${output}:${mode}`);
        fs.writeFileSync(cl, parts.join(' ') + '\n'); return { ok: true, reboot: true };
      } catch (e) { return { error: 'Could not write the boot settings: ' + (e.message || e) }; }
    }
    return { error: 'This system does not allow changing the resolution from here.' };
  });
  ipcMain.handle('disp:confirm', () => { if (dispTimer) clearTimeout(dispTimer); dispTimer = null; dispPrev = null; return { ok: true }; });
  ipcMain.handle('disp:revert', async () => { if (dispTimer) clearTimeout(dispTimer); dispTimer = null; const p = dispPrev; dispPrev = null; if (p && p.prev) await dispApply(p.output, p.prev); return { ok: true }; });
  ipcMain.handle('disp:reboot', async () => { if (!LINUX) return { error: 'Not supported here.' }; if (fs.existsSync(ROOTH)) return rootDo(['reboot']); execFile('systemctl', ['reboot'], e => { if (e) execFile('reboot', [], () => {}); }); return { ok: true }; });
  ipcMain.handle('disp:win', (_e, w, h) => { w = Math.round(+w); h = Math.round(+h); if (!win || !(w >= 640 && w <= 7680 && h >= 360 && h <= 4320)) return { error: 'Bad size' }; setFs(false); win.setSize(w, h); win.center(); return { ok: true }; });
  ipcMain.handle('disp:system', () => { const u = WIN ? 'ms-settings:display' : MAC ? 'x-apple.systempreferences:com.apple.Displays-Settings.extension' : ''; if (!u) return { error: 'Not available here.' }; shell.openExternal(u); return { ok: true }; });
  ipcMain.handle('sync:run', (_e, kind) => syncGo(kind === 'peer' ? 'peer' : 'folder'));
  ipcMain.handle('quit', () => app.quit());
  ipcMain.handle('clip:read', () => { try { return clipboard.readText() || ''; } catch { return ''; } });
  ipcMain.handle('music:cmd', (_e, c) => { if (/^(toggle|next|prev|volup|voldown|shuffle|mute|show|close|overlay|bump|vol:\d{1,3}|seek:\d{1,3}|skip:-?\d{1,2}|play:\d{1,2})$/.test(String(c))) musicCmd(String(c)); return mst; });
  ipcMain.handle('music:get', () => mst);
  ipcMain.handle('music:convert', (_e, url) => convertAudio(String(url)));
  ipcMain.on('music:state', (_e, s) => {
    if (s.shuffleChanged) { const c = load(); c.musicShuffle = !!s.shuffle; save(c); mst.shuffle = !!s.shuffle; }
    else { if (s.url !== undefined && s.url !== mst.url) mst.art = songArt(s.url); mst = { ...mst, ...s }; delete mst.volChanged; if (s.volChanged) { const c = load(); c.musicVol = String(s.vol); save(c); } }
    send('music-state', mst);
  });
  ipcMain.handle('launch', (_e, o) => launchGame(o));
  ipcMain.handle('play:record', (_e, o) => { try { const file = String(o && o.file || ''), secs = Math.round(Number(o && o.secs) || 0); if (!file || secs < 10) return false; const st = getStats(), e = st[file] || { plays: 0, secs: 0 }; st[file] = { plays: e.plays + 1, secs: e.secs + secs, last: Date.now() }; fs.writeFileSync(ST(), JSON.stringify(st)); logPlay(secs, String(o.title || clean(file)), o.system || ''); scanCache = null; return true; } catch { return false; } });
  createWindow(); setTimeout(raWarm, 2500);
  createMusic();
  for (const [k, v] of [['CommandOrControl+Alt+M', 'overlay'], ['MediaPlayPause', 'toggle'], ['MediaNextTrack', 'next'], ['MediaPreviousTrack', 'prev']]) { try { globalShortcut.register(k, () => musicCmd(v)); } catch {} }
  if (LINUX) { jsScan(); setInterval(jsScan, 5000); }
  padStart(); upStart();
});
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => { slog('window-all-closed'); app.quit(); });
app.on('will-quit', () => { try { globalShortcut.unregisterAll(); } catch {} });
