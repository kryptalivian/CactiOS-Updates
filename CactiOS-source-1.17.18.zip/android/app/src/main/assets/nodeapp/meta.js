'use strict';
// Game metadata: a small on-disk store plus the scraping engines that fill it.
// Each engine only fills fields that are still empty, so the engine you put first wins.
// Network engines take their base address from ENGINE_BASE so they can be tested against a local mock server.
const fs = require('fs'), path = require('path');
const FIELDS = ['desc', 'genre', 'year', 'dev', 'pub', 'players', 'rating', 'img', 'video'];
const BASE = Object.assign({
  libretrodb: 'https://raw.githubusercontent.com/libretro/libretro-database/master/metadat',
  hasheous: 'https://hasheous.org/api/v1',
  tgdb: 'https://api.thegamesdb.net/v1',
  igdbAuth: 'https://id.twitch.tv/oauth2/token',
  igdb: 'https://api.igdb.com/v4',
  ss: 'https://www.screenscraper.fr/api2',
  launchbox: 'https://gamesdb.launchbox-app.com',
  lbimg: 'https://images.launchbox-app.com'
}, (() => { try { return JSON.parse(process.env.RETROOS_ENGINE_BASE || '{}'); } catch { return {}; } })());
const UA = 'CactiOS/1 (retro game front end; contact via GitHub)';

const norm = t => String(t || '').toLowerCase().replace(/^the /, '').replace(/[^a-z0-9]/g, '');
const tk = t => norm(String(t || '').replace(/\s*[\(\[][^\)\]]*[\)\]]/g, '').replace(/,\s*(the|a|an)$/i, ''));
const key = (sys, title) => sys + ':' + tk(title);
const dec = s => String(s || '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n)).replace(/&amp;/g, '&').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').trim();
// Fuzzy title match (Dice coefficient on letter pairs) for when a name is spelled a little differently from the database.
const bigrams = s => { const m = new Map(); for (let i = 0; i < s.length - 1; i++) { const b = s.substr(i, 2); m.set(b, (m.get(b) || 0) + 1); } return m; };
function dice(a, b) {
  if (a === b) return 1; if (a.replace(/\D/g, '') !== b.replace(/\D/g, '')) return 0; // sequels (2 vs 3) are never the same game
  if (a.length < 2 || b.length < 2 || Math.abs(a.length - b.length) > Math.max(a.length, b.length) * 0.3) return 0;
  const A = bigrams(a), B = bigrams(b); let hit = 0; for (const [k, n] of A) hit += Math.min(n, B.get(k) || 0); return 2 * hit / (a.length + b.length - 2);
}
function fuzzyKey(keys, title, min = 0.86) { const ks = lbKeys(title); let best = null, bs = min; for (const k of keys) for (const w of ks) { const s = dice(k, w); if (s > bs) { bs = s; best = k; } } return best; }
const yr = v => { const m = String(v || '').match(/(19[6-9]\d|20[0-4]\d)/); return m ? +m[1] : 0; };

// ---------- store ----------
function createStore(file) {
  let d = null, t = null;
  const load = () => { if (!d) { try { d = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { d = { v: 1, g: {}, tried: {} }; } if (!d.g) d.g = {}; if (!d.tried) d.tried = {}; } return d; };
  const flush = () => { if (!d) return; clearTimeout(t); t = null; try { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file + '.tmp', JSON.stringify(d)); fs.renameSync(file + '.tmp', file); } catch {} };
  const later = () => { if (!t) t = setTimeout(flush, 1500); };
  return {
    get: (sys, title) => load().g[key(sys, title)] || null,
    // fill only empty fields; returns how many were added
    merge(sys, title, patch, engine) {
      const g = load().g, k = key(sys, title), cur = g[k] || (g[k] = { src: {} }); let n = 0;
      for (const f of FIELDS) { const v = patch[f]; if (v === undefined || v === null || v === '' || v === 0) continue; if (cur[f] === undefined || cur[f] === '' || cur[f] === 0 || (f === 'desc' && String(cur.desc).length < 60 && String(v).length > String(cur.desc).length + 20)) { cur[f] = f === 'year' ? +v : f === 'rating' ? Math.max(0, Math.min(1, +v)) : typeof v === 'string' ? v.slice(0, f === 'desc' ? 2000 : 200) : v; (cur.src || (cur.src = {}))[f] = engine; n++; } }
      if (n) later(); return n;
    },
    tried: (eng, sys, title) => (load().tried[eng + '|' + key(sys, title)] || 0),
    markTried(eng, sys, title) { load().tried[eng + '|' + key(sys, title)] = Date.now(); later(); },
    clear() { d = { v: 1, g: {}, tried: {} }; flush(); },
    count: () => Object.keys(load().g).length, flush
  };
}

// ---------- write descriptions into the system's ROM folder as gamelist.xml (EmulationStation format) ----------
const xesc = v => String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
// Adds each game's details to <dir>/gamelist.xml. Existing entries are only completed, never overwritten, so a gamelist made by another program stays as it is.
// entries: [{ file, name, desc, genre, year, dev, pub, players, rating }]. Returns how many tags were added.
function writeGamelist(dir, entries) {
  const f = path.join(dir, 'gamelist.xml'); let xml = '', had = false;
  try { xml = fs.readFileSync(f, 'utf8'); had = true; } catch {}
  if (!/<gameList[\s>]/.test(xml)) xml = '<?xml version="1.0"?>\n<gameList>\n</gameList>\n';
  const tags = e => [['name', e.name], ['desc', e.desc], ['genre', e.genre], ['releasedate', e.year ? e.year + '0101T000000' : ''], ['developer', e.dev], ['publisher', e.pub], ['players', e.players], ['rating', e.rating > 0 ? (+e.rating).toFixed(2) : '']].filter(([, v]) => v !== '' && v != null);
  const blocks = []; xml.replace(/<game\b[^>]*>[\s\S]*?<\/game>/g, (m, i) => { blocks.push({ m, i }); return m; });
  const byKey = new Map(); for (const b of blocks) { const pm = b.m.match(/<path>([\s\S]*?)<\/path>/); if (pm) byKey.set(path.parse(dec(pm[1]).replace(/\\/g, '/')).name.toLowerCase(), b); }
  let added = 0, extra = '';
  for (const e of entries) {
    const key = path.parse(e.file).name.toLowerCase(), b = byKey.get(key), tg = tags(e); if (!tg.length) continue;
    if (!b) { extra += '\t<game>\n\t\t<path>' + xesc('./' + path.relative(dir, e.file).replace(/\\/g, '/')) + '</path>\n' + tg.map(([k, v]) => '\t\t<' + k + '>' + xesc(v) + '</' + k + '>').join('\n') + '\n\t</game>\n'; added += tg.length; continue; }
    let nb = b.m, add = '';
    for (const [k, v] of tg) { const have = nb.match(new RegExp('<' + k + '>([\\s\\S]*?)</' + k + '>')); if (have && dec(have[1]).trim()) continue; if (have) nb = nb.replace(have[0], ''); add += '\t\t<' + k + '>' + xesc(v) + '</' + k + '>\n'; added++; }
    if (add) { nb = nb.replace(/\s*<\/game>\s*$/, '\n' + add.replace(/\n$/, '') + '\n\t</game>'); b.n = nb; }
  }
  if (!added) return 0;
  let out = '', last = 0; for (const b of blocks) { if (b.n) { out += xml.slice(last, b.i) + b.n; last = b.i + b.m.length; } } out += xml.slice(last);
  if (extra) out = out.replace(/<\/gameList>\s*$/, extra + '</gameList>\n');
  try { fs.writeFileSync(f + '.tmp', out); fs.renameSync(f + '.tmp', f); } catch (e) { try { fs.rmSync(f + '.tmp', { force: true }); } catch {} return -1; }
  return added;
}
const complete = m => !!(m && m.desc && m.desc.length >= 60 && m.genre && m.year);

// ---------- gamelist.xml (EmulationStation format; works offline, also what Batocera/RetroPie/Recalbox write) ----------
function parseGamelist(xml, baseDir) {
  const out = [], re = /<game\b[^>]*>([\s\S]*?)<\/game>/g; let m;
  const tag = (b, n) => { const x = b.match(new RegExp('<' + n + '>([\\s\\S]*?)</' + n + '>')); return x ? dec(x[1]) : ''; };
  const abs = p => { if (!p) return ''; p = p.replace(/\\/g, '/'); return path.isAbsolute(p) ? p : path.join(baseDir, p); };
  while ((m = re.exec(xml))) {
    const b = m[1], rp = tag(b, 'path'), rate = parseFloat(tag(b, 'rating'));
    out.push({ path: rp, name: tag(b, 'name'), desc: tag(b, 'desc'), genre: tag(b, 'genre'), year: yr(tag(b, 'releasedate')), dev: tag(b, 'developer'), pub: tag(b, 'publisher'), players: tag(b, 'players'), rating: isFinite(rate) ? (rate > 1 ? rate / 10 : rate) : 0, img: abs(tag(b, 'image')), video: abs(tag(b, 'video')) });
  }
  return out;
}
// Apply a gamelist.xml found in a system's ROM folder. Matches on the file name first, then the display name.
function applyGamelist(store, sysId, games, dir) {
  const f = path.join(dir, 'gamelist.xml'); let xml; try { xml = fs.readFileSync(f, 'utf8'); } catch { return 0; }
  const rows = parseGamelist(xml, dir), byFile = new Map(), byName = new Map();
  for (const r of rows) { if (r.path) byFile.set(path.parse(r.path.replace(/\\/g, '/')).name.toLowerCase(), r); if (r.name) byName.set(tk(r.name), r); }
  let n = 0;
  for (const g of games) {
    const r = byFile.get(path.parse(g.file).name.toLowerCase()) || byName.get(tk(g.title)); if (!r) continue;
    const patch = { ...r }; if (patch.img && !fs.existsSync(patch.img)) patch.img = ''; if (patch.video && !fs.existsSync(patch.video)) patch.video = '';
    n += store.merge(sysId, g.title, patch, 'gamelist');
  }
  return n;
}

// ---------- libretro database (no account) ----------
// Files are clrmamepro-style: game ( name "X" genre "Y" ... rom ( ... ) )
function parseDat(text) {
  const out = new Map(); const re = /(?:^|\n)\s*game\s*\(([\s\S]*?)\n\s*\)/g; let m;
  const val = (b, k) => { const x = b.match(new RegExp('\\n\\s*' + k + '\\s+(?:"([^"]*)"|(\\S+))')); return x ? (x[1] !== undefined ? x[1] : x[2]) : ''; };
  while ((m = re.exec(text))) {
    const b = '\n' + m[1], name = val(b, 'name'); if (!name) continue;
    out.set(tk(name), { genre: val(b, 'genre'), year: yr(val(b, 'releaseyear')), dev: val(b, 'developer'), players: val(b, 'users') });
  }
  return out;
}
const datMem = new Map();
async function fetchDat(kind, lr, ctx) {
  const ck = kind + '|' + lr; if (!datMem.has(ck)) datMem.set(ck, fetchDat0(kind, lr, ctx).catch(e => { datMem.delete(ck); throw e; })); return datMem.get(ck);
}
async function fetchDat0(kind, lr, ctx) {
  const url = `${BASE.libretrodb}/${kind}/${encodeURIComponent(lr)}.dat`;
  const r = await ctx.fetch(url, { signal: AbortSignal.timeout(30000), headers: { 'User-Agent': UA } });
  if (r.status === 404) return new Map(); if (!r.ok) throw httpErr(r.status);
  return parseDat(await r.text());
}
const httpErr = s => Object.assign(new Error('HTTP ' + s), { status: s });
async function libretrodb(store, s, games, ctx) {
  if (!s.lr) return 0;
  const kinds = ['genre', 'releaseyear', 'developer', 'max_users'], maps = [];
  for (const k of kinds) maps.push(await fetchDat(k, s.lr, ctx));
  let n = 0;
  for (const g of games) {
    const p = { genre: '', year: 0, dev: '', players: '' };
    for (const mp of maps) { let e = null; for (const k of lbKeys(g.title)) if ((e = mp.get(k))) break; if (!e) { const fk = fuzzyKey(mp.keys(), g.title, 0.9); e = fk && mp.get(fk); } if (!e) continue; p.genre = p.genre || e.genre; p.year = p.year || e.year; p.dev = p.dev || e.dev; p.players = p.players || e.players; }
    n += store.merge(s.id, g.title, p, 'libretrodb');
  }
  return n;
}

// ---------- per-game engines ----------
async function jget(ctx, url, opt = {}) {
  const r = await ctx.fetch(url, { signal: AbortSignal.timeout(20000), ...opt, headers: { 'User-Agent': UA, Accept: 'application/json', ...(opt.headers || {}) } });
  if (!r.ok) throw httpErr(r.status); return r.json();
}
// Hasheous: look the file up by hash (MD5, then SHA-1, plus a headerless variant for NES/SNES). Small files only.
// A 404 just means "not in the database", so it is a normal miss, never a failure that switches the engine off.
async function hasheous(sysId, g, ctx) {
  const fs_ = require('fs'), cr = require('crypto');
  let buf; try { if (fs_.statSync(g.file).size > 64 * 1024 * 1024 || /\.(zip|7z|rar|chd|cue|gdi)$/i.test(g.file)) return {}; buf = fs_.readFileSync(g.file); } catch { return {}; }
  const vars = [buf];
  if (buf.length > 16 && buf[0] === 0x4e && buf[1] === 0x45 && buf[2] === 0x53 && buf[3] === 0x1a) vars.push(buf.subarray(16));
  if (buf.length % 1024 === 512) vars.push(buf.subarray(512));
  let j = null;
  outer: for (const b of vars) for (const t of ['md5', 'sha1']) {
    const h = cr.createHash(t).update(b).digest('hex');
    try { j = await jget(ctx, `${BASE.hasheous}/Lookup/ByHash/${t}/${h}`); if (j && (j.name || (j.attributes || []).length || (j.metadata || []).length)) break outer; j = null; }
    catch (e) { if (e.status === 404 || e.status === 400) continue; throw e; }
  }
  if (!j) return {};
  const attrs = {}; for (const a of (j.attributes || [])) if (a && a.attributeName) attrs[String(a.attributeName).toLowerCase().replace(/[\s_]/g, '')] = a.value !== undefined ? a.value : a.attributeValue;
  const meta = (j.metadata || []).find(m => m && (m.description || m.summary)) || {};
  const txt = v => [].concat(v || []).map(x => (x && typeof x === 'object') ? (x.name || x.value || '') : String(x)).filter(Boolean).join(', ');
  return { year: yr(attrs.releasedate || attrs.year || attrs.releaseyear || attrs.firstreleasedate), genre: txt(attrs.genre || attrs.genres), dev: txt(attrs.developer || attrs.developers || (j.publisher && j.publisher.name) || attrs.publisher), pub: txt(attrs.publisher || (j.publisher && j.publisher.name)), desc: String(meta.description || meta.summary || attrs.description || attrs.summary || '') };
}
// TheGamesDB (free key from the user)
let tgdbLists = null;
async function tgdb(sysId, g, ctx) {
  const key_ = ctx.creds.tgdbKey; if (!key_) throw Object.assign(new Error('no key'), { status: 401 });
  if (!tgdbLists) { tgdbLists = {}; for (const [n, p] of [['genres', 'Genres'], ['developers', 'Developers'], ['publishers', 'Publishers']]) { const j = await jget(ctx, `${BASE.tgdb}/${p}?apikey=${encodeURIComponent(key_)}`); tgdbLists[n] = (j.data && j.data[n]) || {}; } }
  const j = await jget(ctx, `${BASE.tgdb}/Games/ByGameName?${new URLSearchParams({ apikey: key_, name: g.title, fields: 'overview,genres,players,publishers,developers' })}`);
  const cands = (j.data && j.data.games) || [], hk = cands.length ? fuzzyKey(cands.map(x => tk(x.game_title)), g.title, 0.85) : null, hit = hk && cands.find(x => tk(x.game_title) === hk); if (!hit) return {};
  const nm = (list, ids) => (ids || []).map(i => (list[i] || {}).name).filter(Boolean).join(', ');
  return { desc: hit.overview || '', year: yr(hit.release_date), players: hit.players ? String(hit.players) : '', genre: nm(tgdbLists.genres, hit.genres), dev: nm(tgdbLists.developers, hit.developers), pub: nm(tgdbLists.publishers, hit.publishers) };
}
// IGDB (free Twitch client id + secret from the user)
let igdbTok = null;
async function igdb(sysId, g, ctx) {
  const { igdbId, igdbSecret } = ctx.creds; if (!igdbId || !igdbSecret) throw Object.assign(new Error('no key'), { status: 401 });
  if (!igdbTok || igdbTok.exp < Date.now()) { const r = await ctx.fetch(`${BASE.igdbAuth}?${new URLSearchParams({ client_id: igdbId, client_secret: igdbSecret, grant_type: 'client_credentials' })}`, { method: 'POST', signal: AbortSignal.timeout(20000) }); if (!r.ok) throw httpErr(r.status); const j = await r.json(); igdbTok = { t: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 900 }; }
  const body = `search "${g.title.replace(/["\\]/g, '')}"; fields name,summary,first_release_date,genres.name,total_rating,involved_companies.developer,involved_companies.publisher,involved_companies.company.name; limit 10;`;
  const arr = await jget(ctx, `${BASE.igdb}/games`, { method: 'POST', body, headers: { 'Client-ID': igdbId, Authorization: 'Bearer ' + igdbTok.t, 'Content-Type': 'text/plain' } });
  const hk = (arr || []).length ? fuzzyKey(arr.map(x => tk(x.name)), g.title, 0.85) : null, h = hk && arr.find(x => tk(x.name) === hk); if (!h) return {};
  const co = f => (h.involved_companies || []).filter(c => c[f] && c.company).map(c => c.company.name).slice(0, 2).join(', ');
  return { desc: h.summary || '', year: h.first_release_date ? new Date(h.first_release_date * 1000).getUTCFullYear() : 0, genre: (h.genres || []).map(x => x.name).slice(0, 2).join(', '), rating: h.total_rating ? h.total_rating / 100 : 0, dev: co('developer'), pub: co('publisher') };
}
// ScreenScraper (needs the app's developer id plus the user's own login)
const SSID = { nes: 3, snes: 4, genesis: 1, mastersystem: 2, gb: 9, gbc: 10, gba: 12, n64: 14, nds: 15, psx: 57, psp: 61, pcengine: 31, pcenginecd: 114, gamegear: 21, segacd: 20, sega32x: 19, saturn: 22, atari2600: 26, atari7800: 41, lynx: 28, jaguar: 27, ngp: 25, wonderswan: 45, virtualboy: 11, arcade: 75, '3do': 29, msx: 113 };
// Developer credentials for Cacti OS itself, registered once by its maker at screenscraper.fr (fill in before building). End users never see or need these.
// ScreenScraper only accepts apps that present a developer login. Cacti OS does not have one yet, so this stays empty
// until the maker's developer account is approved; users can enter their own developer ID and password in Logins.
// Cacti OS's own ScreenScraper developer pair (verified against the live API). Kept scrambled so it is not plain text in the package; it identifies the app, not a person, and can be rotated at screenscraper.fr.
const unscramble = s => { const k = Buffer.from('cacti-os\x17', 'latin1'); const b = Buffer.from(s, 'base64'); return Buffer.from(b.map((x, i) => x ^ k[i % k.length])).toString('utf8'); };
const SS_BUILTIN = { id: unscramble('KBMaJB1sAzphKgAt'), pass: unscramble('Uw8HPjgUJBEvEy0=') };
const ssDev = async c => ({ id: c.ssDevId || SS_BUILTIN.id, pass: c.ssDevPass || SS_BUILTIN.pass });
const pickName = x => { const l = (x && x.noms) || []; const n = l.find(t => /^(us|wor|eu|ss)$/.test(t.region || '')) || l[0]; return n && n.text ? String(n.text) : ''; };
async function screenscraper(sysId, g, ctx) {
  const c = ctx.creds, dev = await ssDev(c, ctx); if (!dev.id || !dev.pass) throw Object.assign(new Error('not registered'), { status: 401 });
  // The developer ID identifies Cacti OS itself (registered once by its maker). The user's own account is optional and only raises the daily limits.
  const base = { devid: dev.id, devpassword: dev.pass, softname: 'CactiOS', output: 'json', ...(c.ssUser && c.ssPass ? { ssid: c.ssUser, sspassword: c.ssPass } : {}), ...(SSID[sysId] ? { systemeid: String(SSID[sysId]) } : {}) };
  // Identify the file by everything unique about it: checksums and size (small files), then its file name.
  const id = { romnom: path.basename(g.file) };
  try { const st = fs.statSync(g.file); id.romtaille = String(st.size); if (st.size <= 64 * 1024 * 1024 && !/\.(zip|7z|rar|chd|cue|gdi|iso|bin)$/i.test(g.file)) { const buf = fs.readFileSync(g.file), cr = require('crypto'); id.md5 = cr.createHash('md5').update(buf).digest('hex'); id.sha1 = cr.createHash('sha1').update(buf).digest('hex'); } } catch {}
  let jeu = null;
  try { const j = await jget(ctx, `${BASE.ss}/jeuInfos.php?${new URLSearchParams({ ...base, ...id })}`); jeu = j.response && j.response.jeu; } catch (e) { if (e.status !== 404) throw e; }
  if (!jeu) { // not found by file: search by game name
    try { const j = await jget(ctx, `${BASE.ss}/jeuRecherche.php?${new URLSearchParams({ ...base, recherche: g.title })}`); const L = (j.response && j.response.jeux) || [];
      const names = L.map(x => tk(pickName(x))), fk = names.length ? fuzzyKey(names, g.title, 0.85) : null; const hit = fk && L[names.indexOf(fk)]; if (hit) jeu = hit; } catch (e) { if (e.status !== 404) throw e; }
  }
  if (!jeu) return {};
  const pick = a => { const l = (a || []); const x = l.find(t => /^en$|^us$|^wor$/.test(t.langue || t.region || '')) || l[0]; return x && x.text ? String(x.text) : ''; };
  return { desc: pick(jeu.synopsis), year: yr(jeu.dates && jeu.dates[0] && jeu.dates[0].text), genre: (jeu.genres || []).slice(0, 2).map(x => pick(x.noms)).filter(Boolean).join(', '), dev: jeu.developpeur && jeu.developpeur.text || '', pub: jeu.editeur && jeu.editeur.text || '', players: jeu.joueurs && jeu.joueurs.text || '', rating: jeu.note && jeu.note.text ? parseFloat(jeu.note.text) / 20 : 0 };
}


// ---------- LaunchBox Games Database: one free download (Metadata.zip), indexed on this device, no account ----------
const LBPLAT = {
  nes: ['Nintendo Entertainment System'], snes: ['Super Nintendo Entertainment System'], genesis: ['Sega Genesis', 'Sega Mega Drive'], mastersystem: ['Sega Master System'],
  gb: ['Nintendo Game Boy'], gbc: ['Nintendo Game Boy Color'], gba: ['Nintendo Game Boy Advance'], n64: ['Nintendo 64'], nds: ['Nintendo DS'], '3ds': ['Nintendo 3DS'],
  psx: ['Sony Playstation'], psp: ['Sony PSP'], ps2: ['Sony Playstation 2'], ps3: ['Sony Playstation 3'], gamecube: ['Nintendo GameCube'], wii: ['Nintendo Wii'], wiiu: ['Nintendo Wii U'], switch: ['Nintendo Switch'],
  xbox: ['Microsoft Xbox'], xbox360: ['Microsoft Xbox 360'], dreamcast: ['Sega Dreamcast'], saturn: ['Sega Saturn'], segacd: ['Sega CD'], sega32x: ['Sega 32X'], gamegear: ['Sega Game Gear'],
  pcengine: ['NEC TurboGrafx-16', 'NEC PC Engine'], pcenginecd: ['NEC TurboGrafx-CD', 'NEC PC Engine CD'], atari2600: ['Atari 2600'], atari7800: ['Atari 7800'], lynx: ['Atari Lynx'], jaguar: ['Atari Jaguar', 'Atari Jaguar CD'],
  ngp: ['SNK Neo Geo Pocket', 'SNK Neo Geo Pocket Color'], wonderswan: ['WonderSwan', 'WonderSwan Color'], virtualboy: ['Nintendo Virtual Boy'], arcade: ['Arcade'], '3do': ['3DO Interactive Multiplayer'], msx: ['MSX', 'MSX2']
};
const LBREV = (() => { const m = new Map(); for (const [id, l] of Object.entries(LBPLAT)) for (const n of l) m.set(n.toLowerCase(), id); return m; })();
// minimal zip reader (central directory, stored or deflated entry) so no unzip tool is needed on any platform
function zipEntry(file, name) {
  const fd = fs.openSync(file, 'r'); try {
    const size = fs.fstatSync(fd).size, tail = Buffer.alloc(Math.min(size, 70000)); fs.readSync(fd, tail, 0, tail.length, size - tail.length);
    const e = tail.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06])); if (e < 0) throw new Error('not a zip file');
    const n = tail.readUInt16LE(e + 10); let off = tail.readUInt32LE(e + 16); const cd = Buffer.alloc(tail.readUInt32LE(e + 12)); fs.readSync(fd, cd, 0, cd.length, off);
    if (off === 0xffffffff) throw new Error('zip64 is not supported');
    let p = 0; for (let i = 0; i < n; i++) {
      if (cd.readUInt32LE(p) !== 0x02014b50) break; const method = cd.readUInt16LE(p + 10), csize = cd.readUInt32LE(p + 20), nl = cd.readUInt16LE(p + 28), xl = cd.readUInt16LE(p + 30), cl = cd.readUInt16LE(p + 32), lh = cd.readUInt32LE(p + 42), nm = cd.toString('utf8', p + 46, p + 46 + nl);
      if (nm === name || nm.endsWith('/' + name)) { const h = Buffer.alloc(30); fs.readSync(fd, h, 0, 30, lh); return { method, start: lh + 30 + h.readUInt16LE(26) + h.readUInt16LE(28), csize }; }
      p += 46 + nl + xl + cl;
    }
    throw new Error(name + ' is not inside the download');
  } finally { fs.closeSync(fd); }
}
const lbTag = (b, n) => { const x = b.match(new RegExp('<' + n + '>([\\s\\S]*?)</' + n + '>')); return x ? dec(x[1]).trim() : ''; };
const lbRegionRank = r => /north america|united states|world/i.test(r || '') ? 0 : /europe|united kingdom/i.test(r || '') ? 1 : 2;
async function lbBuild(ctx, say) {
  const dir = ctx.dir; fs.mkdirSync(dir, { recursive: true });
  const stamp = path.join(dir, 'lb-built.json'); try { const st = JSON.parse(fs.readFileSync(stamp, 'utf8')); if (st.v === 2 && Date.now() - st.t < 30 * 864e5) return; } catch {}
  const zip = path.join(dir, 'Metadata.zip'); say('LaunchBox: downloading the game database (one time, about 100 MB)…');
  const r = await ctx.fetch(`${BASE.launchbox}/Metadata.zip`, { redirect: 'follow', headers: { 'User-Agent': UA } }); if (!r.ok) throw httpErr(r.status);
  await new Promise((res, rej) => { const ws = fs.createWriteStream(zip); ws.on('error', rej); ws.on('finish', res); (async () => { try { for await (const c of r.body) if (!ws.write(c)) await new Promise(k => ws.once('drain', k)); ws.end(); } catch (e) { rej(e); } })(); });
  say('LaunchBox: indexing the database (one time)…');
  const ent = zipEntry(zip, 'Metadata.xml'), src = fs.createReadStream(zip, { start: ent.start, end: ent.start + ent.csize - 1 });
  const stream = ent.method === 8 ? src.pipe(require('zlib').createInflateRaw()) : src;
  const bySys = {}, byId = new Map(), sd = new (require('string_decoder').StringDecoder)('utf8'); let buf = '', count = 0;
  const take = (name, body) => {
    if (name === 'Game') {
      const sys = LBREV.get(lbTag(body, 'Platform').toLowerCase()); if (!sys) return; const nm = lbTag(body, 'Name'); if (!nm) return;
      const rate = parseFloat(lbTag(body, 'CommunityRating')), rec = { n: nm, d: lbTag(body, 'Overview'), g: lbTag(body, 'Genres').split(/\s*;\s*/).slice(0, 2).join(', '), y: yr(lbTag(body, 'ReleaseDate') || lbTag(body, 'ReleaseYear')), v: lbTag(body, 'Developer'), p: lbTag(body, 'Publisher'), m: lbTag(body, 'MaxPlayers'), r: isFinite(rate) ? Math.round(rate / 5 * 100) / 100 : 0, b: '', br: 9 };
      const k = tk(nm), tbl = bySys[sys] || (bySys[sys] = Object.create(null)), cur = tbl[k]; if (!cur || rec.d.length > cur.d.length) { if (cur && cur.b) { rec.b = cur.b; rec.br = cur.br; } if (cur && cur.f) { rec.f = cur.f; rec.fr = cur.fr; } tbl[k] = rec; byId.set(lbTag(body, 'DatabaseID'), { sys, rec: tbl[k] }); count++; }
      else byId.set(lbTag(body, 'DatabaseID'), { sys, rec: cur });
    } else if (name === 'GameAlternateName') {
      const h = byId.get(lbTag(body, 'DatabaseID')); if (!h) return; const k = tk(lbTag(body, 'AlternateName')); if (k && !bySys[h.sys][k]) bySys[h.sys][k] = h.rec;
    } else if (name === 'GameImage') {
      const ty = lbTag(body, 'Type'), tr = ty === 'Fanart - Background' ? 0 : ty === 'Screenshot - Gameplay' ? 1 : -1;
      if (ty !== 'Box - Front' && tr < 0) return; const h = byId.get(lbTag(body, 'DatabaseID')); if (!h) return; const rk = lbRegionRank(lbTag(body, 'Region'));
      if (ty === 'Box - Front') { if (rk < h.rec.br) { h.rec.br = rk; h.rec.b = lbTag(body, 'FileName'); } }
      else { const sc = tr * 10 + rk; if (h.rec.fr === undefined || sc < h.rec.fr) { h.rec.fr = sc; h.rec.f = lbTag(body, 'FileName'); } }
    }
  };
  await new Promise((res, rej) => {
    stream.on('data', ch => {
      buf += sd.write(ch);
      for (;;) { const m = /<(Game|GameAlternateName|GameImage)>/.exec(buf); if (!m) { buf = buf.slice(-40); break; } const end = buf.indexOf('</' + m[1] + '>', m.index); if (end < 0) { buf = buf.slice(m.index); break; } try { take(m[1], buf.slice(m.index + m[0].length, end)); } catch {} buf = buf.slice(end + m[1].length + 3); }
    });
    stream.on('end', res); stream.on('error', rej);
  });
  if (!count) throw new Error('The LaunchBox database had no games in it');
  for (const [sys, tbl] of Object.entries(bySys)) fs.writeFileSync(path.join(dir, 'lb-' + sys + '.json'), JSON.stringify(tbl));
  fs.writeFileSync(stamp, JSON.stringify({ t: Date.now(), games: count, v: 2 })); try { fs.rmSync(zip, { force: true }); } catch {}
}
const lbMem = new Map();
function lbLoad(dir, sysId) { if (lbMem.has(sysId)) return lbMem.get(sysId); let t = null; try { t = Object.assign(Object.create(null), JSON.parse(fs.readFileSync(path.join(dir, 'lb-' + sysId + '.json'), 'utf8'))); } catch {} lbMem.set(sysId, t); return t; }
// Several spellings of one title, so "Legend of Zelda, The - A Link to the Past (USA)" finds "The Legend of Zelda: A Link to the Past".
function lbKeys(title) {
  const base = String(title || '').replace(/\s*[\(\[][^\)\]]*[\)\]]/g, '').trim(), out = [tk(title)];
  const m = base.replace(/,\s*(the|a|an)(?=\s*[-:\u2013]|\s*$)/i, (_x, a) => '\u0000' + a);
  if (m !== base) { const art = (m.match(/\u0000(\w+)/) || [])[1]; const rest = m.replace(/\u0000\w+/, ''); out.push(norm(art + ' ' + rest), norm(rest)); }
  out.push(norm(base.replace(/^(the|a|an)\s+/i, '')), norm(base.split(/\s+[-\u2013]\s+|:\s+/)[0]));
  return [...new Set(out.filter(Boolean))];
}
const lbKeyList = new WeakMap(), lbFuzzMemo = new WeakMap();
function lbFind(t, title) {
  const ks = lbKeys(title); for (const k of ks.slice(0, -1)) if (t[k]) return t[k]; const bare = ks[ks.length - 1]; if (t[bare] || t['the ' + bare]) return t[bare] || t['the ' + bare];
  let memo = lbFuzzMemo.get(t); if (!memo) lbFuzzMemo.set(t, memo = new Map()); if (memo.has(title)) return memo.get(title);
  let list = lbKeyList.get(t); if (!list) lbKeyList.set(t, list = Object.keys(t)); const fk = fuzzyKey(list, title, 0.88), r = fk ? t[fk] : null; memo.set(title, r); return r;
}
async function launchbox(store, s, games, ctx) {
  if (!LBPLAT[s.id]) return 0; await lbBuild(ctx, ctx.say || (() => {})); const t = lbLoad(ctx.dir, s.id); if (!t) return 0; let n = 0;
  for (const g of games) { const r = lbFind(t, g.title); if (r) n += store.merge(s.id, g.title, { desc: r.d, genre: r.g, year: r.y, dev: r.v, pub: r.p, players: r.m, rating: r.r }, 'launchbox'); }
  return n;
}
// Box art file name for a game from the LaunchBox index (null when not indexed). The picture is fetched on demand and saved on this device.
// Fan art (or a gameplay screenshot when there is no fan art) for the launch screen background.
function lbFan(dir, sysId, title) { const t = lbLoad(dir, sysId), r = t && lbFind(t, title); return r && r.f ? `${BASE.lbimg}/${r.f}` : null; }
function lbBox(dir, sysId, title) { const t = lbLoad(dir, sysId), r = t && lbFind(t, title); return r && r.b ? `${BASE.lbimg}/${r.b}` : null; }

// Engines that look at one game at a time. 'batch' ones work on a whole system folder.
const ENGINES = {
  gamelist: { name: 'gamelist.xml import', batch: true, acct: false },
  libretrodb: { name: 'libretro database', batch: true, acct: false },
  launchbox: { name: 'LaunchBox Games Database', batch: true, acct: false },
  hasheous: { name: 'Hasheous', one: hasheous, acct: false, ver: '2' },
  screenscraper: { name: 'ScreenScraper', one: screenscraper, acct: true, gap: 1200 },
  thegamesdb: { name: 'TheGamesDB', one: tgdb, acct: true },
  igdb: { name: 'IGDB', one: igdb, acct: true, gap: 300 }
};
// Sign-in check for the services that need an account or key. Returns { ok, msg }.
async function testLogin(eng, c, ctx) {
  try {
    if (eng === 'screenscraper') {
      const dev = await ssDev(c, ctx); if (!dev.id) return { ok: false, msg: 'ScreenScraper is not available in this version yet. The other engines work without any account.' };
      const hasUser = !!(c.ssUser && c.ssPass), base = { devid: dev.id, devpassword: dev.pass, softname: 'CactiOS', output: 'json' };
      const q = new URLSearchParams(hasUser ? { ...base, ssid: c.ssUser, sspassword: c.ssPass } : base);
      const r = await ctx.fetch(`${BASE.ss}/${hasUser ? 'ssuserInfos' : 'ssinfraInfos'}.php?${q}`, { signal: AbortSignal.timeout(20000), headers: { 'User-Agent': UA } });
      const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch {}
      const u = j && j.response && j.response.ssuser;
      if (r.ok && hasUser && u) return { ok: true, msg: `Signed in to ScreenScraper as ${u.id || c.ssUser}${u.niveau ? ' (level ' + u.niveau + ')' : ''}.` };
      if (r.ok && !hasUser && j && j.response) return { ok: true, msg: 'ScreenScraper is reachable. Add your free account to get higher daily limits.' };
      if (r.status === 401 || r.status === 403 || /identifiants|login/i.test(t)) return { ok: false, msg: (hasUser ? 'ScreenScraper refused the username or password.' : 'ScreenScraper refused this app. Try again later.') + ` (HTTP ${r.status}: ${t.replace(/\s+/g, ' ').slice(0, 140)})` };
      if (r.status === 429) return { ok: false, msg: 'ScreenScraper says too many requests right now. Try again later.' };
      return { ok: false, msg: 'ScreenScraper answered with an error (' + r.status + ').' };
    }
    if (eng === 'thegamesdb') {
      if (!c.tgdbKey) return { ok: false, msg: 'Enter your TheGamesDB API key first.' };
      const r = await ctx.fetch(`${BASE.tgdb}/Genres?apikey=${encodeURIComponent(c.tgdbKey)}`, { signal: AbortSignal.timeout(20000), headers: { 'User-Agent': UA } });
      return r.ok ? { ok: true, msg: 'TheGamesDB key accepted.' } : { ok: false, msg: r.status === 401 || r.status === 403 ? 'TheGamesDB refused that key.' : 'TheGamesDB answered with an error (' + r.status + ').' };
    }
    if (eng === 'igdb') {
      if (!c.igdbId || !c.igdbSecret) return { ok: false, msg: 'Enter your IGDB (Twitch) client ID and secret first.' };
      const r = await ctx.fetch(`${BASE.igdbAuth}?${new URLSearchParams({ client_id: c.igdbId, client_secret: c.igdbSecret, grant_type: 'client_credentials' })}`, { method: 'POST', signal: AbortSignal.timeout(20000) });
      return r.ok ? { ok: true, msg: 'IGDB login accepted.' } : { ok: false, msg: 'Twitch refused that client ID and secret.' };
    }
    return { ok: false, msg: 'Unknown service.' };
  } catch (e) { return { ok: false, msg: 'Could not reach the service: ' + e.message }; }
}
const resetCaches = () => { datMem.clear(); tgdbLists = null; igdbTok = null; lbMem.clear(); };
// ---------- engine status check (no account needed): is each source reachable right now? ----------
async function probe(ctx, url, opt = {}) {
  const t = Date.now();
  try { const r = await ctx.fetch(url, { method: opt.method || 'GET', headers: { 'User-Agent': UA, ...(opt.headers || {}) }, redirect: 'follow', signal: AbortSignal.timeout(12000) }); try { r.body && r.body.cancel && r.body.cancel(); } catch {} return { status: r.status, ms: Date.now() - t }; }
  catch (e) { return { err: e && e.name === 'TimeoutError' ? 'timeout' : (e && e.cause && e.cause.code) || (e && e.message) || 'error', ms: Date.now() - t }; }
}
function verdict(pr, okMiss) {
  if (pr.err === 'timeout') return ['slow', 'Not responding (no answer after 12 seconds)'];
  if (pr.err) return ['down', 'Cannot connect (' + pr.err + '). Check the internet connection'];
  if (pr.status === 429) return ['limit', 'Limit reached. Too many lookups right now, try again later'];
  if (pr.status >= 500) return ['down', 'The service is down (error ' + pr.status + ')'];
  if (pr.status === 401 || pr.status === 403) return ['blocked', 'The service refused the request (' + pr.status + ')'];
  if (pr.status >= 400 && !(okMiss && okMiss.includes(pr.status))) return ['error', 'Unexpected answer (' + pr.status + ')'];
  return ['ok', 'Working (' + pr.ms + ' ms)'];
}
async function engineStatus(ctx) {
  const rows = [], add = (id, name, v, extra) => rows.push({ id, name, state: v[0], text: v[1], extra: extra || '' });
  let lb = ''; try { const t = JSON.parse(fs.readFileSync(path.join(ctx.dir, 'lb-built.json'), 'utf8')).t; lb = 'Local database built ' + new Date(t).toLocaleDateString(); } catch { lb = 'Local database not downloaded yet (downloads on the first scrape)'; }
  const [a, b, c, d] = await Promise.all([
    probe(ctx, BASE.launchbox + '/Metadata.zip', { method: 'HEAD' }),
    probe(ctx, BASE.hasheous + '/Lookup/ByHash/md5/d41d8cd98f00b204e9800998ecf8427e', { headers: { Accept: 'application/json' } }),
    probe(ctx, BASE.libretrodb + '/no-intro/Nintendo%20-%20Super%20Nintendo%20Entertainment%20System.dat', { headers: { Range: 'bytes=0-0' } }),
    probe(ctx, 'https://thumbnails.libretro.com/', { method: 'HEAD' })
  ]);
  add('launchbox', 'LaunchBox Games Database', verdict(a, [405]), lb);
  add('hasheous', 'Hasheous', verdict(b, [404]), 'Looks games up by file fingerprint');
  add('libretrodb', 'libretro database', verdict(c, [416]), 'Genre, year, developer');
  add('gamelist', 'gamelist.xml import', ['ok', 'Local, no internet needed'], 'Reads files saved next to your ROMs');
  add('libretro', 'Box art (libretro thumbnails)', verdict(d, [405]), 'Cover images');
  return rows;
}

module.exports = { writeGamelist, engineStatus, launchbox, lbBox, lbFan, testLogin, createStore, complete, parseGamelist, applyGamelist, parseDat, libretrodb, ENGINES, tk, key, resetCaches, BASE, FIELDS, httpErr };
