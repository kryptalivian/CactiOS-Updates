const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('mus', {
  convert: u => ipcRenderer.invoke('music:convert', u),
  cmd: c => ipcRenderer.invoke('music:cmd', c),
  state: s => ipcRenderer.send('music:state', s),
  onList: cb => ipcRenderer.on('music:list', (_e, d) => cb(d)),
  onCmd: cb => ipcRenderer.on('music:cmd', (_e, d) => cb(d))
});
