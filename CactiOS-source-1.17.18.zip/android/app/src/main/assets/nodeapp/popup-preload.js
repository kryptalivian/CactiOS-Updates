const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('ach', { onShow: cb => ipcRenderer.on('ach:show', (_e, d) => cb(d)) });
