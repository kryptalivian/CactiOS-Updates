const { contextBridge, ipcRenderer } = require('electron');
const inv = (c, ...a) => ipcRenderer.invoke(c, ...a);
contextBridge.exposeInMainWorld('api', {
  tidyPlan: () => inv('tidy:plan'), tidyRun: () => inv('tidy:run'),
  profPicker: () => inv('prof:picker'), profGuest: () => inv('prof:guest'),
  profList: () => inv('prof:list'), profCreate: (n, a) => inv('prof:create', n, a), profRename: n => inv('prof:rename', n), profUse: n => inv('prof:use', n),
  getConfig: () => inv('cfg:get'), setConfig: p => inv('cfg:set', p), getSystems: () => inv('sys:get'),
  scan: f => inv('scan', f), scanQuick: () => inv('scan:quick'), shareExport: () => inv('share:export'), shareSaves: on => inv('share:saves', on), ra: () => inv('ra'), lobbies: () => inv('lobbies'), raGame: o => inv('ra:game', o), raRecent: () => inv('ra:recent'), raCount: o => inv('ra:count', o), raTotals: g => inv('ra:totals', g), achStop: () => inv('ach:stop'), onRaLists: cb => ipcRenderer.on('ra-lists', (_e, d) => cb(d)), achPreview: st => inv('ach:preview', st), themes: () => inv('themes:list'), themesDir: () => inv('themes:dir'), launch: o => inv('launch', o), playRecord: o => inv('play:record', o), openLog: () => inv('log:open'),
  clip: () => inv('clip:read'), themeSave: t => inv('themes:save', t), themeDelete: n => inv('themes:delete', n), studio: () => inv('studio:open'), onThemes: cb => ipcRenderer.on('themes-changed', () => cb()), pick: t => inv('pick', t), quit: () => inv('quit'), fullscreen: () => inv('fs'),
  wifiScan: () => inv('wifi:scan'), wifiConnect: o => inv('wifi:connect', o), wifiForget: n => inv('wifi:forget', n), padStatus: () => inv('pad:status'), savesInfo: () => inv('saves:info'), savesBackup: () => inv('saves:backup'), savesRestore: id => inv('saves:restore', id), savesOpen: () => inv('saves:open'), btList: () => inv('bt:list'), btScan: () => inv('bt:scan'), btPair: m => inv('bt:pair', m), btAct: (c, m) => inv('bt:act', c, m), btSettings: () => inv('bt:settings'), padCapture: on => inv('pad:capture', on), onPadRaw: cb => ipcRenderer.on('pad:raw', (_e, v) => cb(v)), onPadAct: cb => ipcRenderer.on('pad:act', (_e, a) => cb(a)), onLibrary: cb => ipcRenderer.on('library-changed', () => cb()), uploadInfo: () => inv('upload:info'), uploadNewCode: () => inv('upload:newcode'),
  wifi: () => inv('wifi:get'), wifiPower: on => inv('wifi:power', on), wifiOpen: () => inv('wifi:open'),
  getVolume: () => inv('vol:get'), setVolume: v => inv('vol:set', v),
  check: () => inv('check'), usage: () => inv('usage'), updInfo: () => inv('upd:info'), updRestore: id => inv('upd:restore', id), dispInfo: () => inv('disp:info'), extList: c => inv('ext:list', c), extMount: n => inv('ext:mount', n), extUmount: n => inv('ext:umount', n), extUse: n => inv('ext:use', n), dispSet: (o, m) => inv('disp:set', o, m), dispConfirm: () => inv('disp:confirm'), dispRevert: () => inv('disp:revert'), dispReboot: () => inv('disp:reboot'), dispWin: (w, h) => inv('disp:win', w, h), dispSystem: () => inv('disp:system'), metaClear: () => inv('meta:clear'), metaCount: () => inv('meta:count'), syncRun: k => inv('sync:run', k), shareGet: () => inv('share:get'), instInfo: () => inv('inst:info'), instStart: (d, k) => inv('inst:start', d, k), instStatus: () => inv('inst:status'), instReboot: () => inv('inst:reboot'), shareSet: on => inv('share:set', !!on), updCheck: a => inv('upd:check', a), updStart: () => inv('upd:start'), installCores: () => inv('cores:install'), installRetroArch: () => inv('retroarch:install'),
  history: () => inv('history:get'), raOverview: f => inv('ra:overview', f), raTop: () => inv('ra:top'), raBoards: id => inv('ra:boards', id), raEntries: o => inv('ra:entries', o),
  onAchInline: cb => ipcRenderer.on('ach:inline', (_e, d) => cb(d || {})),
  storeList: r => inv('store:list', r), storeInstall: (id, rom) => inv('store:install', id, rom), storeRom: id => inv('store:rom', id), storePick: id => inv('store:pick', id), storePlay: id => inv('store:play', id), storeRemove: id => inv('store:remove', id), storePage: id => inv('store:page', id), storeLinks: () => inv('store:links'), storeOpen: i => inv('store:open', i), onStoreProgress: cb => ipcRenderer.on('store-progress', (_e, d) => cb(d || {})),
  emuList: () => inv('emu:list'), emuRefresh: f => inv('emu:refresh', f), emuInstall: id => inv('emu:install', id), emuUpdateAll: () => inv('emu:updateAll'), emuPage: id => inv('emu:page', id), emuBrowse: id => inv('emu:browse', id), biosOpen: id => inv('bios:open', id),
  onScanUpdated: cb => ipcRenderer.on('scan:updated', () => cb()),
  onEmuProgress: cb => ipcRenderer.on('emu-progress', (_e, d) => cb(d || {})),
  friends: f => inv('friends:list', f), friendSummaries: u => inv('friends:sum', u), friendGames: u => inv('friends:games', u), friendGame: o => inv('friends:game', o), friendAdd: n => inv('friends:add', n), friendOpen: u => inv('friends:open', u),
  scrape: id => inv('scrape', id), scrapeBg: id => inv('scrape:bg', id), bgGet: q => inv('bg:get', q), scraperTest: e => inv('scraper:test', e), engineStatus: () => inv('scraper:status'), scrapeStop: () => inv('scrape:stop'),
  music: c => inv('music:cmd', c), getMusic: () => inv('music:get'), onMusic: cb => ipcRenderer.on('music-state', (_e, d) => cb(d)),
  onOverlay: cb => ipcRenderer.on('overlay', (_e, v) => cb(v)),
  onGameExit: cb => ipcRenderer.on('game-exit', (_e, d) => cb(d || {})),
  onCfg: cb => ipcRenderer.on('cfg:changed', () => cb()),
  onScrape: cb => ipcRenderer.on('scrape', (_e, d) => cb(d)),
  onScanProgress: cb => ipcRenderer.on('scan:progress', (_e, d) => cb(d))
});
