(() => {
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const norm = t => t.toLowerCase().replace(/^the /, '').replace(/[^a-z0-9]/g, '');
let cfg = {}, BASE = [], SYS = [], sys = 0, selBy = {}, mode = 'home', panel = null, M = null, RA = null, W = null, before = new Set(), tt, lastBtn = '';
let LIBV = null, LAST = null, AVL = null, CY0 = null, ELIB = null, FR = null, FX = null;
let zone = 'games', topIdx = 0, pIdx = 0, LB = null, SM = [], AM = null;
let favs = new Set(); try { favs = new Set(JSON.parse(localStorage.getItem('favs') || '[]')); } catch {}
const S = { music: { playing: false, title: '', idx: -1, total: 0, vol: 70, shuffle: false }, vol: 50, check: null, scrape: { run: false, done: 0, total: 0, found: 0 }, msg: '', busy: '' };
const hue = t => { let h = 0; for (const c of t) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const fit = () => { const s = Math.min(innerWidth / 1440, innerHeight / 810), st = document.documentElement.style; st.setProperty('--s', s); st.setProperty('--sw', Math.round(Math.max(1440, Math.min(2400, innerWidth / s))) + 'px'); st.setProperty('--dy', Math.round(Math.max(0, Math.min(270, innerHeight / s - 810))) + 'px'); }; // the stage grows wider AND taller than 1440x810 to fill the screen, so 16:10 (Steam Deck), 4:3 and ultrawide have no bars
addEventListener('resize', fit); fit();
const clock = () => { $('#clock').textContent = new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); };
clock(); setInterval(clock, 30000);
const theme = () => { try { Themes.apply(cfg, SYS[sys] && SYS[sys].id); } catch (e) { document.documentElement.dataset.theme = cfg.dark ? 'dark' : 'light'; } topIcons(); };
// Declutter: icons can leave the top bar. Trophy = achievements as an icon; Declutter = every icon except the profile bubble moves into the profile menu.
function topIcons() {
  const dc = !!cfg.declutter, tr = !!cfg.trophy && !dc, di = !!cfg.discord && !dc;
  document.documentElement.dataset.layout = lay();
  $('#discord').classList.toggle('hid', !di); setDot(); document.querySelectorAll('#prof .dcd').forEach(r => r.classList.toggle('hid', di));
  for (const id of ['srch', 'music', 'lobby', 'wifi', 'pads']) $('#' + id).classList.toggle('hid', dc);
  $('#trophy').classList.toggle('hid', !tr); $('#rowach').classList.toggle('hid', tr);
  document.querySelectorAll('#prof .dcr').forEach(r => r.classList.toggle('hid', !dc));
  if (typeof topIdx != 'undefined') topIdx = Math.min(topIdx, TOP().length - 1);
}
let ac; function tick(f = 880) { if (!cfg.navSounds) return; try { ac = ac || new AudioContext(); const o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = f; g.gain.value = .04; o.connect(g); g.connect(ac.destination); o.start(); g.gain.exponentialRampToValueAtTime(.0001, ac.currentTime + .06); o.stop(ac.currentTime + .07); } catch {} }
function toast(a, b, c) { clearTimeout(tt); $('#t1').textContent = a; $('#t2').textContent = b; $('#t3').textContent = c || ''; $('#toast').classList.add('show'); tt = setTimeout(() => $('#toast').classList.remove('show'), Math.min(14000, 4200 + (String(b || '').length + String(c || '').length) * 45)); }
$('#toast').addEventListener('click', () => { clearTimeout(tt); $('#toast').classList.remove('show'); });
const fmtTime = s => { const h = Math.floor(s / 3600), m = Math.round((s % 3600) / 60); return h ? `${h}h ${m}m` : `${m}m`; };
let WF = null, CT = null, SR = null, nativePad = false; // declared first: the controller poll can run before the rest of the file has been read
const pads = () => [...(navigator.getGamepads ? navigator.getGamepads() : [])].filter(Boolean);
const cleanPad = id => String(id).replace(/\s*\(.*$/, '').trim() || String(id);

// ----- systems + collections -----
const getSel = () => { const s = SYS[sys]; return s ? Math.min(selBy[s.id] || 0, s.games.length - 1) : 0; };
const setSel = i => { const s = SYS[sys]; if (s) selBy[s.id] = i; };
const cur = () => SYS[sys] && SYS[sys].games[getSel()];
const LAYS = [['classic', 'Classic'], ['compact', 'Compact'], ['flow', 'Cover Flow'], ['side', 'Sidebar'], ['spot', 'Spotlight'], ['wall', 'Grid Wall'], ['rails', 'Rails'], ['cols', 'Columns'], ['dash', 'Dashboard'], ['detail', 'Detail (description + video)'], ['covers', 'Cover Wall'], ['timeline', 'Timeline by year'], ['custom', 'Custom (from theme)']];
const lay = () => (LAYS.some(l => l[0] === cfg.layout) ? cfg.layout : 'classic');
const FREE = ['flow', 'side', 'spot', 'wall', 'rails', 'cols', 'detail', 'covers', 'timeline'], vtabs = () => ['side', 'cols'].includes(lay());
const homeN = () => ({ wall: 23, side: 20, cols: 30, rails: 14 }[lay()] || 8); // games shown on the home screen; the rest live in the Library page
function toRow(list) {
  if (cfg && cfg.layout === 'timeline') { const o = list.map((g, k) => [g, k]).sort((a, b) => ((a[0].meta && a[0].meta.year) || 9999) - ((b[0].meta && b[0].meta.year) || 9999) || a[1] - b[1]).map(x => x[0]); const HOME = homeN(); return o.length > HOME ? [...o.slice(0, HOME), { lib: true, title: 'Library', count: o.length }] : o; }
  const rec = list.filter(g => g.stats && g.stats.last).sort((a, b) => b.stats.last - a.stats.last), rest = list.filter(g => !(g.stats && g.stats.last)), ord = [...rec, ...rest];
  const HOME = homeN(); return ord.length > HOME ? [...ord.slice(0, HOME), { lib: true, title: 'Library', count: ord.length }] : ord;
}

// ----- home layouts: Cover Flow, Sidebar, Spotlight, Grid Wall, Rails, Columns (positions set per card; navigation shares the same selection) -----
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const railN = s => { const r = s.games.filter(g => g.stats && g.stats.last).length; return r > 0 && r < s.games.length ? r : s.games.length; };

// ----- metadata layouts: Detail (description + video), Cover Wall, Timeline by year -----
let VIDT = 0;
function stopVid() { clearTimeout(VIDT); const v = document.querySelector('#stage .dmv'); if (v) v.remove(); }
const fileUrl = p => /^[a-zA-Z]:[\\/]/.test(p) ? 'file:///' + encodeURI(p.replace(/\\/g, '/')) : 'file://' + encodeURI(p);
function detailPanel(g, s) {
  const el = $('#dmeta'); el.classList.remove('hid'); const m = (g && g.meta) || {};
  if (!g || g.lib) { el.innerHTML = `<h2 class="cond">${esc(s.name)}</h2><div class="dmn">${s.all.length} games. Open the library to see them all.</div>`; return; }
  const chips = [m.year, String(m.genre || '').split(',').slice(0, 2).join(' · '), m.dev, m.players && 'Players ' + m.players, m.rating && '★ ' + Math.round(m.rating * 100) + '%'].filter(Boolean);
  el.innerHTML = `<h2 class="cond">${esc(g.title)}</h2><div class="dmc">${chips.map(c => `<span>${esc(c)}</span>`).join('')}</div>${m.desc ? `<div class="dmd">${esc(m.desc)}</div>` : '<div class="dmn">No description yet. Open Menu > Features > Scrapers and run it to look up details for your games.</div>'}`;
  if (m.video && location.protocol === 'file:') VIDT = setTimeout(() => { if (cur() !== g) return; const v = document.createElement('video'); v.className = 'dmv'; v.src = fileUrl(m.video); v.muted = true; v.loop = true; v.autoplay = true; Object.assign(v.style, { left: '470px', top: '160px', width: '300px', height: '354px', zIndex: 3 }); v.oncanplay = () => v.classList.add('on'); $('#stage').appendChild(v); }, 1400);
}
function timelineAxis(s, i, g) {
  const ax = $('#tlax'); ax.classList.remove('hid'); let h = '<b></b>', last = null;
  s.games.forEach((x, k) => { const y = x.meta && x.meta.year ? x.meta.year : 0, d = k - i; if (y === last) return; last = y; const px = d === 0 ? 595 : d > 0 ? 595 + 250 + 26 + (d - 1) * 136 : 595 - 26 - 124 - (Math.abs(d) - 1) * 136; if (px > -20 && px < 1380) h += `<i style="left:${Math.max(64, px)}px;top:${d === 0 ? 238 : 238}px">${y || 'UNKNOWN'}</i>`; });
  ax.innerHTML = h;
}
let placed = false;
function place() {
  const L = lay(), row = $('#row'), cards = [...row.children], s = SYS[sys], dart = $('#dart'), band = $('#dband'), r1 = $('#rl1'), r2 = $('#rl2');
  [dart, band, r1, r2, $('#dmeta'), $('#tlax')].forEach(e => e.classList.add('hid')); stopVid();
  $('#dash').classList.toggle('hid', L !== 'dash'); document.querySelector('.pr[data-a="x"] span').textContent = L === 'dash' ? 'TILES' : 'ACHIEVEMENTS';
  if (L === 'dash') { drawDash(); dashLoad(); }
  if (!FREE.includes(L) || !s || !cards.length) {
    if (placed) cards.forEach(c => ['transform', 'left', 'top', 'opacity', 'visibility', 'z-index', 'pointer-events'].forEach(k => c.style.removeProperty(k)));
    placed = false; return;
  }
  placed = true;
  const i = getSel(), n = cards.length, g = s.games[i];
  const put = (c, x, y, sc, o = {}) => {
    const st = c.style, vis = o.show !== false;
    st.opacity = vis ? '1' : '0'; st.pointerEvents = vis ? '' : 'none'; st.zIndex = o.z || (c.classList.contains('on') ? 5 : 1);
    st.transform = `translate(${x}px,${y}px)${o.rot ? ` perspective(900px) rotateY(${o.rot}deg)` : ''} scale(${sc})`;
  };
  const art = (x, y, w, h) => {
    dart.classList.remove('hid'); Object.assign(dart.style, { left: x + 'px', top: y + 'px', width: w + 'px', height: h + 'px', background: g.lib ? 'var(--chip)' : artBg(g) });
    dart.innerHTML = g.lib ? '<span class="ct" style="font-size:34px">LIBRARY</span>' : artHTML(g); dart.style.fontSize = (w / 200) + 'em'; dart.querySelector('.ct') && (dart.querySelector('.ct').style.fontSize = Math.round(30 * w / 200) + 'px');
  };
  cards.forEach((c, k) => {
    if (L === 'flow') {
      const d = k - i, ad = Math.abs(d), sg = Math.sign(d), off = [0, 300, 440, 550][Math.min(ad, 3)], sc = ad === 0 ? 1.7 : [0, .9, .78, .68][Math.min(ad, 3)];
      put(c, 720 - 100 + sg * off, 366 - 118, sc, { show: ad <= 3, rot: ad ? -sg * 48 : 0, z: 10 - ad });
    } else if (L === 'spot') {
      const first = clamp(i - 3, 0, Math.max(0, n - 8)); put(c, 470 + (k - first) * 112, 616, .5, { show: k >= first && k < first + 8 });
    } else if (L === 'wall') {
      put(c, 64 + (k % 6) * 124, 160 + Math.floor(k / 6) * 144, .56);
    } else if (L === 'side') {
      put(c, 340 + (k % 7) * 140, 160 + Math.floor(k / 7) * 162, .62);
    } else if (L === 'rails') {
      const n1 = railN(s), top = k < n1, col = top ? k : k - n1, selTop = i < n1, selCol = selTop ? i : i - n1;
      const first = (top === selTop) ? clamp(selCol - 4, 0, Math.max(0, (top ? n1 : n - n1) - 9)) : 0;
      put(c, 64 + (col - first) * 136, top ? 398 : 584, .6, { show: col >= first && col < first + 9 });
    } else if (L === 'cols') {
      const first = clamp(i - 4, 0, Math.max(0, n - 10)); put(c, 310, 160 + (k - first) * 56, 1, { show: k >= first && k < first + 10 });
    } else if (L === 'detail') {
      const first = clamp(i - 4, 0, Math.max(0, n - 10)); put(c, 64, 160 + (k - first) * 54, 1, { show: k >= first && k < first + 10 });
    } else if (L === 'covers') {
      const row = Math.floor(k / 10), sel = Math.floor(i / 10), first = clamp(sel - 1, 0, Math.max(0, Math.floor((n - 1) / 10) - 2));
      put(c, 64 + (k % 10) * 132, 150 + (row - first) * 168, .58, { show: row >= first && row < first + 3 });
    } else if (L === 'timeline') {
      const d = k - i, ad = Math.abs(d), x = d === 0 ? 595 : d > 0 ? 595 + 250 + 26 + (d - 1) * 136 : 595 - 26 - 124 - (ad - 1) * 136;
      put(c, x, d === 0 ? 300 : 340, d === 0 ? 1.25 : .62, { show: x > -140 && x < 1450 });
    }
  });
  if (L === 'spot') art(64, 160, 360, 424);
  else if (L === 'wall') art(860, 160, 240, 283);
  else if (L === 'cols') art(840, 160, 240, 283);
  else if (L === 'detail') { art(470, 160, 300, 354); detailPanel(g, s); }
  else if (L === 'timeline') timelineAxis(s, i, g);
  else if (L === 'rails') {
    band.classList.remove('hid'); art(88, 170, 140, 165);
    const n1 = railN(s); r1.classList.remove('hid'); r1.textContent = n1 < s.games.length || s.games.some(x => x.stats && x.stats.last) ? 'RECENTLY PLAYED' : 'ALL GAMES';
    if (n1 < s.games.length) { r2.classList.remove('hid'); r2.textContent = 'MORE GAMES'; }
  }
}
function layNav(a) {
  const L = lay(), s = SYS[sys]; if (!s || !FREE.includes(L)) return false;
  const n = s.games.length, i = getSel(), go = j => { j = clamp(j, 0, n - 1); if (j != i) tick(); setSel(j); paint(); }, to = z => { zone = z; tick(); focusPaint(); };
  if (L === 'detail') {
    if (a === 'up') { if (i === 0) to('tabs'); else go(i - 1); return true; }
    if (a === 'down') { go(i + 1); return true; }
    if (a === 'left' || a === 'right') return true;
    return false;
  }
  if (L === 'wall' || L === 'side' || L === 'covers') {
    const C = L === 'wall' ? 6 : L === 'covers' ? 10 : 7;
    if (a === 'up') { if (i < C) to(L === 'side' ? 'top' : 'tabs'); else go(i - C); return true; }
    if (a === 'down') { go(Math.floor(i / C) < Math.floor((n - 1) / C) ? Math.min(n - 1, i + C) : i); return true; }
    if (a === 'left' && L === 'side' && i % C === 0) { to('tabs'); return true; }
    return false;
  }
  if (L === 'cols') {
    if (a === 'up') { if (i === 0) to('top'); else go(i - 1); return true; }
    if (a === 'down') { go(i + 1); return true; }
    if (a === 'left') { to('tabs'); return true; }
    if (a === 'right') return true;
    return false;
  }
  if (L === 'rails') {
    const n1 = railN(s), col = i < n1 ? i : i - n1;
    if (a === 'up') { if (i < n1) to('tabs'); else go(Math.min(n1 - 1, col)); return true; }
    if (a === 'down') { if (i < n1 && n > n1) go(n1 + Math.min(col, n - n1 - 1)); return true; }
  }
  return false;
}

// ----- Dashboard layout: a screen of tiles (continue, systems, unlocks, friends, progress, leaderboard, recent) -----
const DTILES = [['continue', 'Continue playing', 6], ['systems', 'Systems', 6], ['unlocks', 'Recently unlocked', 4], ['friends', 'Friends', 4], ['progress', 'Your progress', 4], ['board', 'Following leaderboard', 4], ['recent', 'Recently played', 12]];
const DDEF = 'continue,systems,unlocks,friends,progress';
let DASH = { f: 'cont', sheet: false, top: null, asked: false };
const dOn = () => new Set(String(cfg.dashTiles == null || cfg.dashTiles === '' ? DDEF : cfg.dashTiles).split(',').filter(Boolean));
function dRows() { const on = dOn(), rows = []; let cur = [], sum = 0; for (const t of DTILES) { if (!on.has(t[0])) continue; if (sum + t[2] > 12) { rows.push(cur); cur = []; sum = 0; } cur.push(t); sum += t[2]; } if (cur.length) rows.push(cur); return rows.slice(0, 3); }
let _agB = null, _ag = [], _lp = null;
const allGames = () => { if (_agB !== BASE) { _agB = BASE; _ag = BASE.flatMap(x => x.games); _lp = null; } return _ag; };
const lastPlayed = () => { const a = allGames(); return _lp || (_lp = a.filter(g => g.stats && g.stats.last).sort((x, y) => y.stats.last - x.stats.last)); };
const dCover = (g, w, h, f) => `<span class="dcv" data-f="${f}" data-file="${esc(g.file)}" style="width:${w}px;height:${h}px;background:${artBg(g)}">${artHTML(g)}</span>`;
function dTile(k, h, span) {
  const cmp = h < 250, name = cfg.raUser || 'Player';
  const head = t => `<div class="dh">${t}</div>`;
  if (k === 'continue') {
    const g = lastPlayed()[0] || allGames()[0];
    if (!g) return `<div class="dp" style="flex:${span}">${head('CONTINUE PLAYING')}<div class="note">No games found yet. Add your ROMs folder in Menu.</div></div>`;
    const pr = RA && RA.progress && RA.progress[norm(g.title)], sn = (BASE.find(b => b.id === g.sys) || {}).name || '', ch = h - 40, cw = Math.round(ch * .85);
    const bar = pr && pr.total ? `<div class="dpr"><u style="width:${Math.round(100 * pr.earned / pr.total)}%"></u></div><div class="rg"><span class="gold">${pr.earned} / ${pr.total}</span> achievements</div>` : '';
    return `<div class="dp dbtn" data-f="cont" data-file="${esc(g.file)}" style="flex:${span};display:flex;gap:24px;align-items:center;cursor:pointer"><span class="dcv" style="width:${cw}px;height:${ch}px;flex:none;background:${artBg(g)}">${artHTML(g)}</span><div style="min-width:0;flex:1"><div class="dh">CONTINUE PLAYING</div><div class="cond dbig" style="font-size:${cmp ? 32 : 40}px">${esc(g.title)}</div><div class="rg" style="margin:4px 0 10px">${esc(sn)}${g.stats && g.stats.plays ? ' · ' + fmtTime(g.stats.secs) + ' played' : ''}</div>${bar}<span class="dgo">A  ▶  ${g.stats && g.stats.last ? 'RESUME' : 'PLAY'}</span></div></div>`;
  }
  if (k === 'systems') {
    return `<div class="dp" style="flex:${span}">${head('SYSTEMS')}<div class="dsys">${BASE.slice(0, 9).map((b, i) => `<div class="dsc" data-f="sys:${b.id}"><b>${esc(b.name)}</b><span>${b.games.length} games</span></div>`).join('') || '<div class="note">No systems found.</div>'}</div></div>`;
  }
  if (k === 'unlocks') {
    const r = RA && !RA.error && RA.recent ? RA.recent.slice(0, cmp ? 2 : 3) : [];
    return `<div class="dp" style="flex:${span}">${head('RECENTLY UNLOCKED')}${r.length ? r.map((x, i) => `<div class="dr dbtn" data-f="ach:${i}"><img class="dbd" src="${esc(x.badge)}" alt=""><span style="flex:1;min-width:0"><b class="rt dcl">${esc(x.title)}</b><span class="rg dcl">${esc(x.game)} · +${x.points}</span></span></div>`).join('') : `<div class="note">${cfg.hasKey ? 'No recent unlocks yet.' : 'Sign in to RetroAchievements to see your unlocks.'}</div>`}</div>`;
  }
  if (k === 'friends') {
    const f = FL && FL.friends ? FL.friends.slice(0, cmp ? 2 : 3) : [];
    return `<div class="dp" style="flex:${span}">${head('FRIENDS')}${f.length ? f.map(x => `<div class="dr dbtn" data-f="fr:${esc(x.user)}">${avt(x.user, 40)}<span style="flex:1;min-width:0"><b class="rt dcl">${esc(x.user)}</b><span class="rg dcl">${esc(presTxt(FSUM[x.user]) || x.points.toLocaleString() + ' points')}</span></span></div>`).join('') : `<div class="note">${!cfg.hasKey ? 'Sign in to RetroAchievements to see your friends.' : !FL ? 'Loading friends…' : FL.error ? esc(FL.error) : 'Follow people on RetroAchievements to see them here.'}</div>`}</div>`;
  }
  if (k === 'progress') {
    const ok = RA && !RA.error && RA.points != null;
    return `<div class="dp dbtn" data-f="prog" style="flex:${span};cursor:pointer">${head('YOUR PROGRESS')}${ok ? `<div class="cond dbig" style="font-size:${cmp ? 40 : 52}px;color:var(--gold)">${RA.points.toLocaleString()}</div><div class="rg" style="margin-bottom:10px">points · ${esc(name)}</div><div class="dstats"><span><b>${RA.unlocked.toLocaleString()}</b>unlocked</span><span><b>${RA.mastered}</b>mastered</span></div>` : `<div class="note">${cfg.hasKey ? 'Loading…' : 'Sign in to RetroAchievements in Menu to see your progress.'}</div>`}</div>`;
  }
  if (k === 'board') {
    const t = DASH.top && DASH.top.players ? DASH.top.players.slice(0, h < 200 ? 2 : h < 250 ? 3 : 4) : [];
    return `<div class="dp" style="flex:${span}">${head('FOLLOWING LEADERBOARD')}${t.length ? t.map(p => `<div class="dr dbtn" data-f="${p.me ? 'prog' : 'fr:' + esc(p.user)}"><span class="cond" style="width:26px;font-size:24px;color:var(--gold)">${p.rank}</span><b class="rt dcl" style="flex:1">${p.me ? 'You' : esc(p.user)}</b><span class="fpts">${p.points.toLocaleString()}</span></div>`).join('') : `<div class="note">${!cfg.hasKey ? 'Sign in to RetroAchievements to see how you rank against people you follow.' : DASH.top && DASH.top.error ? esc(DASH.top.error) : 'Loading…'}</div>`}</div>`;
  }
  if (k === 'recent') {
    const hh = Math.max(80, h - 70), w = Math.round(hh * .85), n = Math.max(1, Math.min(9, Math.floor(1260 / (w + 16)))), l = lastPlayed().slice(0, n);
    return `<div class="dp" style="flex:${span};padding-bottom:12px">${head('RECENTLY PLAYED')}<div style="display:flex;gap:16px">${l.length ? l.map((g, i) => dCover(g, w, hh, 'rg:' + i)).join('') : '<div class="note">Games you play will show up here.</div>'}</div></div>`;
  }
  return '';
}
function drawDash() {
  const el = $('#dash'), rows = dRows(), n = rows.length || 1, h = Math.min(340, Math.floor((596 - 20 * (n - 1)) / n)), hr = new Date().getHours();
  const hello = `Good ${hr < 12 ? 'morning' : hr < 18 ? 'afternoon' : 'evening'}, ${esc(cfg.raUser || 'Player')}`;
  let sheet = '';
  if (DASH.sheet) { const on = dOn(); sheet = `<div class="dsheet"><div class="dscrim"></div><div class="dp dsh"><div class="cond" style="font-size:34px;letter-spacing:.04em;margin-bottom:4px">CHOOSE YOUR TILES</div><div class="rg" style="margin-bottom:12px;font-size:15px">A turns a tile on or off. Up to three rows fit. B closes.</div>${DTILES.map(t => `<div class="dr dbtn" data-f="tg:${t[0]}"><b style="flex:1">${t[1]}</b><span class="dtg${on.has(t[0]) ? ' on' : ''}"></span></div>`).join('')}</div></div>`; }
  el.innerHTML = `<div class="dhello cond">${hello}</div><div class="dgrid">${rows.length ? rows.map(r => `<div style="display:flex;gap:20px;height:${h}px">${r.map(t => dTile(t[0], h, t[2])).join('')}</div>`).join('') : '<div class="dp"><div class="cond" style="font-size:34px">NO TILES SELECTED</div><div class="note">Press X to choose tiles.</div></div>'}</div>${sheet}`;
  wireImgs(el); dashFocus();
}
function dashQ() { return [...document.querySelectorAll(DASH.sheet ? '#dash .dsheet [data-f]' : '#dash .dgrid [data-f]')]; }
function dashFocus() {
  document.querySelectorAll('#dash .fx').forEach(e => e.classList.remove('fx'));
  if (zone !== 'games') return;
  const q = dashQ(); let e = q.find(x => x.dataset.f === DASH.f) || q[0]; if (e) { DASH.f = e.dataset.f; e.classList.add('fx'); }
}
async function dashLoad() {
  if (DASH.asked || !cfg.hasKey) return; DASH.asked = true;
  try { if (!FL) await loadFriends(); } catch {}
  try { DASH.top = await api.raTop(); } catch {}
  if (lay() === 'dash') drawDash();
}
function dashOpen(id) {
  const [k, a] = [id.split(':')[0], id.split(':').slice(1).join(':')], el = document.querySelector(`#dash [data-f="${CSS.escape(id)}"]`);
  if (k === 'cont' || k === 'rg') { const g = allGames().find(x => x.file === el.dataset.file); if (g) launch(g); }
  else if (k === 'sys') { const i = SYS.findIndex(x => x.id === a); if (i >= 0) { sys = i; selBy[SYS[i].id] = 0; openLib(); } }
  else if (k === 'ach') document.querySelector('[data-a="menu-recent"]').click();
  else if (k === 'fr') openFX(a);
  else if (k === 'prog') openPO();
  else if (k === 'tg') { const on = dOn(); on.has(a) ? on.delete(a) : on.add(a); set({ dashTiles: DTILES.map(t => t[0]).filter(x => on.has(x)).join(',') || 'none' }); }
}
function dashAct(a) {
  if (a === 'x') { DASH.sheet = !DASH.sheet; tick(); drawDash(); return true; }
  if (DASH.sheet && (a === 'b')) { DASH.sheet = false; tick(); drawDash(); return true; }
  if (a === 'a') { if (DASH.f) { tick(660); dashOpen(DASH.f); } return true; }
  if (a === 'lb' || a === 'rb' || a === 'y' || a === 'sel' || a === 'jl' || a === 'jr') return true;
  const d = { left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] }[a]; if (!d) return false;
  const q = dashQ(), cur = q.find(e => e.dataset.f === DASH.f); if (!cur) { dashFocus(); return true; }
  const r = cur.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2; let best = null, bs = 1e9;
  for (const e of q) { if (e === cur) continue; const b = e.getBoundingClientRect(), x = b.left + b.width / 2 - cx, y = b.top + b.height / 2 - cy, al = d[0] ? x * d[0] : y * d[1], pe = d[0] ? Math.abs(y) : Math.abs(x); if (al <= 2) continue; const sc = al + pe * 2.2; if (sc < bs) { bs = sc; best = e; } }
  if (best) { DASH.f = best.dataset.f; tick(); dashFocus(); } else if (a === 'up' && !DASH.sheet) { zone = 'top'; tick(); focusPaint(); }
  return true;
}

// ----- update popups (shown when an online check finds a signed newer version, or after an update was applied) -----
let UPD = null;
const lsGet = k => { try { return localStorage.getItem(k); } catch { return null; } }, lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch {} };
function showUpd(kind, d) {
  if (!cfg.updatePopups || mode !== 'home' || UPD) return false;
  if (kind === 'avail' && (lsGet('updSkip') === d.version || Number(lsGet('updLater') || 0) > Date.now())) return false;
  UPD = { kind, d, i: 0 }; drawUpd(); return true;
}
function updBtns() { if (UPD.kind === 'scrapres') return [['a', 'Close', 'ok']]; if (UPD.kind === 'engstat') return [['a', 'Close', 'ok'], ['x', 'Check again', 'again']]; return UPD.kind === 'avail' ? [['a', 'Update now', 'go'], ['b', 'Later', 'later'], ['y', 'Skip this version', 'skip']] : [['a', 'Got it', 'ok']].concat(UPD.d.backupId ? [['x', 'Restore previous version', 'undo']] : []); }
function drawUpd() {
  const el = $('#upop'); if (!UPD) { el.classList.add('hid'); return; }
  const d = UPD.d, av = UPD.kind === 'avail', bt = updBtns();
  if (UPD.kind === 'scrapres') {
    const r = d.res, NM = { gamelist: 'gamelist.xml', launchbox: 'LaunchBox', hasheous: 'Hasheous', libretrodb: 'libretro database' }, f = n => Number(n || 0).toLocaleString();
    const row = (label, got, tot) => `<div style="margin:0 0 14px"><div class="cond" style="font-size:26px">${label}: ${f(got)} / ${f(tot)}</div><div style="height:10px;border-radius:5px;background:rgba(127,127,127,.25);margin-top:6px;overflow:hidden"><div style="height:100%;width:${tot ? Math.round(100 * got / tot) : 100}%;background:#2fbf71"></div></div></div>`;
    const per = Object.entries(r.per || {}).filter(([, n]) => n).map(([k, n]) => `${NM[k] || k} ${f(n)}`).join(' · ');
    el.innerHTML = `<div class="dscrim"></div><div class="dp upc" role="dialog" aria-modal="true"><div class="dh">${r.stopped ? 'SCRAPE STOPPED' : 'SCRAPE COMPLETE'}</div>${r.artTotal !== undefined ? row('Images pulled', r.artGot, r.artTotal) : ''}${r.bgTotal !== undefined ? row('Backgrounds pulled', r.bgGot, r.bgTotal) : ''}${r.detTotal !== undefined ? row('Details pulled', r.detGot, r.detTotal) : ''}${r.all ? `<div class="rg" style="margin:0 0 6px">${f(r.withDesc)} of ${f(r.all)} games now have a description${r.still ? ` · ${f(r.still)} could not be found` : ''}</div>` : ''}${per ? `<div class="rg" style="margin:0 0 6px">By source: ${esc(per)}</div>` : ''}${(r.notes || []).map(n => `<div class="rg" style="margin:0 0 6px;color:#e5484d">${esc(n)}</div>`).join('')}<div class="upb" style="margin-top:14px">${bt.map((b, k) => `<button class="sbtn${k === UPD.i ? ' fx' : ''}" data-up="${b[2]}"><b>${b[0].toUpperCase()}</b> ${b[1]}</button>`).join('')}</div></div>`;
    el.classList.remove('hid'); return;
  }
  if (UPD.kind === 'engstat') {
    const col = { ok: '#2fbf71', slow: '#e0a526', limit: '#e0a526', down: '#e5484d', blocked: '#e5484d', error: '#e5484d' }, lab = { ok: 'WORKING', slow: 'NOT RESPONDING', limit: 'LIMIT HIT', down: 'DOWN', blocked: 'REFUSED', error: 'PROBLEM' };
    el.innerHTML = `<div class="dscrim"></div><div class="dp upc" role="dialog" aria-modal="true"><div class="dh">ENGINE STATUS</div><div class="rg" style="margin:4px 0 12px">${d.busy ? 'Checking every source…' : 'Checked just now. A source that is down is skipped and the next one takes over.'}</div>${(d.rows || []).map(r => `<div style="display:flex;gap:12px;align-items:flex-start;margin:0 0 12px"><span style="flex:none;margin-top:6px;width:14px;height:14px;border-radius:50%;background:${col[r.state] || '#888'}"></span><div style="min-width:0"><div class="cond" style="font-size:22px">${esc(r.name)} · ${lab[r.state] || ''}</div><div class="rg">${esc(r.text)}${r.extra ? ' · ' + esc(r.extra) : ''}</div></div></div>`).join('')}<div class="upb">${bt.map((b, k) => `<button class="sbtn${k === UPD.i ? ' fx' : ''}" data-up="${b[2]}"><b>${b[0].toUpperCase()}</b> ${b[1]}</button>`).join('')}</div></div>`;
    el.classList.remove('hid'); return;
  }
  el.innerHTML = `<div class="dscrim"></div><div class="dp upc" role="dialog" aria-modal="true"><div class="dh">${av ? 'UPDATE AVAILABLE' : 'UPDATED'}</div><div class="cond" style="font-size:40px;letter-spacing:.03em">${av ? `CACTI OS ${esc(d.version)}` : `NOW ON VERSION ${esc(d.version)}`}</div><div class="rg" style="margin:4px 0 14px">${av ? 'A new version is ready.' : 'The update installed successfully.'}</div><div class="lbl">${av ? "WHAT'S NEW" : 'WHAT CHANGED'}</div><ul class="upl">${(d.notes || []).slice(0, 6).map(n => `<li>${esc(n)}</li>`).join('') || '<li>Improvements and fixes.</li>'}</ul><div class="upb">${bt.map((b, k) => `<button class="sbtn${k === UPD.i ? ' fx' : ''}" data-up="${b[2]}"><b>${b[0].toUpperCase()}</b> ${b[1]}</button>`).join('')}</div></div>`;
  el.classList.remove('hid');
}
let AFTERUPD = null; // what to open once the update popup is closed (e.g. System Check when no games are found)
async function engStatus() {
  UPD = { kind: 'engstat', d: { rows: [], busy: true }, i: 0 }; drawUpd();
  let r; try { r = await api.engineStatus(); } catch { r = null; }
  if (!UPD || UPD.kind !== 'engstat') return;
  UPD.d = { rows: r && r.rows || [{ name: 'Status check', state: 'error', text: 'Could not check. Try again' }], busy: false }; drawUpd();
}
async function updDo(w) {
  if (w === 'again') return engStatus();
  const d = UPD.d; UPD = null; drawUpd(); tick(660);
  if (AFTERUPD) { const f = AFTERUPD; AFTERUPD = null; setTimeout(f, 80); }
  if (w === 'later') lsSet('updLater', String(Date.now() + 864e5));
  else if (w === 'skip') lsSet('updSkip', d.version);
  else if (w === 'go' && api.updStart) { toast('UPDATING', 'Downloading and checking the update…'); const r = await api.updStart(); toast(r && r.ok ? 'UPDATED' : 'UPDATE FAILED', r && r.ok ? (r.msg || (r.manual ? 'Start Cacti OS again to use it.' : 'Restarting Cacti OS…')) : (r && r.error) || 'Something went wrong'); }
  else if (w === 'undo') { const r = await api.updRestore(d.backupId); toast('RESTORING', r && r.ok ? 'Restarting Cacti OS…' : (r && r.error) || 'Could not restore'); }
}
function updAct(a) {
  const bt = updBtns();
  if (a === 'left') UPD.i = Math.max(0, UPD.i - 1); else if (a === 'right') UPD.i = Math.min(bt.length - 1, UPD.i + 1);
  else if (a === 'a') return updDo(bt[UPD.i][2]);
  else { const m = bt.find(b => b[0] === a); if (m) return updDo(m[2]); if (a === 'b') return updDo(UPD.kind === 'avail' ? 'later' : 'ok'); }
  drawUpd();
}
async function updStartup() {
  if (!cfg.updatePopups) return;
  try {
    const md = cfg.updMode, due = md === 'startup' || (md === 'weekly' && Date.now() - Number(cfg.updLast || 0) > 6048e5);
    if (due && cfg.updateUrl) api.updCheck(true).then(r => { if (r && r.available) showUpd('avail', { version: r.version, notes: r.notes }); });
  } catch {}
  try {
    const i = await api.updInfo(), last = lsGet('lastVer'); lsSet('lastVer', i.version);
    if (last && last !== i.version) { const ap = (i.applied || []).find(x => x.version === i.version) || {}, bk = (i.backups || []).find(b => b.version === last) || (i.backups || [])[0]; showUpd('done', { version: i.version, notes: ap.notes || [], backupId: bk && bk.id }); }
  } catch {}
}
window.RetroOSUpdate = { available: d => showUpd('avail', d) };
const ACOLL = new Intl.Collator();
function fitName(t) {
  const el = $('#sysname'); el.textContent = t; el.style.whiteSpace = 'nowrap'; el.style.fontSize = '';
  const cw = el.clientWidth, sw = el.scrollWidth; if (cw && sw > cw) el.style.fontSize = Math.max(48, Math.floor(104 * cw / sw)) + 'px';
}
const sysRA = s => { const m = SM.find(x => x.id === s.id); if (m) { const ch = m.cores.find(c => c.id === m.choice); return !!(ch && ch.ra); } return s.ra !== false; };
function rebuildSys() {
  const keepId = SYS[sys] && SYS[sys].id, keepFile = cur() && cur().file, B0 = cfg.raOnly ? BASE.filter(sysRA) : BASE, B = cfg.raGames ? B0.map(s => ({ ...s, games: s.games.filter(g => RCNT[g.sys + ':' + norm(g.title)] !== -1) })).filter(s => s.games.length) : B0, all = B.flatMap(s => s.games), mine = B0.flatMap(s => s.games), cols = []; // Favorites and Last Played keep every game you starred or played, even ones the RA-only filter hides elsewhere
  if (cfg.showFav) { const g = mine.filter(x => favs.has(x.file)); if (g.length) cols.push({ id: 'col-fav', tab: 'FAVORITES', name: 'Favorites', desc: 'Games you starred, from every system.', games: g }); }
  if (cfg.showLast) { const g = mine.filter(x => x.stats && x.stats.last).sort((a, b) => b.stats.last - a.stats.last).slice(0, 30); if (g.length) cols.push({ id: 'col-last', tab: 'LAST PLAYED', name: 'Last Played', desc: 'Your most recent sessions.', games: g, pin: true }); }
  if (cfg.showAll && all.length) cols.push({ id: 'col-all', tab: 'ALL GAMES', name: 'All Games', desc: 'Every game from every system, A to Z.', games: [...all].sort((a, b) => ACOLL.compare(a.title, b.title)) });
  const pins = cols.filter(c => c.pin); SYS = [...pins, ...B, ...cols.filter(c => !c.pin)].map(s => ({ ...s, all: s.games, games: toRow(s.games) }));
  let k = SYS.findIndex(s => s.id === keepId); if (k < 0) { k = SYS.findIndex(s => s.id === 'snes'); if (k < 0) k = 0; }
  sys = k;
  if (keepFile && SYS[sys]) { const j = SYS[sys].games.findIndex(g => g.file === keepFile); if (j >= 0) selBy[SYS[sys].id] = j; }
}
function tabs() {
  const b = (s, i) => `<button class="tab${i == sys ? ' on' : ''}" data-sys="${i}">${esc(s.tab)}</button>`;
  const pin = SYS.map((s, i) => s.pin ? b(s, i) : '').join(''), rest = SYS.map((s, i) => s.pin ? '' : b(s, i)).join('');
  $('#tabs').innerHTML = (pin ? `<div id="tpin">${pin}</div>` : '') + `<div id="tscroll">${rest}</div>` + (SYS.length > 6 ? `<button id="tjump" class="tab" data-a="sysjump" title="Jump to a system (J)" aria-label="Jump to a system">&#9662; ALL</button>` : '');
  const sc = $('#tscroll'), on = sc.querySelector('.tab.on');
  if (on && vtabs()) { const t = on.offsetTop, b = t + on.offsetHeight; if (t < sc.scrollTop) sc.scrollTop = t; else if (b > sc.scrollTop + sc.clientHeight) sc.scrollTop = b - sc.clientHeight; }
  else if (on) { const l = on.offsetLeft, r = l + on.offsetWidth; if (l < sc.scrollLeft + 20) sc.scrollLeft = Math.max(0, l - 20); else { const nx = on.nextElementSibling, r2 = nx ? nx.offsetLeft + Math.min(90, nx.offsetWidth * 0.5) : r; if (r2 > sc.scrollLeft + sc.clientWidth - 20) sc.scrollLeft = r2 - sc.clientWidth + 20; } }
  sc.classList.toggle('scl', !vtabs() && sc.scrollLeft > 2);
}
function artBg(g) { const h = hue(g.title); return g.art ? '#1b2238' : `linear-gradient(170deg,hsl(${h} 60% 55%),hsl(${(h + 45) % 360} 55% 32%))`; }
function artHTML(g) {
  const L = g.title.length, lw = Math.max(...g.title.split(/\s+/).map(w => w.length)), fs = Math.min(L > 26 ? 18 : L > 16 ? 24 : 30, Math.max(12, Math.floor(150 / (lw * 0.64))));
  return g.art ? `<span class="bgb" style="background-image:url('${g.art}')"></span><img class="im" src="${g.art}" alt="" loading="lazy">` : `<span class="orb"></span><span class="ct" style="font-size:${fs}px">${esc(g.title)}</span>`;
}
function buildRow() {
  const s = SYS[sys];
  $('#row').innerHTML = s ? s.games.map((g, i) => {
    if (g.lib) return `<button class="card libc" data-i="${i}" aria-label="Library"><span class="lt">Library</span><svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.800" stroke-linecap="round" aria-hidden="true"><rect x="3.500" y="3.500" width="7" height="7" rx="1.500"/><rect x="13.500" y="3.500" width="7" height="7" rx="1.500"/><rect x="3.500" y="13.500" width="7" height="7" rx="1.500"/><rect x="13.500" y="13.500" width="7" height="7" rx="1.500"/></svg><span class="lt2">LIBRARY</span><span class="ls2">${g.count} GAMES</span><span class="fav hid">★</span></button>`;
    return `<button class="card" data-i="${i}" aria-label="${esc(g.title)}" style="background:${artBg(g)}">${artHTML(g)}<span class="lt">${esc(g.title)}</span><span class="fav hid">★</span></button>`;
  }).join('') : '';
}
const RCNT = {}, RCTRY = new Set(); let rcT = null, RCFAIL = false;
async function loadTotals() {
  const all = BASE.flatMap(s => s.games); if (!all.length || !cfg.hasKey) return;
  for (let o = 0; o < all.length; o += 1500) {
    const part = all.slice(o, o + 1500); let r = null; try { r = await api.raTotals(part.map(g => ({ sys: g.sys, title: g.title }))); } catch {}
    if (!r) return; RCFAIL = r.state === 'failed';
    r.totals.forEach((n, i) => { if (n != null) RCNT[part[i].sys + ':' + norm(part[i].title)] = n; });
    await new Promise(r => setTimeout(r, 30));
  }
  if (cfg.raGames) { rebuildSys(); refresh(); }
  if (LIBV) paintBadges(); else if (mode == 'home') paint();
}
function wantCount(g, ck) {
  if (RCTRY.has(ck)) return; clearTimeout(rcT);
  rcT = setTimeout(async () => {
    RCTRY.add(ck); let r = null; try { r = await api.raCount({ sys: g.sys, title: g.title, gameId: g.gameId }); } catch {}
    if (r && r.total != null) RCNT[ck] = r.total > 0 ? r.total : -1;
    const c = cur(); if (LIBV) { paintBadges(); paintLib(); } else if (c && c.file === g.file) paint();
  }, 600);
}
function gameInfo(g) {
  const pr = RA && RA.progress && RA.progress[norm(g.title)], sn = (BASE.find(b => b.id === g.sys) || {}).name || '', parts = [];
  const ck = g.sys + ':' + norm(g.title), tot = RCNT[ck];
  if (pr) parts.push(`<span class="gold">${pr.earned} of ${pr.total}</span> achievements`);
  else if (!cfg.hasKey) parts.push(`${esc(sn)} · sign in to RetroAchievements to see achievements`);
  else if (tot > 0) parts.push(`<span class="gold">0 of ${tot}</span> achievements`);
  else if (tot === -1) parts.push(`${esc(sn)} · no achievements for this game`);
  else if (tot === 0) { parts.push(`${esc(sn)} · checking achievements…`); wantCount(g, ck); }
  else if (RCFAIL) parts.push(`${esc(sn)}`);
  else parts.push(`${esc(sn)} · checking achievements…`);
  { const m = g.meta; const d = m && [m.year, String(m.genre || '').split(',')[0].trim(), m.dev].filter(Boolean).join(' · '); if (d) parts.push(esc(d)); }
  if (g.stats && g.stats.plays) parts.push(`${g.stats.plays} play${g.stats.plays > 1 ? 's' : ''} · ${fmtTime(g.stats.secs)}`);
  return parts.join(' &nbsp;•&nbsp; ');
}
// Small badge on each library card: only what is already known, never a network call per card.
function cardBadge(g) {
  const pr = RA && RA.progress && RA.progress[norm(g.title)], tot = RCNT[g.sys + ':' + norm(g.title)];
  if (pr) return `<span class="lbadge${pr.total && pr.earned >= pr.total ? ' done' : ''}">${pr.earned}/${pr.total}</span>`;
  if (tot > 0) return `<span class="lbadge">0/${tot}</span>`;
  return '';
}
function paintBadges() { const s = LIBV && LIBV.s; if (!s) return; document.querySelectorAll('.lcard').forEach(c => { const g = s.all[+c.dataset.lg]; if (!g) return; const o = c.querySelector('.lbadge'); if (o) o.remove(); c.insertAdjacentHTML('beforeend', cardBadge(g)); }); }
function paint() { paint0(); place(); }
function paint0() {
  const s = SYS[sys];
  document.querySelectorAll('.tab').forEach((t, k) => t.classList.toggle('on', k == sys));
  if (!s) { $('#sysname').textContent = 'NO GAMES FOUND'; $('#sysdesc').textContent = 'Press S to open the menu. System Check shows what is missing: your ROMs folder, RetroArch and cores.'; $('#gtitle').textContent = ''; $('#ginfo').textContent = ''; return; }
  const g = cur(), i = getSel();
  fitName(s.name.toUpperCase()); $('#sysdesc').textContent = s.desc;
  document.querySelectorAll('.card').forEach((c, k) => { c.classList.toggle('on', k == i); c.querySelector('.fav').classList.toggle('hid', !favs.has(s.games[k].file)); });
  $('#row').style.transform = `translateX(${-i * 224}px)`;
  if (g.lib) { $('#gtitle').textContent = 'LIBRARY'; $('#ginfo').textContent = `${g.count} games · press A to browse everything`; return; }
  $('#gtitle').textContent = g.title + (favs.has(g.file) ? '  ★' : '');
  $('#ginfo').innerHTML = gameInfo(g);
}
// ----- controller focus: games row, system tabs, top bar, and the panels -----
const TOP = () => ['#srch', '#music', '#lobby', '#wifi', '#pads', '#discord', '#trophy', '#avatar', '#gear'].filter(s => !$(s).classList.contains('hid'));
const panelBtns = () => panel ? [...document.querySelectorAll(PN[panel][0] + ' button')].filter(b => b.offsetParent !== null) : [];
function focusPaint() {
  document.querySelectorAll('.fx').forEach(e => e.classList.remove('fx'));
  if (M) return;
  if (panel) { const b = panelBtns()[pIdx]; if (b) { b.classList.add('fx'); b.scrollIntoView({ block: 'nearest' }); } return; }
  if (zone == 'tabs') { const t = document.querySelector('.tab.on'); if (t) t.classList.add('fx'); }
  else if (zone == 'top') $(TOP()[topIdx]).classList.add('fx');
  if (lay() === 'dash') dashFocus();
}
const refresh = () => { theme(); tabs(); buildRow(); paint(); focusPaint(); };
async function reload() { BASE = await api.scan(true); rebuildSys(); refresh(); loadTotals(); }
function move(d) { const s = SYS[sys]; if (!s) return; const n = Math.max(0, Math.min(s.games.length - 1, getSel() + d)); if (n != getSel()) tick(); setSel(n); paint(); }
function jump(d) {
  const s = SYS[sys]; if (!s) return; let i = getSel(); const L = g => (g.lib ? '~' : g.title[0].toUpperCase()), c = L(s.games[i]);
  if (d > 0) { while (i < s.games.length - 1 && L(s.games[i]) === c) i++; }
  else { while (i > 0 && L(s.games[i]) === c) i--; const l = L(s.games[i]); while (i > 0 && L(s.games[i - 1]) === l) i--; }
  tick(); setSel(i); paint(); toast('JUMP', L(s.games[i]), s.games[i].title);
}
function rand() { const s = SYS[sys]; if (!s) return; tick(660); const n = s.games.filter(g => !g.lib).length; setSel(Math.floor(Math.random() * Math.max(1, n))); paint(); }
function toggleFav(g) { favs.has(g.file) ? favs.delete(g.file) : favs.add(g.file); try { localStorage.setItem('favs', JSON.stringify([...favs])); } catch {} const keep = LIBV; rebuildSys(); LIBV = keep; refresh(); if (LIBV) paintLib(); }
function fav() { const g = cur(); if (!g || g.lib) return; toggleFav(g); }
function openSysJump() { // a list of every system, for jumping straight to one
  if (!SYS.length) return;
  openCy({ label: 'Jump to a system', opts: SYS.map((s, i) => [`${s.name || s.tab} · ${(s.all || s.games || []).length} game${(s.all || s.games || []).length == 1 ? '' : 's'}`, () => { sys = i; tick(); refresh(); }, i == sys]) });
}
function setSys(d) { if (!SYS.length) return; tick(); sys = (sys + d + SYS.length) % SYS.length; refresh(); }

// ----- RetroAchievements -----
function renderProf() {
  const el = $('#pbody');
  if (!RA || RA.error) { el.innerHTML = `<div class="note">${esc(RA ? RA.error : 'Loading…')}</div>`; return; }
  el.innerHTML = `<div class="prow"><div class="pav">${cfg.avatar ? avSvg(cfg.avatar, 70) : `<img src="${esc(RA.pic)}" alt="">`}</div><div><div class="cond nm">${esc(RA.user)}</div>
<div class="st"><b>${RA.points.toLocaleString()}</b> POINTS</div><div class="st"><b>${RA.unlocked.toLocaleString()}</b> UNLOCKED</div><div class="st"><b>${RA.mastered}</b> MASTERED</div></div></div>
<div class="lbl">RECENT UNLOCKS</div>` + (RA.recent.length ? RA.recent.slice(0, 3).map(r => `<div class="ru"><img src="${esc(r.badge)}" alt=""><div><div class="rt">${esc(r.title)}</div><div class="rg">${esc(r.game)} · +${r.points}</div></div></div>`).join('') : '<div class="note">No unlocks in the last 30 days</div>');
  const c = Cacti.calc(RA);
  if (c) el.insertAdjacentHTML('beforeend', `<div class="lvrule"></div><div class="lvnext"><div class="lvt"><b class="cond">NEXT LEVEL ${c.level + 1}</b><span>${c.toNext.toLocaleString()} to go</span></div><div class="lvbar2"><i style="width:${c.pct}%"></i></div><div class="lvbrk"><span>${c.ra.toLocaleString()} RA POINTS</span><span>+ ${c.ach.toLocaleString()} × ${Cacti.PER_ACH} ACHIEVEMENTS</span></div></div>`);
  el.querySelectorAll('img').forEach(i => i.addEventListener('error', () => { i.style.visibility = 'hidden'; }));
}
async function refreshRA() {
  RA = await api.ra(); const i = $('#topav');
  if (RA && !RA.error && RA.pic && !cfg.avatar) { i.src = RA.pic; i.style.visibility = 'visible'; } else i.style.visibility = 'hidden';
  renderProf(); applyAv(); paint(); if (M) drawMenu(); applyLevel();
}
// Cacti Level: bubble header, progress bar, and the colored number on the trophy icon
function applyLevel() {
  const c = Cacti.calc(RA), b = $('#lvb'), t = $('#trophy'), n = $('#trn');
  if (!c) { b.classList.add('hid'); $('#lvfill').style.width = '0'; t.classList.remove('lv'); n.classList.add('hid'); return; }
  document.documentElement.style.setProperty('--lvc', c.tier.color);
  b.classList.remove('hid'); b.innerHTML = `CACTI LEVEL ${Cacti.cactus(c.tier, 30)}<b>${c.level}</b>`; b.title = `${c.tier.name} · ${c.points.toLocaleString()} Cacti points`;
  $('#lvfill').style.width = c.pct + '%';
  t.classList.add('lv'); n.textContent = c.level; n.classList.remove('hid'); t.setAttribute('aria-label', `Achievements, Cacti Level ${c.level}`);
}

// ----- panels: profile, Wi-Fi, controllers -----
const PN = { prof: ['#prof', '#avatar'], wifi: ['#wpop', '#wifi'], pads: ['#ppop', '#pads'], lobby: ['#lpop', '#lobby'], music: ['#mpop', '#music'], recent: ['#rpop', '#avatar'], discord: ['#dpop', '#discord'] };
const anchor = n => { const b = n == 'recent' ? '#trophy' : PN[n][1]; return $(b) && !$(b).classList.contains('hid') ? b : '#avatar'; };
function closePanel() { panel = null; Object.values(PN).forEach(([p]) => $(p).classList.add('hid')); document.querySelectorAll('.hb,#avatar').forEach(e => e.classList.remove('on')); pIdx = 0; focusPaint(); }
const mo = new MutationObserver(() => focusPaint());
['#pbody', '#wbody', '#pdbody', '#lbody', '#mbody', '#rbody', '#dbody'].forEach(s => mo.observe($(s), { childList: true }));
async function loadLobby(show) {
  if (show && panel == 'lobby') { LB = null; drawLobby(); }
  LB = await api.lobbies();
  const n = LB && LB.rooms ? LB.rooms.length : 0, b = $('#lbadge'); b.textContent = n > 99 ? '99+' : n; b.classList.toggle('hid', !n);
  if (panel == 'lobby') drawLobby();
}
function drawLobby() {
  const el = $('#lbody');
  if (!LB) { el.innerHTML = '<div class="note">Contacting the RetroArch lobby…</div>'; return; }
  if (LB.error) { el.innerHTML = `<div class="note">${esc(LB.error)}</div><div class="pbtns"><button class="sbtn" data-lr="1">Retry</button></div>`; return; }
  const all = LB.rooms, hide = lbHide(), rooms = all.map((r, i) => ({ r, i })).filter(x => !(hide && x.r.locked)), nLocked = all.filter(r => r.locked).length, mine = rooms.filter(x => x.r.mine && !x.r.locked).length;
  el.innerHTML = `<div class="sub">${rooms.length} active room${rooms.length == 1 ? '' : 's'}${mine ? ` · ${mine} you can join` : ''}${hide && nLocked ? ` · ${nLocked} password-protected hidden` : ''}</div><div class="pbtns"><button class="sbtn" data-lr="1">Refresh</button><button class="sbtn lhb${hide ? ' on' : ''}" data-lh="1" aria-pressed="${hide}" title="${hide ? 'Show' : 'Hide'} password-protected lobbies" aria-label="${hide ? 'Show' : 'Hide'} password-protected lobbies"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>${hide ? '<path d="M3 3l18 18"/>' : ''}</svg></button></div><div class="lrows">` +
    (rooms.length ? rooms.slice(0, 40).map(({ r, i }) => `<button class="lr lb" data-j="${i}"><div style="flex:1;min-width:0"><div class="rt">${esc(r.game)}</div><div class="rg">${esc(r.user)} · ${esc(r.core)}${r.country ? ' · ' + esc(r.country) : ''}</div></div><span class="chip${!window.AndroidBridge && r.mine && !r.locked ? ' go' : ''}">${r.locked ? '🔒 PASSWORD' : window.AndroidBridge ? 'VIEW ONLY' : r.mine ? 'JOIN' : 'NOT IN LIBRARY'}</span></button>`).join('') : '<div class="note">No rooms are open right now.</div>') + '</div>';
}
const lbHide = () => { try { return localStorage.getItem('lbHideLocked') === '1'; } catch { return false; } };
function joinRoom(i) {
  const r = LB && LB.rooms && LB.rooms[i]; if (!r) return;
  if (window.AndroidBridge) { toast('NETPLAY', r.game, 'Joining online rooms is not available in the built-in player yet'); return; }
  if (r.locked) { toast('PASSWORD REQUIRED', r.game, 'This room is password-protected'); return; }
  if (!r.mine) { toast('NOT IN YOUR LIBRARY', r.game, `Add it for ${r.core || 'this emulator'} to join`); return; }
  closePanel(); launch({ title: r.game, file: r.mine.file, sys: r.mine.sys, core: r.mine.core }, { host: r.host, port: r.port });
}
function placeCaret(n) {
  const p = $(PN[n][0]), b = $(anchor(n)), c = p.querySelector('.caret');
  const sc = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--s')) || 1, pr = p.getBoundingClientRect(), br = b.getBoundingClientRect();
  // every top-row popup opens centered directly under its icon (kept inside the screen margins), arrow pointing up at the icon
  const st = $('#stage') ? $('#stage').getBoundingClientRect() : { left: 0 }, w = pr.width / sc, cx = (br.left + br.width / 2 - st.left) / sc;
  const L = Math.round(Math.max(24, Math.min((($('#stage') || {}).offsetWidth || 1440) - 24 - w, cx - w / 2)));
  p.style.right = 'auto'; p.style.left = L + 'px';
  if (c && n != 'music') { c.style.right = 'auto'; c.style.left = Math.round(Math.max(14, Math.min(w - 30, cx - L - 8))) + 'px'; }
}
let RG = null;
async function loadRecent() { RG = await api.raRecent(); if (panel == 'recent') drawRecent(); }
function drawRecent() {
  const el = $('#rbody');
  if (!RG) { el.innerHTML = '<div class="note">Loading your recent games…</div>'; return; }
  if (RG.error) { el.innerHTML = `<div class="note">${esc(RG.error)}</div>`; return; }
  el.innerHTML = RG.games.length ? '<div class="lrows2">' + RG.games.map((g, i) => {
    const pct = g.total ? Math.round(g.earned / g.total * 100) : 0;
    return `<button class="lr lb" data-rg="${i}"><img class="gi" src="${esc(g.icon)}" alt=""><div style="flex:1;min-width:0"><div class="rt">${esc(g.title)}</div><div class="rg">${esc(g.console)} · ${g.total ? `<span class="gold">${g.earned}</span> of ${g.total}` : 'no achievements'}</div>${g.total ? `<div class="mini"><u style="width:${pct}%"></u></div>` : ''}</div><span class="chip go">VIEW</span></button>`;
  }).join('') + '</div>' : '<div class="note">No recently played games on your RetroAchievements account yet.</div>';
  el.querySelectorAll('img').forEach(i => i.addEventListener('error', () => { i.style.visibility = 'hidden'; }));
}
function togglePanel(n) {
  if (panel == n) { closePanel(); return; }
  closePanel(); panel = n; $(PN[n][0]).classList.remove('hid'); $(anchor(n)).classList.add('on'); placeCaret(n);
  if (n == 'recent') { drawRecent(); loadRecent(); }
  if (n == 'discord') { drawFriends(); loadFriends(FNEED); FNEED = false; }
  if (n == 'prof') renderProf(); if (n == 'pads') drawPads(); if (n == 'wifi') { drawWifi(true); loadWifi(); } if (n == 'lobby') { drawLobby(); loadLobby(); } if (n == 'music') { drawMusicPanel(); api.getMusic().then(m => { S.music = m; if (panel == 'music') drawMusicPanel(); }); }
  pIdx = 0; focusPaint();
}
function updWifiIcon() { const b = $('#wifi'), off = !!(W && W.supported !== false && !W.connected); b.style.opacity = off ? .45 : 1; b.classList.toggle('wfoff', off); b.classList.toggle('wfon', !off); }
let wfWatch = null; // looks for Wi-Fi every 10 seconds only until it is connected, then stops
function wifiWatch() { if (wfWatch) return; wfWatch = setInterval(() => { if (document.hidden || mode != 'home') return; api.wifi().then(w => { W = w; updWifiIcon(); if (!w || w.supported === false || w.connected) { clearInterval(wfWatch); wfWatch = null; } }).catch(() => {}); }, 10000); }
async function loadWifi() { W = await api.wifi(); if (panel == 'wifi') drawWifi(false); updWifiIcon(); }
function drawWifi(busy) {
  const el = $('#wbody');
  if (!W) { el.innerHTML = '<div class="note">Checking your network…</div>'; return; }
  if (W.supported === false) { el.innerHTML = '<div class="note">Network details are available on macOS.</div>'; return; }
  const on = W.connected && W.power !== false;
  const title = !W.power ? 'Wi-Fi is off' : W.ssid ? esc(W.ssid) : W.wired && !W.ip ? 'Wired connection' : W.ip ? 'Connected' : 'Not connected';
  const sub = !W.power ? 'Turn Wi-Fi on to connect' : W.ssid ? 'Connected' : W.wired && !W.ip ? 'Using ' + esc(W.wiredIf) : W.ip ? 'macOS is hiding the network name from apps' : 'Not connected to a network';
  const n = W.rssi == null ? 0 : W.rssi >= -50 ? 4 : W.rssi >= -60 ? 3 : W.rssi >= -70 ? 2 : 1;
  const bars = [...'▂▄▆█'].map((c, i) => `<span style="opacity:${i < n ? 1 : .25}">${c}</span>`).join('');
  const rows = [['IP address', W.ip], ['Signal', W.rssi != null ? `${bars} ${W.rssi} dBm` : null], ['Speed', W.rate ? W.rate + ' Mbps' : null], ['Channel', W.channel], ['Security', W.security], ['Also connected by', W.wired && W.ip ? W.wiredIf : null]].filter(r => r[1]);
  el.innerHTML = `<div class="big"><span class="sd${on ? '' : ' off'}"></span>${title}</div><div class="sub">${busy ? 'Refreshing… ' : ''}${sub}</div>` +
    `<div class="pbtns"><button class="sbtn" data-w="refresh">Refresh</button><button class="sbtn" data-w="power">Turn Wi-Fi ${W.power ? 'off' : 'on'}</button><button class="sbtn" data-w="${cfg.linux ? 'nets' : 'open'}">${cfg.linux ? 'Choose network' : 'Wi-Fi settings'}</button></div>` +
    rows.map(r => `<div class="kv"><span>${r[0]}</span><span>${r[0] == 'Signal' ? r[1] : esc(r[1])}</span></div>`).join('');
}
async function wifiAct(k) {
  if (k == 'refresh') { drawWifi(true); await loadWifi(); }
  else if (k == 'power') { drawWifi(true); W = await api.wifiPower(!W.power); drawWifi(false); updWifiIcon(); }
  else if (k == 'open') api.wifiOpen();
  else if (k == 'nets') openWifi();
}
function cardInner(g) {
  const h = hue(g.title), L = g.title.length, lw = Math.max(...g.title.split(/\s+/).map(w => w.length)), fs = Math.min(L > 26 ? 18 : L > 16 ? 24 : 30, Math.max(12, Math.floor(150 / (lw * 0.64))));
  const bg = g.art ? '#1b2238' : `linear-gradient(170deg,hsl(${h} 60% 55%),hsl(${(h + 45) % 360} 55% 32%))`;
  const inner = g.art ? `<span class="bgb" style="background-image:url('${g.art}')"></span><img class="im" src="${g.art}" alt="" loading="lazy">` : `<span class="orb"></span><span class="ct" style="font-size:${fs}px">${esc(g.title)}</span>`;
  return { bg, inner };
}
function openLib() {
  const s = SYS[sys]; if (!s || !s.all || !s.all.length) return;
  const f = cur(), i = f && !f.lib ? s.all.findIndex(g => g.file === f.file) : -1;
  LIBV = { s, idx: Math.max(0, i) }; tick(660); drawLib();
}
const LIB_CH = 150;
const libCards = (s, a, b) => s.all.slice(a, b).map((g, j) => { const c = cardInner(g); return `<button class="lcard" data-lg="${a + j}" aria-label="${esc(g.title)}" style="background:${c.bg}">${c.inner}<span class="fav hid">★</span>${cardBadge(g)}</button>`; }).join('');
function libMore(upto) {
  const el = $('#lgrid'); if (!el || !LIBV) return; const s = LIBV.s, have = el.children.length;
  if (have >= s.all.length || have >= upto) return;
  el.insertAdjacentHTML('beforeend', libCards(s, have, Math.min(s.all.length, Math.max(upto, have + LIB_CH))));
  paintFavs();
}
function paintFavs() { const s = LIBV && LIBV.s; if (!s) return; document.querySelectorAll('.lcard').forEach(c => { const g = s.all[+c.dataset.lg]; c.querySelector('.fav').classList.toggle('hid', !g || !favs.has(g.file)); }); }
function drawLib() {
  const el = $('#lib');
  if (!LIBV) { el.classList.add('hid'); el.innerHTML = ''; return; }
  const s = LIBV.s; el.classList.remove('hid');
  el.innerHTML = `<div class="lh"><div class="cond lt">${esc(s.name.toUpperCase())} LIBRARY</div><div class="lc">${s.all.length} GAMES · A TO Z</div><button class="lback" data-lb="1">B BACK</button></div>
<div id="lgrid">${libCards(s, 0, LIB_CH)}</div>
<div class="ls" id="lsel"></div><div class="lk">← ↑ ↓ → Move · A Play · Y Info · X Achievements · LB / RB Jump letter · B Back</div>`;
  const gr = $('#lgrid'); if (gr) gr.onscroll = () => { if (gr.scrollTop + gr.clientHeight > gr.scrollHeight - 600) libMore(gr.children.length + LIB_CH); };
  paintLib();
}
function paintLib() {
  if (!LIBV) return; const s = LIBV.s, g = s.all[LIBV.idx];
  libMore(LIBV.idx + 60);
  document.querySelectorAll('.lcard').forEach((c, k) => { c.classList.toggle('on', k == LIBV.idx); c.querySelector('.fav').classList.toggle('hid', !favs.has(s.all[k].file)); });
  $('#lsel').innerHTML = g ? `${esc(g.title)}${favs.has(g.file) ? '  ★' : ''}<div class="linfo">${gameInfo(g)}</div>` : '';
  const on = document.querySelector('.lcard.on'); if (on) { on.scrollIntoView({ block: 'nearest' }); const st = $('#stage'); if (st) { st.scrollTop = 0; st.scrollLeft = 0; } }
}
function libAct(a) {
  const s = LIBV.s, n = s.all.length; let i = LIBV.idx;
  if (a == 'b' || a == 'start') { LIBV = null; tick(); drawLib(); return; }
  if (a == 'left') i = Math.max(0, i - 1); else if (a == 'right') i = Math.min(n - 1, i + 1);
  else if (a == 'up') i = Math.max(0, i - 6); else if (a == 'down') i = Math.min(n - 1, i + 6);
  else if (a == 'lb' || a == 'jl' || a == 'rb' || a == 'jr') {
    const L = g => g.title[0].toUpperCase(), c = L(s.all[i]);
    if (a == 'rb' || a == 'jr') { while (i < n - 1 && L(s.all[i]) === c) i++; } else { while (i > 0 && L(s.all[i]) === c) i--; const l = L(s.all[i]); while (i > 0 && L(s.all[i - 1]) === l) i--; }
    toast('JUMP', L(s.all[i]), s.all[i].title);
  }
  else if (a == 'sel') i = Math.floor(Math.random() * n);
  else if (a == 'a') { launch(s.all[i]); return; }
  else if (a == 'y') { showInfo(s.all[i]); return; }
  else if (a == 'x') { showAch(s.all[i]); return; }
  else return;
  if (i != LIBV.idx) tick(); LIBV.idx = i; paintLib();
}

// ----- Emulator Library: standalone emulators (PCSX2, Dolphin, ...) -----
const EST = { none: ['Not installed', 'e0'], installed: ['Installed', 'e1'], uptodate: ['Up to date', 'e1'], update: ['Update available', 'e2'], unsupported: ['Not supported here', 'e3'] };
async function openElib() {
  ELIB = { list: [], idx: 0, msg: 'Checking versions…', prog: {} }; tick(660); drawElib();
  ELIB.list = await api.emuList(); if (ELIB) { ELIB.msg = ''; drawElib(); }
  const l = await api.emuRefresh(false); if (ELIB) { ELIB.list = l; drawElib(); }
}
function drawElib() {
  const el = $('#elib'); const oldG = el.querySelector('#egrid'), oldTop = oldG ? oldG.scrollTop : 0;
  if (!ELIB) { el.classList.add('hid'); el.innerHTML = ''; return; }
  el.classList.remove('hid');
  const cards = ELIB.list.map((e, i) => {
    const st = EST[e.status] || EST.none, pr = ELIB.prog[e.id], busy = !!(pr && pr.msg);
    const sub = busy ? `${pr.msg}${pr.pct != null ? ' ' + pr.pct + '%' : ''}` : (st[0] + (e.version ? ' · ' + e.version : '') + (e.status == 'update' && e.latest ? ' → ' + e.latest : ''));
    const act = busy ? 'Working…' : e.status == 'unsupported' ? '' : e.status == 'none' ? (e.canAuto ? 'A  Install' : 'A  Open download page') : e.status == 'update' ? 'A  Update' : 'A  Reinstall';
    return `<button class="ecard ${st[1]}${i == ELIB.idx ? ' on' : ''}" data-el="${i}"><span class="eic" style="background:linear-gradient(150deg,${e.color},#0b1020)">${esc(e.letter)}</span>
<span class="en">${esc(e.name)}</span><span class="eb">${esc(e.blurb)}</span><span class="es">${esc(sub)}</span>${busy && pr.pct != null ? `<span class="mini"><u style="width:${pr.pct}%"></u></span>` : ''}
<span class="ea">${esc(act)}</span>${e.ra ? '<span class="era">ACHIEVEMENTS</span>' : ''}</button>`;
  }).join('');
  const cur = ELIB.list[ELIB.idx];
  el.innerHTML = `<div class="lh"><div class="cond lt">EMULATOR LIBRARY</div><div class="lc">${ELIB.list.length} STANDALONE EMULATORS</div><button class="lback" data-elb="1">B BACK</button></div>
<div id="egrid">${cards}</div>
<div class="ls" id="esel">${cur ? esc(cur.name + ' · ' + (cur.systems || []).join(', ')) : ''}</div><div class="lk">${esc(ELIB.msg || '← ↑ ↓ → Move · A Install / Update · X Open download page in browser · Y I installed it myself · B Back')}</div>
<div class="lk">Games go in your ROMs folder: ps2, gamecube, wii, psp, dreamcast, nds, 3ds. Large systems like Xbox 360 and PS3 are not included.</div>`;
  const g = el.querySelector('#egrid'), on = g && g.querySelector('.ecard.on');
  if (g) { g.style.scrollBehavior = 'auto'; g.scrollTop = oldTop; if (on) { const t = on.offsetTop - g.offsetTop, b = t + on.offsetHeight; if (t < g.scrollTop) g.scrollTop = t - 4; else if (b > g.scrollTop + g.clientHeight) g.scrollTop = b - g.clientHeight + 4; } }
}
async function elibGo(i) {
  const e = ELIB.list[i]; if (!e || e.status == 'unsupported') { if (e) toast('EMULATOR', e.name, 'Too demanding for this device'); return; }
  if (ELIB.prog[e.id] && ELIB.prog[e.id].msg) return;
  tick(660);
  if (!e.canAuto) { api.emuPage(e.id); ELIB.msg = `Opened the ${e.name} download page. Install it, then press Y to point Cacti OS at it.`; drawElib(); return; }
  ELIB.prog[e.id] = { msg: 'Starting…' }; drawElib();
  const r = await api.emuInstall(e.id);
  if (!ELIB) return; ELIB.prog[e.id] = null;
  ELIB.msg = r && r.ok ? `${e.name} ${r.version} installed.` : (r && r.error) || 'Install failed.';
  if (r && r.ok) toast('EMULATOR', e.name + ' installed', r.version);
  ELIB.list = await api.emuList(); drawElib();
}
async function elibAct(a) {
  const n = ELIB.list.length; let i = ELIB.idx;
  if (a == 'b' || a == 'start') { ELIB = null; tick(); drawElib(); return; }
  if (a == 'left') i = Math.max(0, i - 1); else if (a == 'right') i = Math.min(n - 1, i + 1);
  else if (a == 'up') i = Math.max(0, i - 3); else if (a == 'down') i = Math.min(n - 1, i + 3);
  else if (a == 'a') { elibGo(i); return; }
  else if (a == 'x') { const e = ELIB.list[i]; if (e) { api.emuPage(e.id); ELIB.msg = `Opened the ${e.name} download page in your browser.`; drawElib(); } return; }
  else if (a == 'y') { const e = ELIB.list[i]; if (e && e.status != 'unsupported') { const r = await api.emuBrowse(e.id); if (!ELIB) return; if (r && r.ok) { ELIB.msg = e.name + ' linked.'; ELIB.list = await api.emuList(); } else if (r && r.error) ELIB.msg = r.error; drawElib(); } return; }
  else return;
  if (i != ELIB.idx) tick(); ELIB.idx = i; drawElib();
}
if (api.onScanUpdated) api.onScanUpdated(async () => { try { const q = await api.scanQuick(); if (q && q.length) { BASE = q; rebuildSys(); if (mode != 'game') refresh(); } } catch {} });
api.onEmuProgress(d => { if (FR) { FR.prog[d.id] = d.msg ? d : null; drawFR(); } if (!ELIB) return; ELIB.prog[d.id] = d.msg ? d : null; drawElib(); });

// ----- Option popup: A on a choice row opens a list to pick from (left/right still cycles) -----
let CY = null;
function openCy(it) { CY = { title: it.label, opts: it.opts, i: Math.max(0, it.opts.findIndex(o => o[2])) }; tick(660); drawCy(); }
function drawCy() {
  const el = $('#cypop'); if (!CY) { el.classList.add('hid'); el.innerHTML = ''; return; }
  el.classList.remove('hid');
  el.innerHTML = `<div class="dscrim"></div><div class="dp cyp" role="listbox"><div class="dh">${esc(CY.title.toUpperCase())}</div><div class="cyl">${CY.opts.map((o, k) => `<button class="cyo${k == CY.i ? ' on' : ''}${o[2] ? ' cur' : ''}" data-cy="${k}"><span>${o[2] ? '●' : '○'}</span>${esc(o[0])}</button>`).join('')}</div><div class="lk">↑ ↓ Move · A Choose · B Cancel</div></div>`;
  const on = el.querySelector('.cyo.on'); if (on) on.scrollIntoView({ block: 'nearest' });
}
async function cyAct(a) {
  const n = CY.opts.length;
  if (a == 'b' || a == 'start') { CY = null; tick(); drawCy(); return; }
  if (a == 'up') CY.i = (CY.i + n - 1) % n; else if (a == 'down') CY.i = (CY.i + 1) % n;
  else if (a == 'a') { const o = CY.opts[CY.i]; CY = null; drawCy(); try { tick(660); await o[1](); } catch (e) {} return; }
  else return;
  tick(); drawCy();
}

// ----- Profile pictures: a handful in the menu row, the rest in a full picker -----
const AV_FAV = ['astronaut', 'v_cactus', 'v_fox', 'v_rocket', 'v_panda'];
function avShown() { const ids = AV_FAV.slice(); if (cfg.avatar && !ids.includes(cfg.avatar) && AVATARS.some(x => x.id == cfg.avatar)) ids[ids.length - 1] = cfg.avatar; return ids.map(id => AVATARS.find(x => x.id == id)).filter(Boolean); }
function avFocus(sh) { if (M.pf == null || M.pf > sh.length) { const k = sh.findIndex(x => x.id == cfg.avatar); M.pf = k < 0 ? 0 : k; } return M.pf; }
function avlRows() { const rows = []; for (const g of ['Pixel', 'Illustrated', 'Live']) { const l = AVATARS.filter(a => a.group == g); for (let i = 0; i < l.length; i += 9) rows.push({ g: i ? '' : g, ids: l.slice(i, i + 9).map(a => a.id) }); } return rows; }
function openAvl() { try { document.activeElement.blur(); } catch {} const rows = avlRows(); let r = 0, c = 0; rows.forEach((x, i) => { const j = x.ids.indexOf(cfg.avatar); if (j >= 0) { r = i; c = j; } }); AVL = { rows, r, c }; tick(660); drawAvl(); }
function drawAvl() {
  const el = $('#avl'); if (!AVL) { el.classList.add('hid'); el.innerHTML = ''; return; }
  el.classList.remove('hid');
  const lab = { Pixel: 'PIXEL', Illustrated: 'ILLUSTRATED', Live: 'LIVE · ANIMATED' };
  el.innerHTML = `<div class="lh"><div class="cond lt">PROFILE PICTURE</div><div class="lc">${AVATARS.length} PICTURES</div><button class="lback" data-avlb="1">B BACK</button></div>` +
    AVL.rows.map((row, ri) => (row.g ? `<div class="ag">${lab[row.g]}</div>` : '') + `<div class="arow">${row.ids.map((id, ci) => { const a = AVATARS.find(x => x.id == id); return `<button class="at${cfg.avatar == id ? ' cur' : ''}${ri == AVL.r && ci == AVL.c ? ' on' : ''}" data-avl="${id}">${avSvg(id, 72)}<span>${esc(a.name)}</span></button>`; }).join('')}</div>`).join('') +
    `<div class="lk">← ↑ ↓ → Move · A Use this picture · B Back</div>`;
}
async function avlAct(a) {
  const { rows } = AVL; let { r, c } = AVL;
  if (a == 'b' || a == 'start') { AVL = null; tick(); drawAvl(); if (M) drawMenu(); return; }
  if (a == 'left') c = Math.max(0, c - 1); else if (a == 'right') c = Math.min(rows[r].ids.length - 1, c + 1);
  else if (a == 'up') r = Math.max(0, r - 1); else if (a == 'down') r = Math.min(rows.length - 1, r + 1);
  else if (a == 'a') { const id = rows[r].ids[c]; AVL = null; drawAvl(); await pickAv(0, id); if (M) drawMenu(); return; }
  else return;
  c = Math.min(c, rows[r].ids.length - 1); if (r != AVL.r || c != AVL.c) tick(); AVL.r = r; AVL.c = c; drawAvl();
}

// ----- Game Store: freely released PC ports and recompilations, downloaded from the authors' own GitHub pages -----
let STORE = null;
async function openStore() {
  STORE = { list: [], idx: 0, msg: 'Loading…', prog: {}, rm: '', links: [] }; tick(660); drawStore(); api.storeLinks().then(l => { if (STORE) STORE.links = l; });
  STORE.list = await api.storeList(false); if (STORE) { STORE.msg = ''; drawStore(); }
  const l = await api.storeList(true); if (STORE) { STORE.list = l; drawStore(); }
}
function drawStore() {
  const el = $('#elib');
  if (!STORE) { el.classList.add('hid'); el.innerHTML = ''; return; }
  el.classList.remove('hid');
  const cards = STORE.list.map((e, i) => {
    const pr = STORE.prog[e.id], busy = !!(pr && pr.msg);
    const cls = !e.supported ? 'e3' : e.update ? 'e2' : e.installed ? 'e1' : 'e0';
    const sub = busy ? `${pr.msg}${pr.pct != null ? ' ' + pr.pct + '%' : ''}` : !e.supported ? 'Not available for this device' : e.installed ? (e.update ? `Update ${e.version} → ${e.latest}` : `Installed · ${e.version}`) + (e.rom || !e.romCopy ? '' : ' · needs your ROM') : 'Not installed';
    const act = busy ? 'Working…' : !e.supported ? 'A  Open authors\' page' : !e.installed ? 'A  Install' : e.romCopy && !e.rom ? 'A  Add your ROM' : e.update ? 'A  Play · Y Update' : 'A  Play';
    return `<button class="ecard ${cls}${i == STORE.idx ? ' on' : ''}" data-st="${i}"><span class="eic" style="background:linear-gradient(150deg,#3b8f4f,#0b1020)">${esc(e.name[0])}</span>
<span class="en">${esc(e.name)}</span><span class="eb">${esc(e.game + ' · ' + e.kind)}</span><span class="es">${esc(sub)}</span>${busy && pr.pct != null ? `<span class="mini"><u style="width:${pr.pct}%"></u></span>` : ''}
<span class="ea">${esc(act)}</span></button>`;
  }).join('');
  const more = `<button class="ecard e0${STORE.idx == STORE.list.length ? ' on' : ''}" data-st="${STORE.list.length}"><span class="eic" style="background:linear-gradient(150deg,#5b6cff,#0b1020)">+</span><span class="en">Find more games</span><span class="eb">Community lists of recompiled and fan-made ports</span><span class="es">Opens in your browser</span><span class="ea">A  Choose a list</span></button>`;
  const cur = STORE.list[STORE.idx];
  el.innerHTML = `<div class="lh"><div class="cond lt">GAME STORE</div><div class="lc">${STORE.list.length} FREE PC PORTS + COMMUNITY LISTS</div><button class="lback" data-stb="1">B BACK</button></div>
<div id="egrid">${cards}${more}</div>
<div class="ls" id="esel">${cur ? esc(cur.blurb) : 'Lists kept by the community. Cacti OS is not part of them and does not host any of these games.'}</div><div class="lk">${esc(STORE.msg || (cur ? 'Needs: ' + cur.needs + ' · by ' + cur.author : ''))}</div>
<div class="lk">← ↑ ↓ → Move · A Install / Play · X Add or change ROM · Y Update · SELECT Remove (press twice) · Start Authors' page · B Back. Downloads come straight from each project's own GitHub page. Cacti OS does not host or supply any game files.</div>`;
  const on = el.querySelector('.ecard.on'); if (on) on.scrollIntoView({ block: 'nearest' });
}
async function storeGo(i) {
  if (i == STORE.list.length) { tick(660); openCy({ label: 'Find more games', opts: (STORE.links || []).map((l, k) => [l.name + ' — ' + l.note, () => api.storeOpen(k), false]) }); return; }
  const e = STORE.list[i]; if (!e) return; const pr = STORE.prog[e.id]; if (pr && pr.msg) return; tick(660);
  if (!e.supported) { api.storePage(e.id); STORE.msg = `Opened ${e.name}'s page in your browser.`; drawStore(); return; }
  if (!e.installed) {
    let rom = '';
    if (e.romCopy) { STORE.msg = `Choose your own ${e.romLabel} when the file window opens. It is copied into the game's folder, nowhere else.`; drawStore(); const p = await api.storePick(e.id); if (!STORE) return; if (p && p.file) rom = p.file; else { STORE.msg = (p && p.error) || 'No ROM chosen. You can add it afterwards with X.'; } }
    STORE.prog[e.id] = { msg: 'Starting…' }; drawStore();
    const r = await api.storeInstall(e.id, rom); if (!STORE) return; STORE.prog[e.id] = null;
    STORE.msg = r && r.ok ? `${e.name} ${r.version} installed.${r.needsRom ? ' Press X to add your ROM.' : ''}` : (r && r.error) || 'Install failed.';
    if (r && r.ok) toast('GAME STORE', e.name + ' installed', r.version);
    STORE.list = await api.storeList(false); drawStore(); return;
  }
  if (e.romCopy && !e.rom) { storeRom(e); return; }
  STORE.msg = 'Starting ' + e.name + '…'; drawStore();
  const r = await api.storePlay(e.id); if (!STORE) return;
  if (!r || !r.ok) { STORE.msg = (r && r.error) || 'Could not start.'; drawStore(); } else { STORE = null; drawStore(); }
}
async function storeRom(e) {
  const r = await api.storeRom(e.id); if (!STORE) return;
  STORE.msg = r && r.ok ? 'ROM added.' : r && r.canceled ? '' : (r && r.error) || 'Could not add that file.';
  STORE.list = await api.storeList(false); drawStore();
}
async function storeAct(a) {
  const n = STORE.list.length + 1; let i = STORE.idx, e = STORE.list[i];
  if (a != 'sel') STORE.rm = '';
  if (a == 'b') { STORE = null; tick(); drawStore(); return; }
  if (a == 'start') { if (e) { api.storePage(e.id); STORE.msg = `Opened ${e.name}'s page in your browser.`; drawStore(); } return; }
  if (a == 'left') i = Math.max(0, i - 1); else if (a == 'right') i = Math.min(n - 1, i + 1);
  else if (a == 'up') i = Math.max(0, i - 3); else if (a == 'down') i = Math.min(n - 1, i + 3);
  else if (a == 'a') { storeGo(i); return; }
  else if (a == 'x') { if (e && e.installed && e.romCopy) storeRom(e); return; }
  else if (a == 'y') { if (e && e.installed && e.update) { STORE.prog[e.id] = { msg: 'Starting…' }; drawStore(); const r = await api.storeInstall(e.id, ''); if (!STORE) return; STORE.prog[e.id] = null; STORE.msg = r && r.ok ? 'Updated to ' + r.version + '.' : (r && r.error) || 'Update failed.'; STORE.list = await api.storeList(false); drawStore(); } return; }
  else if (a == 'sel') { if (e && e.installed) { if (STORE.rm == e.id) { STORE.rm = ''; await api.storeRemove(e.id); STORE.msg = e.name + ' removed.'; STORE.list = await api.storeList(false); } else { STORE.rm = e.id; STORE.msg = 'Press SELECT again to remove ' + e.name + '.'; } drawStore(); } return; }
  else return;
  if (i != STORE.idx) tick(); STORE.idx = i; drawStore();
}
if (api.onAchInline) api.onAchInline(d => { // Linux kiosk: the popup is drawn inside this window (a second window would be forced to a corner and steal the controller)
  const f = $('#achf'); if (!f) return;
  if (d.hide) { f.style.display = 'none'; try { f.contentWindow.postMessage({ cactiAchHide: 1 }, '*'); } catch {} return; }
  const w = d.vw; f.style.width = w + 'vw'; f.style.height = (w * .26) + 'vw';
  f.style.left = d.x == 'left' ? '0' : d.x == 'right' ? 'auto' : ((100 - w) / 2) + 'vw'; f.style.right = d.x == 'right' ? '0' : 'auto';
  f.style.top = d.y == 'top' ? '0' : 'auto'; f.style.bottom = d.y == 'bottom' ? '0' : 'auto';
  f.style.display = 'block'; try { f.contentWindow.postMessage({ cactiAch: d.p }, '*'); } catch {}
});
api.onStoreProgress(d => { if (!STORE) return; STORE.prog[d.id] = d.msg ? d : null; drawStore(); });

// ----- Profile Overview: Overview, History, Leaderboards (network only when opened; cached) -----
let PO = null;
const POT = [['ov', 'OVERVIEW'], ['hist', 'HISTORY'], ['lb', 'LEADERBOARDS']];
const fmtH = s => s >= 3600 ? (s / 3600).toFixed(1).replace(/\.0$/, '') + 'h' : Math.max(1, Math.round(s / 60)) + 'm';
async function openPO(tab) {
  PO = { tab: tab || 'ov', view: 'top', top: null, d: null, h: null, err: '', gi: 0, bi: 0, mode: 'global', boards: null, ent: null, busy: '' }; tick(660); drawPO();
  const [d, h] = await Promise.all([api.raOverview(false), api.history()]); if (!PO) return;
  PO.h = h; if (d && d.error) PO.err = d.error; else PO.d = d; drawPO();
  if (PO.tab == 'lb') poLbLoad();
}
function poLbLoad() { if (PO.view == 'top') { if (!PO.top) api.raTop().then(r => { if (PO) { PO.top = r; drawPO(); } }); } else if (PO.d && !PO.boards && !PO.busy) poLoadBoards(); drawPO(); }
async function poLoadBoards() {
  const g = PO.d && PO.d.games[PO.gi]; PO.boards = null; PO.ent = null; PO.bi = 0; if (!g) { drawPO(); return; }
  PO.busy = 'Loading boards…'; drawPO();
  const r = await api.raBoards(g.gameId); if (!PO) return; PO.busy = ''; PO.boards = r; drawPO(); poLoadEntries();
}
async function poLoadEntries() {
  const b = PO.boards && PO.boards.boards && PO.boards.boards[PO.bi]; PO.ent = null; if (!b) { drawPO(); return; }
  drawPO(); const r = await api.raEntries({ id: b.id, mode: PO.mode, rank: b.mine && b.mine.rank }); if (!PO) return; PO.ent = r; drawPO();
}
function drawPO() {
  const el = $('#po');
  if (!PO) { el.classList.add('hid'); el.innerHTML = ''; return; }
  el.classList.remove('hid');
  const tabs = POT.map(([k, n]) => `<button class="potab${PO.tab == k ? ' on' : ''}" data-pot="${k}">${n}</button>`).join('');
  const body = PO.tab == 'ov' ? poOv() : PO.tab == 'hist' ? poHist() : poLb();
  el.innerHTML = `<div class="poh"><div class="cond lt">PROFILE OVERVIEW</div><div class="potabs">${tabs}</div><button class="lback" data-pob="1">B BACK</button></div><div class="pob">${body}</div>
${poAch()}<div class="lk">LB / RB${PO.tab == 'ov' ? ' Switch tab · ← → ↑ ↓ Pick · A Details' : ' or ← → Switch tab'} · ${PO.tab == 'lb' ? (PO.view == 'top' ? 'A Game boards · ' : 'A Following · ↑ ↓ Board · X Game · Y Global / Near me · ') : ''}B Back</div>`;
  el.querySelectorAll('img').forEach(i => i.addEventListener('error', () => { i.style.visibility = 'hidden'; }));
}
function poAch() {
  const u = PO.tab == 'ov' && PO.d && PO.d.unlocks && PO.ap ? PO.d.unlocks[PO.ai] : null; if (!u) return '';
  return `<div class="poaov" data-poax="1"><div class="poapop"><img class="poabig" src="${esc(u.badge)}" alt=""><div class="poat">${esc(u.title)}</div><div class="poad">${esc(u.desc || 'No description.')}</div><div class="poam"><span>${esc(u.game)}</span>${u.console ? `<span>${esc(u.console)}</span>` : ''}<span>${u.points} pts</span><span>${u.hard ? 'Hardcore' : 'Softcore'}</span>${u.when ? `<span>${esc(u.when)}</span>` : ''}</div><button class="lback" data-poax="1">B CLOSE</button></div></div>`;
}
const poNote = t => `<div class="pocard"><div class="note">${esc(t)}</div></div>`;
function poRank(d) { // site ranking pill: where you stand among everyone ranked on RetroAchievements
  const tot = d.ranked || 0, top = tot && d.rank ? Math.max(0.01, Math.round(d.rank / tot * 10000) / 100) : 0;
  if (!d.rank) return `<div class="porpill"><span class="pors"><i>SITE RANKING</i><em>No rank found yet</em></span></div>`;
  return `<div class="porpill"><b>#${d.rank.toLocaleString()}</b><span class="pors"><i>SITE RANKING${d.rkind === 'casual' ? ' · CASUAL' : ''}</i>${tot ? `<em>of ${tot.toLocaleString()} players</em>` : ''}</span>${tot ? `<span class="porc">TOP ${top < 1 ? top.toFixed(2) : top < 10 ? top.toFixed(1) : Math.round(top)}%</span>` : ''}</div>`;
}
function poOv() {
  const d = PO.d; if (PO.err) return poNote(PO.err); if (!d) return poNote('Loading your profile…');
  const pct = d.totalAch ? Math.round(100 * d.unlocked / d.totalAch) : 0, mx = Math.max(1, ...d.weeks.map(w => w.h));
  const tile = (n, l) => `<div class="potile"><b>${n}</b><span>${l}</span></div>`;
  return `<div class="pocol" style="width:350px"><div class="pocard"><div class="pohd"><div class="poav">${cfg.avatar ? avSvg(cfg.avatar, 64) : (RA && RA.pic ? `<img src="${esc(RA.pic)}" alt="">` : esc(d.user.slice(0, 2).toUpperCase()))}</div><div><div class="cond ponm">${esc(d.user)}</div><div class="pogold">${d.hardcore ? 'HARDCORE' : 'SOFTCORE'}${d.rank ? ' · RANK #' + d.rank.toLocaleString() : ''}</div></div></div>
<div class="popts"><b>${(d.hardcore ? d.points : (d.softPoints || 0)).toLocaleString()}</b> ${d.hardcore ? 'HARDCORE' : 'SOFTCORE'} POINTS</div><div class="polab"><span>ACHIEVEMENTS UNLOCKED</span><span>${d.unlocked.toLocaleString()} of ${d.totalAch.toLocaleString()}</span></div><div class="pobar"><u style="width:${pct}%"></u></div></div>
${poRank(d)}<div class="potiles">${tile(d.played, 'GAMES STARTED')}${tile(d.mastered, 'MASTERED')}${tile(d.beaten, 'BEATEN')}${tile(d.hours + 'h', 'PLAY TIME')}</div>
<div class="pocard pofoot"><b>Mastered</b> = every achievement earned. <b>Beaten</b> = the story achievements.</div></div>
<div class="pocol" style="flex:1"><div class="pocard"><div class="polbl">COMPLETION BY CONSOLE</div>${d.consoles.length ? d.consoles.map(c => `<div class="porow"><span class="pocn">${esc(c.name)}</span><span class="pobar"><u style="width:${c.pct}%"></u></span><span class="pocs">${c.games} games · ${c.pct}%</span></div>`).join('') : '<div class="note">Nothing started yet.</div>'}</div>
<div class="pocard" style="flex:1"><div class="pohd2"><div class="polbl">ACHIEVEMENTS UNLOCKED</div><div class="pocs">${d.unlocked.toLocaleString()} total</div></div>
${(d.unlocks || []).length ? `<div class="poag">${d.unlocks.map((u, i) => `<button class="poab${PO.ai == i ? ' sel' : ''}${u.hard ? ' hc' : ''}" data-poa="${i}" title="${esc(u.title)}"><img src="${esc(u.badge)}" alt=""></button>`).join('')}</div><div class="note" style="margin-top:8px">Your latest unlocks. Click one for what it is.</div>` : '<div class="note">Nothing unlocked in the past year yet, or the list is still loading.</div>'}</div></div>
<div class="pocol" style="width:380px"><div class="pocard"><div class="pohd2"><div class="polbl">MASTERED</div><div class="pogold">${d.mastered} GAMES</div></div>
${d.medals.length ? `<div class="pomed">${d.medals.map(m => `<div class="pomd"><span class="pomr"><img src="${esc(m.icon)}" alt=""></span><span>${esc(m.title)}</span></div>`).join('')}</div>` : '<div class="note">No mastered games yet. Your first is the best one.</div>'}</div>
<div class="pocard" style="flex:1"><div class="polbl">RECENT ACTIVITY</div>${d.recent.length ? d.recent.map(r => `<div class="pora"><i class="${r.kind == 'mastered' ? 'g' : ''}"></i><div><div class="rt">${esc(r.title)}</div><div class="rg">${esc(r.sub)}</div></div><span class="pocs">${esc(r.when)}</span></div>`).join('') : '<div class="note">No activity yet.</div>'}</div></div>`;
}
function poHist() {
  const h = PO.h; if (!h) return poNote('Loading…');
  const when = t => { const d = new Date(t), n = new Date(), y = new Date(Date.now() - 864e5), tm = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); return (d.toDateString() == n.toDateString() ? 'Today' : d.toDateString() == y.toDateString() ? 'Yesterday' : d.toLocaleDateString([], { month: 'short', day: 'numeric' })) + ' · ' + tm; };
  const tile = (n, l) => `<div class="potile"><b>${n}</b><span>${l}</span></div>`;
  return `<div class="pocol" style="width:350px"><div class="potiles">${tile(fmtH(h.weekSecs || 0), 'THIS WEEK')}${tile(fmtH(h.totalSecs || 0), 'ALL TIME')}${tile(h.totalPlays, 'SESSIONS')}${tile(h.top.length, 'GAMES PLAYED')}</div>
<div class="pocard" style="flex:1"><div class="polbl">MOST PLAYED</div>${h.top.length ? h.top.map((g, i) => `<div class="pora"><i class="n">${i + 1}</i><div style="min-width:0"><div class="rt">${esc(g.title)}</div><div class="rg">${g.plays} session${g.plays == 1 ? '' : 's'}</div></div><span class="pocs">${fmtH(g.secs)}</span></div>`).join('') : '<div class="note">Play a game for ten seconds or more and it shows up here.</div>'}</div></div>
<div class="pocol" style="flex:1"><div class="pocard" style="flex:1;overflow:auto"><div class="polbl">RECENT SESSIONS</div>${h.sessions.length ? h.sessions.map(s => `<div class="pora"><i class="g"></i><div style="min-width:0;flex:1"><div class="rt">${esc(s.title)}</div><div class="rg">${esc(s.sys ? s.sys + ' · ' : '')}${esc(when(s.t))}</div></div><span class="pocs">${fmtH(s.secs)}</span></div>`).join('') : '<div class="note">Sessions are logged from this version on. Nothing played yet.</div>'}</div></div>`;
}
function poTop() {
  const T = PO.top, d = PO.d, chips = [['top', 'FOLLOWING'], ['game', 'GAME BOARDS']].map(([k, n]) => `<button class="pochip${PO.view == k ? ' on' : ''}" data-pov="${k}">${n}</button>`).join('');
  const rows = T && T.players ? T.players.map(p => `<${p.me ? 'div' : 'button data-fo="' + esc(p.user) + '"'} class="pole${p.me ? ' me' : ''}"><span class="por">${p.rank}</span><span class="pou">${esc(p.user)}${p.me ? ' (you)' : ''}${p.back ? ' <small title="Follows you back">⇄</small>' : ''}</span><span class="pos">${p.points.toLocaleString()}</span><span class="pos">${p.soft.toLocaleString()}</span></${p.me ? 'div' : 'button'}>`).join('') : '';
  const mine = T && T.players && T.players.find(p => p.me), n = T && T.following || 0;
  return `<div class="pocol" style="flex:1"><div class="pocard" style="flex:1"><div class="pohd2"><div><div class="ponm2">People you follow</div><div class="polbl">RANKED BY HARDCORE POINTS · SELECT A PERSON TO SEE THEIR ACHIEVEMENTS</div></div><div class="pochips">${chips}</div></div>
${!T ? '<div class="note">Loading…</div>' : T.error ? `<div class="note">${esc(T.error)}</div>` : `<div class="pole hd"><span class="por">RANK</span><span class="pou">PLAYER</span><span class="pos">HARDCORE</span><span class="pos">SOFTCORE</span></div>${n ? rows : '<div class="note">You are not following anyone yet. Open a player\'s profile on retroachievements.org and press Follow. They will appear here within 30 minutes.</div>' + rows}`}
<div class="pofootr">${mine ? `<b>#${mine.rank}</b><span>You, of ${n + 1} (you and ${n} ${n == 1 ? 'person' : 'people'} you follow) · ${mine.points.toLocaleString()} hardcore points</span>` : `<span>${d ? d.points.toLocaleString() + ' points' : ''}</span>`}</div></div></div>`;
}
function poLb() {
  if (PO.err) return poNote(PO.err); const d = PO.d; if (!d) return poNote('Loading…');
  if (PO.view == 'top') return poTop();
  if (!d.games.length) return poNote('Play a game with RetroAchievements first, then its leaderboards show up here.');
  const g = d.games[PO.gi], B = PO.boards, bs = B && B.boards || [], b = bs[PO.bi];
  const left = `<div class="pocol" style="width:380px"><div class="pocard"><button class="pogame" data-pog="1">${g.icon ? `<img src="${esc(g.icon)}" alt="">` : ''}<span><b>${esc(g.title)}</b><i>${esc(g.console)} · X changes game (${PO.gi + 1} of ${d.games.length})</i></span></button></div>
<div class="pocard" style="flex:1;overflow:auto"><div class="polbl">BOARDS</div>${PO.busy ? `<div class="note">${PO.busy}</div>` : B && B.error ? `<div class="note">${esc(B.error)}</div>` : bs.length ? bs.map((x, i) => `<button class="pobd${i == PO.bi ? ' on' : ''}" data-pobd="${i}"><span><b>${esc(x.name)}</b><i>${x.lowWins ? 'Lowest wins' : 'Highest wins'}</i></span><em>${x.mine ? '#' + x.mine.rank : '—'}</em></button>`).join('') : '<div class="note">This game has no leaderboards.</div>'}</div></div>`;
  let right = '<div class="pocard" style="flex:1"><div class="note">Pick a board.</div></div>';
  if (b) {
    const E = PO.ent, rows = E && E.entries ? E.entries.map(e => `<div class="pole${e.me ? ' me' : ''}"><span class="por">${e.rank}</span><span class="pou">${esc(e.user)}</span><span class="pos">${esc(e.score)}</span><span class="pod">${esc(e.date)}</span></div>`).join('') : '';
    const sb = [['top', 'FOLLOWING'], ['game', 'GAME BOARDS']].map(([k, n]) => `<button class="pochip${PO.view == k ? ' on' : ''}" data-pov="${k}">${n}</button>`).join('') + [['global', 'GLOBAL'], ['near', 'NEAR ME']].map(([k, n]) => `<button class="pochip${PO.mode == k ? ' on' : ''}" data-pom="${k}">${n}</button>`).join('');
    right = `<div class="pocard" style="flex:1"><div class="pohd2"><div><div class="ponm2">${esc(b.name)}</div><div class="polbl">${esc(b.desc || (b.lowWins ? 'LOWEST WINS' : 'HIGHEST WINS'))}</div></div><div class="pochips">${sb}</div></div>
${!E ? '<div class="note">Loading…</div>' : E.error ? `<div class="note">${esc(E.error)}</div>` : `<div class="pole hd"><span class="por">RANK</span><span class="pou">PLAYER</span><span class="pos">SCORE</span><span class="pod">DATE</span></div>${rows || '<div class="note">No entries.</div>'}`}
${PO.mode == 'near' && !(b.mine && b.mine.rank) ? '<div class="note">You have no entry on this board yet, so Near me shows the top.</div>' : ''}
<div class="pofootr">${b.mine ? `<b>#${b.mine.rank}</b><span>Your best ${esc(b.mine.score)}${E && E.total ? ' · of ' + E.total.toLocaleString() + ' players' : ''}</span>` : '<span>You have no entry on this board yet.</span>'}</div></div>`;
  }
  return left + `<div class="pocol" style="flex:1">${right}</div>`;
}
function poAct(a) {
  const ti = POT.findIndex(t => t[0] == PO.tab);
  if (PO.ap) { if (a == 'b' || a == 'a' || a == 'start') { PO.ap = false; tick(); drawPO(); } return; }
  if (a == 'b' || a == 'start') { PO = null; tick(); drawPO(); return; }
  if (PO.tab == 'ov' && PO.d && PO.d.unlocks && PO.d.unlocks.length && ['left', 'right', 'up', 'down', 'a'].includes(a)) {
    const n = PO.d.unlocks.length, per = 9; PO.ai = PO.ai || 0;
    if (a == 'a') PO.ap = true; else PO.ai = Math.max(0, Math.min(n - 1, PO.ai + (a == 'left' ? -1 : a == 'right' ? 1 : a == 'up' ? -per : per)));
    tick(); drawPO(); return;
  }
  const go = k => { PO.tab = POT[(ti + k + POT.length) % POT.length][0]; tick(); drawPO(); if (PO.tab == 'lb' && PO.d) poLbLoad(); };
  if (a == 'lb') { go(-1); return; } if (a == 'rb') { go(1); return; }
  if (PO.tab == 'lb' && a == 'a') { PO.view = PO.view == 'top' ? 'game' : 'top'; tick(); poLbLoad(); return; }
  if (PO.tab != 'lb') { if (a == 'left') go(-1); else if (a == 'right') go(1); return; }
  if (PO.view == 'top') { if (a == 'left') go(-1); else if (a == 'right') go(1); return; }
  const bs = PO.boards && PO.boards.boards || [];
  if (a == 'left') go(-1); else if (a == 'right') go(1);
  else if (a == 'down' && PO.bi < bs.length - 1) { PO.bi++; tick(); poLoadEntries(); }
  else if (a == 'up' && PO.bi > 0) { PO.bi--; tick(); poLoadEntries(); }
  else if (a == 'x' && PO.d && PO.d.games.length) { PO.gi = (PO.gi + 1) % PO.d.games.length; tick(); poLoadBoards(); }
  else if (a == 'y' || a == 'a') { PO.mode = PO.mode == 'global' ? 'near' : 'global'; tick(); poLoadEntries(); }
}
const MI = {
  prev: '<rect x="4.5" y="5" width="2.8" height="14" rx="1.2" fill="currentColor"/><path d="M19.5 5.2v13.6L9 12z" fill="currentColor"/>', next: '<rect x="16.7" y="5" width="2.8" height="14" rx="1.2" fill="currentColor"/><path d="M4.5 5.2v13.6L15 12z" fill="currentColor"/>',
  play: '<path d="M7 4.5v15l13-7.5z" fill="currentColor"/>', pause: '<path d="M7 4h3.5v16H7zM13.5 4H17v16h-3.5z" fill="currentColor"/>',
  shuffle: '<path d="M3 6h3.5c5 0 6 12 11 12H21M3 18h3.5c1.8 0 3-1.5 4-3.2M13.5 8.8C14.5 7.2 15.7 6 17.5 6H21M18.5 3L21.5 6l-3 3M18.5 15l3 3-3 3" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
  vol: '<path d="M4 9.5v5h4l5 4v-13l-5 4zM16.5 9a4 4 0 010 6M18.8 6.5a7.5 7.5 0 010 11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
  mute: '<path d="M4 9.5v5h4l5 4v-13l-5 4zM16.5 9.5l5 5M21.5 9.5l-5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
  down: '<path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>', up: '<path d="M6 15l6-6 6 6" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>',
  minus: '<path d="M6 12h12" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>', plus: '<path d="M6 12h12M12 6v12" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>',
  note: '<path d="M9 18V5l11-2v13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="6" cy="18" r="3" fill="currentColor"/><circle cx="17" cy="16" r="3" fill="currentColor"/>'
};
const mi = (n, sz = 20) => `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" aria-hidden="true">${MI[n]}</svg>`;
let musExp = false; try { musExp = localStorage.getItem('musExp') === '1'; } catch {}
const mmss = t => { t = Math.max(0, Math.floor(t || 0)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };
function drawMusicPanel() {
  const m = S.music, el = $('#mbody'), has = m.total > 0, pct = m.dur ? Math.min(100, Math.round(100 * m.pos / m.dur)) : 0, ttl = has ? (m.title || 'Press play') : 'No music folder set';
  const sub = has ? `${m.idx >= 0 ? (m.folder ? esc(m.folder) + ' · ' : '') : ''}${m.total} songs${m.shuffle ? ' · shuffle' : ''}` : 'Choose a folder with your songs';
  const chev = `<button class="mx" data-m="expand" aria-label="${musExp ? 'Collapse player' : 'Expand player'}">${mi(musExp ? 'up' : 'down', 18)}</button>`;
  const art = `<span class="mart${m.playing ? ' on' : ''}${m.art ? ' pic' : ''}"${m.art ? ` style="background-image:url('${m.art}')"` : ''}>${m.art ? '' : mi('note', 24)}</span>`;
  const tr = (cls = '') => `<div class="mtr ${cls}"><button class="mub${m.shuffle ? ' on' : ''}" data-m="shuffle" aria-label="Shuffle">${mi('shuffle')}</button><button class="mub" data-m="prev" aria-label="Previous">${mi('prev')}</button><button class="mub big" data-m="toggle" aria-label="Play or pause">${mi(m.playing ? 'pause' : 'play', 24)}</button><button class="mub" data-m="next" aria-label="Next">${mi('next')}</button><button class="mub${m.mute ? ' on' : ''}" data-m="mute" aria-label="Mute">${mi(m.mute ? 'mute' : 'vol')}</button></div>`;
  if (!musExp) {
    el.innerHTML = `<div class="mcmp">${art}<span class="mmeta"><b class="rt dcl">${esc(ttl)}</b><span class="rg dcl">${sub}</span></span>${chev}</div><div class="mbar" data-mbar="seek"><u style="width:${pct}%"></u></div><div class="mtr cmp"><button class="mub" data-m="prev" aria-label="Previous">${mi('prev')}</button><button class="mub big" data-m="toggle" aria-label="Play or pause">${mi(m.playing ? 'pause' : 'play', 24)}</button><button class="mub" data-m="next" aria-label="Next">${mi('next')}</button></div>`;
    return;
  }
  el.innerHTML = `<div class="mfull"><span class="mart lg${m.playing ? ' on' : ''}${m.art ? ' pic' : ''}"${m.art ? ` style="background-image:url('${m.art}')"` : ''}>${m.art ? '' : mi('note', 40)}</span><span class="mmeta" style="flex:1"><b class="rt dcl" style="font-size:19px">${esc(ttl)}</b><span class="rg dcl">${sub}</span></span>${chev}</div>
<div class="mbar" data-mbar="seek"><u style="width:${pct}%"></u></div><div class="mtime"><span>${mmss(m.pos)}</span><span>${m.dur ? mmss(m.dur) : '--:--'}</span></div>
<div class="mtr"><button class="mub" data-m="back" aria-label="Back 10 seconds">−10s</button>${tr().replace(/^<div class="mtr ">|<\/div>$/g, '')}<button class="mub" data-m="fwd" aria-label="Forward 10 seconds">+10s</button></div>
<div class="mvol"><button class="mub" data-m="voldown" aria-label="Volume down">${mi('minus')}</button><div class="mbar" data-mbar="vol" style="flex:1"><u style="width:${m.vol}%"></u></div><button class="mub" data-m="volup" aria-label="Volume up">${mi('plus')}</button><span class="rg" style="width:36px;text-align:right">${m.vol}%</span></div>
<div class="lbl" style="margin-top:12px">UP NEXT</div>${m.next && m.next.length ? m.next.map((t, i) => `<button class="row mq" data-m="play:${i + 1}"><span class="rg" style="width:18px">${i + 1}</span><span class="rt dcl" style="flex:1">${esc(t)}</span></button>`).join('') : '<div class="note">Nothing queued.</div>'}
<div class="mfold"><span class="rg dcl" style="flex:1">${esc((cfg.musicDir || 'No folder chosen').split(/[\\/]/).filter(Boolean).pop() || cfg.musicDir || 'No folder chosen')}</span><button class="sbtn" data-m="folder">Change</button></div>
<div class="mhint rg">During a game: Start + D-pad Down opens this player. D-pad ◀ ▶ skips, ▲ ▼ volume, A play or pause, B closes.</div>`;
}
async function musicAct(k) {
  tick(660);
  if (k == 'folder') { const p = await api.pick('folder'); if (p) { await set({ musicDir: p }); toast('MUSIC', 'Folder set', p.split(/[\\/]/).pop()); } }
  else if (k == 'expand') { musExp = !musExp; try { localStorage.setItem('musExp', musExp ? '1' : '0'); } catch {} drawMusicPanel(); }
  else if (k == 'back') api.music('skip:-10'); else if (k == 'fwd') api.music('skip:10');
  else api.music(k);
}
function drawPads() {
  const p = pads();
  $('#pdbody').innerHTML = (p.length ? p.map(g => `<div class="pd"><div class="pn">${g.index + 1}</div><div><div class="rt">${esc(cleanPad(g.id))}</div><div class="rg">Player ${g.index + 1} · ${g.buttons.length} buttons · ${g.axes.length} axes${g.mapping == 'standard' ? ' · standard layout' : ''}</div></div></div>`).join('')
    : '<div class="note">No controllers detected. Connect one, then press any button to wake it up.</div>') + `<div class="kv"><span>Last input</span><span>${esc(lastBtn || '—')}</span></div><button class="wfr" style="font-size:15px;margin-top:8px;width:100%" data-ctmenu="1">Manage controllers…</button>`;
}

// ----- EmulationStation-style menu -----
const ACHS = [['retroarch', 'RetroArch built-in'], ['pill', 'Pill'], ['banner', 'Drop banner'], ['pixel', 'Pixel'], ['neon', 'Neon burst'], ['medal', 'Medal reveal'], ['off', 'Off']];
const achPick = id => set({ achStyle: id }).then(() => { if (['retroarch', 'off'].includes(id)) api.achStop(); else api.achPreview(id); });
const L = (label, go) => ({ t: 'lnk', label, go }), A = (label, fn) => ({ t: 'act', label, fn }), I = (label, val) => ({ t: 'inf', label, val });
const DC = { S, A: (l, f) => A(l, f), I: (l, v) => I(l, v), api, redraw: () => drawMenu(), open: () => !!M && M.stack[M.stack.length - 1] == 'drives', setIdx: n => { if (M && n >= 0) M.idx = n; }, first: () => firstNav('drives') };
const IC = { S, A: (l, f) => A(l, f), I: (l, v) => I(l, v), T: (l, v, s) => T(l, v, s), api, redraw: () => drawMenu(), open: () => !!M && M.stack[M.stack.length - 1] == 'install', setIdx: n => { if (M && n >= 0) M.idx = n; }, first: () => firstNav('install') };
const T = (label, val, set) => ({ t: 'tog', label, val, set }), SL = (label, val, min, max, step, set) => ({ t: 'sli', label, val, min, max, step, set }), X = (label, key, pwd) => ({ t: 'txt', label, key, pwd });
async function set(p) {
  let st = 'cfg'; try { cfg = await api.setConfig(p); if (cfg.saveError) toast('SETTINGS NOT SAVED', String(cfg.saveError).slice(0, 200), String(cfg.cfgPath || '').slice(-120)); st = 'prompts'; applyPrompts(); st = 'sizes'; applySizes(); st = 'theme'; theme(); st = 'sys'; rebuildSys(); st = 'refresh'; refresh(); st = 'menu'; drawMenu(); }
  catch (e) { try { toast('SETTING ERROR', st + ': ' + String(e && e.message || e).slice(0, 200), String((e && e.stack || '').split('\n')[1] || '').trim().slice(-70)); } catch {} try { drawMenu(); } catch {} }
}
async function loadCheck() { S.check = await api.check(); drawMenu(); api.usage().then(u => { S.usage = u; if (M && M.stack[M.stack.length - 1] == 'check') drawMenu(); }).catch(() => {}); }
async function installCores() { S.busy = 'Downloading cores…'; drawMenu(); const r = await api.installCores(); S.busy = r.fail.length ? `Installed ${r.ok}. Problem: ${r.fail[0]}` : (r.ok ? `Installed ${r.ok} core${r.ok == 1 ? '' : 's'}` : 'All cores are already installed'); await loadCheck(); }
async function installRA() { S.busy = 'Installing RetroArch… this can take a few minutes'; drawMenu(); const r = await api.installRetroArch(); S.busy = r.error || (r.opened ? 'Opened the download page. Install RetroArch, then Re-check' : 'RetroArch installed'); await loadCheck(); }
function cycleCore(s, ch) { const n = s.cores[(s.cores.indexOf(ch) + 1) % s.cores.length]; set({ cores: { [s.id]: n.id } }).then(() => toast('EMULATOR', `${s.name}: ${n.name}`, n.ra ? 'Achievements supported · install it in System Check' : 'NO achievements support with this one')); }
function doScrapeBg(id) { S.scrape = { run: true, done: 0, total: 0, found: 0 }; S.msg = ''; drawMenu(); api.scrapeBg(id); }
function doScrape(id) { S.scrape = { run: true, done: 0, total: 0, found: 0 }; S.msg = ''; drawMenu(); api.scrape(id); }
async function pickRoms() { const p = await api.pick('folder'); if (p) { await set({ romRoot: p }); await reload(); } }
async function pickRA() { let p = await api.pick('file'); if (p) { if (p.endsWith('.app')) p += '/Contents/MacOS/RetroArch'; await set({ retroarch: p }); } }
const QC = [['0', 'Off'], ['2', 'L3 + R3 (press both sticks)'], ['3', 'L1 + R1 + Start + Select'], ['1', 'Down + Y + L1 + R1']];
const ENG = [
  { id: 'libretro', name: 'libretro thumbnails', acct: false, ready: true, gives: 'Box art, titles, screenshots' },
  { id: 'libretrodb', name: 'libretro database', acct: false, ready: true, gives: 'Year, developer, genre, players' },
  { id: 'launchbox', name: 'LaunchBox Games Database', acct: false, ready: true, gives: 'Descriptions, genre, year, developer, players, rating. One download, then works offline' },
  { id: 'hasheous', name: 'Hasheous', acct: false, ready: true, gives: 'Matches by file: year, genre, developer, description' },
  { id: 'gamelist', name: 'Import gamelist.xml files', acct: false, ready: true, gives: 'Everything EmulationStation and Batocera saved' },
  { id: 'screenscraper', name: 'ScreenScraper', acct: false, ready: true, gives: 'Matches by file checksum, then by name: description, year, genre, developer, players, rating' }
];
const engOn = e => { const v = (cfg.scrapeEngines || {})[e.id]; return typeof v === 'boolean' ? v : ['libretro', 'libretrodb', 'launchbox', 'hasheous', 'gamelist', 'screenscraper'].includes(e.id) || false; }; // free engines start on; the ones that need keys start off
const engSet = (id, v) => set({ scrapeEngines: { ...(cfg.scrapeEngines || {}), [id]: v } });
// Menu rows that only explain a button or feature are not shown; rows that report a status or a value stay.
const DESC_ROWS = new Set(['How it works', 'Why', 'How', 'Applies to', 'What this does', 'What it does', 'Takes effect', 'Defaults', 'Menu combo in games', 'Screen effect needs shaders', 'On this device', 'Resolution', 'Screen', 'Screen resolution', 'Live preview', 'Automatic', 'Folders shared', 'Careful', 'Good to know', 'Privacy', 'Offline update', 'Standalone systems', 'Decomps & Ports', 'Emulators', 'What counts as missing', 'Launch backgrounds', 'Media keys', 'Players', 'Sync saves between devices', 'Update all emulators', 'Standalone emulators']);
function pageDef(id) { const p = pageDef0(id); if (p && Array.isArray(p.items)) p.items = p.items.filter(it => !(it && it.t == 'inf' && DESC_ROWS.has(it.label))); return p; }
function pageDef0(id) {
  switch (id) {
    case 'main': return { title: 'MAIN MENU', items: [A('Search settings…', () => { M = null; drawMenu(); openSearch('menu'); }), L('Features', 'features'), L('Store', 'store'), L('ROMs & Emulators', 'emu'), L('UI Settings', 'ui'), L('Advanced', 'adv'), L('Updates', 'updates'), ...(cfg.linux && !window.AndroidBridge ? [L('Drives & Storage…', 'drives'), L('Install to a Drive…', 'install')] : []), A('Quit', () => api.quit())] };
    case 'features': return { title: 'FEATURES', items: [L('RetroAchievements', 'ra'), A('Multiplayer Lobbies', () => { M = null; drawMenu(); togglePanel('lobby'); }), A('Friends', () => { M = null; drawMenu(); togglePanel('discord'); }), L('Scrapers', 'scraper'), L('Music Player', 'music'), ...(window.AndroidBridge ? [] : [L('Web UI', 'upload')])] };
    case 'store': return window.AndroidBridge ? { title: 'STORE', items: [A('Emulators', () => { M = null; drawMenu(); openElib(); }), I('Emulators', 'Get the emulators for systems Cacti OS does not play by itself, such as PSP, Dreamcast and 3DS')] } : { title: 'STORE', items: [A('Decomps & Ports', () => { M = null; drawMenu(); openStore(); }), A('Emulators', () => { M = null; drawMenu(); openElib(); }), I('Decomps & Ports', 'Free recompiled and fan-made PC versions of classic games, downloaded from their authors. You bring your own game file'), I('Emulators', 'Download and update standalone emulators such as Dolphin, PCSX2 and PPSSPP')] };
    case 'scraper': { const s = S.scrape; return { title: 'SCRAPERS', items: [L('Scraper Engines…', 'engines'), I('Active now', ENG.filter(e => e.ready && engOn(e)).map(e => e.name).join(', ') || 'None. Turn one on in Scraper Engines'), I('Status', s.run ? `Working… ${s.done} / ${s.total || '?'} · ${s.found} found` : (S.msg || 'Idle')), L('Assets…', 'assets'), L('ROMs asset folder…', 'romassets')] }; }
    case 'assets': { const s = S.scrape; const cs = SYS[sys] && BASE.find(b => b.id === SYS[sys].id) ? SYS[sys].id : null; return { title: 'ASSETS', items: [I('Status', s.run ? `Working… ${s.done} / ${s.total || '?'} · ${s.found} found` : (S.msg || 'Idle')), A('Scrape missing assets: all systems', () => doScrape(null)), A('Scrape missing assets: current system', () => doScrape(cs)), A('Download launch backgrounds: all systems', () => doScrapeBg(null)), A('Download launch backgrounds: current system', () => doScrapeBg(cs)), A('Stop', () => api.scrapeStop()), I('What counts as missing', 'Box art, plus any game still without a description, genre or year. Games that already have everything are skipped'), I('Launch backgrounds', 'Fetched when you first start a game. The buttons above get them all ahead of time')] }; }
    case 'romassets': return { title: 'ROMS ASSET FOLDER', items: [T('Save art and descriptions in the ROM folders', cfg.shareMeta !== false, v => set({ shareMeta: v })), A('Copy what this device has into the ROM folders', async () => { S.msg = 'Saving to the ROM folders…'; drawMenu(); const r = await api.shareExport(); S.msg = `Saved: ${r.art} images, details in ${r.lists} gamelist file${r.lists == 1 ? '' : 's'}`; drawMenu(); }), I('Status', S.msg || 'Idle'), I('Why', 'Everything is saved next to your games, in media/covers, media/fanart and gamelist.xml. Another device that opens the same folder, such as a network share, uses it without scraping again')] };
    case 'engines': { const on = ENG.filter(engOn), first = ENG.find(e => e.id == cfg.scrapeFirst && engOn(e)) || on[0];
      return { title: 'SCRAPER ENGINES', items: [L('Engines…', 'englist'), L('ScreenScraper account…', 'ssacct'), A('Check engine status', engStatus), { t: 'cyc', label: 'Engine priority', val: first ? first.name : 'None enabled', opts: on.map(e => [e.name, () => set({ scrapeFirst: e.id }), e == first]), next: () => { if (on.length) set({ scrapeFirst: on[(on.indexOf(first) + 1) % on.length].id }); }, prev: () => { if (on.length) set({ scrapeFirst: on[(on.indexOf(first) + on.length - 1) % on.length].id }); } }, A('Reset engines to defaults', () => set({ scrapeEngines: {}, scrapeFirst: 'libretro' }))] }; }
    case 'ssacct': return { title: 'SCREENSCRAPER ACCOUNT', items: [X('Username', 'ssUser'), X('Password', 'ssPass', true), A('Sign in and test', async () => { S.ssMsg = 'Checking…'; drawMenu(); let r; try { r = await api.scraperTest('screenscraper'); } catch { r = null; } S.ssMsg = r && r.msg ? r.msg : 'Could not check. Try again'; drawMenu(); }), I('Status', S.ssMsg || (cfg.ssUser ? 'Not checked yet' : 'No account added. ScreenScraper still works without one, with lower daily limits'))] };
    case 'englist': return { title: 'ENGINES', items: [I('How it works', 'Tick the engines you want. They are tried in order, and the next one is used if one is down or out of free lookups'),
        A('Check engine status', engStatus), I('No account needed', ''), ...ENG.filter(e => !e.acct).map(e => T(`${e.name}${e.ready ? '' : '  (coming soon)'} · ${e.gives}`, engOn(e), v => engSet(e.id, v)))] };
    case 'music': { const m = S.music; return { title: 'MUSIC PLAYER', items: [X('Music folder', 'musicDir'), A('Choose music folder…', async () => { const p = await api.pick('folder'); if (p) { await set({ musicDir: p }); toast('MUSIC', 'Folder set', p.split(/[\\/]/).pop()); } }),
      I('Now playing', m.total ? (m.title || 'Stopped') + ` (${m.total} songs)` : 'No songs found. Choose a folder'), A(m.playing ? 'Pause' : 'Play', () => api.music('toggle')), A('Next song', () => api.music('next')), A('Previous song', () => api.music('prev')),
      SL('Music volume', m.vol, 0, 100, 10, v => { m.vol = v; api.music('vol:' + v); drawMenu(); }), T('Shuffle', m.shuffle, () => api.music('shuffle')), T('Start playing when Cacti OS opens', cfg.musicAuto, v => set({ musicAuto: v })),
      A('Show the player now', () => { M = null; drawMenu(); api.music('show'); }), I('Over a running game', cfg.mac ? 'Press Cmd+Alt+M, then arrows / Space / S' : 'Hold Start and press D-pad Down (Windows Xbox-style pads and Raspberry Pi), or Ctrl+Alt+M'), I('Media keys', 'Play/Pause, Next and Previous keys also work')] }; }
    case 'upload': { const u = S.up || { enabled: false, on: false, ips: [], code: '', port: 8080, host: 'device' }; const adr = u.ips.map(i => `http://${i}:${u.port}`);
      return { title: 'WEB UI', items: [T('Allow other devices on my network to open the Web UI', cfg.upload, v => set({ upload: v }).then(loadUp)),
        ...(u.on ? [...adr.map((a, i) => I(i ? 'Or' : 'Open this address', a)), I('Or', `http://${u.host}.local:${u.port}`), I('Code', u.code), A('Make a new code', async () => { S.up = await api.uploadNewCode(); drawMenu(); })] : [I('Status', u.enabled ? 'Starting… check your network connection' : 'Off')]),
        I('How', 'On a computer or phone on the same network, open the address in a browser and enter the code. Drop in ROM files, enter keys and passwords, check for updates and manage backups.')] }; }
    case 'ctrl': { const PR = ['Xbox', 'PlayStation', 'Nintendo'], pr = PR.includes(cfg.prompts) ? cfg.prompts : 'Xbox';
      return { title: 'CONTROLLERS', items: [A(cfg.linux ? 'Bluetooth pairing' : 'Bluetooth settings (opens system settings)', openBT), A('Button mapping', openMap),
        { t: 'cyc', label: 'Button prompts', val: pr, opts: PR.map(x => [x, () => set({ prompts: x }), x == pr]), next: () => set({ prompts: PR[(PR.indexOf(pr) + 1) % 3] }), prev: () => set({ prompts: PR[(PR.indexOf(pr) + 2) % 3] }) },
        A('Open controller window', () => { M = null; drawMenu(); togglePanel('pads'); }),
        I('Applies to', 'Cacti OS menus. Games use RetroArch controls')] }; }
    case 'tidy': {
      const P = S.tidy, items = [I('What this does', 'Moves loose ROMs into their console\u2019s folder (.nes to NES, .sfc to SNES, and so on) inside your ROMs folder, along with their save files, box art and scraped images. Zips, discs and anything else Cacti OS cannot place with certainty stay where they are. Nothing is deleted or overwritten.')];
      items.push(A(S.tidyBusy ? 'Working…' : 'Check what would move', async () => { if (S.tidyBusy) return; S.tidyBusy = true; S.tidyMsg = ''; drawMenu(); S.tidy = await api.tidyPlan(); S.tidyBusy = false; drawMenu(); }));
      if (P && P.error) items.push(I('Problem', P.error));
      else if (P) {
        items.push(I('Would move', P.count ? P.count + ' game' + (P.count == 1 ? '' : 's') + ': ' + Object.entries(P.bySys).map(([k, v]) => k + ' ' + v).join(', ') : 'Nothing. Your library is already tidy.'));
        for (const x of P.sample || []) items.push(I('•', x));
        if (P.skipped && P.skipped.length) items.push(I('Left alone', P.skipped.length + '+ (a file with that name is already in the target folder)'));
        if (P.count) items.push(A(S.tidySure ? 'Press again to move ' + P.count + ' files' : 'Move them now', async () => {
          if (!S.tidySure) { S.tidySure = true; drawMenu(); return; }
          S.tidySure = false; S.tidyBusy = true; drawMenu(); const r = await api.tidyRun(); S.tidyBusy = false;
          if (r.ok) { try { const f = new Set(JSON.parse(localStorage.getItem('favs') || '[]')), o = [...f].map(x => r.remap[x] || x); localStorage.setItem('favs', JSON.stringify(o)); favs = new Set(o); } catch {} S.tidyMsg = `Moved ${r.moved} game${r.moved == 1 ? '' : 's'} and ${r.extra} saves/images${r.failed ? ' · ' + r.failed + ' could not be moved' : ''}`; S.tidy = null; await reload(); } else S.tidyMsg = r.error;
          drawMenu();
        }));
      }
      if (S.tidyMsg) items.push(I('Result', S.tidyMsg));
      return { title: 'CLEAN UP LIBRARY', items };
    }
    case 'players': {
      const P = S.prof, items = [I('Players', 'Each player gets their own folder for saves and save states. Name it after your RetroAchievements account and it will match when you sign in.')];
      if (!P) { api.profList().then(x => { S.prof = x; if (M && M.stack[M.stack.length - 1] == 'players') drawMenu(); }); return { title: 'PLAYERS', items: [...items, I('Loading', 'Checking players…')] }; }
      items.push(I('Playing as', P.current || 'Nobody (shared saves)'));
      if (S.profMsg) items.push(I('Result', S.profMsg));
      for (const n of P.list) items.push(A((n == P.current ? '● ' : '') + n, async () => { if (n == P.current) return; const r = await api.profUse(n); S.profMsg = r.ok ? 'Switched to ' + n : r.error; cfg = await api.getConfig(); S.prof = await api.profList(); drawMenu(); }));
      if (P.current) items.push(A('Stop using players (shared saves)', async () => { const r = await api.profUse(''); S.profMsg = r.ok ? 'Using shared saves again' : r.error; cfg = await api.getConfig(); S.prof = await api.profList(); drawMenu(); }));
      items.push(T('Ask who is playing at startup', cfg.profAsk !== false, v => set({ profAsk: v })), T('Copy my current saves into a new player', S.profAdopt !== false, v => { S.profAdopt = v; drawMenu(); }), X('Add a player (type a name)', '_newPlayer'));
      if (P.current && P.ra && P.current.toLowerCase() != P.ra.toLowerCase()) items.push(A('Rename ' + P.current + ' to ' + P.ra + ' (your RetroAchievements name)', async () => { const r = await api.profRename(P.ra); S.profMsg = r.ok ? 'Renamed. Emulator save paths follow automatically.' : r.error; cfg = await api.getConfig(); S.prof = await api.profList(); drawMenu(); }));
      else if (!P.current && P.ra && !P.list.includes(P.ra)) items.push(A('Create player ' + P.ra + ' (your RetroAchievements name)', async () => { const r = await api.profCreate(P.ra, S.profAdopt !== false); S.profMsg = r.ok ? 'Added ' + P.ra : r.error; cfg = await api.getConfig(); S.prof = await api.profList(); drawMenu(); }));
      items.push(I('Folders are in', P.base), I('Backups', 'Each player is backed up on their own, with their settings, from Menu > Saves & Backups.'));
      return { title: 'PLAYERS', items };
    }
    case 'saves': { const v = S.sv, K = ['5', '10', '20'], kp = K.includes(String(cfg.backupKeep)) ? String(cfg.backupKeep) : '10', last = v && v.backups[0], dt = w => new Date(w).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
      const AND = !!window.AndroidBridge; return { title: 'SAVES & BACKUPS', items: [L('Players', 'players'), ...(AND ? [] : [T('Auto-load the last save state when a game starts', cfg.autoLoad, x => set({ autoLoad: x })), T('Auto-save a state when a game closes', cfg.autoSave, x => set({ autoSave: x })),
        I('Applies to', 'RetroArch games. Standalone emulators have their own settings')]),
        ...(AND ? [] : [T('Share saves on the ROMs folder', !!cfg.shareSaves, async v => { S.svMsg = v ? 'Copying your saves to the ROMs folder…' : ''; drawMenu(); const r = await api.shareSaves(v); cfg = await api.getConfig(); S.svMsg = r.ok ? (v ? `Saves are now kept in the ROMs folder (${r.dir}). ${r.copied} file${r.copied == 1 ? '' : 's'} copied. Turn this on for your other devices too` : 'Saves go back to this device') : r.error; loadSaves(); drawMenu(); }), ...(cfg.shareSaves ? [I('Shared folder', (cfg.romRoot || '') + '/Cacti Saves')] : [I('Why', 'Keeps saves and save states in a Cacti Saves folder beside your games, so every device using the same ROM folder, like a network share, shares progress. Two devices playing the same game at once overwrite each other')])]), I('Game saves are kept', cfg.saveDir || (AND ? 'In the Cacti OS app folder (saved automatically every 15 seconds)' : 'Next to each game (RetroArch default)')), ...(AND ? [] : [A('Choose a saves folder…', async () => { const p = await api.pick('folder'); if (p) { await set({ saveDir: p }); loadSaves(); toast('SAVES', 'New saves folder set', 'Older saves stay where they were'); } })]),
        ...(cfg.saveDir ? [A('Use the default location again', () => set({ saveDir: '' }).then(loadSaves))] : []),
        T('Back up saves automatically after each game', cfg.backupAuto, x => set({ backupAuto: x })),
        { t: 'cyc', label: 'Backups to keep', val: kp, opts: K.map(x => [x, () => set({ backupKeep: x }), x == kp]), next: () => set({ backupKeep: K[(K.indexOf(kp) + 1) % 3] }), prev: () => set({ backupKeep: K[(K.indexOf(kp) + 2) % 3] }) },
        I('Saves found', v ? `${v.files} file${v.files == 1 ? '' : 's'}` : 'Checking…'), I('Last backup', last ? `${dt(last.when)} · ${last.files} files` : 'None yet'),
        ...(S.svMsg ? [I('Result', S.svMsg)] : []),
        A(S.svBusy ? 'Backing up…' : 'Back up now', async () => { if (S.svBusy) return; S.svBusy = true; S.svMsg = ''; drawMenu(); const r = await api.savesBackup(); S.svBusy = false; S.svMsg = r.ok ? `Backed up ${r.files} files` : r.error; await loadSaves(); }),
        L('Restore a backup…', 'restore'), ...(AND ? [] : [A('Open backups folder', () => api.savesOpen())])] }; }
    case 'restore': { const v = S.sv, dt = w => new Date(w).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }), items = [];
      if (S.svMsg) items.push(I('Result', S.svMsg));
      for (const b of (v && v.backups) || []) { const sure = S.svSure == b.id; items.push(A(sure ? 'Press again to restore this backup. Current saves are backed up first' : `${dt(b.when)} · ${b.files} files${b.why ? ' · ' + b.why.replace(/-/g, ' ') : ''}`, async () => { if (!sure) { S.svSure = b.id; drawMenu(); return; } S.svSure = null; const r = await api.savesRestore(b.id); S.svMsg = r.ok ? `Restored ${r.files} files` : r.error; await loadSaves(); })); }
      if (!items.length || (items.length == 1 && S.svMsg)) items.push(I('Backups', 'None yet. Use Back up now first'));
      return { title: 'RESTORE A BACKUP', items }; }
    case 'sound': return { title: 'SOUND SETTINGS', items: [SL('System volume', S.vol, 0, 100, 10, v => { S.vol = v; api.setVolume(v); }), T('Navigation sounds', cfg.navSounds, v => set({ navSounds: v }))] };
    case 'ach': { const AS = ACHS, SZ = [['1', 'Small'], ['2', 'Medium'], ['3', 'Large']];
      const a = AS.find(x => x[0] == cfg.achStyle) || AS[1], z = SZ.find(x => x[0] == cfg.achSize) || SZ[1];
      return { title: 'ACHIEVEMENT POPUPS', items: [{ t: 'cyc', label: 'Popup style', val: a[1], go: 'achstyle', start: () => AS.indexOf(a), next: () => achPick(AS[(AS.indexOf(a) + 1) % AS.length][0]), prev: () => achPick(AS[(AS.indexOf(a) + AS.length - 1) % AS.length][0]) },
        { t: 'cyc', label: 'Popup size', val: z[1], opts: SZ.map(n => [n[1], () => set({ achSize: n[0] }).then(() => api.achPreview()), n == z]), next: () => { const n = SZ[(SZ.indexOf(z) + 1) % SZ.length]; set({ achSize: n[0] }).then(() => api.achPreview()); } },
        T('Popup sound', cfg.achSound !== false, v => set({ achSound: v })), A('Preview popup', () => api.achPreview()),
        I('How it works', 'Reads RetroArch\'s local log, no extra website traffic'), I('Takes effect', 'The next time you start a game')] }; }
    case 'achstyle': return { title: 'POPUP STYLE', items: ACHS.map(([id, name]) => A((cfg.achStyle == id || (!cfg.achStyle && id == 'pill') ? '●   ' : '○   ') + name, () => achPick(id))) };
    case 'ui': return { title: 'UI SETTINGS', items: [L('Themes', 'themes'), L('Display & Resolution', 'display'), L('Visuals', 'visuals'), L('Sound Settings', 'sound'), L('Controllers', 'ctrl'), L('Achievement Popups', 'ach'), L('Game Collection Settings', 'coll'), L('Icons', 'icons'), T('Start in fullscreen', cfg.fullscreen, v => set({ fullscreen: v })), T('Play the Cacti OS intro when the app starts', cfg.splash !== false, v => set({ splash: v })), A('Toggle fullscreen now', () => api.fullscreen())] };
    case 'icons': return { title: 'ICONS', items: [T('Achievements trophy icon on the main screen', cfg.trophy, v => set({ trophy: v })), T('Friends icon on the main screen', cfg.discord, v => set({ discord: v })), T('Declutter: move top icons into the profile menu', cfg.declutter, v => set({ declutter: v })), L('Header icon size…', 'sizes')] };
    case 'themes': return { title: 'THEMES', items: [{ t: 'cyc', label: 'Home screen layout', val: (LAYS.find(l => l[0] === lay()) || LAYS[0])[1], opts: LAYS.map(l => [l[1], () => set({ layout: l[0] }), l[0] === lay()]), next: () => set({ layout: LAYS[(LAYS.findIndex(l => l[0] === lay()) + 1) % LAYS.length][0] }) }, { t: 'cyc', label: 'Theme', val: Themes.nameOf(cfg.theme), opts: Themes.ids().map(n => [Themes.nameOf(n), () => set(Themes.get(n).layout ? { theme: n, layout: 'custom' } : { theme: n }), n == (cfg.theme || 'classic')]), next: () => { const L = Themes.ids(), n = L[(Math.max(0, L.indexOf(cfg.theme || 'classic')) + 1) % L.length]; set(Themes.get(n).layout ? { theme: n, layout: 'custom' } : { theme: n }); } }, T('Console skins (each system has its own look)', cfg.skins !== false, v => set({ skins: v })), T('Dark mode (Classic theme)', cfg.dark, v => set({ dark: v })), ...(window.AndroidBridge ? [] : [A('Open Theme Studio (make your own theme)', () => api.studio()), A('Open custom themes folder', () => api.themesDir())])] };
    case 'coll': return { title: 'GAME COLLECTION SETTINGS', items: [T('Show Favorites collection', cfg.showFav, v => set({ showFav: v })), T('Show Last Played collection', cfg.showLast, v => set({ showLast: v })), T('Show All Games collection', cfg.showAll, v => set({ showAll: v })), T('Only show games with achievements', cfg.raGames, v => set({ raGames: v }).then(() => toast('LIBRARY', v ? 'Games with achievements only' : 'All games shown', v && !cfg.hasKey ? 'Add your RetroAchievements key first' : ''))), T('Only show systems with achievements', cfg.raOnly, v => set({ raOnly: v }).then(() => toast('LIBRARY', v ? 'Achievement systems only' : 'All systems', v ? 'Systems without RetroAchievements are hidden' : '')))] };
    case 'adv': return { title: 'ADVANCED', items: [L('System Check', 'check'), L('Saves & Backups', 'saves'), L('Network & Sync', 'netsync'), A('Run first-time setup again', () => { M = null; drawMenu(); openFR(); })] };
    case 'emu': return { title: 'ROMS & EMULATORS', items: [X('ROMs folder', 'romRoot'), A('Choose ROMs folder…', pickRoms), A('Rescan games', async () => { await reload(); toast('SCAN COMPLETE', `${BASE.reduce((n, s) => n + s.games.length, 0)} games found`, ''); }), L('Clean up library…', 'tidy'), ...(window.AndroidBridge ? [] : [{ t: 'cyc', label: 'Resolution boost (3D systems)', val: ({ 0: 'Native', 2: '2x', 3: '3x', 4: '4x', 5: '5x', 6: '6x' })[cfg.emuScale || 0], opts: [0, 2, 3, 4, 5, 6].map(n => [n ? n + 'x' : 'Native', () => set({ emuScale: n }).then(() => toast('RESOLUTION', n ? n + 'x internal resolution' : 'Native resolution', 'Standalone emulators plus the N64, PSX (SwanStation), PSP and Dreamcast cores. Applied the next time a game starts')), (cfg.emuScale || 0) == n]), next: () => { const o = [0, 2, 3, 4, 5, 6], n = o[(o.indexOf(+cfg.emuScale || 0) + 1) % o.length]; set({ emuScale: n }).then(() => toast('RESOLUTION', n ? n + 'x internal resolution' : 'Native resolution', 'Applied the next time a game starts')); } }, T('Sign standalone emulators in to RetroAchievements', cfg.emuRA !== false, v => set({ emuRA: v })), I('Standalone emulators', 'Resolution and your RetroAchievements sign-in are written into PCSX2, Dolphin, PPSSPP (resolution only) and Flycast just before a game starts, so you never sign in twice. Open each emulator once first so it has a settings file')]), T('Hide duplicate regions (keeps USA/English, or the RetroAchievements copy)', cfg.dedupe !== false, v => set({ dedupe: v }).then(reload)), ...(window.AndroidBridge ? [L('Emulator for each system…', 'emucores')] : [X('RetroArch app', 'retroarch'), A('Choose RetroArch…', pickRA), L('Emulator for each system…', 'emucores'), L('Configure Input', 'input')])] };
    case 'emucores': { const ABUILT = ['FCEUmm', 'Genesis Plus GX', 'mGBA', 'Snes9x']; return { title: 'EMULATOR FOR EACH SYSTEM', items: [I('Defaults', 'Only emulators with RetroAchievements support are picked automatically'), ...SM.filter(s => !window.AndroidBridge || s.cores.some(c => ABUILT.includes(c.name))).map(s0 => { const s = window.AndroidBridge ? { ...s0, cores: s0.cores.filter(c => ABUILT.includes(c.name)) } : s0; const ch = s.cores.find(x => x.id == (cfg.cores && cfg.cores[s.id])) || s.cores.find(x => x.id === s.choice) || s.cores.find(x => x.ra) || s.cores[0]; return { t: 'cyc', label: s.name, val: ch.name + (ch.ra ? '  ✓ achievements' : '  ✗ no achievements'), opts: s.cores.map(c => [c.name + (c.ra ? '  ✓ achievements' : '  ✗ no achievements'), () => set({ cores: { [s.id]: c.id } }).then(() => toast('EMULATOR', `${s.name}: ${c.name}`, c.ra ? 'Achievements supported · install it in System Check' : 'No achievements with this one')), c == ch]), next: () => cycleCore(s, ch) }; })] }; }
    case 'input': { const q = QC.find(x => x[0] == cfg.quitCombo) || QC[1]; return { title: 'CONFIGURE INPUT', items: [
      { t: 'cyc', label: 'Quit game combo', val: q[1], opts: QC.map(n => [n[1], () => set({ quitCombo: n[0] }).then(() => toast('QUIT COMBO', n[1], 'Hold it in a game to close RetroArch')), n == q]), next: () => { const n = QC[(QC.indexOf(q) + 1) % QC.length]; set({ quitCombo: n[0] }).then(() => toast('QUIT COMBO', n[1], 'Hold it in a game to close RetroArch')); } },
      I('Menu combo in games', 'Start + Select opens the RetroArch menu'), A('Open controller window', () => { M = null; drawMenu(); togglePanel('pads'); })] }; }
    case 'visuals': {
      const VM = [['off', 'Off (my own picture settings)'], ['original', 'Original console look']], vm = VM.find(x => x[0] === (cfg.visual || 'off')) || VM[0];
      const items = [{ t: 'cyc', label: 'Picture mode', val: vm[1], opts: VM.map(x => [x[1], () => set({ visual: x[0] }), x == vm]), next: () => set({ visual: vm[0] == 'off' ? 'original' : 'off' }) }];
      if (cfg.visual == 'original') {
        items.push(I('What it does', 'TV consoles (NES, SNES, Genesis, N64, PlayStation and similar) show in 4:3 like a CRT. Handhelds (Game Boy, GBA, Game Gear, PSP) keep their own shape with whole-number scaling. Pixels stay sharp.'),
          ...(window.AndroidBridge ? [] : [T('Screen effect (scanlines for TV consoles, pixel grid for handhelds)', cfg.visFx !== false, v => set({ visFx: v })),
          I('Screen effect needs shaders', 'It uses RetroArch\u2019s shader pack. In RetroArch: Main Menu > Online Updater > Update GLSL Shaders (or Update Slang Shaders). Without it you still get the original shape and sharp scaling.')]));
      }
      if (window.AndroidBridge) items.push(I('On this device', 'Scanlines and pixel-grid effects are not available for the built-in emulators. You get the original picture shape and sharp scaling.'));
      return { title: 'VISUALS', items };
    }
    case 'display': {
      const D = S.disp; if (!D) return { title: 'DISPLAY & RESOLUTION', items: [I('Status', 'Loading…')] };
      const items = [];
      if (S.dispT) return { title: 'KEEP THIS RESOLUTION?', items: [A('Keep ' + S.dispT.mode, async () => { await api.dispConfirm(); clearInterval(S.dispT.iv); S.dispT = null; S.dispMsg = 'Resolution saved for this session.'; loadDisp(); }), A('Go back to the old one', async () => { clearInterval(S.dispT.iv); S.dispT = null; await api.dispRevert(); S.dispMsg = 'Went back to the previous resolution.'; loadDisp(); }), I('Auto-revert', `Going back in ${S.dispT.left} seconds if you do nothing`)] };
      if (S.dispMsg) items.push(I('Result', S.dispMsg));
      if (D.platform === 'linux') {
        items.push(I('Display', D.output === 'all' ? 'all outputs' : (D.output || 'none found')), I('Current mode', D.current || 'unknown')); if (D.diag) items.push(I('Found', D.diag));
        if (S.dispReboot) items.push(A('Restart now to apply', () => api.dispReboot()));
        if (D.method === 'none' || !D.modes.length) items.push(I('Resolution', 'Cannot be changed from here on this display.'));
        else { items.push(I('How it applies', D.method === 'live' ? 'Tried on screen for 10 seconds; it reverts unless you keep it.' : 'Saved to the boot settings and applied after a restart.'));
          for (const m of D.modes) items.push(A(`${({ 1080: '1080p  ', 1440: '1440p  ', 2160: '4K  ' })[m.h] || ''}${m.w} × ${m.h}${m.hz ? ' @ ' + m.hz + ' Hz' : ''}${m.id === D.current ? '  (current)' : ''}${m.preferred ? '  (recommended)' : ''}`, async () => dispPick(D, m))); }
      } else if (window.AndroidBridge) {
        items.push(I('Screen', 'Cacti OS fills your whole screen. Change resolution and refresh rate in Android display settings.'), A('Open system display settings', () => api.dispSystem()));
      } else {
        items.push(I('Screen resolution', 'Set in your system display settings. Cacti OS scales to fit any window or screen.'), A('Open system display settings', () => api.dispSystem()), T('Fullscreen', !!cfg.fullscreen, v => { set({ fullscreen: v }); }), I('Window size now', D.size ? D.size.join(' × ') : ''));
        for (const [w, h] of [[1280, 720], [1600, 900], [1920, 1080]]) items.push(A(`Window ${w} × ${h}`, async () => { await api.dispWin(w, h); loadDisp(); }));
      }
      const GA = [['core', 'As the game was made'], ['4:3', '4:3'], ['16:9', '16:9 widescreen'], ['square', 'Square pixels']], ga = GA.find(x => x[0] === cfg.gameAspect) || GA[0];
      items.push({ t: 'cyc', label: 'Game picture shape', val: ga[1], opts: GA.map(x => [x[1], () => set({ gameAspect: x[0] }), x == ga]), next: () => set({ gameAspect: GA[(GA.indexOf(ga) + 1) % GA.length][0] }), prev: () => set({ gameAspect: GA[(GA.indexOf(ga) + GA.length - 1) % GA.length][0] }) });
      items.push(T('Sharp pixels (whole-number scaling)', !!cfg.gameInt, v => set({ gameInt: v })), T('Smooth the picture', !!cfg.gameSmooth, v => set({ gameSmooth: v })), L('Interface sizes…', 'sizes'));
      return { title: 'DISPLAY & RESOLUTION', items };
    }
    case 'sizes': {
      const PR = [['auto', 'Automatic'], ['small', 'Small'], ['normal', 'Normal'], ['large', 'Large (TV)'], ['custom', 'Custom']], pr = PR.find(x => x[0] === (cfg.szPreset || 'auto')) || PR[0], e = szEff();
      const sl = (label, i, key, min, max) => SL(label + ' %', e[i], min, max, 5, v => { const a = szEff(); a[i] = v; set({ szPreset: 'custom', szHeader: String(a[0]), szTile: String(a[1]), szText: String(a[2]), szPrompt: String(a[3]) }); });
      return { title: 'INTERFACE SIZES', items: [{ t: 'cyc', label: 'Size preset', val: pr[1], opts: PR.map(x => [x[1], () => set({ szPreset: x[0] }), x == pr]), next: () => set({ szPreset: PR[(PR.indexOf(pr) + 1) % PR.length][0] }), prev: () => set({ szPreset: PR[(PR.indexOf(pr) + PR.length - 1) % PR.length][0] }) },
        sl('Header icons', 0, 'szHeader', 70, 150), sl('Game tiles', 1, 'szTile', 70, 115), sl('Text', 2, 'szText', 70, 130), sl('Button prompts', 3, 'szPrompt', 70, 150),
        I('Live preview', 'The header, tiles and button prompts behind this menu change as you adjust.'), I('Automatic', 'Makes header icons and prompts larger on small handheld screens.'),
        A('Reset to defaults', () => set({ szPreset: 'auto', szHeader: '100', szTile: '100', szText: '100', szPrompt: '100' }))] };
    }
    case 'netsync': {
      const sh = S.share, up = S.up || { enabled: false, on: false, ips: [], code: '', port: 8080 }, dt = w => w ? new Date(+w).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : 'never';
      const items = [];
      if (S.syncMsg) items.push(I('Result', S.syncMsg));
      items.push(I('Share your games', ''));
      if (sh && sh.supported) {
        items.push(T('Share games, BIOS and saves on my network', sh.on, v => { S.share = { ...sh, busy: true }; api.shareSet(v).then(r => { S.syncMsg = r.error || ''; S.share = r.error ? sh : r; drawMenu(); }); }));
        if (sh.on) { const ip = sh.ips[0] || 'this-device'; items.push(I('Windows: File Explorer address', `\\\\${ip}\\roms`), I('Mac: Finder > Go > Connect to Server', `smb://${ip}/roms`), I('Also try', `\\\\${sh.host}\\roms  or  smb://${sh.host}.local/roms`), I('Folders shared', 'roms, bios, saves. No password.')); }
        items.push(I('Careful', 'Anyone on your home network can add or delete files while sharing is on.'));
      } else {
        items.push(I('Your games folder', cfg.romRoot || 'not set'), A('Use a folder on another computer or NAS…', pickRoms), I('How', 'Map or mount the network share first (Windows: Map network drive. Mac: Connect to Server), then choose it here. Scans can be slow over Wi-Fi.'));
      }
      items.push(I('Sync saves between devices', 'Saves and save states only, never games'), X('Sync folder (OneDrive, Dropbox, Syncthing…)', 'syncDir'), A('Choose sync folder…', async () => { const p = await api.pick('folder'); if (p) await set({ syncDir: p }); }),
        A(S.syncBusy ? 'Syncing…' : 'Sync with the folder now', () => syncNow('folder')),
        I('This device (for the other one)', up.on ? `${up.ips[0] || 'address'}:${up.port}   code ${up.code}` : 'Turn on "Web UI" to let another Cacti OS reach this one'),
        X('Other Cacti OS address (like 192.168.1.20:8080)', 'syncPeer'), X('Other Cacti OS code', 'syncCode'), A(S.syncBusy ? 'Syncing…' : 'Sync with that device now', () => syncNow('peer')),
        T('Sync automatically at start and after each game', cfg.syncAuto, v => set({ syncAuto: v })), I('Last sync', dt(cfg.syncLast)),
        I('Good to know', 'The newer save wins. If both changed, the older one is kept in a .sync-conflicts folder. A backup is made before anything is replaced.'));
      return { title: 'NETWORK & SYNC', items };
    }
    case 'install': return window.instPage(IC);
    case 'drives': return window.drvPage(DC);
    case 'updates': {
      const u = S.upd; if (!u) return { title: 'UPDATES', items: [I('Status', 'Loading…')] };
      const dt = w => w ? new Date(w).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '';
      const items = [I('Installed version', u.version)];
      if (S.updMsg) items.push(I('Result', S.updMsg));
      if (u.applied[0]) { items.push(I('Last updated', `${u.applied[0].version} on ${dt(u.applied[0].when)}`)); for (const n of u.applied[0].notes) items.push(I('New in ' + u.applied[0].version, n)); }
      const UM = [['manual', 'Only when I ask'], ['startup', 'Every time it starts'], ['weekly', 'About once a week'], ['off', 'Never']], um = UM.find(x => x[0] == cfg.updMode) || UM[0];
      items.push({ t: 'cyc', label: 'Check for updates', val: um[1], opts: UM.map(x => [x[1], () => set({ updMode: x[0] }), x == um]), next: () => set({ updMode: UM[(UM.indexOf(um) + 1) % 4][0] }), prev: () => set({ updMode: UM[(UM.indexOf(um) + 3) % 4][0] }) });
      items.push(A(S.updBusy ? 'Checking…' : 'Check for updates now', async () => {
        if (S.updBusy) return; S.updBusy = true; S.updMsg = ''; drawMenu();
        const r = await api.updCheck(false); S.updBusy = false;
        if (r.error) S.updMsg = r.error; else if (!r.available) S.updMsg = `You are up to date (${r.current}).`; else { S.updMsg = `Version ${r.version} is available.`; S.updNew = r; }
        drawMenu();
      }));
      if (!window.AndroidBridge) items.push(A(S.emuUpdBusy ? 'Updating emulators…' : 'Update all emulators', async () => {
        if (S.emuUpdBusy) return; S.emuUpdBusy = true; S.updMsg = 'Checking your emulators and updating any that are out of date. This can take a few minutes.'; drawMenu();
        let r; try { r = await api.emuUpdateAll(); } catch (e) { r = { updated: [], failed: [String(e.message || e)], current: 0, other: 0 }; }
        S.emuUpdBusy = false;
        S.updMsg = (r.updated.length ? 'Updated ' + r.updated.join(', ') + '. ' : 'No emulator needed an update. ') + (r.current ? r.current + ' already up to date. ' : '') + (r.other ? r.other + ' installed by you or another app (update those yourself). ' : '') + (r.failed.length ? 'Could not update: ' + r.failed.join('; ') : '');
        if (r.updated.length) toast('EMULATORS', 'Updated ' + r.updated.length, r.updated.join(', ')); drawMenu();
      }), I('Update all emulators', 'Updates every emulator Cacti OS installed for you (PCSX2, PPSSPP, Flycast and so on) to its newest release in one go. Emulators you installed yourself are left alone'));
      if (S.updNew) { items.push(A(`Install version ${S.updNew.version} now`, async () => { const r = await api.updStart(); S.updMsg = r.error || r.msg || (r.manual ? 'Installed. Start Cacti OS again to use it.' : 'Installed. Restarting…'); S.updNew = null; drawMenu(); })); for (const n of S.updNew.notes) items.push(I('New in ' + S.updNew.version, n)); }
      items.push(I('Privacy', 'Updates are only fetched when you allow it. Nothing about you is sent, and every update is signature-checked. A backup is kept so you can go back.'));
      items.push(I('Offline update', 'You can still double-click an Update file you were sent.'));
      for (const b of u.backups) { const sure = S.updSure == b.id; items.push(A(sure ? `Press again to go back to ${b.version} and restart` : `Restore version ${b.version} (saved ${dt(b.when)})`, async () => { if (!sure) { S.updSure = b.id; drawMenu(); return; } S.updSure = null; const r = await api.updRestore(b.id); S.updMsg = r.error || (r.manual ? `Restored ${r.version}. Start Cacti OS again to use it.` : `Restored ${r.version}. Restarting…`); S.upd = await api.updInfo(); drawMenu(); })); }
      if (!u.backups.length) items.push(I('Backups', u.bkNote || 'None yet. One is saved each time you update.'));
      return { title: 'UPDATES', items };
    }
    case 'check': {
      const c = S.check; if (!c) return { title: 'SYSTEM CHECK', items: [I('Status', 'Checking…')] };
      const y = v => v ? '✓' : '✗', items = [];
      if (S.busy) items.push(I('Working', S.busy));
      if (window.AndroidBridge) items.push(I('Built-in cores', 'mGBA, FCEUmm, Snes9x, Genesis Plus GX ✓')); else items.push(I('RetroArch app', `${y(c.retroarch.ok)} ${c.retroarch.ok ? 'found' : 'not found'}`), I('RetroArch cores folder', `${y(c.coresDirOk)} ${c.coresDirOk ? 'found' : 'not created yet'}`)); items.push(I('ROMs folder', `${y(c.romRootOk)} ${c.romRootOk ? c.romRoot : 'not set (ROMs & Emulators)'}`));
      for (const s of c.systems) items.push(I(s.name, `${s.count} games ${y(s.count)} · ${s.core} ${y(s.coreOk)}${s.ra ? '' : ' · no achievements'}${s.count ? '' : ' · folder: ' + s.folders}`));
      if (c.standalone) { items.push(I('Standalone systems', 'Run by their own emulator. Install them in Menu > Store > Emulators'));
        for (const x of c.standalone) items.push(I(x.name, `${x.count} games ${y(x.count)}${x.count ? '' : ' · folder: ' + x.folders}`));
        for (const b of c.bios || []) items.push(A(`${b.label}: ${b.ok ? '✓ ' + b.found + ' file' + (b.found == 1 ? '' : 's') + ' found' : b.optional ? '✗ optional, not found' : '✗ required, not found'} · open folder`, () => api.biosOpen(b.id).then(() => toast('BIOS FOLDER', b.name, 'Put your own BIOS files here, then Re-check')))); }
      if (S.usage) { const mb = n => n >= 1e9 ? (n / 1e9).toFixed(1) + ' GB' : Math.round(n / 1e6) + ' MB'; items.push(I('Memory in use right now', `${mb(S.usage.ram)} (${S.usage.procs} process${S.usage.procs == 1 ? '' : 'es'}, not counting a running game)`), I('Cacti OS data on disk', `${mb(S.usage.data)} · emulators ${mb(S.usage.emus)} · cores ${mb(S.usage.cores)}`)); }
      items.push(I('RetroArch login', `${y(c.ra.pass)} ${c.ra.pass ? 'password saved, achievements will track in-game' : 'add your account password in RetroAchievements'}`));
      items.push(I('RetroAchievements', `${y(c.ra.user && c.ra.key)} ${c.ra.user && c.ra.key ? 'credentials saved' : 'add them in Menu > RetroAchievements'}`));
      items.push(A(c.retroarch.ok ? 'RetroArch is installed' : 'Install RetroArch (one click)', () => c.retroarch.ok ? loadCheck() : installRA()), A('Install all cores', installCores), A('Open last launch log', async () => { const ok = await api.openLog(); if (!ok) toast('NO LOG YET', 'Launch a game first', ''); }), A('Re-check', loadCheck));
      return { title: 'SYSTEM CHECK', items };
    }
    case 'ra': return { title: 'RETROACHIEVEMENTS', items: [X('Username', 'raUser'), X('Web API key', 'raKey', true), X('Sign in to RetroArch (account password, not stored)', 'raPass', true), { t: 'pic', label: 'Profile picture' }, T('Hardcore mode (disables save states)', cfg.hardcore, v => set({ hardcore: v })), A('Sync now', async () => { await refreshRA(); toast('RETROACHIEVEMENTS', RA && !RA.error ? 'Synced ' + RA.user : 'Sync failed', RA && RA.error ? RA.error.slice(0, 60) : ''); }), I('Status', RA ? (RA.error || 'Connected as ' + RA.user) : 'Not synced yet')] };
  }
  return { title: '', items: [] };
}
const firstNav = id => { const i = pageDef(id).items.findIndex(x => x.t !== 'inf'); return i < 0 ? 0 : i; };
async function loadSaves() { S.sv = await api.savesInfo(); if (M && ['saves', 'restore'].includes(M.stack[M.stack.length - 1])) drawMenu(); }
async function loadDisp() { S.disp = await api.dispInfo(); if (M && M.stack[M.stack.length - 1] == 'display') drawMenu(); }
async function dispPick(D, m) {
  if (m.id === D.current) return; S.dispMsg = '';
  const r = await api.dispSet(D.output, m.id);
  if (r.error) { S.dispMsg = r.error; drawMenu(); return; }
  if (r.reboot) { S.dispReboot = true; S.dispMsg = `${m.w} × ${m.h} saved. Restart to use it.`; drawMenu(); return; }
  S.dispT = { mode: `${m.w} × ${m.h}`, left: r.seconds || 10, iv: setInterval(() => { if (!S.dispT) return; S.dispT.left--; if (S.dispT.left <= 0) { clearInterval(S.dispT.iv); S.dispT = null; S.dispMsg = 'No answer, so it went back to the old resolution.'; setTimeout(loadDisp, 1500); } drawMenu(); }, 1000) };
  if (M) M.idx = 0; drawMenu();
}
async function syncNow(kind) {
  if (S.syncBusy) return; S.syncBusy = true; S.syncMsg = ''; drawMenu();
  const r = await api.syncRun(kind); S.syncBusy = false; cfg = await api.getConfig();
  S.syncMsg = r.error || `Done: ${r.pushed} sent, ${r.pulled} received${r.conflicts ? `, ${r.conflicts} conflict${r.conflicts > 1 ? 's' : ''} kept aside` : ''}.`; drawMenu();
}
function enter(id) { if (id == 'install') window.instEnter(IC); if (id == 'drives') window.drvEnter(DC); if (id == 'tidy') { S.tidy = null; S.tidyMsg = ''; S.tidySure = false; } if (id == 'players') { S.prof = null; S.profMsg = ''; } if (id == 'netsync') { S.syncMsg = ''; api.shareGet().then(x => { S.share = x; if (M && M.stack[M.stack.length - 1] == 'netsync') drawMenu(); }); loadUp(); } if (id == 'engines') api.metaCount().then(n => { S.metaN = n; if (M && M.stack[M.stack.length - 1] == 'engines') drawMenu(); }); if (id == 'display') { S.dispMsg = ''; S.dispReboot = false; loadDisp(); } if (id == 'saves' || id == 'restore') { S.svSure = null; S.svMsg = ''; loadSaves(); } if (id == 'upload') loadUp(); if (id == 'updates') { S.updSure = null; S.updMsg = ''; S.updNew = null; api.updInfo().then(u => { S.upd = u; if (M && M.stack[M.stack.length - 1] == 'updates') drawMenu(); }); } if (id == 'check') loadCheck(); if (id == 'sound') api.getVolume().then(v => { S.vol = v; drawMenu(); }); }
function openMenu(id = 'main') { closePanel(); M = { stack: [id], idx: firstNav(id), edit: null }; enter(id); drawMenu(); }
function drawMenu() {
  const el = $('#menu'); if (!M) { el.classList.add('hid'); return; }
  el.classList.remove('hid');
  const id = M.stack[M.stack.length - 1]; let pg; try { pg = pageDef(id); } catch (e) { pg = { title: 'ERROR', items: [I('Page', id), I('Error', String(e && e.message || e)), I('Where', String((e && e.stack || '').split('\n')[1] || '').trim().slice(-90))] }; }
  const rows = pg.items.map((it, i) => {
    if (it.t == 'inf') return `<div class="mi inf"><span>${esc(it.label)}</span><em>${esc(it.val)}</em></div>`;
    let r = '';
    if (it.t == 'lnk') r = `<span>${esc(it.label)}</span><b>›</b>`;
    else if (it.t == 'act') r = `<span>${esc(it.label)}</span>`;
    else if (it.t == 'pic') { const sh = avShown(), pf = M.idx == i ? avFocus(sh) : -1; r = `<span>${esc(it.label)}</span><span class="pics">${sh.map((a, k) => `<span class="pk${cfg.avatar == a.id ? ' sel' : ''}${k == pf ? ' foc' : ''}" data-av="${a.id}" title="${a.name}">${avSvg(a.id, 40)}</span>`).join('')}<span class="pk more${pf == sh.length ? ' foc' : ''}" data-avmore="1" title="All pictures">ALL</span></span>`; }
    else if (it.t == 'cyc') r = `<span>${esc(it.label)}</span><em>${esc(it.val)}</em><b>‹ ›</b>`;
    else if (it.t == 'tog') r = `<span>${esc(it.label)}</span><i class="tg${it.val ? ' y' : ''}"></i>`;
    else if (it.t == 'sli') { const p = Math.round((it.val - it.min) / (it.max - it.min) * 100); r = `<span>${esc(it.label)}</span><span class="bar"><u style="width:${p}%"></u></span><em>${it.val}</em>`; }
    else { const ed = M.edit && M.edit.key == it.key, v = it.pwd ? ((it.key == 'raPass' ? (cfg.hasToken || cfg.hasPass) : it.key == 'raKey' ? cfg.hasKey : cfg[it.key]) ? (it.key == 'raPass' ? 'Signed in ✓' : '•••••••• (saved)') : 'not set') : (cfg[it.key] || 'not set');
      r = `<span>${esc(it.label)}</span>` + (ed ? `<input id="medit" type="${it.pwd ? 'password' : 'text'}" value="${it.pwd ? '' : esc(cfg[it.key] || '')}" placeholder="${it.pwd ? 'Paste new key, Enter to save' : ''}" spellcheck="false" autocomplete="off">` : `<em>${esc(v)}</em>`); }
    return `<button class="mi${i == M.idx ? ' on' : ''}" data-mi="${i}">${r}</button>`;
  }).join('');
  el.innerHTML = `<div class="cond mt">${pg.title}</div><div class="ml">${rows}</div><div class="mh">↑ ↓ Select · A / Enter Open · ← → Adjust · B / Esc Back</div>`;
  const e = $('#medit'); if (e) { e.focus(); e.select(); } else { const on = el.querySelector('.mi.on'); if (on) on.scrollIntoView({ block: 'nearest' });
    // Info rows can sit above the first thing you can select (System Check starts with many), so they were unreachable. On the first or last selectable row, scroll the list all the way to its end.
    const sel = pg.items.map((it, i) => it.t == 'inf' ? -1 : i).filter(i => i >= 0), ml = el.querySelector('.ml');
    if (sel.length && ml) { if (M.idx === sel[0]) { ml.scrollTop = 0; el.scrollTop = 0; } else if (M.idx === sel[sel.length - 1]) { ml.scrollTop = ml.scrollHeight; } } }
}
function applyAv() {
  const b = $('#avatar'); let h = $('#avh');
  if (!h) { h = document.createElement('div'); h.id = 'avh'; b.insertBefore(h, b.firstChild); }
  h.innerHTML = cfg.avatar ? avSvg(cfg.avatar, 48) : ''; b.classList.toggle('hasav', !!cfg.avatar);
  const pa = document.querySelector('#pbody .pav'); if (pa && cfg.avatar) pa.innerHTML = avSvg(cfg.avatar, 70);
}
async function pickAv(d, id) {
  const i = AVATARS.findIndex(a => a.id == cfg.avatar), n = id || AVATARS[((i < 0 ? (d > 0 ? -1 : 0) : i) + d + AVATARS.length) % AVATARS.length].id;
  tick(660); await set({ avatar: n }); applyAv(); renderProf(); applyAv();
}
async function saveEdit() {
  const k = M.edit.key, v = $('#medit').value.trim(); M.edit = null;
  if (k == '_newPlayer') { if (v) { const r = await api.profCreate(v, S.profAdopt !== false); S.profMsg = r.ok ? `Added ${v}${r.copied ? ` · copied ${r.copied} existing save${r.copied == 1 ? '' : 's'}` : ''}` : r.error; if (r.ok) { cfg = await api.getConfig(); } } S.prof = await api.profList(); drawMenu(); return; }
  if (k == 'raKey' || k == 'raPass') { if (v) { cfg = await api.setConfig({ [k]: v }); if (k == 'raPass') toast('RETROACHIEVEMENTS', cfg.loginError ? 'Sign-in failed' : 'Signed in to RetroArch', cfg.loginError || (cfg.profile && cfg.raUser && cfg.profile.toLowerCase() != cfg.raUser.toLowerCase() ? 'Menu > Players can rename your save folder to ' + cfg.raUser : 'Games will log in automatically')); } } else await set({ [k]: v });
  drawMenu(); if (k == 'raUser' || k == 'raKey') refreshRA(); if (k == 'romRoot') reload();
}
function menuAct(a) {
  if (M.edit) return;
  const pg = pageDef(M.stack[M.stack.length - 1]), it = pg.items[M.idx], nav = pg.items.map((x, i) => x.t == 'inf' ? -1 : i).filter(i => i >= 0);
  if ((a == 'up' || a == 'down') && nav.length) { const p = nav.indexOf(M.idx); M.idx = nav[(p + (a == 'up' ? -1 : 1) + nav.length) % nav.length]; tick(); drawMenu(); }
  else if (a == 'a' && it) {
    tick(660);
    if (it.t == 'pic') { const sh = avShown(), k = avFocus(sh); if (k >= sh.length) openAvl(); else pickAv(0, sh[k].id); }
    else if (it.t == 'lnk') { M.stack.push(it.go); M.idx = firstNav(it.go); enter(it.go); drawMenu(); }
    else if (it.t == 'act') it.fn(); else if (it.t == 'tog') it.set(!it.val); else if (it.t == 'cyc' && it.go) { M.stack.push(it.go); M.idx = it.start ? it.start() : firstNav(it.go); enter(it.go); drawMenu(); } else if (it.t == 'cyc') { if (it.opts && it.opts.length > 1) openCy(it); else it.next(); }
    else if (it.t == 'txt') { M.edit = { key: it.key }; drawMenu(); }
  }
  else if ((a == 'left' || a == 'right') && it) {
    if (it.t == 'pic') { const sh = avShown(), k = avFocus(sh); M.pf = Math.max(0, Math.min(sh.length, k + (a == 'left' ? -1 : 1))); if (M.pf != k) tick(); drawMenu(); }
    else if (it.t == 'sli') { it.set(Math.max(it.min, Math.min(it.max, it.val + (a == 'left' ? -it.step : it.step)))); drawMenu(); }
    else if (it.t == 'tog') it.set(!it.val); else if (it.t == 'cyc') (a == 'left' && it.prev ? it.prev : it.next)();
  }
  else if (a == 'b' || a == 'start') { if (M.stack.length > 1) { M.stack.pop(); M.idx = firstNav(M.stack[M.stack.length - 1]); } else M = null; drawMenu(); }
}

// ----- launching + scraper events -----
async function launch(g = cur(), connect) {
  if (!g || mode == 'game') return;
  LAST = g; if (LIBV) { LIBV = null; drawLib(); }
  mode = 'game'; before = new Set(((RA && RA.recent) || []).map(r => r.id));
  $('#gname').textContent = g.title; $('#game').classList.remove('hid');
  { const gb = $('#gbg') || document.createElement('div'), bx = $('#gbox') || document.createElement('img'), setBg = (u, blur) => { gb.style.backgroundImage = `url('${u}')`; gb.className = (blur ? 'blur ' : '') + 'on'; const gf = $('#gfill'); if (gf) { gf.style.setProperty('--gf', `url('${u}')`); gf.classList.add('on'); } };
    gb.className = ''; gb.style.backgroundImage = '';
    if (g.art) { bx.src = g.art; bx.style.display = 'block'; $('#game').classList.add('hasbox'); } else { bx.removeAttribute('src'); bx.style.display = 'none'; $('#game').classList.remove('hasbox'); }
    if (g.hero) setBg(g.hero); else if (g.art) setBg(g.art, true);
    if (!g.hero && api.bgGet && g.file && !String(g.file).startsWith('store:')) api.bgGet({ sys: g.sys, file: g.file, title: g.title }).then(u => { if (u && mode == 'game' && LAST === g) setBg(u); }).catch(() => {}); }
  const r = await api.launch({ file: g.file, system: g.sys, connect, core: g.core || (window.AndroidBridge && cfg.cores && cfg.cores[g.sys]) || undefined, title: g.title, gameId: g.gameId, pads: pads().map(p => cleanPad(p.id)) });
  if (!r.ok) { mode = 'home'; $('#game').classList.add('hid'); { const gf = $('#gfill'); if (gf) gf.classList.remove('on'); } toast('COULD NOT LAUNCH', r.error); }
}
api.onGameExit(async d => {
  mode = 'home'; $('#game').classList.add('hid'); { const gf = $('#gfill'); if (gf) gf.classList.remove('on'); }
  if (d.error) { toast('LAUNCH PROBLEM', String(d.error).slice(0, 300), d.log ? String(d.log).slice(0, 300) : 'Menu > System Check > Open last launch log'); return; }
  toast('WELCOME BACK', 'Syncing RetroAchievements…', '');
  if (LAST && LAST.file) { const now = Date.now(); for (const b of BASE) for (const x of b.games) if (x.file === LAST.file) x.stats = { ...(x.stats || {}), last: now }; rebuildSys(); refresh(); } // Last Played shows this session right away
  await new Promise(r => setTimeout(r, 4000));
  await refreshRA(); // no library rescan on exit: the list is already current and a network share walk is slow
  if (LAST && SYS[sys]) { const j = SYS[sys].games.findIndex(x => x.file === LAST.file); if (j >= 0) { setSel(j); paint(); } }
  const n = RA && RA.recent ? RA.recent.filter(r => !before.has(r.id)) : [];
  if (n.length) toast('ACHIEVEMENTS EARNED', `${n.length} new unlock${n.length > 1 ? 's' : ''}`, `+${n.reduce((a, r) => a + r.points, 0)} pts · ${n[0].title}`);
  else toast('SESSION ENDED', 'No new achievements', '');
});
api.onMusic(m => { S.music = m; if (panel == 'music') drawMusicPanel(); if (M && M.stack[M.stack.length - 1] == 'music') drawMenu(); });
api.getMusic().then(m => { S.music = m; });
api.onCfg(async () => { cfg = await api.getConfig(); applyPrompts(); applySizes(); theme(); await reload(); rebuildSys(); refresh(); drawMenu(); });
api.onScrape(s => { S.scrape = s; if (!s.run && s.res && !UPD) { UPD = { kind: 'scrapres', d: { res: s.res }, i: 0 }; drawUpd(); reload(); } if (!s.run) { S.msg = s.msg || `Done: ${s.found} new covers; checked ${s.total} games`; if (!s.msg) reload(); } if (M) drawMenu(); });

// ----- input -----
// ----- game info popup (Y): box art, description, details, achievements; Y again stars it -----
let IM = null;
function showInfo(g = cur()) {
  if (!g || g.lib) return;
  IM = { g }; tick(660); drawInfo();
  const ck = g.sys + ':' + norm(g.title); if (cfg.hasKey && RCNT[ck] === undefined) { wantCount(g, ck); setTimeout(() => { if (IM && IM.g === g) drawInfo(); }, 1500); }
}
function drawInfo() {
  const el = $('#ipop'); if (!IM) { el.classList.add('hid'); el.innerHTML = ''; return; }
  const g = IM.g, m = g.meta || {}, sn = (BASE.find(b => b.id === g.sys) || {}).name || '', star = favs.has(g.file);
  const chips = [String(m.genre || '').split(',').slice(0, 2).join(' · ').trim(), m.players && 'Players ' + m.players, m.dev, m.rating && '★ ' + Math.round(m.rating * 100) + '%'].filter(Boolean);
  const pr = RA && RA.progress && RA.progress[norm(g.title)], tot = RCNT[g.sys + ':' + norm(g.title)];
  let ach = '', pct = 0;
  if (pr) { ach = `<span class="gold">${pr.earned} of ${pr.total}</span> achievements`; pct = pr.total ? Math.round(pr.earned / pr.total * 100) : 0; }
  else if (tot > 0) ach = `<span class="gold">0 of ${tot}</span> achievements`;
  else if (tot === -1) ach = 'No achievements for this game';
  else if (!cfg.hasKey) ach = 'Sign in to RetroAchievements to see achievements';
  const played = g.stats && g.stats.plays ? `${g.stats.plays} play${g.stats.plays > 1 ? 's' : ''} · ${fmtTime(g.stats.secs)}` : '';
  const cover = g.art ? `<img src="${esc(g.art)}" alt="">` : `<span class="ct">${esc(g.title)}</span>`;
  const text = `<div class="ik">${esc(sn.toUpperCase())}${m.year ? ' · ' + esc(m.year) : ''}</div><div class="cond it">${esc(g.title)}</div>
${chips.length ? `<div class="dmc">${chips.map(x => `<span>${esc(x)}</span>`).join('')}</div>` : ''}
<div class="idesc">${m.desc ? esc(m.desc) : '<span class="dmn">No description yet. Open Menu > Features > Scrapers and run it to look up details for your games.</span>'}</div>
${ach ? `<div class="iach"><div class="irow"><span>${ach}</span><span>${esc(played)}</span></div>${pct || pr ? `<div class="abar"><u style="width:${pct}%"></u></div>` : ''}</div>` : (played ? `<div class="iach"><div class="irow"><span></span><span>${esc(played)}</span></div></div>` : '')}`;
  el.classList.remove('wide');
  el.innerHTML = `<div class="ibody"><div class="icv" style="background:${artBg(g)}">${cover}</div><div class="iinf">${text}</div></div>` + `
<div class="ift"><button class="pr" data-ia="a" style="color:var(--pa)"><i>A</i><span>PLAY</span></button><button class="pr" data-ia="y" style="color:var(--gold)"><i>Y</i><span>${star ? 'UNFAVORITE' : 'FAVORITE'}</span></button><button class="pr" data-ia="x" style="color:var(--acc)"><i>X</i><span>ACHIEVEMENTS</span></button><button class="pr" data-ia="b" style="color:var(--pb);margin-left:auto"><i>B</i><span>CLOSE</span></button></div>`;
  el.classList.remove('hid');
  el.querySelectorAll('img').forEach(i => i.addEventListener('error', () => { i.style.visibility = 'hidden'; }));
}
function infoAct(a) {
  if (!IM) return; const g = IM.g;
  if (a == 'b' || a == 'start') { IM = null; drawInfo(); tick(); return; }
  if (a == 'y') { toggleFav(g); drawInfo(); tick(); return; }
  if (a == 'a') { IM = null; drawInfo(); launch(g); return; }
  if (a == 'x') { IM = null; drawInfo(); showAch(g); return; }
  const d = document.querySelector('#ipop .idesc'); if (d && (a == 'up' || a == 'down')) d.scrollBy({ top: a == 'up' ? -70 : 70 });
}
// ----- achievements box (X) -----
const fmtDate = d => { const t = new Date(String(d).replace(' ', 'T') + 'Z'); return isNaN(t) ? String(d) : t.toLocaleDateString([], { year: 'numeric', month: 'short', day: 'numeric' }); };
async function showAch(g = cur()) {
  if (!g || g.lib) return;
  AM = { loading: true, g, idx: 0, filter: 'all' }; tick(660); drawAch();
  const r = await api.raGame({ sys: g.sys, title: g.title, gameId: g.gameId });
  if (!AM || AM.g !== g) return;
  AM = { ...AM, ...r, loading: false }; drawAch();
}
const achRows = () => AM && AM.list ? AM.list.filter(a => AM.filter == 'all' || (AM.filter == 'unlocked') == !!a.date) : [];
function drawAch() {
  const el = $('#apop'); if (!AM) { el.classList.add('hid'); return; }
  el.classList.remove('hid'); const b = $('#abody');
  if (AM.loading) { b.innerHTML = `<div class="cond at">${esc(AM.g.title)}</div><div class="note">Loading achievements…</div>`; return; }
  if (AM.error) { b.innerHTML = `<div class="cond at">${esc(AM.g.title)}</div><div class="note">${esc(AM.error)}</div><div class="ah2">B Close</div>`; return; }
  const rows = achRows(), pct = AM.total ? Math.round(AM.earned / AM.total * 100) : 0;
  AM.idx = Math.max(0, Math.min(AM.idx, rows.length - 1));
  b.innerHTML = `<div class="ah">${AM.icon ? `<img src="${esc(AM.icon)}" alt="">` : ''}<div><div class="cond at">${esc(AM.title)}</div><div class="as"><span class="gold">${AM.earned} of ${AM.total}</span> unlocked · ${AM.earnedPoints} / ${AM.points} points · ${pct}%</div></div></div>
<div class="abar"><u style="width:${pct}%"></u></div>
<div class="af">${[['all', 'All'], ['unlocked', 'Unlocked'], ['locked', 'Locked']].map(f => `<span class="${AM.filter == f[0] ? 'on' : ''}">${f[1]}</span>`).join('')}</div>
<div class="alist">` + (rows.length ? rows.map((a, i) => `<div class="ar ${a.date ? 'u' : 'l'}${i == AM.idx ? ' sel' : ''}"><img src="${esc(a.badge)}" alt=""><div><div class="n">${esc(a.title)}</div><div class="d">${esc(a.desc)}</div>${a.date ? `<div class="d" style="color:var(--gold)">Unlocked ${esc(fmtDate(a.date))}${a.hard ? ' · Hardcore' : ''}</div>` : ''}</div><div class="p"><b>${a.points}</b>pts</div></div>`).join('') : '<div class="note">Nothing in this filter.</div>') +
    `</div><div class="ah2">↑ ↓ Browse · ← → Filter · B / X Close</div>`;
  b.querySelectorAll('img').forEach(i => i.addEventListener('error', () => { i.style.visibility = 'hidden'; }));
  const s = b.querySelector('.ar.sel'); if (s) s.scrollIntoView({ block: 'nearest' });
}
function amAct(a) {
  if (a == 'b' || a == 'x' || a == 'start') { AM = null; drawAch(); return; }
  if (!AM || !AM.list) return;
  const rows = achRows(), F = ['all', 'unlocked', 'locked'];
  if (a == 'up') AM.idx = Math.max(0, AM.idx - 1); else if (a == 'down') AM.idx = Math.min(rows.length - 1, AM.idx + 1);
  else if (a == 'left' || a == 'lb') { AM.filter = F[(F.indexOf(AM.filter) + 2) % 3]; AM.idx = 0; }
  else if (a == 'right' || a == 'rb') { AM.filter = F[(F.indexOf(AM.filter) + 1) % 3]; AM.idx = 0; }
  else if (a == 'jl') AM.idx = Math.max(0, AM.idx - 5); else if (a == 'jr') AM.idx = Math.min(rows.length - 1, AM.idx + 5);
  else return;
  tick(); drawAch();
}
function panelAct(a) {
  const bs = panelBtns();
  if (a == 'b' || a == 'start') { closePanel(); return; }
  if (!bs.length) { if (a == 'a') closePanel(); return; }
  if (a == 'left' || a == 'right' || a == 'up' || a == 'down') { const n = panelMove(bs, Math.min(pIdx, bs.length - 1), a); if (n != pIdx) { pIdx = n; tick(); focusPaint(); } }
  else if (a == 'a') bs[Math.min(pIdx, bs.length - 1)].click();
}
// Arrow keys move in the direction they point (up/down jump between rows, left/right along a row), by where the buttons sit on screen.
function panelMove(bs, cur, a) {
  const R = bs.map(b => b.getBoundingClientRect()), me = R[cur], horiz = a == 'left' || a == 'right', sgn = a == 'left' || a == 'up' ? -1 : 1;
  const cx = r => (r.left + r.right) / 2, cy = r => (r.top + r.bottom) / 2;
  const sameRow = (r, q) => Math.min(r.bottom, q.bottom) - Math.max(r.top, q.top) > Math.min(r.height, q.height) * 0.4;
  const pick = (ok, score) => { let best = -1, bsc = Infinity; R.forEach((r, i) => { if (i == cur || !ok(r)) return; const sc = score(r); if (sc < bsc) { bsc = sc; best = i; } }); return best; };
  let n;
  if (horiz) {
    n = pick(r => sameRow(me, r) && (cx(r) - cx(me)) * sgn > 2, r => Math.abs(cx(r) - cx(me)));
    if (n < 0) n = pick(r => sameRow(me, r) && (cx(r) - cx(me)) * sgn < -2, r => -Math.abs(cx(r) - cx(me))); // wrap along the row
  } else {
    const beyond = r => sgn > 0 ? r.top >= me.bottom - me.height * 0.3 && !sameRow(me, r) : r.bottom <= me.top + me.height * 0.3 && !sameRow(me, r);
    n = pick(beyond, r => Math.abs(cy(r) - cy(me)) + Math.abs(cx(r) - cx(me)) * 2.5);
    if (n < 0) { const back = r => sgn > 0 ? r.bottom <= me.top + me.height * 0.3 && !sameRow(me, r) : r.top >= me.bottom - me.height * 0.3 && !sameRow(me, r); n = pick(back, r => Math.abs(cx(r) - cx(me)) * 2.5 - Math.abs(cy(r) - cy(me))); } // wrap to the far end
  }
  return n >= 0 ? n : cur;
}
function act(a) {
  if (mode == 'game') return;
  if (UPD) { updAct(a); return; }
  if (SR) { srAct(a); return; }
  if (WF) { wfAct(a); return; }
  if (CT) { ctAct(a); return; }
  if (FR) { frAct(a); return; }
  if (PP) { ppAct(a); return; }
  if (FX) { fxAct(a); return; }
  if (IM) { infoAct(a); return; }
  if (AM) { amAct(a); return; }
  if (PO) { poAct(a); return; }
  if (CY) { cyAct(a); return; }
  if (AVL) { avlAct(a); return; }
  if (STORE) { storeAct(a); return; }
  if (ELIB) { elibAct(a); return; }
  if (LIBV) { libAct(a); return; }
  if (M) { menuAct(a); return; }
  if (panel) { panelAct(a); return; }
  if (a == 'start') { openMenu(); return; }
  if (zone == 'top') {
    if (a == 'left') { topIdx = Math.max(0, topIdx - 1); tick(); }
    else if (a == 'right') { topIdx = Math.min(TOP().length - 1, topIdx + 1); tick(); }
    else if (a == 'down') { zone = lay() === 'dash' ? 'games' : 'tabs'; tick(); }
    else if (a == 'b') { zone = 'games'; tick(); }
    else if (a == 'a') { tick(660); $(TOP()[topIdx]).click(); return; }
    focusPaint(); return;
  }
  if (zone == 'tabs' && vtabs()) {
    if (a == 'up') { if (sys === 0) { zone = 'top'; tick(); focusPaint(); } else setSys(-1); return; }
    if (a == 'down') { setSys(1); return; }
    if (a == 'lb') { setSys(-1); return; } if (a == 'rb') { setSys(1); return; }
    if (a == 'right' || a == 'a' || a == 'b') { zone = 'games'; tick(); focusPaint(); } return;
  }
  if (zone == 'tabs') {
    if (a == 'left' || a == 'lb') { setSys(-1); return; }
    if (a == 'right' || a == 'rb') { setSys(1); return; }
    if (a == 'up') zone = 'top'; else if (a == 'down' || a == 'a' || a == 'b') zone = 'games'; else return;
    tick(); focusPaint(); return;
  }
  if (lay() === 'dash') { dashAct(a); return; }
  if (layNav(a)) return;
  if (a == 'up') { zone = 'tabs'; tick(); focusPaint(); return; }
  if (a == 'left') move(-1); else if (a == 'right') move(1); else if (a == 'a') { cur() && cur().lib ? openLib() : launch(); } else if (a == 'y') showInfo(); else if (a == 'x') showAch(); else if (a == 'sel') rand();
  else if (a == 'lb') setSys(-1); else if (a == 'rb') setSys(1); else if (a == 'jl') jump(-1); else if (a == 'jr') jump(1);
}
document.addEventListener('click', async e => {
  const mb = e.target.closest('[data-mbar]'); if (mb) { const r = mb.getBoundingClientRect(), p = Math.max(0, Math.min(100, Math.round(100 * (e.clientX - r.left) / r.width))); api.music((mb.dataset.mbar == 'vol' ? 'vol:' : 'seek:') + p); return; }
  if (e.target.closest('[data-ctmenu]')) { closePanel(); M = { stack: ['main', 'ctrl'], idx: 0, edit: null }; drawMenu(); return; }
  if (IM) { const t = e.target.closest('[data-ia]'); if (t) infoAct(t.dataset.ia); else if (!e.target.closest('#ipop')) infoAct('b'); return; }
  if (CY) { const t = e.target.closest('[data-cy]'); if (t) { CY.i = +t.dataset.cy; cyAct('a'); } else if (!e.target.closest('.cyp')) cyAct('b'); return; }
  if (e.target.closest && e.target.closest('#tjump')) { openSysJump(); return; }
  if (AVL) { const t = e.target.closest('[data-avl]'); if (t) { AVL.rows.forEach((x, ri) => { const ci = x.ids.indexOf(t.dataset.avl); if (ci >= 0) { AVL.r = ri; AVL.c = ci; } }); avlAct('a'); return; } if (e.target.closest('[data-avlb]')) avlAct('b'); return; }
  if (e.target.closest('[data-avmore]') && M) { openAvl(); return; }
  const av = e.target.closest('[data-av]'); if (av && M) { M.idx = Math.max(0, pageDef(M.stack[M.stack.length - 1]).items.findIndex(x => x.t == 'pic')); pickAv(0, av.dataset.av); return; }
  if (PO && PO.ap && !e.target.closest('.poapop')) { PO.ap = false; tick(); drawPO(); return; }
  const b = e.target.closest('button');
  if (!b) { if (panel && !e.target.closest('.pop')) closePanel(); return; }
  const d = b.dataset;
  if (d.mi != null) { if (M) { M.idx = +d.mi; menuAct('a'); } }
  else if (d.i != null) { const i = +d.i; if (i == getSel()) act('a'); else { setSel(i); paint(); } }
  else if (d.sys != null) { sys = +d.sys; refresh(); }
  else if (d.up) { if (UPD) updDo(d.up); }
  else if (d.lr) loadLobby(true);
  else if (d.lh) { try { localStorage.setItem('lbHideLocked', lbHide() ? '0' : '1'); } catch {} tick(); drawLobby(); }
  else if (d.j != null) joinRoom(+d.j);
  else if (d.w) wifiAct(d.w);
  else if (d.m) musicAct(d.m);
  else if (d.rg != null) { const g = RG && RG.games && RG.games[+d.rg]; if (g) { closePanel(); showAch({ title: g.title, gameId: g.gameId }); } }
  else if (d.lg != null) { if (LIBV) { const i = +d.lg; if (i == LIBV.idx) libAct('a'); else { LIBV.idx = i; paintLib(); } } }
  else if (d.lb) libAct('b')
  else if (d.pob) poAct('b')
  else if (d.poa !== undefined) { PO.ai = +d.poa; PO.ap = true; tick(); drawPO(); }
  else if (d.poax) { PO.ap = false; tick(); drawPO(); }
  else if (d.pot) { PO.tab = d.pot; tick(); drawPO(); if (PO.tab == 'lb' && PO.d) poLbLoad(); }
  else if (d.pov) { PO.view = d.pov; tick(); poLbLoad(); }
  else if (d.pobd != null) { PO.bi = +d.pobd; poLoadEntries(); }
  else if (d.pog) poAct('x')
  else if (d.pom) { PO.mode = d.pom; poLoadEntries(); }
  else if (d.fo) { closePanel(); openFX(d.fo); }
  else if (d.ft) { FTAB = d.ft; tick(); drawFriends(); }
  else if (d.fadd) { FADD = true; drawFriends(); }
  else if (d.pp != null) { const i = +d.pp; if (PP && i == PP.idx) ppPick(i); else if (PP) { PP.idx = i; tick(); drawPP(); } }
  else if (d.fxm != null) fxMenu(+d.fxm)
  else if (d.fxg != null) { if (+d.fxg == FX.gi && FX.view == 'cmp') fxAct('a'); else { FX.gi = +d.fxg; fxLoadDet(); } }
  else if (d.fxb) fxAct('b')
  else if (d.fr != null) frRun(+d.fr)
  else if (d.frk != null) frPress(+d.frk, +d.frc)
  else if (d.elb) elibAct('b')
  else if (d.stb != null) { if (STORE) storeAct('b'); }
  else if (d.st != null) { if (STORE) { const i = +d.st; if (i == STORE.idx) storeAct('a'); else { STORE.idx = i; drawStore(); } } }
  else if (d.el != null) { if (ELIB) { const i = +d.el; if (i == ELIB.idx) elibAct('a'); else { ELIB.idx = i; drawElib(); } } }
  else if (d.a == 'menu-ra') openMenu('ra');
  else if (d.a == 'menu-po') { closePanel(); openPO(); }
  else if (d.a == 'menu-recent') togglePanel('recent');
  else if (d.a && d.a.startsWith('p-')) togglePanel(d.a.slice(2));
  else if (d.a) act(d.a);
  else if (b.id == 'avatar') { if (!M) togglePanel('prof'); }
  else if (b.id == 'trophy') { if (!M) togglePanel('recent'); }
  else if (b.id == 'discord') { if (!M) togglePanel('discord'); }
  else if (b.id == 'srch') { if (!M) openSearch('games'); }
  else if (b.id == 'music') { if (!M) togglePanel('music'); }
  else if (b.id == 'lobby') { if (!M) togglePanel('lobby'); }
  else if (b.id == 'wifi') { if (!M) togglePanel('wifi'); }
  else if (b.id == 'pads') { if (!M) togglePanel('pads'); }
  else if (b.id == 'gear') { M ? (M = null, drawMenu()) : openMenu(); }
});
// click outside a popup to close it, the same as pressing Esc / B
addEventListener('mousedown', e => {
  if (e.button !== 0 || !e.target || !e.target.closest) return;
  if (e.target.closest('.hb, #gear, #toast, #scanbar, input, textarea, select')) return;
  const vis = id => { const el = document.getElementById(id); return el && !el.classList.contains('hid') ? el : null; };
  const inside = (el, sel) => { const box = sel ? el.querySelector(sel) : el; return !box || box.contains(e.target); };
  const swallow = () => { const f = ev => { ev.stopPropagation(); ev.preventDefault(); }; addEventListener('click', f, { capture: true, once: true }); setTimeout(() => removeEventListener('click', f, true), 600); };
  const esc = () => { swallow(); e.preventDefault(); e.stopPropagation(); dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true, cancelable: true })); };
  let el;
  if ((el = vis('upop'))) { if (!inside(el, '.dp')) esc(); return; }
  if ((el = vis('cypop'))) { if (!inside(el, '.dp')) esc(); return; }
  if ((el = vis('menu'))) { if (!el.contains(e.target)) { swallow(); e.preventDefault(); e.stopPropagation(); M = null; drawMenu(); } return; }
  for (const id of ['apop', 'ipop', 'prof', 'wpop', 'ppop', 'lpop', 'mpop', 'dpop', 'rpop']) { if ((el = vis(id))) { if (!el.contains(e.target)) esc(); return; } }
}, true);
addEventListener('keydown', e => {
  if (SR) { srKey(e); return; }
  if (WF) { wfKey(e); return; }
  if (CT) { ctKey(e); return; }
  if (e.target.id == 'fadd') { if (e.key == 'Enter') { e.preventDefault(); friendAdd(e.target.value); } else if (e.key == 'Escape') { e.preventDefault(); FADD = false; drawFriends(); } return; }
  if (FR && FR.field) { frKeyDown(e); return; }
  if (e.target.id == 'medit') { if (e.key == 'Enter') { e.preventDefault(); saveEdit(); } else if (e.key == 'Escape') { M.edit = null; drawMenu(); } return; }
  if (e.target.tagName == 'INPUT' || mode == 'game' || OVL) return;
  const k = e.code || (e.key && e.key.length == 1 ? (/[a-z]/i.test(e.key) ? 'Key' + e.key.toUpperCase() : e.key == ' ' ? 'Space' : e.key == '/' ? 'Slash' : '') : e.key); // Android keyboards and d-pads can leave code empty
  if (!M && !panel && !CY && k == 'KeyJ' && mode == 'home') { e.preventDefault(); openSysJump(); return; }
  if (!M && !panel) { if (k == 'Slash' || k == 'KeyF') { e.preventDefault(); openSearch('games'); return; } if (k == 'KeyP') { togglePanel('prof'); return; } if (k == 'KeyW') { togglePanel('wifi'); return; } if (k == 'KeyC') { togglePanel('pads'); return; } if (k == 'KeyL') { togglePanel('lobby'); return; } if (k == 'KeyN') { togglePanel('music'); return; } if (k == 'KeyT') { togglePanel('recent'); return; } }
  if (k == 'Enter' || k == 'Space') { if (e.target.closest && e.target.closest('button')) return; e.preventDefault(); act('a'); return; }
  const m = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down', Escape: 'b', KeyY: 'y', KeyX: 'x', KeyR: 'sel', KeyQ: 'lb', PageUp: 'lb', KeyE: 'rb', PageDown: 'rb', BracketLeft: 'jl', BracketRight: 'jr', KeyS: 'start', KeyM: 'start' };
  if (m[k]) { e.preventDefault(); act(m[k]); }
});
const BN = { 0: 'A', 1: 'B', 2: 'X', 3: 'Y', 4: 'LB', 5: 'RB', 6: 'LT', 7: 'RT', 8: 'Back', 9: 'Start', 10: 'L3', 11: 'R3', 12: 'D-pad Up', 13: 'D-pad Down', 14: 'D-pad Left', 15: 'D-pad Right', 16: 'Home' };
const MAP = { 12: 'up', 13: 'down', 14: 'left', 15: 'right', 0: 'a', 1: 'b', 2: 'x', 3: 'y', 4: 'lb', 5: 'rb', 6: 'jl', 7: 'jr', 8: 'sel', 9: 'start' };
let prevP = {}, lastAx = 0, lastN = -1, OVL = false; // OVL: the music overlay is open, so ignore input here
api.onOverlay(v => { OVL = !!v; });
function padCount() { const n = pads().length; if (n !== lastN) { lastN = n; $('#padn').textContent = n; if (panel == 'pads') drawPads(); if (M) drawMenu(); } }
addEventListener('gamepadconnected', e => { padCount(); toast('CONTROLLER CONNECTED', cleanPad(e.gamepad.id).slice(0, 30), `Player ${e.gamepad.index + 1}`); });
addEventListener('gamepaddisconnected', e => { padCount(); toast('CONTROLLER DISCONNECTED', cleanPad(e.gamepad.id).slice(0, 30), ''); });
function poll() {
  padCount(); const now = performance.now();
  for (const gp of pads()) {
    const pv = prevP[gp.index] = prevP[gp.index] || {};
    for (let i = 0; i < gp.buttons.length; i++) {
      const p = gp.buttons[i].pressed;
      if (p && !pv[i]) { lastBtn = `${BN[i] || 'Button ' + i} (Player ${gp.index + 1})`; if (panel == 'pads') drawPads(); if (nativePad) {} else if (CT && CT.view == 'map') ctPadPress(cleanPad(gp.id), i); else if (!OVL) { const a = padActFor(cleanPad(gp.id), i); if (a) act(a); } }
      pv[i] = p;
    }
    const ax = gp.axes[0] || 0, ay = gp.axes[1] || 0;
    if (!OVL && !nativePad && now - lastAx > 200) { if (Math.abs(ax) > .6) { lastAx = now; act(ax < 0 ? 'left' : 'right'); } else if (Math.abs(ay) > .6) { lastAx = now; act(ay < 0 ? 'up' : 'down'); } }
  }
  requestAnimationFrame(poll);
}
poll();

// ----- Friends: the people you follow on RetroAchievements, their status, achievements, and a comparison with you -----
let FL = null, FSUM = {}, FTAB = 'ra', FADD = false, FMSG = '', FNEED = false;
const DCS = { state: 'off' }; // Discord link: on | hidden | retry | off. Discord sign-in is not built yet, so this stays 'off'.
const DST = { on: ['gr', 'Connected', 'Discord is linked and your game status is showing.'], hidden: ['y', 'Status hidden', 'Linked, but "Show my game status" is off.'], retry: ['r', 'Reconnecting', 'The link dropped. Cacti OS retries on its own.'], off: ['g', 'Not connected', 'Discord sign-in is not available in this build yet. When it is, your game shows as your Discord status and Discord friends list here. Cacti OS only handles status and friends, never messages.'] };
function setDot() { const d = $('#dstat'); if (d) { d.className = 'sdot ' + DST[DCS.state][0]; d.style.display = DCS.state == 'off' ? 'none' : ''; } const b = $('#discord'); if (b) b.title = 'Friends · Discord: ' + DST[DCS.state][1]; }
const avt = (u, sz = 34) => `<span class="fa" style="width:${sz}px;height:${sz}px;font-size:${Math.round(sz / 3)}px;background:hsl(${hue(u)} 55% 70%)">${esc(u.slice(0, 2).toUpperCase())}<img src="https://media.retroachievements.org/UserPic/${encodeURIComponent(u)}.png" alt=""></span>`;
const agoT = t => { const m = Math.max(1, Math.round((Date.now() - t) / 60000)); return m < 60 ? m + 'm ago' : m < 1440 ? Math.round(m / 60) + 'h ago' : Math.round(m / 1440) + 'd ago'; };
function presTxt(s) {
  if (!s) return ''; const t = s.date ? Date.parse(String(s.date).replace(' ', 'T') + 'Z') : 0;
  if (t && Date.now() - t < 15 * 60e3 && s.game) return 'Playing now · ' + s.game;
  return s.game ? 'Last played ' + s.game + (t ? ' · ' + agoT(t) : '') : (t ? 'Active ' + agoT(t) : '');
}
function wireImgs(el) { el.querySelectorAll('img').forEach(i => i.addEventListener('error', () => { i.style.visibility = 'hidden'; })); }
function drawFriends() {
  const el = $('#dbody'), chip = (k, l) => `<button class="sbtn${FTAB == k ? ' on' : ''}" data-ft="${k}">${l}</button>`;
  const dcOn = DCS.state != 'off'; if (!dcOn) FTAB = 'ra';
  let h = dcOn ? `<div class="pbtns">${chip('ra', 'RETROACHIEVEMENTS')}${chip('dc', 'DISCORD')}</div>` : '';
  if (FTAB == 'ra') {
    if (!FL) h += '<div class="note">Loading the people you follow…</div>';
    else if (FL.error) h += `<div class="note">${esc(FL.error)}</div>`;
    else h += FL.friends.length ? FL.friends.map(f => `<button class="row frow" data-fo="${esc(f.user)}">${avt(f.user)}<span style="flex:1;min-width:0"><b class="rt">${esc(f.user)}${f.back ? ' ⇄' : ''}</b><span class="rg">${esc(presTxt(FSUM[f.user]) || 'Select to see their achievements')}</span></span><span class="fpts">${f.points.toLocaleString()}</span></button>`).join('') : '<div class="note">You are not following anyone yet. Use Add by username, or press Follow on a player\'s profile at retroachievements.org.</div>';
    h += FADD ? '<div class="faddr"><input id="fadd" placeholder="RetroAchievements username, Enter to check" spellcheck="false" autocomplete="off"></div>' : '<button class="row frow" data-fadd="1"><span style="flex:1">+ ADD BY USERNAME</span><span>›</span></button>';
    h += `<div class="note">${esc(FMSG || 'People you follow on RetroAchievements. ⇄ follows you back.')}</div>`;
  } else { const d = DST[DCS.state]; h += `<div class="frow2"><i class="sdot ${d[0]}"></i><b>${d[1]}</b></div><div class="note">${esc(d[2])}</div>`; }
  el.innerHTML = h; wireImgs(el); const i = $('#fadd'); if (i) i.focus();
}
async function loadFriends(force) {
  const r = await api.friends(!!force); FL = r; if (panel == 'discord') drawFriends();
  if (r && r.friends && r.friends.length) { const s = await api.friendSummaries(r.friends.slice(0, 12).map(f => f.user)); FSUM = { ...FSUM, ...(s || {}) }; if (panel == 'discord') drawFriends(); }
}
async function friendAdd(v) {
  FADD = false; FMSG = 'Checking…'; drawFriends(); const r = await api.friendAdd(String(v || '').trim());
  FMSG = r && r.ok ? `Opened ${r.user}'s profile in your browser. Press Follow there. They appear here within 30 minutes.` : (r && r.error) || 'Could not check that name.'; if (r && r.ok) FNEED = true; drawFriends();
}
// Friend screens: a small menu, then their achievements or a comparison with yours
function openFX(user) {
  FX = { user, view: 'menu', idx: 0, games: null, gi: 0, det: null, busy: '', req: 0, row: null, sum: null }; tick(660); drawFX();
  api.friends(false).then(r => { if (FX && FX.user == user && r && r.friends) { FX.row = r.friends.find(f => f.user == user) || null; drawFX(); } });
  api.friendSummaries([user]).then(s => { if (FX && FX.user == user) { FX.sum = s && s[user]; drawFX(); } });
}
const fxKey = t => String(t || '').toLowerCase().replace(/^(.*), (the|a|an)\b(.*)$/, '$2 $1$3').replace(/~[^~]*~/g, '').replace(/[\(\[][^\)\]]*[\)\]]/g, '').replace(/&/g, 'and').replace(/[^a-z0-9]+/g, ' ').trim();
function fxLocal(g) { const k = fxKey(g.title); for (const s of BASE) for (const x of s.games) if ((g.gameId && x.gameId && String(x.gameId) == String(g.gameId)) || fxKey(x.title) == k) return x; return null; }
const fxList = () => FX && FX.games && FX.games.them ? (FX.view == 'cmp' ? FX.games.shared : FX.games.them) : [];
async function fxView(v) { FX.view = v; FX.gi = 0; FX.det = null; drawFX(); if (!FX.games) { FX.busy = 'Loading their games…'; drawFX(); const r = await api.friendGames(FX.user); if (!FX) return; FX.busy = ''; FX.games = r; } drawFX(); fxLoadDet(); }
async function fxLoadDet() {
  const g = fxList()[FX.gi]; FX.det = null; const my = ++FX.req; drawFX(); if (!g) return;
  const r = await api.friendGame({ user: FX.user, gameId: g.gameId }); if (!FX || FX.req !== my) return; FX.det = r; drawFX();
}
function fxMenu(i) { if (i == 0) fxView('ach'); else if (i == 1) fxView('cmp'); else { api.friendOpen(FX.user); toast('PROFILE', FX.user, 'Opened in your browser'); } }
function fxAct(a) {
  if (a == 'b' || a == 'start') { if (FX.view != 'menu') { FX.view = 'menu'; FX.idx = 0; } else FX = null; tick(); drawFX(); return; }
  if (FX.view == 'menu') { if (a == 'up') FX.idx = Math.max(0, FX.idx - 1); else if (a == 'down') FX.idx = Math.min(2, FX.idx + 1); else if (a == 'a') { fxMenu(FX.idx); return; } tick(); drawFX(); return; }
  const n = fxList().length;
  if (a == 'up' || a == 'down') { const g = Math.max(0, Math.min(n - 1, FX.gi + (a == 'up' ? -1 : 1))); if (g != FX.gi) { FX.gi = g; tick(); fxLoadDet(); } }
  else if (a == 'a') { const g = fxList()[FX.gi], lg = g && fxLocal(g); if (!g) return; if (!lg) { toast('NOT IN YOUR LIBRARY', g.title.slice(0, 40), 'No matching ROM was found in your games folder.'); return; } FX = null; drawFX(); launch(lg); }
  else if (a == 'left' || a == 'right') { const d = $('#fxdet'); if (d) d.scrollBy({ top: (a == 'left' ? -1 : 1) * 240, behavior: 'smooth' }); }
}
function fxTile(l, a, b) { const f = x => Number(x || 0).toLocaleString(); return `<div class="fxt"><span class="l">${l}</span><b class="${a >= b ? 'w' : ''}">${f(a)}</b><b class="${b > a ? 'w' : ''}">${f(b)}</b><small>YOU</small><small>${esc(FX.user.toUpperCase().slice(0, 14))}</small></div>`; }
function fxRows(both) {
  const d = FX.det; if (!d) return '<div class="note">Loading…</div>'; if (d.error) return `<div class="note">${esc(d.error)}</div>`;
  const dt = x => x ? String(x).slice(0, 10) : '', cell = x => x ? `<span class="ok">✓ <small>${esc(dt(x))}</small></span>` : '<span class="no">locked</span>';
  return `<div class="ar${both ? '' : ' one'} hd"><span></span><span>ACHIEVEMENT</span>${both ? `<span>YOU</span><span>${esc(FX.user.toUpperCase().slice(0, 12))}</span>` : '<span>STATUS</span>'}</div>` + d.list.map(a => `<div class="ar${both ? '' : ' one'}"><img src="${esc(a.badge)}" alt=""><span>${esc(a.title)}<small>${a.points} points · ${esc(a.desc || '')}</small></span>${both ? cell(a.me) + cell(a.them) : cell(a.them)}</div>`).join('');
}
function drawFX() {
  const el = $('#fx'); if (!FX) { el.classList.add('hid'); el.innerHTML = ''; return; }
  el.classList.remove('hid'); const u = FX.user, v = FX.view;
  el.className = 'abs ' + (v == 'menu' ? 'menuv' : 'fullv');
  if (v == 'menu') {
    const row = FX.row, s = FX.sum, items = [['See their achievements', '›'], ['Compare with me', '›'], ['Open their profile on RetroAchievements', '↗']];
    el.innerHTML = `<div class="fxm pop"><div style="display:flex;gap:18px;align-items:center;margin-bottom:12px">${avt(u, 84)}<div><div class="cond" style="font-size:38px;line-height:1">${esc(u)}</div><div class="pogold">${row ? row.points.toLocaleString() + ' HARDCORE POINTS' : ''}</div></div></div>
<div class="note" style="padding:0 0 12px">${esc(presTxt(s) || 'No recent activity')}${s && s.presence ? ' · ' + esc(s.presence) : ''}${row ? (row.back ? ' · follows you' : ' · does not follow you') : ''}</div>
<div style="display:flex;flex-direction:column;gap:8px">${items.map((it, i) => `<button class="fxmi${FX.idx == i ? ' on' : ''}" data-fxm="${i}">${it[0]}<b>${it[1]}</b></button>`).join('')}</div><div class="lk" style="margin-top:12px">↑ ↓ Choose · A Select · B Back</div></div>`;
    wireImgs(el); return;
  }
  const head = `<div class="fxh">${avt(u, 50)}<div class="cond lt">${v == 'ach' ? esc(u) + '’s achievements' : 'You vs ' + esc(u)}</div><button class="lback" data-fxb="1">B BACK</button></div>`;
  const G = FX.games, list = fxList(), start = Math.max(0, Math.min(FX.gi - 5, list.length - 11)), vis = list.slice(start, start + 11);
  const gl = FX.busy ? `<div class="note">${esc(FX.busy)}</div>` : G && G.error ? `<div class="note">${esc(G.error)}</div>` : !list.length ? `<div class="note">${v == 'cmp' ? 'You have no games in common yet.' : 'No games yet.'}</div>` :
    vis.map((g, k) => { const i = start + k; return `<button class="gr${i == FX.gi ? ' on' : ''}" data-fxg="${i}"><img src="${esc(g.icon)}" alt=""><span class="t">${esc(g.title)}<small>${esc(g.console)}</small></span><span class="bars">${v == 'cmp' ? `<u><i style="width:${g.total ? Math.round(100 * g.mine / g.total) : 0}%"></i></u><u class="th"><i style="width:${g.total ? Math.round(100 * g.earned / g.total) : 0}%"></i></u>` : `<u class="th"><i style="width:${g.total ? Math.round(100 * g.earned / g.total) : 0}%"></i></u>`}</span><span class="n">${v == 'cmp' ? g.mine + ' vs ' + g.earned + (g.mine > g.earned ? ' ▲' : g.mine < g.earned ? ' ▽' : '') : g.earned + ' of ' + g.total}</span></button>`; }).join('');
  const g = list[FX.gi], d = FX.det, tiles = v == 'cmp' && G && G.sumMe ? `<div class="fxc" style="margin-top:6px">${fxTile('ACHIEVEMENTS', G.sumMe.achievements, G.sumThem.achievements)}${fxTile('GAMES MASTERED', G.sumMe.mastered, G.sumThem.mastered)}${fxTile('GAMES BEATEN', G.sumMe.beaten, G.sumThem.beaten)}${fxTile('GAMES STARTED', G.sumMe.games, G.sumThem.games)}</div>` : '';
  const dh = g ? `<div class="cond" style="font-size:26px">${esc(g.title)}</div><div class="note" style="padding:0">${d && !d.error ? (v == 'cmp' ? `${d.meEarned} unlocked by you · ${d.themEarned} by ${esc(u)} · of ${d.total}` : `${d.themEarned} of ${d.total} unlocked by ${esc(u)}`) : ''}</div>` : '';
  el.innerHTML = head + tiles + `<div class="pob" style="height:${v == 'cmp' ? 520 : 650}px;margin-top:12px"><div class="pocol" style="width:${v == 'cmp' ? 560 : 500}px"><div class="pocard" style="flex:1;overflow:hidden"><div class="polbl">${v == 'cmp' ? 'GAMES YOU BOTH PLAY' : 'GAMES THEY HAVE PLAYED'}</div>${gl}${v == 'cmp' ? `<div class="note">Purple bar is you, gold is ${esc(u)}. ▲ you lead, ▽ they lead.</div>` : ''}</div></div><div class="pocol" style="flex:1"><div class="pocard" style="flex:1;overflow:hidden">${dh}<div id="fxdet">${g ? fxRows(v == 'cmp') : ''}</div></div></div></div><div class="lk" style="margin-top:6px">↑ ↓ Choose game · A Play it · ← → Scroll achievements · B Back</div>`;
  wireImgs(el);
}

// ----- Who's playing? shown after boot when there are two or more players -----
let PP = null;
const ppHue = n => { let h = 0; for (const ch of n) h = (h * 31 + ch.charCodeAt(0)) % 360; return h; };
function drawPP() {
  const el = $('#pp'); if (!PP) { el.classList.add('hid'); el.innerHTML = ''; return; }
  el.classList.remove('hid');
  el.innerHTML = `<div><div class="ppk">CACTI OS</div><h1 class="cond">Who\u2019s playing?</h1></div><div class="ppr">${PP.items.map((p, i) => `<button class="ppb${i == PP.idx ? ' on' : ''}" data-pp="${i}"><div class="ppring"><div class="ppav${p.guest ? ' g' : ''} cond" style="--h:${p.guest ? 0 : ppHue(p.name)}">${p.guest ? '?' : esc(p.name[0].toUpperCase())}</div></div><div class="ppn cond">${esc(p.name)}</div>${p.pts ? `<div class="pps" style="opacity:1;font-weight:600">${esc(p.pts)}</div>` : ''}<div class="pps">${esc(p.last)}${p.game ? '<br>' + esc(p.game.slice(0, 26)) : ''}</div></button>`).join('')}</div><div class="pph"><span><b>\u2190 \u2192</b> Choose</span><span><b>A</b> Play as this player</span></div>`;
}
async function openPP() {
  let r; try { r = await api.profPicker(); } catch { return; }
  if (!r || !r.ask) return;
  const ago = t => { const d = Math.floor((Date.now() - t) / 864e5); return d < 1 ? 'today' : d == 1 ? 'yesterday' : d < 7 ? d + ' days ago' : d < 30 ? Math.floor(d / 7) + (d < 14 ? ' week ago' : ' weeks ago') : 'a while ago'; };
  const items = r.players.map(p => ({ name: p.name, pts: p.points ? p.points.toLocaleString() + ' pts' : '', last: p.last ? 'Last played ' + ago(p.last.t) : 'Not played yet', game: p.last ? p.last.g : '', cur: p.name == r.current })).concat([{ name: 'Guest', pts: '', last: 'Saves are not kept', game: '', guest: true }]);
  PP = { items, idx: Math.max(0, items.findIndex(p => p.cur)) }; tick(660); drawPP();
}
async function ppPick(i) {
  if (!PP) return; const p = PP.items[i]; if (!p) return;
  const r = p.guest ? await api.profGuest() : await api.profUse(p.name);
  if (!r.ok) { toast('COULD NOT SWITCH', String(r.error || '').slice(0, 200), ''); return; }
  PP = null; drawPP(); cfg = await api.getConfig(); tick(); toast(p.guest ? 'GUEST' : 'WELCOME', p.guest ? 'Playing without saving' : p.name, ''); reload();
}
function ppAct(a) {
  const n = PP.items.length;
  if (a == 'left' || a == 'up') PP.idx = (PP.idx + n - 1) % n; else if (a == 'right' || a == 'down') PP.idx = (PP.idx + 1) % n; else if (a == 'a') { ppPick(PP.idx); return; } else return;
  tick(); drawPP();
}

// ----- First-run setup: games folder, emulators, BIOS, RetroAchievements, Discord. Everything but the games folder is optional. -----
const FRN = ['Welcome', 'Your games', 'Emulators', 'BIOS files', 'RetroAchievements', 'Ready'];
const FKB = ['1234567890', 'qwertyuiop', 'asdfghjkl-', 'zxcvbnm_.', '!@#$%&*+?='], FSP = ['SHIFT', 'DELETE', 'DONE'];
function openFR() {
  FR = { step: 0, sel: '', acts: [], cur: 0, chk: null, list: [], busy: '', msg: '', field: '', shift: false, kr: 0, kc: 0, prog: {}, user: cfg.raUser || '', pass: '', key: '', ra: cfg.hasKey && cfg.hasToken ? 2 : 0, err: '' };
  tick(660); drawFR(); frLoad();
}
async function frLoad() { const c = await api.check(), l = await api.emuList(); if (!FR) return; FR.chk = c; FR.list = l; drawFR(); }
function frGo(n) { FR.step = Math.max(0, Math.min(5, n)); FR.sel = ''; FR.msg = ''; tick(); drawFR(); if (FR.step == 2 || FR.step == 3 || FR.step == 1) frLoad(); }
const frB = (k, label, fn, o = {}) => { FR.acts.push({ k, fn, pri: !!o.pri, dis: !!o.dis }); return `<button class="frb${o.pri ? ' pri' : ''}" data-fr="${FR.acts.length - 1}"${o.dis ? ' disabled' : ''}>${label}</button>`; };
const frRow = (t, s, r) => `<div class="frw"><div class="t"><b>${esc(t)}</b><span>${esc(s)}</span></div>${r}</div>`;
const frPill = (t, c) => `<span class="frpill ${c || ''}">${t}</span>`;
function frNav(back, nextLabel, nextFn, dis) { return `<div class="fract">${back ? frB('back', 'BACK', () => frGo(FR.step - 1)) : ''}<span class="sp"></span>${frB('next', nextLabel, nextFn || (() => frGo(FR.step + 1)), { pri: true, dis })}</div>`; }
async function frPickRoms() { const p = await api.pick('folder'); if (!p || !FR) return; FR.busy = 'Scanning…'; drawFR(); cfg = await api.setConfig({ romRoot: p }); await reload(); FR.busy = ''; frLoad(); }
const FRV = [
  () => `<div class="lbl">STEP 1 OF 6</div><h1>Let's get you playing.</h1><p class="lead">Cacti OS needs a folder of games, the emulators that run them, any BIOS files, and, if you want them, your RetroAchievements and Discord. About three minutes.</p>
${frRow('Nothing is guessed', 'Only what your games need gets installed.', '')}${frRow('Everything but the games folder is optional', 'Skip anything and add it later from the menu. System Check shows what is missing.', '')}${frRow('No keyboard needed', 'Typing your login works with a controller too.', '')}
<div class="fract">${frB('skip', 'SKIP SETUP', async () => { try { cfg = await api.setConfig({ setupDone: true }); if (cfg.saveError) toast('SETTINGS NOT SAVED', String(cfg.saveError).slice(0, 70), String(cfg.cfgPath || '').slice(-60)); } catch (e) { cfg.setupDone = true; } FR = null; drawFR(); }) }<span class="sp"></span>${frB('next', 'START SETUP', () => frGo(1), { pri: true })}</div>`,
  () => {
    const c = FR.chk, ok = c && c.romRootOk, sy = c ? [...c.systems, ...(c.standalone || [])].filter(s => s.count) : [], tot = sy.reduce((n, s) => n + s.count, 0);
    if (!ok) return `<div class="lbl">STEP 2 OF 6</div><h1>Where are your games?</h1><p class="lead">Pick the folder that holds your ROMs. Cacti OS reads the subfolder names and file types. It never moves or changes your files.</p>${FR.busy ? frRow('Working', FR.busy, '') : ''}<div class="fract">${frB('back', 'BACK', () => frGo(0))}<span class="sp"></span>${frB('skip', 'SKIP FOR NOW', () => frGo(2))}${frB('pick', 'CHOOSE ROMS FOLDER', frPickRoms, { pri: true })}</div>`;
    return `<div class="lbl">STEP 2 OF 6</div><h1>${tot} game${tot == 1 ? '' : 's'} found.</h1><p class="lead">Folder: <b>${esc(c.romRoot)}</b>. Systems are recognized from subfolder names.</p><div class="frg">${sy.slice(0, 12).map(s => `<div><b>${s.count}</b><span>${esc(s.name.replace(/^Nintendo Entertainment System$/i, 'NES').toUpperCase())}</span></div>`).join('')}${sy.length > 12 ? `<div><b>+${sy.length - 12}</b><span>MORE SYSTEMS</span></div>` : ''}</div>${tot ? '' : frRow('No games yet', 'Put ROMs in subfolders like snes, gba or genesis, then choose the folder again.', '')}
<div class="fract">${frB('back', 'BACK', () => frGo(0))}<span class="sp"></span>${frB('pick', 'CHANGE FOLDER', frPickRoms)}${frB('next', 'CONTINUE', () => frGo(2), { pri: true })}</div>`;
  },
  () => {
    const c = FR.chk; if (!c) return `<div class="lbl">STEP 3 OF 6</div><h1>Install the emulators.</h1><p class="lead">Checking what is already installed…</p>`;
    const have = c.systems.filter(s => s.count), need = have.length ? have : c.systems, cOk = need.filter(s => s.coreOk).length, busy = !!FR.busy || Object.values(FR.prog).some(Boolean);
    let h = `<div class="lbl">STEP 3 OF 6</div><h1>Install the emulators.</h1><p class="lead">RetroArch runs most systems. PS2, GameCube, PSP and a few more use their own emulators. Install what you want now, the rest can wait for Menu › Store › Emulators.</p>`;
    h += frRow('RetroArch', c.retroarch.ok ? 'Found on this computer.' : (c.flatpak ? 'One click install with Flatpak. This can take a few minutes.' : 'One click install. This can take a few minutes.'), c.retroarch.ok ? frPill('INSTALLED', 'ok') : frB('ra', 'INSTALL', async () => { FR.busy = 'Installing RetroArch…'; drawFR(); const r = await api.installRetroArch(); if (!FR) return; FR.busy = ''; FR.msg = r.error || (r.opened ? 'Opened the download page. Install RetroArch, then come back and press CHECK AGAIN.' : 'RetroArch installed.'); await frLoad(); }, { dis: busy }));
    h += frRow('RetroArch cores', `${cOk} of ${need.length} installed for ${have.length ? 'your systems' : 'all systems'}. The best core for each system is the default. Installing downloads every core Cacti supports, so you can switch any time.`, cOk == need.length ? frPill('INSTALLED', 'ok') : frB('cores', 'INSTALL CORES', async () => { FR.busy = 'Downloading cores…'; drawFR(); const r = await api.installCores(); if (!FR) return; FR.busy = ''; FR.msg = r.fail.length ? `Installed ${r.ok}. Problem: ${r.fail[0]}` : `Installed ${r.ok} core${r.ok == 1 ? '' : 's'}.`; await frLoad(); }, { dis: busy || !c.retroarch.ok }));
    const seenE = new Set();
    for (const x of (c.standalone || []).filter(s => s.count && !s.via)) {
      const e = FR.list.find(z => z.id == x.emu); if (!e || seenE.has(e.id)) continue; seenE.add(e.id); const pr = FR.prog[e.id], inst = e.status == 'installed' || e.status == 'uptodate' || e.status == 'update';
      h += frRow(e.name, `${x.name} · ${x.count} game${x.count == 1 ? '' : 's'}${pr && pr.msg ? ' · ' + pr.msg : ''}`, e.status == 'unsupported' ? frPill('NOT FOR THIS DEVICE') : inst ? frPill('INSTALLED', 'ok') : frB('emu-' + e.id, e.canAuto ? 'INSTALL' : 'OPEN DOWNLOAD PAGE', async () => { if (!e.canAuto) { api.emuPage(e.id); FR.msg = `Opened the ${e.name} download page. Install it, then press CHECK AGAIN.`; drawFR(); return; } FR.prog[e.id] = { msg: 'Starting…' }; drawFR(); const r = await api.emuInstall(e.id); if (!FR) return; FR.prog[e.id] = null; FR.msg = r && r.ok ? `${e.name} installed.` : (r && r.error) || 'Install failed.'; await frLoad(); }, { dis: busy }));
    }
    if (FR.busy || FR.msg) h += `<div class="note">${esc(FR.busy || FR.msg)}</div>`;
    return h + `<div class="fract">${frB('back', 'BACK', () => frGo(1))}<span class="sp"></span>${frB('again', 'CHECK AGAIN', frLoad)}${frB('next', c.retroarch.ok ? 'CONTINUE' : 'SKIP FOR NOW', () => frGo(3), { pri: true, dis: busy })}</div>`;
  },
  () => {
    const c = FR.chk, b = (c && c.bios) || []; let h = `<div class="lbl">STEP 4 OF 6</div><h1>BIOS files.</h1><p class="lead">Some consoles need their own BIOS file, from your own console. Cacti OS opens the folder where it goes and checks it is there.</p>`;
    h += b.length ? b.map(x => frRow(x.label, x.name + (x.optional ? ' · optional' : ' · required to start games'), x.ok ? frPill('FOUND', 'ok') : frPill(x.optional ? 'OPTIONAL' : 'MISSING', x.optional ? '' : 'warn') + frB('bf-' + x.id, 'OPEN FOLDER', () => { api.biosOpen(x.id); FR.msg = 'Put the BIOS file in that folder, then press CHECK AGAIN.'; drawFR(); }))).join('') : frRow('Nothing to check', 'No BIOS files are needed for the systems Cacti OS found.', '');
    if (FR.msg) h += `<div class="note">${esc(FR.msg)}</div>`;
    return h + `<div class="fract">${frB('back', 'BACK', () => frGo(2))}<span class="sp"></span>${frB('again', 'CHECK AGAIN', frLoad)}${frB('next', b.some(x => !x.ok && !x.optional) ? 'SKIP FOR NOW' : 'CONTINUE', () => frGo(4), { pri: true })}</div>`;
  },
  () => {
    const fd = (k, l, v, mask, saved) => { const sh = v ? (mask ? '•'.repeat(v.length) : esc(v)) : (saved ? '<i>saved, select to replace</i>' : '<i>Select to type</i>'); return `<div><div class="lbl">${l}</div>${FR.field ? `<div class="frfd${FR.field == k ? ' f' : ''}">${sh}</div>` : frB('f-' + k, sh, () => { FR.field = k; FR.kr = 0; FR.kc = 0; drawFR(); }).replace('class="frb', 'class="frfd')}</div>`; };
    let kb = ''; if (FR.field) kb = `<div class="osk">${FKB.map((r, ri) => `<div>${[...r].map((k, ci) => `<button class="frk" data-frk="${ri}" data-frc="${ci}">${FR.shift ? k.toUpperCase() : k}</button>`).join('')}</div>`).join('')}<div>${FSP.map((k, ci) => `<button class="frk w" data-frk="5" data-frc="${ci}">${k}</button>`).join('')}</div></div><div class="note">Typing on a keyboard works too, and Ctrl+V pastes. Enter finishes a field.</div>`;
    const s = FR.ra, st = s == 1 ? frPill('CHECKING…') : s == 2 ? frPill('SIGNED IN AS ' + esc((cfg.raUser || FR.user).toUpperCase()), 'ok') : s == 3 ? frPill(esc(FR.err || 'FAILED'), 'warn') : '';
    return `<div class="lbl">STEP 5 OF 6</div><h1>Track your achievements.</h1><p class="lead">Needs your username, Web API key and, to track in game, your password. The password signs RetroArch in once and is never saved. The key is stored on this computer. Skip to add it later.</p><div class="frf">${fd('user', 'USERNAME', FR.user)}${fd('pass', 'PASSWORD', FR.pass, 1, cfg.hasToken)}${fd('key', 'WEB API KEY', FR.key, 1, cfg.hasKey)}</div>${kb}
${FR.field ? '' : `<div class="fract">${frB('back', 'BACK', () => frGo(3))}${st}<span class="sp"></span>${frB('next', cfg.hasKey || FR.ra == 2 ? 'CONTINUE' : 'SKIP FOR NOW', () => frGo(5))}${frB('test', 'SIGN IN', async () => { FR.ra = 1; drawFR(); const p = { raUser: FR.user }; if (FR.key) p.raKey = FR.key; if (FR.pass) p.raPass = FR.pass; cfg = await api.setConfig(p); if (!FR) return; FR.err = cfg.loginError || ''; FR.ra = FR.err ? 3 : 2; FR.pass = ''; FR.key = ''; drawFR(); refreshRA(); }, { pri: true, dis: !(FR.user && (FR.key || cfg.hasKey)) || FR.ra == 1 })}</div>`}`;
  },
  () => { const c = FR.chk, have = c ? [...c.systems, ...(c.standalone || [])].reduce((n, s) => n + s.count, 0) : 0; return `<div class="lbl">STEP 6 OF 6</div><h1>You're ready.</h1><p class="lead">Anything skipped lives in Menu › System Check, with a button to fix it.</p><div class="frg" style="grid-template-columns:repeat(3,1fr)"><div><b>${have}</b><span>GAMES FOUND</span></div><div><b>${c && c.retroarch.ok ? 'Yes' : 'No'}</b><span>RETROARCH</span></div><div><b>${cfg.hasKey ? 'On' : 'Off'}</b><span>ACHIEVEMENTS</span></div></div>${frNav(true, 'OPEN MY LIBRARY', async () => { cfg = await api.setConfig({ setupDone: true }); FR = null; drawFR(); theme(); await reload(); refreshRA(); toast('WELCOME', 'Your library is ready', 'Press S for the menu'); })}`; }
];
function drawFR() {
  const el = $('#fr'); if (!FR) { el.classList.add('hid'); el.innerHTML = ''; return; }
  el.classList.remove('hid'); FR.acts = [];
  const body = FRV[FR.step]();
  el.innerHTML = `<div class="frh"><div class="cond">CACTI OS</div><span>FIRST RUN · SETUP</span></div><div class="frs"><div class="frr">${FRN.map((n, i) => `<div class="${i == FR.step ? 'on' : i < FR.step ? 'dn' : ''}"><i>${i < FR.step ? '✓' : i + 1}</i>${n}</div>`).join('')}</div><div class="frp">${body}</div></div>`;
  let ix = FR.acts.findIndex(a => a.k === FR.sel && !a.dis); if (ix < 0) ix = FR.acts.findIndex(a => a.pri && !a.dis); if (ix < 0) ix = FR.acts.findIndex(a => !a.dis);
  FR.cur = ix; if (ix >= 0) { FR.sel = FR.acts[ix].k; const b = el.querySelector(`[data-fr="${ix}"]`); if (b) { b.classList.add('on'); b.scrollIntoView({ block: 'nearest' }); } }
  if (FR.field) { const k = el.querySelector(`[data-frk="${FR.kr}"][data-frc="${FR.kc}"]`); if (k) k.classList.add('on'); }
}
function frRun(i) { const x = FR && FR.acts[i]; if (x && !x.dis) { tick(660); FR.sel = x.k; x.fn(); } }
function frPress(r, c) {
  if (!FR || !FR.field) return; const f = FR.field;
  if (r < 5) { const ch = FKB[r][c]; FR[f] += FR.shift ? ch.toUpperCase() : ch; tick(); }
  else if (c == 0) FR.shift = !FR.shift; else if (c == 1) FR[f] = FR[f].slice(0, -1); else { FR.field = ''; FR.sel = f == 'user' ? 'f-pass' : f == 'pass' ? 'f-key' : 'test'; FR.shift = false; if (FR.ra != 2) FR.ra = 0; }
  if (f == 'user' || f == 'pass' || f == 'key') { if (FR.ra == 3) FR.ra = 0; }
  drawFR();
}
function frAct(a) {
  if (FR.field) { frKbAct(a); return; }
  if (a == 'b') { if (FR.step > 0) frGo(FR.step - 1); return; }
  const en = FR.acts.map((x, i) => x.dis ? -1 : i).filter(i => i >= 0); if (!en.length) return;
  let p = en.indexOf(FR.cur); if (p < 0) p = 0;
  if (a == 'left' || a == 'up') { FR.sel = FR.acts[en[(p - 1 + en.length) % en.length]].k; tick(); drawFR(); }
  else if (a == 'right' || a == 'down') { FR.sel = FR.acts[en[(p + 1) % en.length]].k; tick(); drawFR(); }
  else if (a == 'a') frRun(FR.cur);
}
function frKbAct(a) {
  const rows = [...FKB.map(r => r.length), 3];
  if (a == 'b') { FR.field = ''; FR.sel = ''; drawFR(); return; }
  if (a == 'left') FR.kc = Math.max(0, FR.kc - 1); else if (a == 'right') FR.kc = Math.min(rows[FR.kr] - 1, FR.kc + 1);
  else if (a == 'up') FR.kr = Math.max(0, FR.kr - 1); else if (a == 'down') FR.kr = Math.min(5, FR.kr + 1);
  else if (a == 'a') { frPress(FR.kr, FR.kc); return; }
  FR.kc = Math.min(FR.kc, rows[FR.kr] - 1); tick(); drawFR();
}
async function frPaste() {
  const f = FR.field; if (!f) return; let t = '';
  try { t = await api.clip(); } catch {}
  if (!t) { try { t = await navigator.clipboard.readText(); } catch {} }
  t = String(t || '').replace(/\s+/g, '').slice(0, 200); if (!t || FR.field != f) return;
  FR[f] += t; drawFR();
}
function frKeyDown(e) {
  const f = FR.field, k = e.key;
  if (((e.ctrlKey || e.metaKey) && !e.altKey && k.toLowerCase() == 'v') || (e.shiftKey && k == 'Insert')) { e.preventDefault(); frPaste(); return; }
  if (k == 'Enter') { e.preventDefault(); frPress(5, 2); }
  else if (k == 'Escape') { e.preventDefault(); FR.field = ''; FR.sel = ''; drawFR(); }
  else if (k == 'Backspace') { e.preventDefault(); FR[f] = FR[f].slice(0, -1); drawFR(); }
  else if (k.length == 1 && !e.metaKey && !e.ctrlKey && !e.altKey) { e.preventDefault(); FR[f] += k; drawFR(); }
  else if (k == 'ArrowLeft' || k == 'ArrowRight' || k == 'ArrowUp' || k == 'ArrowDown') { e.preventDefault(); frKbAct(k.slice(5).toLowerCase()); }
}

// ----- Wi-Fi networks popup (Raspberry Pi): pick a network, type the password with an on-screen keyboard -----
const WKB = [['1234567890', 'qwertyuiop', 'asdfghjkl', 'zxcvbnm.-_'], ['1234567890', 'QWERTYUIOP', 'ASDFGHJKL', 'ZXCVBNM.-_'], ['!@#$%^&*()', '-_=+[]{}|\\', ';:\'",.<>/?', '`~ ']];
const WSP = ['CAPS', '#+=', 'SPACE', 'SHOW', 'DELETE', 'NEXT', 'BACK'];
const wfBars = s => { const n = s >= 75 ? 4 : s >= 55 ? 3 : s >= 35 ? 2 : 1; return [...'▂▄▆█'].map((c, i) => `<span style="opacity:${i < n ? 1 : .22}">${c}</span>`).join(''); };
function openWifi() {
  closePanel(); WF = { view: 'list', nets: null, idx: 0, msg: '', field: '', kr: 0, kc: 0, layer: 0, show: false, ssid: '', pass: '', hidden: false };
  drawWF(); wfScan();
}
async function wfScan(keep) {
  if (!WF) return; WF.scanning = true; if (!keep) WF.msg = ''; drawWF();
  const r = await api.wifiScan(); if (!WF) return; WF.scanning = false;
  if (r.error) { WF.nets = []; WF.msg = r.error; } else { WF.nets = r.nets; if (WF.idx > r.nets.length) WF.idx = 0; }
  drawWF();
}
const wfRows = () => (WF.nets || []).length + 1; // the last row is "Other network"
function wfCell() { const row = WF.kr < 4 ? WKB[WF.layer][WF.kr] : null; return { row, len: row ? [...row].length : WSP.length }; }
function drawWF() {
  const el = $('#wfp'); if (!WF) { el.classList.add('hid'); el.innerHTML = ''; return; }
  el.classList.remove('hid');
  const msg = WF.msg ? `<div class="wfm">${esc(WF.msg)}</div>` : '';
  if (WF.view == 'list') {
    const rows = (WF.nets || []).map((n, i) => `<button class="wfr${i == WF.idx ? ' fx' : ''}" data-wfi="${i}"><span class="wfs">${wfBars(n.signal)}</span><span class="wfn">${esc(n.ssid)}</span><span class="wft">${n.inUse ? 'CONNECTED' : n.saved ? 'SAVED' : n.sec ? 'PASSWORD' : 'OPEN'}</span></button>`).join('');
    const other = `<button class="wfr${WF.idx == (WF.nets || []).length ? ' fx' : ''}" data-wfi="${(WF.nets || []).length}"><span class="wfs">+</span><span class="wfn">Other network (type its name)</span><span class="wft"></span></button>`;
    el.innerHTML = `<div class="wfc"><div class="lbl">WI-FI</div><h1 class="cond">CHOOSE A NETWORK</h1>${WF.scanning ? '<div class="note">Looking for networks…</div>' : ''}<div class="wfl">${rows}${other}</div>${msg}<div class="lk">A Connect · X Forget saved · Y Search again · B Close</div></div>`;
    const f = el.querySelector('.fx'); if (f) f.scrollIntoView({ block: 'nearest' });
  } else if (WF.view == 'key') {
    const f = WF.field, val = WF[f], shown = f == 'pass' && !WF.show ? '•'.repeat(val.length) : esc(val);
    const title = f == 'ssid' ? 'NETWORK NAME' : `PASSWORD FOR ${esc(WF.ssid.toUpperCase())}`;
    const lab = k => k == 'CAPS' ? (WF.layer == 1 ? 'caps on' : 'CAPS') : k == '#+=' ? (WF.layer == 2 ? 'abc' : '#+=') : k == 'SHOW' ? (WF.show ? 'HIDE' : 'SHOW') : k == 'NEXT' ? (f == 'ssid' ? 'NEXT' : 'CONNECT') : k;
    const grid = WKB[WF.layer].map((r, ri) => `<div>${[...r].map((k, ci) => `<button class="frk${WF.kr == ri && WF.kc == ci ? ' fx' : ''}" data-wk="${ri}" data-wc="${ci}">${esc(k)}</button>`).join('')}</div>`).join('') + `<div>${WSP.map((k, ci) => `<button class="frk w${WF.kr == 4 && WF.kc == ci ? ' fx' : ''}" data-wk="4" data-wc="${ci}">${lab(k)}</button>`).join('')}</div>`;
    el.innerHTML = `<div class="wfc"><div class="lbl">WI-FI</div><h1 class="cond">${title}</h1><div class="wff">${shown || '<i>' + (f == 'pass' ? 'Type the password' : 'Type the name') + '</i>'}<span class="wfcr"></span></div>${msg}<div class="osk wfk">${grid}</div><div class="lk">D-pad Move · A Type · X Delete · Y Show · LB Caps · RB Symbols · Start ${f == 'ssid' ? 'Next' : 'Connect'} · B Back</div></div>`;
  } else {
    el.innerHTML = `<div class="wfc"><div class="lbl">WI-FI</div><h1 class="cond">CONNECTING…</h1><div class="note">Joining ${esc(WF.ssid)}. This can take up to half a minute.</div><div class="wfsp"></div></div>`;
  }
}
function wfPick() {
  const n = (WF.nets || [])[WF.idx];
  if (!n) { WF.view = 'key'; WF.field = 'ssid'; WF.ssid = ''; WF.pass = ''; WF.hidden = true; WF.kr = 0; WF.kc = 0; WF.layer = 0; WF.msg = ''; drawWF(); return; }
  WF.ssid = n.ssid; WF.hidden = false; WF.pass = ''; WF.msg = '';
  if (n.inUse) { WF.msg = 'You are already connected to this network.'; drawWF(); return; }
  if (/802\.1X/.test(n.sec)) { WF.msg = 'This network needs a work or school sign-in, which is not supported here.'; drawWF(); return; }
  if (n.saved || !n.sec) { wfGo(); return; }
  WF.view = 'key'; WF.field = 'pass'; WF.kr = 0; WF.kc = 0; WF.layer = 0; WF.show = false; drawWF();
}
async function wfGo() {
  const ssid = WF.ssid; if (!ssid) { WF.msg = 'Type the network name first.'; drawWF(); return; }
  const back = WF.view == 'key' ? 'key' : 'list'; WF.view = 'busy'; drawWF();
  const r = await api.wifiConnect({ ssid, password: WF.pass, hidden: WF.hidden }); if (!WF) return;
  if (r && r.ok) { WF = null; drawWF(); toast('WI-FI', 'Connected', ssid); loadWifi(); return; }
  WF.view = back; WF.msg = (r && r.error) || 'Could not connect.'; drawWF();
}
function wfType(ch) { WF[WF.field] += ch; WF.msg = ''; tick(); drawWF(); }
function wfNext() { // CONNECT / NEXT
  if (WF.field == 'ssid') { if (!WF.ssid.trim()) { WF.msg = 'Type the network name first.'; drawWF(); return; } WF.field = 'pass'; WF.kr = 0; WF.kc = 0; WF.msg = 'Leave the password empty if the network is open.'; drawWF(); return; }
  wfGo();
}
function wfKeyPress(r, c) {
  if (r < 4) { const k = [...WKB[WF.layer][r]][c]; if (k) wfType(k); return; }
  const k = WSP[c];
  if (k == 'CAPS') { WF.layer = WF.layer == 1 ? 0 : 1; drawWF(); }
  else if (k == '#+=') { WF.layer = WF.layer == 2 ? 0 : 2; drawWF(); }
  else if (k == 'SPACE') wfType(' ');
  else if (k == 'SHOW') { WF.show = !WF.show; drawWF(); }
  else if (k == 'DELETE') { WF[WF.field] = WF[WF.field].slice(0, -1); tick(); drawWF(); }
  else if (k == 'NEXT') wfNext();
  else if (k == 'BACK') { WF.view = 'list'; WF.msg = ''; drawWF(); }
}
function wfAct(a) {
  if (WF.view == 'busy') return;
  if (WF.view == 'list') {
    const n = wfRows();
    if (a == 'up') { WF.idx = (WF.idx - 1 + n) % n; tick(); drawWF(); }
    else if (a == 'down') { WF.idx = (WF.idx + 1) % n; tick(); drawWF(); }
    else if (a == 'a') { tick(660); wfPick(); }
    else if (a == 'x') { const x = (WF.nets || [])[WF.idx]; if (x && x.saved) api.wifiForget(x.ssid).then(() => { if (WF) { WF.msg = 'Forgot ' + x.ssid + '.'; wfScan(true); } }); }
    else if (a == 'y') wfScan();
    else if (a == 'b' || a == 'start') { WF = null; drawWF(); }
    return;
  }
  if (a == 'b') { WF.view = 'list'; WF.msg = ''; drawWF(); return; }
  if (a == 'start') { wfNext(); return; }
  if (a == 'x') { WF[WF.field] = WF[WF.field].slice(0, -1); tick(); drawWF(); return; }
  if (a == 'y') { WF.show = !WF.show; drawWF(); return; }
  if (a == 'lb') { WF.layer = WF.layer == 1 ? 0 : 1; drawWF(); return; }
  if (a == 'rb') { WF.layer = WF.layer == 2 ? 0 : 2; drawWF(); return; }
  if (a == 'a') { wfKeyPress(WF.kr, WF.kc); return; }
  if (a == 'left') WF.kc--; else if (a == 'right') WF.kc++; else if (a == 'up') WF.kr--; else if (a == 'down') WF.kr++; else return;
  WF.kr = (WF.kr + 5) % 5; const len = wfCell().len; WF.kc = (WF.kc + len) % len; tick(); drawWF();
}
function wfKey(e) {
  const k = e.key;
  if (WF.view == 'busy') { e.preventDefault(); return; }
  if (WF.view == 'list') { const m = { ArrowUp: 'up', ArrowDown: 'down', Enter: 'a', Escape: 'b' }; const a = m[k] || (e.code == 'KeyX' ? 'x' : e.code == 'KeyY' ? 'y' : ''); if (a) { e.preventDefault(); wfAct(a); } return; }
  if (k == 'Enter') { e.preventDefault(); wfNext(); }
  else if (k == 'Escape') { e.preventDefault(); wfAct('b'); }
  else if (k == 'Backspace') { e.preventDefault(); wfAct('x'); }
  else if (k.length == 1 && !e.ctrlKey && !e.metaKey && !e.altKey) { e.preventDefault(); wfType(k); }
  else if (k.startsWith('Arrow')) { e.preventDefault(); wfAct(k.slice(5).toLowerCase()); }
}
document.addEventListener('click', e => {
  if (!WF) return; const r = e.target.closest('[data-wfi]'), q = e.target.closest('[data-wk]');
  if (r && WF.view == 'list') { WF.idx = +r.dataset.wfi; wfPick(); }
  else if (q && WF.view == 'key') { WF.kr = +q.dataset.wk; WF.kc = +q.dataset.wc; wfKeyPress(WF.kr, WF.kc); }
});

// ----- search: games (filters by system, favorites, genre, year, players) and settings; on-screen keyboard for controllers, typing works too -----
const SKB = ['abcdefg', 'hijklmn', 'opqrstu', 'vwxyz-\'', '1234567', '890&.!:'], SSP = ['SPACE', 'DELETE', 'CLEAR', 'CLOSE'];
const srNorm = t => String(t || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
function menuIndex() { // every setting with the path of pages that leads to it
  const out = [], seen = new Set();
  const walk = (id, path, names) => {
    if (seen.has(id) || path.length > 5) return; seen.add(id);
    let pg; try { pg = pageDef(id); } catch { return; }
    pg.items.forEach((it, i) => {
      if (!it.label) return;
      if (it.t == 'lnk') walk(it.go, [...path, it.go], [...names, pg.title]);
      if (it.t != 'inf' || /\w/.test(it.val || '')) out.push({ path, idx: i, label: it.label, page: pg.title, text: srNorm(it.label + ' ' + pg.title + ' ' + (it.t == 'inf' ? it.val : '')) });
    });
  };
  walk('main', ['main'], []); return out;
}
function srData() {
  const rows = []; for (const b of BASE) for (const g of b.games) rows.push({ g, sys: b.id, sysName: b.name });
  return rows;
}
const srYearLab = y => y ? Math.floor(y / 10) * 10 + 's' : '';
function openSearch(mode) {
  closePanel(); const games = mode == 'games';
  SR = { mode, q: '', kr: 0, kc: 0, zone: 'kb', fi: 0, ri: 0, res: [], data: games ? srData() : menuIndex(), f: { sys: '', fav: false, genre: '', dec: '', pl: '' } };
  if (games) { const gs = new Set(), ds = new Set(); for (const r of SR.data) { const m = r.g.meta; if (m && m.genre) gs.add(String(m.genre).split(',')[0].trim()); if (m && m.year) ds.add(srYearLab(m.year)); } SR.genres = [...gs].sort(), SR.decs = [...ds].sort(); }
  srRun(); drawSR(); tick(660);
}
function srRun() {
  const w = srNorm(SR.q).split(' ').filter(Boolean), out = [];
  if (SR.mode == 'menu') { for (const r of SR.data) { if (!w.length) break; if (w.every(t => r.text.includes(t))) out.push({ r, score: r.text.startsWith(w[0]) ? 0 : srNorm(r.label).includes(w[0]) ? 1 : 2 }); } out.sort((a, b) => a.score - b.score || a.r.label.length - b.r.label.length); SR.res = out.slice(0, 60).map(x => x.r); }
  else {
    const f = SR.f;
    for (const r of SR.data) {
      const m = r.g.meta || {}; if (f.sys && r.sys != f.sys) continue; if (f.fav && !favs.has(r.g.file)) continue; if (f.genre && !String(m.genre || '').split(',').some(x => x.trim() == f.genre)) continue; if (f.dec && srYearLab(m.year) != f.dec) continue;
      if (f.pl == '1' && !/^1\b/.test(String(m.players || '1'))) continue; if (f.pl == '2+' && !/[2-9]/.test(String(m.players || ''))) continue;
      const t = srNorm(r.g.title), hay = t + ' ' + srNorm((m.genre || '') + ' ' + (m.dev || '') + ' ' + (m.pub || '') + ' ' + (m.year || '') + ' ' + r.sysName);
      if (w.length && !w.every(x => hay.includes(x))) continue;
      out.push({ r, score: !w.length ? 3 : t.startsWith(w[0]) ? 0 : t.includes(w.join(' ')) ? 1 : 2 });
    }
    out.sort((a, b) => a.score - b.score || ACOLL.compare(a.r.g.title, b.r.g.title)); SR.res = out.slice(0, 80).map(x => x.r);
  }
  SR.ri = Math.min(SR.ri, Math.max(0, SR.res.length - 1));
}
const srFilters = () => { const f = SR.f; return [
  ['SYSTEM', f.sys ? (BASE.find(b => b.id == f.sys) || {}).name || '' : 'All', () => { const ids = ['', ...BASE.map(b => b.id)]; f.sys = ids[(ids.indexOf(f.sys) + 1) % ids.length]; }],
  ['FAVORITES', f.fav ? 'Only' : 'Any', () => { f.fav = !f.fav; }],
  ['GENRE', f.genre || 'Any', () => { const l = ['', ...SR.genres]; f.genre = l[(l.indexOf(f.genre) + 1) % l.length]; }],
  ['YEAR', f.dec || 'Any', () => { const l = ['', ...SR.decs]; f.dec = l[(l.indexOf(f.dec) + 1) % l.length]; }],
  ['PLAYERS', f.pl || 'Any', () => { const l = ['', '1', '2+']; f.pl = l[(l.indexOf(f.pl) + 1) % l.length]; }]]; };
function drawSR() {
  const el = $('#srp'); if (!SR) { el.classList.add('hid'); el.innerHTML = ''; return; } el.classList.remove('hid');
  const games = SR.mode == 'games', fl = games ? srFilters() : [];
  const grid = SKB.map((r, ri) => `<div>${[...r].map((k, ci) => `<button class="frk${SR.zone == 'kb' && SR.kr == ri && SR.kc == ci ? ' fx' : ''}" data-srk="${ri}" data-src="${ci}">${esc(k)}</button>`).join('')}</div>`).join('') + `<div>${SSP.map((k, ci) => `<button class="frk w${SR.zone == 'kb' && SR.kr == 6 && SR.kc == ci ? ' fx' : ''}" data-srk="6" data-src="${ci}">${k}</button>`).join('')}</div>`;
  const chips = fl.map((f, i) => `<button class="srf${SR.zone == 'flt' && SR.fi == i ? ' fx' : ''}${f[1] != 'All' && f[1] != 'Any' ? ' on' : ''}" data-srf="${i}"><i>${f[0]}</i><b>${esc(f[1])}</b></button>`).join('');
  const a = Math.max(0, Math.min(SR.ri - 3, SR.res.length - 8)), win = SR.res.slice(a, a + 8);
  const rows = win.map((r, j) => { const i = a + j, fx = SR.zone == 'res' && SR.ri == i; if (games) { const m = r.g.meta || {}, sub = [m.year, String(m.genre || '').split(',')[0], m.dev].filter(Boolean).join(' · '); return `<button class="srr${fx ? ' fx' : ''}${SR.ri == i ? ' cur' : ''}" data-srr="${i}"><span class="sn">${esc(r.g.title)}${favs.has(r.g.file) ? ' ★' : ''}</span><span class="ss">${esc(r.sysName)}</span>${sub ? `<span class="sm">${esc(sub)}</span>` : ''}</button>`; } return `<button class="srr${fx ? ' fx' : ''}${SR.ri == i ? ' cur' : ''}" data-srr="${i}"><span class="sn">${esc(r.label)}</span><span class="ss">${esc(r.page)}</span></button>`; }).join('');
  const none = !SR.res.length ? `<div class="srn">${games ? (SR.q || Object.values(SR.f).some(Boolean) ? 'No games match.' : 'Type a name, a genre, a developer or a year. Use the filters above the keyboard.') : (SR.q ? 'No settings match.' : 'Type what you are looking for, for example "volume", "wifi" or "backup".')}</div>` : '';
  el.innerHTML = `<div class="src"><div class="lbl">${games ? 'SEARCH GAMES' : 'SEARCH SETTINGS'}</div><div class="srq"><span>${esc(SR.q) || '<i>Start typing</i>'}</span><em>${SR.res.length ? SR.res.length + (SR.res.length >= (games ? 80 : 60) ? '+' : '') + ' found' : ''}</em><span class="wfcr"></span></div>
  <div class="srg"><div class="srl">${games ? `<div class="srfs">${chips}</div>` : ''}<div class="osk wfk">${grid}</div></div><div class="srv">${rows}${none}</div></div>
  <div class="lk">D-pad Move · A ${SR.zone == 'res' ? (games ? 'Go to game' : 'Open setting') : 'Select'} · X Delete · Y ${games ? 'Favorite' : 'Clear'} · Start ${games ? 'Go to top result' : 'Open top result'} · B Close</div></div>`;
}
function srGo(r) {
  if (!r) return; const mode = SR.mode; SR = null; drawSR();
  if (mode == 'menu') { M = { stack: [...r.path], idx: r.idx, edit: null }; for (const p of r.path) enter(p); drawMenu(); return; }
  const g = r.g, i = SYS.findIndex(s => s.id === r.sys); if (i < 0) { toast('SEARCH', 'That system is hidden', 'Turn off "Only show systems with achievements"'); return; }
  sys = i; zone = 'games'; const j = SYS[i].games.findIndex(x => x.file === g.file);
  if (j >= 0) { selBy[SYS[i].id] = j; refresh(); } else { const k = SYS[i].all.findIndex(x => x.file === g.file); LIBV = { s: SYS[i], idx: Math.max(0, k) }; refresh(); drawLib(); }
  tick(660);
}
function srType(ch) { SR.q += ch; SR.ri = 0; srRun(); tick(); drawSR(); }
function srPress(r, c) {
  if (r < 6) { const k = [...SKB[r]][c]; if (k) srType(k); return; }
  const k = SSP[c];
  if (k == 'SPACE') { if (SR.q && !SR.q.endsWith(' ')) srType(' '); } else if (k == 'DELETE') srDel(); else if (k == 'CLEAR') { SR.q = ''; SR.ri = 0; srRun(); drawSR(); } else srClose();
}
function srDel() { SR.q = SR.q.slice(0, -1); SR.ri = 0; srRun(); tick(); drawSR(); }
function srClose() { SR = null; drawSR(); }
function srAct(a) {
  const games = SR.mode == 'games', fl = games ? srFilters() : [];
  if (a == 'b') { srClose(); return; }
  if (a == 'start') { srGo(SR.res[0]); return; }
  if (a == 'x') { srDel(); return; }
  if (a == 'y') { if (games && SR.res[SR.ri]) { const g = SR.res[SR.ri].g; favs.has(g.file) ? favs.delete(g.file) : favs.add(g.file); try { localStorage.setItem('favs', JSON.stringify([...favs])); } catch {} rebuildSys(); toast('FAVORITES', favs.has(g.file) ? 'Added' : 'Removed', g.title); drawSR(); } else { SR.q = ''; srRun(); drawSR(); } return; }
  if (SR.zone == 'kb') {
    if (a == 'a') { srPress(SR.kr, SR.kc); return; }
    if (a == 'left') SR.kc--; else if (a == 'right') { if (SR.kc >= (SR.kr < 6 ? [...SKB[SR.kr]].length : 4) - 1 && SR.res.length) { SR.zone = 'res'; tick(); drawSR(); return; } SR.kc++; }
    else if (a == 'up') { if (SR.kr == 0 && games) { SR.zone = 'flt'; tick(); drawSR(); return; } SR.kr--; } else if (a == 'down') { if (SR.kr == 6) { if (SR.res.length) { SR.zone = 'res'; tick(); drawSR(); } return; } SR.kr++; } else return;
    SR.kr = (SR.kr + 7) % 7; const len = SR.kr < 6 ? [...SKB[SR.kr]].length : 4; SR.kc = (SR.kc + len) % len; tick(); drawSR(); return;
  }
  if (SR.zone == 'flt') {
    if (a == 'left') SR.fi = (SR.fi + fl.length - 1) % fl.length; else if (a == 'right') SR.fi = (SR.fi + 1) % fl.length; else if (a == 'down') SR.zone = 'kb'; else if (a == 'a') { fl[SR.fi][2](); SR.ri = 0; srRun(); } else return;
    tick(); drawSR(); return;
  }
  if (a == 'up') SR.ri = Math.max(0, SR.ri - 1); else if (a == 'down') SR.ri = Math.min(SR.res.length - 1, SR.ri + 1); else if (a == 'left') SR.zone = 'kb'; else if (a == 'a') { srGo(SR.res[SR.ri]); return; } else if (a == 'jl') SR.ri = Math.max(0, SR.ri - 8); else if (a == 'jr') SR.ri = Math.min(SR.res.length - 1, SR.ri + 8); else return;
  tick(); drawSR();
}
function srKey(e) {
  const k = e.key;
  if (k == 'Escape') { e.preventDefault(); srAct('b'); }
  else if (k == 'Enter') { e.preventDefault(); if (SR.zone == 'res' || SR.zone == 'kb' && SR.q) srGo(SR.res[SR.zone == 'res' ? SR.ri : 0]); else srAct('a'); }
  else if (k == 'Backspace') { e.preventDefault(); srDel(); }
  else if (k.length == 1 && !e.ctrlKey && !e.metaKey && !e.altKey) { e.preventDefault(); srType(k.toLowerCase()); }
  else if (k.startsWith('Arrow')) { e.preventDefault(); srAct(k.slice(5).toLowerCase()); }
}
document.addEventListener('click', e => {
  if (!SR) return; const q = e.target.closest('[data-srk]'), f = e.target.closest('[data-srf]'), r = e.target.closest('[data-srr]');
  if (q) { SR.zone = 'kb'; SR.kr = +q.dataset.srk; SR.kc = +q.dataset.src; srPress(SR.kr, SR.kc); } else if (f) { SR.zone = 'flt'; SR.fi = +f.dataset.srf; srFilters()[SR.fi][2](); SR.ri = 0; srRun(); drawSR(); } else if (r) srGo(SR.res[+r.dataset.srr]);
});

// ----- Controllers read by the system (Raspberry Pi): the app gets button presses directly, so menus work with any pad -----
let libT = 0;

// ----- Controllers: Bluetooth pairing and button mapping -----
const LOGI = ['a', 'b', 'x', 'y', 'lb', 'rb', 'lt', 'rt', 'sel', 'start', 'l3', 'r3', 'up', 'down', 'left', 'right', 'home'];
const ACTN = { a: 'a', b: 'b', x: 'x', y: 'y', lb: 'lb', rb: 'rb', lt: 'jl', rt: 'jr', sel: 'sel', start: 'start', up: 'up', down: 'down', left: 'left', right: 'right' };
const CTORDER = ['lt', 'lb', 'l3', 'up', 'left', 'right', 'down', 'sel', 'home', 'start', 'y', 'x', 'b', 'a', 'r3', 'rb', 'rt'];
const CTN = { a: ['A', 'Confirm in menus, bottom face button in games.'], b: ['B', 'Back in menus, right face button.'], x: ['X', 'Left face button.'], y: ['Y', 'Top face button.'], lb: ['LB', 'Left bumper. Previous tab.'], rb: ['RB', 'Right bumper. Next tab.'], lt: ['LT', 'Left trigger. Jump back a letter.'], rt: ['RT', 'Right trigger. Jump ahead a letter.'], sel: ['View', 'Small button left of centre.'], start: ['Menu', 'Small button right of centre. Opens the menu.'], home: ['Home', 'Centre button.'], l3: ['L3', 'Press the left stick.'], r3: ['R3', 'Press the right stick.'], up: ['D-pad Up', 'Directional pad.'], down: ['D-pad Down', 'Directional pad.'], left: ['D-pad Left', 'Directional pad.'], right: ['D-pad Right', 'Directional pad.'] };
const ctEff = (name, l) => { const m = (cfg.padMap || {})[name] || {}; return l in m ? m[l] : LOGI.indexOf(l); };
function padActFor(name, idx) { for (const l of LOGI) if (ctEff(name, l) === idx) return ACTN[l] || ''; return ''; }
// interface sizes: four independent scales (header icons, tiles, text, button prompts) with presets; 'auto' enlarges header and prompts on small handheld screens
const SZP = { small: [90, 90, 90, 90], normal: [100, 100, 100, 100], large: [120, 105, 120, 125] };
function szEff() {
  const pr = (cfg && cfg.szPreset) || 'auto', n = k => Math.max(70, Math.min(150, parseInt(cfg && cfg[k], 10) || 100));
  if (pr === 'custom') return [n('szHeader'), n('szTile'), n('szText'), n('szPrompt')];
  if (pr === 'auto') return innerWidth < 1100 ? [125, 100, 115, 125] : SZP.normal;
  return SZP[pr] || SZP.normal;
}
function applySizes() { const e = szEff(), st = document.documentElement.style; st.setProperty('--zh', e[0] / 100); st.setProperty('--zt', Math.min(e[1], 115) / 100); st.setProperty('--zx', e[2] / 100); st.setProperty('--zp', e[3] / 100); }
addEventListener('resize', () => { if (cfg && (cfg.szPreset || 'auto') === 'auto') applySizes(); });
function applyPrompts() { const P = { Xbox: ['B', 'A', 'Y', 'X'], PlayStation: ['○', '✕', '△', '□'], Nintendo: ['B', 'A', 'X', 'Y'] }[cfg && cfg.prompts] || ['B', 'A', 'Y', 'X']; ['b', 'a', 'y', 'x'].forEach((k, i) => { const e = document.querySelector(`.pr[data-a="${k}"] i`); if (e) e.textContent = P[i]; }); }
const ctBack = () => { stopCT(); M = { stack: ['main', 'ctrl'], idx: 0, edit: null }; drawMenu(); };
function stopCT() { if (CT && CT.tmr) clearInterval(CT.tmr); try { api.padCapture(false); } catch {} CT = null; drawCT(); }
async function openBT() {
  if (!cfg.linux) { api.btSettings(); toast('BLUETOOTH', 'Opened system settings', 'Pair the controller there'); return; }
  M = null; drawMenu(); closePanel(); CT = { view: 'bt', devs: [], idx: 0, scanning: false, busy: '', msg: '', sup: true, forget: '' }; drawCT();
  const r = await api.btList(); if (!CT) return; ctBtSet(r);
}
function ctBtSet(r) { CT.sup = r.supported !== false; CT.msg = r.error || ''; CT.devs = r.devices || []; CT.idx = Math.min(CT.idx, CT.devs.length); drawCT(); }
async function ctScan() { if (CT.scanning) return; CT.scanning = true; CT.msg = ''; drawCT(); const r = await api.btScan(); if (!CT) return; CT.scanning = false; ctBtSet(r); if (!CT.devs.some(d => !d.paired)) { CT.msg = 'Nothing new found. Put the controller in pairing mode, then scan again.'; drawCT(); } }
async function ctBtGo(d) {
  CT.forget = ''; if (d.paired) { CT.busy = (d.connected ? 'Disconnecting ' : 'Connecting ') + d.name + '…'; drawCT(); const r = await api.btAct(d.connected ? 'disconnect' : 'connect', d.mac); if (!CT) return; CT.busy = ''; if (!r.ok) CT.msg = r.error; ctBtSet(await api.btList()); return; }
  CT.busy = 'Pairing ' + d.name + '… keep the controller in pairing mode'; drawCT();
  const r = await api.btPair(d.mac); if (!CT) return; CT.busy = ''; CT.msg = r.ok ? '' : r.error; if (r.ok) toast('BLUETOOTH', d.name, 'Paired and connected'); ctBtSet(await api.btList());
}
async function openMap() {
  M = null; drawMenu(); closePanel(); CT = { view: 'map', names: [], pi: 0, sel: 'a', listen: 0, msg: '', tmr: null };
  let names = []; try { const s = await api.padStatus(); if (s && s.n) names = s.names; } catch {}
  if (!names.length) names = pads().map(g => cleanPad(g.id));
  CT.names = [...new Set(names)]; drawCT();
}
function ctLight(l) { const n = document.querySelector(`#ctp [data-b="${l}"]`); if (!n) return; n.classList.add('hit'); setTimeout(() => n.classList.remove('hit'), 220); }
function ctRaw(name, idx) { if (!CT || CT.view != 'map') return; if (CT.listen) { ctAssign(name, idx); return; } const l = LOGI.find(x => ctEff(name, x) === idx); if (l && name === CT.names[CT.pi]) ctLight(l); }
function ctPadPress(name, idx) { const was = CT.listen; ctRaw(name, idx); if (!was) { const a = padActFor(name, idx); if (a) act(a); } }
async function ctAssign(name, idx) {
  if (name !== CT.names[CT.pi]) return;
  const cur = (cfg.padMap || {})[name] || {}, eff = {}; LOGI.forEach(l => { eff[l] = l in cur ? cur[l] : LOGI.indexOf(l); });
  const other = LOGI.find(l => l !== CT.sel && eff[l] === idx), old = eff[CT.sel]; eff[CT.sel] = idx; if (other) eff[other] = old;
  const diff = {}; LOGI.forEach((l, i) => { if (eff[l] !== i) diff[l] = eff[l]; });
  CT.listen = 0; clearInterval(CT.tmr); api.padCapture(false);
  CT.msg = `${CTN[CT.sel][0]} now uses ${BN[idx] || 'button ' + idx}` + (other ? `. ${CTN[other][0]} took ${BN[old] || 'button ' + old}.` : '');
  await set({ padMap: { ...(cfg.padMap || {}), [name]: diff } }); drawCT();
}
function ctListen() {
  if (!CT.names.length) { CT.msg = 'No controller connected. Connect one first.'; drawCT(); return; }
  CT.listen = 8; CT.msg = ''; api.padCapture(true); drawCT();
  CT.tmr = setInterval(() => { if (!CT) return; CT.listen--; if (CT.listen <= 0) { clearInterval(CT.tmr); CT.listen = 0; api.padCapture(false); CT.msg = 'No button pressed. Remap cancelled.'; } drawCT(); }, 1000);
}
function ctReset(all) {
  const name = CT.names[CT.pi]; if (!name) return; const pm = { ...(cfg.padMap || {}) };
  if (all) delete pm[name]; else { const cur = { ...(pm[name] || {}) }, eff = {}; LOGI.forEach(l => { eff[l] = l in cur ? cur[l] : LOGI.indexOf(l); }); const d = LOGI.indexOf(CT.sel), other = LOGI.find(l => l !== CT.sel && eff[l] === d); if (other) eff[other] = eff[CT.sel]; eff[CT.sel] = d; const diff = {}; LOGI.forEach((l, i) => { if (eff[l] !== i) diff[l] = eff[l]; }); if (Object.keys(diff).length) pm[name] = diff; else delete pm[name]; }
  CT.msg = all ? 'All buttons reset.' : CTN[CT.sel][0] + ' reset.'; set({ padMap: pm }).then(drawCT);
}
function ctAct(a) {
  if (CT.view == 'bt') {
    const n = CT.devs.length + 1;
    if (a == 'b') { ctBack(); return; } if (CT.busy) return;
    if (a == 'up') CT.idx = (CT.idx + n - 1) % n; else if (a == 'down') CT.idx = (CT.idx + 1) % n;
    else if (a == 'a') { CT.idx == 0 ? ctScan() : ctBtGo(CT.devs[CT.idx - 1]); return; }
    else if (a == 'x') { const d = CT.devs[CT.idx - 1]; if (d && d.paired) { if (CT.forget == d.mac) { CT.forget = ''; api.btAct('remove', d.mac).then(async () => { if (CT) { CT.idx = 0; ctBtSet(await api.btList()); } }); return; } CT.forget = d.mac; CT.msg = `Press X again to forget ${d.name}.`; } }
    drawCT(); return;
  }
  if (CT.listen) { return; }
  const i = CTORDER.indexOf(CT.sel);
  if (a == 'b') { ctBack(); return; }
  if (a == 'left' || a == 'up') CT.sel = CTORDER[(i + CTORDER.length - 1) % CTORDER.length]; else if (a == 'right' || a == 'down') CT.sel = CTORDER[(i + 1) % CTORDER.length];
  else if (a == 'a') { ctListen(); return; } else if (a == 'x') { ctReset(false); return; } else if (a == 'y') { ctReset(true); return; }
  else if ((a == 'lb' || a == 'rb') && CT.names.length > 1) CT.pi = (CT.pi + (a == 'rb' ? 1 : CT.names.length - 1)) % CT.names.length;
  CT.msg = ''; drawCT();
}
function ctKey(e) {
  const m = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right', Enter: 'a', Escape: 'b', Backspace: 'b', x: 'x', X: 'x', y: 'y', Y: 'y', q: 'lb', e: 'rb' };
  if (e.key == 'Escape' && CT.listen) { e.preventDefault(); clearInterval(CT.tmr); CT.listen = 0; api.padCapture(false); CT.msg = 'Remap cancelled.'; drawCT(); return; }
  if (m[e.key]) { e.preventDefault(); ctAct(m[e.key]); }
}
const ctBat = b => b == null ? '' : `<span class="wft">${b}%</span>`;
function padSVG(name) {
  const part = (id, shape, label, x, y) => { const eff = ctEff(name, id) !== LOGI.indexOf(id); return shape.replace('<', `<`).replace(/^<(\w+)/, `<$1 class="part${id == CT.sel ? ' sel' : ''}${eff ? ' chg' : ''}" data-b="${id}"`) + (label ? `<text x="${x}" y="${y}" data-c="${id}">${label}</text>` : ''); };
  const P = (d) => `<path d="${d}"/>`, C = (cx, cy, r, c = '') => `<circle cx="${cx}" cy="${cy}" r="${r}" ${c ? `class="${c}"` : ''}/>`;
  const body = 'M215 112C170 112 140 125 118 165C90 220 55 330 52 390C50 430 95 445 125 420C160 392 180 335 225 322L475 322C520 335 540 392 575 420C605 445 650 430 648 390C645 330 610 220 582 165C560 125 530 112 485 112C430 104 270 104 215 112Z';
  return `<svg class="pad" viewBox="0 18 700 440"><path class="body" d="${body}"/><rect x="257" y="255" width="26" height="26" class="cube"/><circle cx="205" cy="195" r="48" class="ring"/><circle cx="430" cy="268" r="44" class="ring"/>` +
    part('lt', P('M160 70C175 40 230 28 285 38L278 76C232 68 200 74 182 94Z'), 'LT', 226, 56) + part('rt', P('M540 70C525 40 470 28 415 38L422 76C468 68 500 74 518 94Z'), 'RT', 474, 56) +
    part('lb', P('M138 140C150 108 205 90 275 100L270 124C215 118 180 128 160 152Z'), 'LB', 210, 112) + part('rb', P('M562 140C550 108 495 90 425 100L430 124C485 118 520 128 540 152Z'), 'RB', 490, 112) +
    part('l3', C(205, 195, 30, 'dome'), 'L3', 205, 195) + part('r3', C(430, 268, 28, 'dome'), 'R3', 430, 268) +
    part('up', P('M260 255V240l3-4h14l3 4v15z')) + part('down', P('M260 281v15l3 4h14l3-4v-15z')) + part('left', P('M257 258h-15l-4 3v14l4 3h15z')) + part('right', P('M283 258h15l4 3v14l-4 3h-15z')) +
    '<path class="tri" d="M270 242l-5 8h10zM270 294l-5-8h10zM244 268l8-5v10zM296 268l-8-5v10z"/>' +
    part('y', C(495, 163, 19), 'Y', 495, 163) + part('x', C(457, 201, 19), 'X', 457, 201) + part('b', C(533, 201, 19), 'B', 533, 201) + part('a', C(495, 239, 19), 'A', 495, 239) +
    part('sel', C(310, 205, 13)) + part('start', C(390, 205, 13)) + part('home', C(350, 150, 22)) +
    '<path class="ic" d="M304 201h8v6h-8zM308 203h8v6h-8zM384 201h12M384 205h12M384 209h12"/><circle class="ic" cx="350" cy="150" r="9"/></svg>';
}
function drawCT() {
  const el = $('#ctp'); if (!CT) { el.classList.add('hid'); el.innerHTML = ''; return; }
  el.classList.remove('hid');
  const msg = CT.msg ? `<div class="wfm">${esc(CT.msg)}</div>` : '';
  if (CT.view == 'bt') {
    if (!CT.sup) { el.innerHTML = `<div class="wfc"><div class="lbl">CONTROLLERS</div><h1 class="cond">BLUETOOTH PAIRING</h1><div class="wfm">${esc(CT.msg || 'Bluetooth is not available here.')}</div><div class="lk">B / Esc Back</div></div>`; return; }
    const rows = CT.devs.map((d, i) => `<button class="wfr${CT.idx == i + 1 ? ' fx' : ''}" data-bi="${i + 1}"><span class="wfs">${d.connected ? '●' : d.paired ? '○' : '+'}</span><span class="wfn">${esc(d.name)}</span>${ctBat(d.battery)}<span class="wft">${d.connected ? 'CONNECTED' : d.paired ? 'PAIRED' : 'PRESS A TO PAIR'}</span></button>`).join('');
    el.innerHTML = `<div class="wfc"><div class="lbl">CONTROLLERS</div><h1 class="cond">BLUETOOTH PAIRING</h1>` +
      `<button class="wfr${CT.idx == 0 ? ' fx' : ''}" data-bi="0"><span class="wfs">${CT.scanning ? '<i class="wfsp" style="width:18px;height:18px;margin:0;border-width:3px;display:inline-block"></i>' : '⟳'}</span><span class="wfn">${CT.scanning ? 'Looking for controllers…' : 'Scan for controllers'}</span><span class="wft">${CT.scanning ? 'ABOUT 8 SECONDS' : 'PUT THE CONTROLLER IN PAIRING MODE FIRST'}</span></button>` +
      `<div class="wfl">${rows || '<div class="note">No controllers yet. Hold the pair button on your controller until its light blinks fast, then scan.</div>'}</div>${CT.busy ? `<div class="wfm">${esc(CT.busy)}</div>` : msg}<div class="lk">↑ ↓ Select · A Pair or Connect · X Forget · B Back</div></div>`;
    const f = el.querySelector('.fx'); if (f) f.scrollIntoView({ block: 'nearest' }); return;
  }
  const name = CT.names[CT.pi], S = CT.sel, eff = n => ctEff(name, n), chg = LOGI.filter(l => name && eff(l) !== LOGI.indexOf(l)).length;
  const lis = CT.listen ? `<div class="ctl">Press the button you want for <b>${CTN[S][0]}</b> on your controller <span class="chip">${CT.listen}</span></div>` : '';
  el.innerHTML = `<div class="wfc ctw"><div class="lbl">CONTROLLERS</div><h1 class="cond">BUTTON MAPPING</h1><div class="ctg"><div>${padSVG(name)}<div class="lk">Amber outline = changed from default (${chg}). Press a button on your controller to see it light up.</div></div>` +
    `<div class="cts">${CT.names.length ? `<div class="ctp"><button data-ca="pm" aria-label="Previous controller">‹</button><b>${esc(name)}</b><button data-ca="pp" aria-label="Next controller">›</button></div>` : '<div class="wfm">No controller connected. Connect one, then press any button.</div>'}` +
    `<h4>${CTN[S][0]}</h4><p>${CTN[S][1]}</p><div class="kv"><span>Uses controller button</span><span>${name ? esc(BN[eff(S)] || 'Button ' + eff(S)) : '—'}</span></div><div class="kv"><span>Default</span><span>${esc(BN[LOGI.indexOf(S)])}</span></div>${lis}${CT.listen ? '' : msg}` +
    `<div class="ctb"><button class="wfr" data-ca="remap">Remap</button><button class="wfr" data-ca="r1">Reset</button><button class="wfr" data-ca="r2">Reset all</button></div></div></div><div class="lk">← → Choose a button · A Remap · X Reset · Y Reset all · LB RB Switch controller · B Back</div></div>`;
}
document.addEventListener('click', e => {
  if (!CT) return; const t = e.target;
  if (t.id == 'ctp') { ctBack(); return; }
  const bi = t.closest('[data-bi]'); if (bi && !CT.busy) { CT.idx = +bi.dataset.bi; drawCT(); ctAct('a'); return; }
  const pb = t.closest('[data-b]'); if (pb && CT.view == 'map' && !CT.listen) { CT.sel = pb.dataset.b; CT.msg = ''; drawCT(); return; }
  const ca = t.closest('[data-ca]'); if (!ca || CT.view != 'map') return; const k = ca.dataset.ca;
  if (k == 'remap') ctListen(); else if (k == 'r1') ctReset(false); else if (k == 'r2') ctReset(true); else if ((k == 'pm' || k == 'pp') && CT.names.length > 1) { CT.pi = (CT.pi + (k == 'pp' ? 1 : CT.names.length - 1)) % CT.names.length; drawCT(); }
});
try { api.onPadRaw(v => ctRaw(v.name, v.idx)); } catch {}

try { api.padStatus().then(s => { if (s && s.n) nativePad = true; }); api.onPadAct(a => { nativePad = true; if (!OVL) act(a); }); } catch {}
try { api.onLibrary(() => { clearTimeout(libT); libT = setTimeout(() => reload(), 2500); }); } catch {}

// ----- Send ROMs from a browser on the same network -----
async function loadUp() { S.up = await api.uploadInfo(); if (M && ['upload', 'netsync'].includes(M.stack[M.stack.length - 1])) drawMenu(); }

(async () => {
  try { Themes.loadCustom(await api.themes()); } catch {}
  try { api.onThemes && api.onThemes(async () => { try { Themes.loadCustom(await api.themes()); } catch {} theme(); }); } catch {}
  cfg = await api.getConfig(); applyPrompts(); applySizes(); theme(); renderProf(); applyAv();
  if (cfg.splash !== false && window.CactiSplash) CactiSplash.play(!!cfg.dark);
  try { api.onRaLists(() => loadTotals()); } catch {}
  api.wifi().then(w => { W = w; updWifiIcon(); if (w && w.supported !== false && !w.connected) wifiWatch(); });
  SM = await api.getSystems(); loadLobby(); setInterval(loadLobby, 120000);
  { const q = api.scanQuick ? await api.scanQuick().catch(() => null) : null; // open from the saved library, then bring it up to date while you use the app
    if (q && q.length) { BASE = q; rebuildSys(); refresh(); loadTotals(); api.scan(true).then(b => { if (b && b.length) { BASE = b; rebuildSys(); if (mode != 'game') refresh(); loadTotals(); } }).catch(() => {}); } else await reload(); }
  refreshRA();
  { const t0 = Date.now(); while (document.getElementById('csplash') && Date.now() - t0 < 9000) await new Promise(r => setTimeout(r, 200)); await openPP(); }
  if (!cfg.setupDone && !cfg.raUser) openFR(); else updStartup().then(() => { if (!BASE.length) { if (UPD) AFTERUPD = () => openMenu('check'); else openMenu('check'); } });
})();
// mouse wheel / trackpad scrolls the system tabs sideways
$('#tabs').addEventListener('wheel', e => { const sc = $('#tscroll'); if (!sc) return; const d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY; sc.scrollLeft += d; sc.classList.toggle('scl', sc.scrollLeft > 2); e.preventDefault(); }, { passive: false });
})();

// scan progress: appears only when a scan takes longer than about a second
{ let el = null, showT = 0, hideT = 0;
  const make = () => { el = document.createElement('div'); el.id = 'scanbar'; el.style.cssText = 'position:fixed;left:50%;bottom:48px;transform:translateX(-50%);width:min(560px,86vw);padding:16px 20px;border-radius:16px;background:rgba(14,18,40,.94);border:1px solid rgba(255,255,255,.18);box-shadow:0 12px 40px rgba(0,0,0,.5);color:#fff;font:600 15px system-ui,sans-serif;z-index:9999;display:none;pointer-events:none';
    el.innerHTML = '<div style="display:flex;justify-content:space-between;gap:12px"><span id="scanT">Updating your game list</span><span id="scanP">0%</span></div><div style="margin-top:10px;height:8px;border-radius:6px;background:rgba(255,255,255,.14);overflow:hidden"><div id="scanF" style="height:100%;width:0;background:linear-gradient(90deg,#f5b83d,#ffd97a);transition:width .25s"></div></div><div id="scanM" style="margin-top:8px;font-weight:500;font-size:13px;opacity:.75;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"></div>'; document.body.appendChild(el); };
  if (api.onScanProgress) api.onScanProgress(d => {
    if (!el) make();
    if (d.done) { clearTimeout(showT); showT = 0; el.querySelector('#scanF').style.width = '100%'; el.querySelector('#scanP').textContent = '100%'; clearTimeout(hideT); hideT = setTimeout(() => { el.style.display = 'none'; }, 500); return; }
    el.querySelector('#scanF').style.width = d.pct + '%'; el.querySelector('#scanP').textContent = d.pct + '%';
    el.querySelector('#scanM').textContent = (d.found || 0).toLocaleString() + ' games found' + (d.msg ? ' · ' + d.msg : '');
    clearTimeout(hideT); if (!showT && el.style.display === 'none') showT = setTimeout(() => { el.style.display = 'block'; showT = 0; }, 900);
  }); }
