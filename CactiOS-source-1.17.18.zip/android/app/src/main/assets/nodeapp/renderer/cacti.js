// Cacti Level: points = RetroAchievements points (hardcore + softcore) + 10 per achievement unlocked.
// Everything is calculated from the RetroAchievements account, so a fresh install rebuilds the same level.
const Cacti = (() => {
  const PER_ACH = 10;
  const TIERS = [
    { name: 'Seedling', from: 1, color: '#7fa68e', bloom: false },
    { name: 'Sprout', from: 5, color: '#3d9a6a', bloom: false },
    { name: 'Prickly Pear', from: 10, color: '#2f8f8a', bloom: true },
    { name: 'Barrel', from: 20, color: '#e0702f', bloom: true },
    { name: 'Saguaro', from: 30, color: '#8a5cc4', bloom: true },
    { name: 'Golden Bloom', from: 45, color: '#c8941a', bloom: true },
    { name: 'Fiesta Cacto', from: 50, color: '#d6336c', bloom: true, fiesta: true }
  ];
  const cum = L => 50 * (L - 1) * (L + 4); // total points needed to reach level L
  const tierOf = L => TIERS.reduce((t, x) => (L >= x.from ? x : t), TIERS[0]);
  function calc(ra) {
    if (!ra || ra.error) return null;
    const hard = ra.hardPoints || 0, soft = ra.softPoints != null ? ra.softPoints : 0, ach = ra.unlocked || 0;
    const points = hard + soft + PER_ACH * ach;
    let L = 1; while (cum(L + 1) <= points) L++;
    const a = cum(L), b = cum(L + 1), t = tierOf(L);
    return { points, ra: hard + soft, ach, level: L, tier: t, next: b, toNext: b - points, pct: Math.max(0, Math.min(100, Math.round((points - a) / (b - a) * 100))) };
  }
  // Level 50 and up: a cactus in a sombrero and poncho shaking maracas
  function fiesta(s) {
    const g = '#3d9a6a'; let x = '';
    x += '<ellipse cx="48" cy="91" rx="24" ry="4" fill="#000" fill-opacity=".14"/><rect x="40" y="28" width="16" height="62" rx="8" fill="' + g + '"/>';
    x += '<path d="M41 62H30V46" stroke="' + g + '" stroke-width="9" stroke-linecap="round" stroke-linejoin="round" fill="none"/><path d="M55 58H66V42" stroke="' + g + '" stroke-width="9" stroke-linecap="round" stroke-linejoin="round" fill="none"/>';
    x += '<defs><clipPath id="cxpc"><path d="M25 60Q48 48 71 60L78 82H18Z"/></clipPath></defs><g clip-path="url(#cxpc)"><rect x="14" y="46" width="68" height="40" fill="#d6453d"/><rect x="14" y="64" width="68" height="5" fill="#f4c542"/><rect x="14" y="69" width="68" height="4" fill="#fff6e0"/><rect x="14" y="73" width="68" height="5" fill="#1f9aa0"/><rect x="14" y="78" width="68" height="6" fill="#f4c542"/></g><path d="M42 53L48 62L54 53" fill="#7a1f1a"/>';
    for (let k = 21; k <= 76; k += 5) x += `<path d="M${k} 82v4" stroke="#f4c542" stroke-width="1.6" stroke-linecap="round"/>`;
    x += '<circle cx="44" cy="40" r="1.9" fill="#1d1710"/><circle cx="52" cy="40" r="1.9" fill="#1d1710"/><path d="M40 46Q44 42.5 48 46Q52 42.5 56 46Q52 48.5 48 47Q44 48.5 40 46Z" fill="#3a2410"/><path d="M44 50Q48 53 52 50" stroke="#1d1710" stroke-width="1.6" fill="none" stroke-linecap="round"/>';
    x += '<ellipse cx="48" cy="31" rx="29" ry="7" fill="#d9a85b" stroke="#a9772c" stroke-width="1.5"/><path d="M37 30Q36 9 48 9Q60 9 59 30Z" fill="#e2b56a" stroke="#a9772c" stroke-width="1.5"/><path d="M37.5 25H58.5L59 30H37Z" fill="#d6453d"/><circle cx="41" cy="27.5" r="1.2" fill="#f4c542"/><circle cx="48" cy="27.5" r="1.2" fill="#f4c542"/><circle cx="55" cy="27.5" r="1.2" fill="#f4c542"/><path d="M21 33Q48 41 75 33" stroke="#f4c542" stroke-width="1.6" fill="none" stroke-linecap="round"/>';
    x += '<path d="M30 44L24 30" stroke="#8a5a2b" stroke-width="3" stroke-linecap="round"/><ellipse cx="21" cy="22" rx="7" ry="9" fill="#d6453d" transform="rotate(-18 21 22)"/><path d="M15.5 20Q21 24 26 17" stroke="#f4c542" stroke-width="2.2" fill="none"/><path d="M66 40L72 26" stroke="#8a5a2b" stroke-width="3" stroke-linecap="round"/><ellipse cx="75" cy="18" rx="7" ry="9" fill="#1f9aa0" transform="rotate(18 75 18)"/><path d="M70 21Q75 14 81 18" stroke="#f4c542" stroke-width="2.2" fill="none"/>';
    x += '<path d="M10 14q-3 4 0 8M7 12q-4 6 0 12M86 8q3 4 0 8M89 6q4 6 0 12" stroke="#d6336c" stroke-width="1.4" fill="none" stroke-linecap="round"/>';
    return `<svg width="${s}" height="${s}" viewBox="0 0 96 96" role="img" aria-label="Cactus in a sombrero and poncho shaking maracas">${x}</svg>`;
  }
  function cactus(t, size) {
    const s = size || 26; if (t.fiesta) return fiesta(s);
    const color = t.color;
    return `<svg width="${s}" height="${s}" viewBox="0 0 64 64" aria-hidden="true"><rect x="26" y="14" width="12" height="42" rx="6" fill="${color}"/><path d="M26 34h-6a4 4 0 0 1-4-4V24a4 4 0 0 1 8 0v4h2z" fill="${color}"/><path d="M38 40h6a4 4 0 0 0 4-4V28a4 4 0 0 0-8 0v6h-2z" fill="${color}"/><path d="M32 18v34" stroke="#fff" stroke-opacity=".28" stroke-width="2"/>${t.bloom ? '<circle cx="32" cy="12" r="5" fill="#f2a1b3"/><circle cx="32" cy="12" r="2" fill="#fbe08a"/>' : ''}</svg>`;
  }
  return { calc, cactus, TIERS, cum, PER_ACH };
})();
