// Other drives (USB sticks, external SSDs): connect them, pick one for the games, disconnect safely. Linux PC / Pi image only.
(function () {
  const gb = n => n >= 1e12 ? (n / 1e12).toFixed(1) + ' TB' : n >= 1e9 ? Math.round(n / 1e9) + ' GB' : Math.round(n / 1e6) + ' MB';
  const BUS = { nvme: 'NVMe', sata: 'SATA', usb: 'USB', mmc: 'SD / eMMC' }, FS = { exfat: 'exFAT', ntfs: 'NTFS', vfat: 'FAT32', ext4: 'ext4', ext3: 'ext3', ext2: 'ext2', btrfs: 'btrfs', xfs: 'XFS' };
  let poll = null;
  const stop = () => { clearInterval(poll); poll = null; };
  async function load(c, connect) { const X = c.S.drv; if (!X) return; const r = await c.api.extList(!!connect).catch(() => ({ supported: false })); if (c.S.drv !== X) return; X.info = r; X.busy = ''; if (!X.focused && c.open() && r && r.supported) { X.focused = true; c.setIdx(c.first()); } c.redraw(); }
  window.drvEnter = c => { c.S.drv = { info: null, msg: '', busy: '' }; load(c, true); stop(); poll = setInterval(() => { if (!c.open() || c.S.drv.busy) { if (!c.open()) stop(); return; } load(c, true); }, 6000); };
  window.drvPage = c => {
    const { A, I: INF } = c, X = c.S.drv, TITLE = 'DRIVES & STORAGE';
    if (!X || !X.info) return { title: TITLE, items: [INF('Status', 'Looking for drives…')] };
    const inf = X.info;
    if (!inf.supported) return { title: TITLE, items: [INF('Not available here', 'Connecting drives from this menu works on the Cacti OS PC image.')] };
    const items = [];
    if (X.msg) items.push(INF('Result', X.msg));
    if (X.busy) items.push(INF('Working', X.busy));
    items.push(INF('Games folder', inf.romRoot || 'not set'));
    if (inf.error) items.push(INF('Problem', inf.error));
    if (!inf.drives.length) items.push(INF('No other drives', 'Plug in a USB drive or external SSD. It shows up here by itself (exFAT, NTFS, FAT32 and ext4 work).'));
    const run = async (busy, fn) => { X.busy = busy; X.msg = ''; c.redraw(); const r = await fn().catch(e => ({ error: String(e && e.message || e) })); X.msg = r && r.error ? r.error : (r && r.folder ? 'Your games folder is now ' + r.folder + '. Put your ROMs in system folders there (snes, gba, psx...).' : 'Done.'); await load(c, false); };
    for (const d of inf.drives) {
      items.push(INF(d.label, `${gb(d.size)} · ${BUS[d.bus] || d.bus} · ${FS[d.fs] || d.fs}${d.mount ? ' · ' + gb(d.free) + ' free' : ' · not connected'}${d.games ? ' · your games are here' : ''}`));
      if (!d.mount) items.push(A('Connect ' + d.label, () => run('Connecting…', () => c.api.extMount(d.name))));
      else {
        if (!d.games) items.push(A('Use ' + d.label + ' for my games', () => run('Switching…', () => c.api.extUse(d.name))));
        items.push(A('Safely disconnect ' + d.label, () => run('Disconnecting…', () => c.api.extUmount(d.name))));
      }
    }
    items.push(A('Look for drives again', () => { X.msg = ''; X.busy = 'Looking…'; c.redraw(); load(c, true); }));
    return { title: TITLE, items };
  };
})();
