// Pre-launch settings for standalone emulators: RetroAchievements sign-in and internal-resolution boost.
// Only existing config files are touched (an emulator that has never been opened is left alone), and only the keys listed here.
const fs = require('fs'), path = require('path'), os = require('os');
const HOME = os.homedir(), WIN = process.platform === 'win32', MAC = process.platform === 'darwin';
const APPDATA = process.env.APPDATA || path.join(HOME, 'AppData', 'Roaming'), DOCS = path.join(HOME, 'Documents'), SUP = path.join(HOME, 'Library', 'Application Support'), CFG = process.env.XDG_CONFIG_HOME || path.join(HOME, '.config');
const pick = (win, mac, lin) => WIN ? win : MAC ? mac : lin;
function setIni(file, section, key, val) {
  let t = fs.readFileSync(file, 'utf8'); const nl = t.includes('\r\n') ? '\r\n' : '\n', L = t.split(/\r?\n/); let sec = false, at = -1, end = -1;
  for (let i = 0; i < L.length; i++) {
    const m = L[i].match(/^\s*\[(.+?)\]\s*$/);
    if (m) { if (sec && end < 0) end = i; sec = m[1].toLowerCase() === section.toLowerCase(); continue; }
    if (sec) { const k = L[i].match(/^\s*([^=;#]+?)\s*=/); if (k && k[1].toLowerCase() === key.toLowerCase()) { at = i; break; } }
  }
  const line = key + ' = ' + val;
  if (at >= 0) L[at] = line;
  else if (end >= 0 || sec) { const pos = end >= 0 ? end : L.length; L.splice(pos, 0, line); }
  else { if (L.length && L[L.length - 1] !== '') L.push(''); L.push('[' + section + ']', line); }
  fs.writeFileSync(file, L.join(nl));
}
const first = list => list.find(f => { try { return fs.existsSync(f); } catch { return false; } });
const FILES = {
  pcsx2: { ini: [path.join(pick(DOCS, SUP, CFG), 'PCSX2', 'inis', 'PCSX2.ini')] },
  dolphin: { dir: [pick(path.join(DOCS, 'Dolphin Emulator'), path.join(SUP, 'Dolphin'), path.join(CFG, 'dolphin-emu'))] },
  ppsspp: { ini: [pick(path.join(DOCS, 'PPSSPP', 'memstick', 'PSP', 'SYSTEM', 'ppsspp.ini'), path.join(SUP, 'PPSSPP', 'PSP', 'SYSTEM', 'ppsspp.ini'), path.join(CFG, 'ppsspp', 'PSP', 'SYSTEM', 'ppsspp.ini'))] },
  flycast: { ini: [pick(path.join(APPDATA, 'flycast', 'emu.cfg'), path.join(SUP, 'Flycast', 'emu.cfg'), path.join(CFG, 'flycast', 'emu.cfg'))] }
};
// opt: { scale: 1..6 (0/1 = leave), user, token, ra: bool }. Returns a list of what was changed.
function apply(emuId, opt = {}) {
  const done = [], scale = Math.max(0, Math.min(8, parseInt(opt.scale, 10) || 0)), ra = opt.ra !== false && opt.user && opt.token;
  try {
    if (emuId === 'pcsx2') { const f = first(FILES.pcsx2.ini); if (!f) return done;
      if (scale > 1) { setIni(f, 'EmuCore/GS', 'upscale_multiplier', String(scale)); done.push('resolution'); }
      if (ra) { setIni(f, 'Achievements', 'Enabled', 'true'); setIni(f, 'Achievements', 'Username', opt.user); setIni(f, 'Achievements', 'Token', opt.token); setIni(f, 'Achievements', 'LoginTimestamp', String(Math.floor(Date.now() / 1000))); done.push('achievements'); } }
    else if (emuId === 'dolphin') { const d = first(FILES.dolphin.dir); if (!d) return done; const cd = path.join(d, 'Config');
      if (scale > 1 && fs.existsSync(path.join(cd, 'GFX.ini'))) { setIni(path.join(cd, 'GFX.ini'), 'Settings', 'InternalResolution', String(scale)); done.push('resolution'); }
      { // L3 + R3 (click both sticks) stops the game, using whichever controller the user already set up in Dolphin
        const pf = ['GCPadNew.ini', 'WiimoteNew.ini'].map(n => path.join(cd, n)).find(x => fs.existsSync(x)); let dev = '';
        if (pf) { const m = fs.readFileSync(pf, 'utf8').match(/^\s*Device\s*=\s*(\S.*?)\s*$/mi); if (m) dev = m[1]; }
        const hf = path.join(cd, 'Hotkeys.ini'); if (dev) { if (!fs.existsSync(hf)) fs.writeFileSync(hf, '[Hotkeys]\n'); const t = fs.readFileSync(hf, 'utf8'); if (!/^\s*General\/Stop\s*=/mi.test(t)) { setIni(hf, 'Hotkeys', 'Device', dev); setIni(hf, 'Hotkeys', 'General/Stop', '@(`Thumb L`&`Thumb R`)'); done.push('quit combo'); } }
        if (fs.existsSync(path.join(cd, 'Dolphin.ini'))) setIni(path.join(cd, 'Dolphin.ini'), 'Interface', 'ConfirmStop', 'False'); }
      if (ra && fs.existsSync(path.join(cd, 'Dolphin.ini'))) { const f = path.join(cd, 'Dolphin.ini'); setIni(f, 'Achievements', 'Enabled', 'True'); setIni(f, 'Achievements', 'Username', opt.user); setIni(f, 'Achievements', 'ApiToken', opt.token); done.push('achievements'); } }
    else if (emuId === 'ppsspp') { const f = first(FILES.ppsspp.ini); if (!f) return done;
      if (scale > 1) { setIni(f, 'Graphics', 'InternalResolution', String(scale)); done.push('resolution'); }
      if (ra) { setIni(f, 'Achievements', 'AchievementsEnable', 'True'); setIni(f, 'Achievements', 'AchievementsUserName', opt.user); done.push('achievements'); } }
    else if (emuId === 'flycast') { const f = first(FILES.flycast.ini); if (!f) return done;
      if (scale > 1) { setIni(f, 'config', 'rend.Resolution', String(480 * scale)); done.push('resolution'); }
      if (ra) { setIni(f, 'achievements', 'Enabled', 'yes'); setIni(f, 'achievements', 'UserName', opt.user); setIni(f, 'achievements', 'Token', opt.token); done.push('achievements'); } }
  } catch {}
  return done;
}
module.exports = { apply, setIni };
