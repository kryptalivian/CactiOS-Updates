// Install Cacti OS onto an internal drive (PC image only). A menu page lists the drives, asks before erasing, then shows the progress.
(function () {
  const gb = n => n >= 1e12 ? (n / 1e12).toFixed(1) + ' TB' : n >= 1e9 ? Math.round(n / 1e9) + ' GB' : Math.round(n / 1e6) + ' MB';
  const BUS = { nvme: 'NVMe', sata: 'SATA', usb: 'USB', mmc: 'SD / eMMC' };
  let poll = null;
  const stop = () => { clearInterval(poll); poll = null; };
  async function load(c) { const X = c.S.inst; if (!X) return; const r = await c.api.instInfo().catch(() => ({ supported: false })); if (c.S.inst !== X) return; X.info = r; if (c.open()) c.setIdx(c.first()); c.redraw(); }
  async function tick(c) {
    const X = c.S.inst; if (!X || !c.open()) { stop(); return; }
    const r = await c.api.instStatus().catch(() => null); if (!r || c.S.inst !== X) return;
    if (r.state === 'run' || ((r.state === 'ok' || r.state === 'err') && !X.ack)) { X.run = r; c.redraw(); }
    if ((r.state === 'ok' || r.state === 'err') && X.run) stop();
  }
  function watch(c) { stop(); tick(c); poll = setInterval(() => tick(c), 1500); }
  window.instEnter = c => { c.S.inst = { info: null, sel: null, keep: true, run: null, msg: '', ack: false }; load(c); watch(c); };
  window.instPage = c => {
    const { A, I: INF, T } = c, X = c.S.inst, TITLE = 'INSTALL CACTI OS';
    if (!X) return { title: TITLE, items: [INF('Status', 'Loading…')] };
    const run = X.run;
    if (run && run.state === 'run') return { title: 'INSTALLING CACTI OS', items: [INF('Progress', run.pct + '%'), INF('Doing now', run.text), INF('Please wait', 'Do not turn off or unplug anything')] };
    if (run && run.state === 'ok') return { title: 'INSTALL FINISHED', items: [INF('Done', 'Cacti OS is installed' + (X.sel ? ' on ' + X.sel.model : '') + '.'), INF('Next', 'Restart and remove the USB stick'), INF('Not starting?', 'Pick the new drive in the boot menu'), A('Restart now', () => c.api.instReboot())] };
    if (run && run.state === 'err') return { title: 'INSTALL FAILED', items: [INF('What happened', run.text), INF('Your USB stick', 'Was not changed'), A('Back to the drive list', () => { X.ack = true; X.run = null; X.sel = null; X.info = null; load(c); c.redraw(); })] };
    const inf = X.info;
    if (!inf) return { title: TITLE, items: [INF('Status', 'Looking for drives…')] };
    if (!inf.supported) return { title: TITLE, items: [INF('Not available here', inf.error || 'Installing works when Cacti OS is running from its own PC image, for example from a USB stick. Start the Cacti OS PC image on this computer to install it.')] };
    const d = X.sel;
    if (d) {
      const items = [INF('Drive', `${d.model} · ${gb(d.size)} · ${BUS[d.bus] || d.bus}`), INF('Warning', 'Everything on it will be erased')];
      if (d.parts) items.push(INF('On it now', `${d.parts} partition${d.parts == 1 ? '' : 's'}`));
      if (X.msg) items.push(INF('Problem', X.msg));
      items.push(A('Cancel', () => { X.sel = null; X.msg = ''; c.setIdx(c.first()); c.redraw(); }),
        T('Copy my games, saves, settings and logins', X.keep, v => { X.keep = v; c.redraw(); }),
        INF(X.keep ? 'Will be copied' : 'Fresh start', X.keep ? `Settings, logins, Wi-Fi, games and saves · about ${gb(inf.dataUsed || 0)}` : 'Starts empty, no logins'),
        A('Erase the drive and install', async () => { X.msg = ''; X.ack = false; const r = await c.api.instStart(d.name, X.keep); if (r.error) { X.msg = r.error; c.redraw(); return; } X.run = { state: 'run', pct: 1, text: 'Starting' }; watch(c); c.redraw(); }));
      return { title: 'ERASE ' + d.model.toUpperCase() + '?', items };
    }
    const items = [INF('What this does', 'Copies Cacti OS to an internal drive'), INF('The drive you pick', 'Is erased first'), INF('Running from', inf.src || 'this system')];
    if (!inf.drives.length) items.push(INF('No other drives found', 'Connect the SSD, then refresh'));
    for (const dr of inf.drives) {
      const label = `${dr.model} · ${gb(dr.size)} · ${BUS[dr.bus] || dr.bus}`;
      if (dr.busy) items.push(INF(label, 'in use'));
      else if (!dr.fits) items.push(INF(label, 'too small'));
      else items.push(A(label, () => { X.sel = dr; X.msg = ''; const pg = window.instPage(c); c.setIdx(pg.items.findIndex(x => x.t == 'act' && x.label == 'Cancel')); c.redraw(); }));
    }
    items.push(A('Refresh the list', () => { X.info = null; load(c); c.redraw(); }));
    return { title: TITLE, items };
  };
})();
