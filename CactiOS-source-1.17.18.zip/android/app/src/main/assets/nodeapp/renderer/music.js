// Audio engine + small overlay UI. Lives in its own (normally hidden) window so music keeps playing during games.
const $ = s => document.querySelector(s);
const au = new Audio(); au.preload = 'auto';
let list = [], idx = -1, shuffle = false, vol = 0.7, order = [], pos = 0, want = false;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
function buildOrder(keep) {
  order = list.map((_, i) => i);
  if (shuffle) for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
  pos = keep >= 0 ? Math.max(0, order.indexOf(keep)) : 0;
}
function load(i, play) {
  if (!list.length) return;
  idx = i; au.src = list[i].url; au.volume = vol;
  if (play) au.play().catch(() => {});
  draw(); push();
}
function step(d) {
  if (!list.length) return;
  pos = (pos + d + order.length) % order.length; load(order[pos], true);
}
function toggle() {
  if (!list.length) return;
  if (idx < 0) { load(order[pos], true); return; }
  au.paused ? au.play().catch(() => {}) : au.pause();
}
function setVol(v) { vol = clamp(Math.round(v * 100) / 100, 0, 1); au.volume = vol; draw(); push(true); }
function draw() {
  const t = list[idx];
  $('#t').textContent = t ? t.title : (list.length ? 'Press play' : 'No music folder set');
  $('#s').textContent = t ? `${t.folder} · ${order.indexOf(idx) + 1} / ${list.length}` : (list.length ? `${list.length} songs` : 'Menu › Music Player');
  $('#pp').textContent = au.paused ? '▶' : '⏸';
  $('#sh').className = shuffle ? 'on' : '';
  $('#vf').style.width = Math.round(vol * 100) + '%'; $('#vn').textContent = Math.round(vol * 100);
  $('#pg').style.width = au.duration ? (au.currentTime / au.duration * 100) + '%' : '0';
}
function push(vchg) {
  const nx = []; for (let k = 1; k <= 4 && order.length > 1; k++) { const t = list[order[(pos + k) % order.length]]; if (t) nx.push(t.title); }
  window.mus.state({ playing: !au.paused && idx >= 0, title: list[idx] ? list[idx].title : '', url: list[idx] ? list[idx].url : '', idx, total: list.length, vol: Math.round(vol * 100), shuffle, volChanged: !!vchg, pos: Math.floor(au.currentTime || 0), dur: Math.floor(isFinite(au.duration) ? au.duration : 0), next: nx, folder: list[idx] ? list[idx].folder : '', mute: au.muted });
}
let lastSec = -1;
au.addEventListener('ended', () => step(1));
let tried = '';
au.addEventListener('error', async () => {
  const t = list[idx]; if (!t) return;
  if (tried !== t.url) { // first failure: convert with a system tool and retry
    tried = t.url; $('#s').textContent = 'Converting…';
    const w = await window.mus.convert(t.url);
    if (w && list[idx] === t) { au.src = w; au.volume = vol; au.play().catch(() => {}); return; }
  }
  $('#s').textContent = "Can't play this file. Skipping";
  if (list.length > 1) setTimeout(() => step(1), 800);
});
au.addEventListener('play', () => { draw(); push(); });
au.addEventListener('pause', () => { draw(); push(); });
au.addEventListener('timeupdate', () => { draw(); const sc = Math.floor(au.currentTime || 0); if (sc !== lastSec) { lastSec = sc; push(); } });
au.addEventListener('loadedmetadata', () => push());
window.mus.onList(d => {
  const cur = list[idx] && list[idx].url;
  list = d.files || []; vol = clamp((d.vol == null ? 70 : d.vol) / 100, 0, 1); shuffle = !!d.shuffle; au.volume = vol;
  const keep = cur ? list.findIndex(x => x.url === cur) : -1;
  if (keep < 0 && idx >= 0) { au.pause(); au.removeAttribute('src'); idx = -1; }
  else idx = keep;
  buildOrder(idx);
  draw(); push();
  if (d.auto && idx < 0 && list.length && !want) { want = true; load(order[pos], true); }
});
window.mus.onCmd(c => {
  const [cmd, arg] = String(c).split(':');
  if (cmd == 'toggle') toggle();
  else if (cmd == 'next') step(1);
  else if (cmd == 'prev') step(-1);
  else if (cmd == 'volup') setVol(vol + 0.1);
  else if (cmd == 'voldown') setVol(vol - 0.1);
  else if (cmd == 'vol') setVol(+arg / 100);
  else if (cmd == 'shuffle') { shuffle = !shuffle; buildOrder(idx); draw(); push(); window.mus.state({ shuffleChanged: true, shuffle }); }
  else if (cmd == 'pause') au.pause();
  else if (cmd == 'mute') { au.muted = !au.muted; push(); }
  else if (cmd == 'seek') { if (au.duration) au.currentTime = au.duration * clamp(+arg, 0, 100) / 100; push(); }
  else if (cmd == 'skip') { if (au.duration) au.currentTime = clamp(au.currentTime + +arg, 0, au.duration); push(); }
  else if (cmd == 'play') { if (order.length) { pos = (pos + (+arg || 0)) % order.length; load(order[pos], true); } }
});
const bump = () => { try { window.mus.cmd('bump'); } catch {} };
const on = (id, fn) => $(id).addEventListener('click', e => { e.stopPropagation(); fn(); bump(); });
on('#sh', () => { shuffle = !shuffle; buildOrder(idx); draw(); push(); window.mus.state({ shuffleChanged: true, shuffle }); });
on('#pv', () => step(-1)); on('#pp', toggle); on('#nx', () => step(1));
on('#vd', () => setVol(vol - 0.1)); on('#vu', () => setVol(vol + 0.1));
on('#cl', () => window.mus.cmd('close'));
$('#vb').addEventListener('click', e => { const r = e.currentTarget.getBoundingClientRect(); setVol((e.clientX - r.left) / r.width); bump(); });
$('#bar').addEventListener('click', e => { if (au.duration) { const r = e.currentTarget.getBoundingClientRect(); au.currentTime = au.duration * (e.clientX - r.left) / r.width; } bump(); });
document.addEventListener('mousemove', () => { bump(); });
// Controller support: when the overlay has focus (opened over a game), read the gamepad directly.
const held = {}; let rep = 0;
function padAct(a) {
  if (a == 'toggle') toggle(); else if (a == 'next') step(1); else if (a == 'prev') step(-1);
  else if (a == 'volup') setVol(vol + 0.1); else if (a == 'voldown') setVol(vol - 0.1);
  else if (a == 'shuffle') { shuffle = !shuffle; buildOrder(idx); draw(); push(); window.mus.state({ shuffleChanged: true, shuffle }); }
  else if (a == 'close') window.mus.cmd('close');
  bump();
}
const PADMAP = { 0: 'toggle', 1: 'close', 2: 'shuffle', 3: 'toggle', 4: 'prev', 5: 'next', 9: 'toggle', 12: 'volup', 13: 'voldown', 14: 'prev', 15: 'next', 16: 'close' };
setInterval(() => {
  if (!document.hasFocus()) { for (const k in held) delete held[k]; return; }
  const pads = (navigator.getGamepads ? [...navigator.getGamepads()] : []).filter(Boolean), now = Date.now(), down = new Set();
  for (const p of pads) {
    p.buttons.forEach((b, i) => { if (b.pressed && PADMAP[i]) down.add(PADMAP[i] + ':' + i); });
    const x = p.axes[0] || 0, y = p.axes[1] || 0;
    if (x < -.6) down.add('prev:ax'); if (x > .6) down.add('next:ax'); if (y < -.6) down.add('volup:ay'); if (y > .6) down.add('voldown:ay');
  }
  for (const k of down) {
    const a = k.split(':')[0];
    if (!held[k]) { held[k] = now; padAct(a); }
    else if ((a == 'volup' || a == 'voldown') && now - held[k] > 450 && now - rep > 140) { rep = now; padAct(a); }
  }
  for (const k in held) if (!down.has(k)) delete held[k];
}, 40);
draw();
