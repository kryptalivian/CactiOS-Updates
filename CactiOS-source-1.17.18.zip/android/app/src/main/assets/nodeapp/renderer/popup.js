// Draws one achievement popup. The main process sends {style, title, desc, points, badge, earned, total, rare, sound}.
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const STY = ['pill', 'banner', 'pixel', 'neon', 'medal'], CLS = { pill: 'p1', banner: 'p2', pixel: 'p3', neon: 'p4', medal: 'p5' };
const NOTES = { pill: [523, 659, 784, 1047], banner: [587, 740, 880], pixel: [523, 523, 784, 1047], neon: [392, 587, 784, 988, 1175], medal: [330, 415, 494, 659, 830] };
let ctx = null, tmr = null;
function chime(style, delay) {
  try {
    ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
    const t0 = ctx.currentTime + delay;
    NOTES[style].forEach((f, i) => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = style === 'pixel' ? 'square' : 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(0, t0 + i * .09); g.gain.linearRampToValueAtTime(style === 'pixel' ? .05 : .12, t0 + i * .09 + .02); g.gain.exponentialRampToValueAtTime(.0001, t0 + i * .09 + .5);
      o.connect(g).connect(ctx.destination); o.start(t0 + i * .09); o.stop(t0 + i * .09 + .55);
    });
  } catch {}
}
const img = (p, cls) => (p.badge ? `<img class="${cls || 'bimg'}" src="${esc(p.badge)}" alt="">` : '<svg class="badge-svg"><use href="#medal"/></svg>');
const pts = p => (p.points ? `<span class="pts"><span data-count="${+p.points || 0}">${+p.points || 0}</span> pts</span>` : '');
const pixBadge = '<svg class="bd" viewBox="0 0 8 8" shape-rendering="crispEdges"><rect width="8" height="8" fill="#2b1f6b"/><path fill="#ffd23f" d="M3 0h2v2h2v2H6v2h1v2H5V6H3v2H1V6h1V4H1V2h2z"/><path fill="#fff6bf" d="M3 2h1v1H3z"/></svg>';
function html(p) {
  const t = esc(p.title || 'Achievement'), d = esc(p.desc || '');
  const frac = p.total ? Math.max(2, Math.min(100, Math.round(100 * (p.earned || 0) / p.total))) : 0;
  switch (p.style) {
    case 'pill': return `<div class="pop p1"><div class="pill"><div class="bd">${img(p)}</div><div class="tx"><span class="label">Achievement unlocked</span><span class="ttl">${t}</span>${pts(p)}</div><div class="shine"></div></div></div>`;
    case 'banner': return `<div class="pop p2"><div class="box"><div class="bd">${img(p)}</div><div class="tx"><span class="label">Achievement unlocked</span><span class="ttl">${t}</span><span class="dsc">${d}</span>${p.total ? `<span class="track"><span class="fill" style="--w:${frac}%"></span></span><span class="meta pts"><span>${p.earned || 0} of ${p.total} earned</span><span>${p.points ? '+' + (+p.points) + ' pts' : ''}</span></span>` : ''}</div></div></div>`;
    case 'pixel': return `<div class="pop p3"><div class="sp"></div><div class="sp"></div><div class="sp"></div><div class="sp"></div><div class="box">${pixBadge}<div class="tx"><span class="label">New achievement</span><span class="ttl">${t}</span><span class="dsc">${d}</span>${p.points ? `<span class="pts">+${+p.points} pts</span>` : ''}</div></div></div>`;
    case 'neon': { let sk = ''; for (let a = 0; a < 360; a += 30) sk += `<i style="--a:${a}deg"></i>`;
      return `<div class="pop p4"><div class="panel"><span class="label">Achievement unlocked</span><span class="ttl">${t}</span>${p.points ? `<span class="pts">+${+p.points} pts</span>` : ''}</div><div class="bw"><span class="r"></span><span class="r b"></span><div class="sk">${sk}</div><div class="bd">${img(p)}</div></div></div>`; }
    case 'medal': return `<div class="pop p5"><div class="box"><div class="coin"><div class="f front"><svg class="badge-svg"><use href="#lock"/></svg></div><div class="f back">${img(p)}</div></div><div class="tx"><span class="label">Achievement unlocked</span><span class="ttl">${t}</span><span class="dsc">${d}</span><span class="row">${pts(p)}${p.rare != null ? `<span class="chip">Rare · ${p.rare}% of players</span>` : ''}</span></div><div class="sheen"></div></div></div>`;
  }
  return '';
}
function count(el, delay) {
  const to = +el.dataset.count; el.textContent = '0';
  setTimeout(() => { const s = performance.now(); (function f(n) { const k = Math.min(1, (n - s) / 700); el.textContent = Math.round(to * k); if (k < 1) requestAnimationFrame(f); })(s); }, delay);
}
const onShow = window.ach ? window.ach.onShow : cb => window.addEventListener('message', e => { const d = e.data; if (e.source !== parent || !d) return; if (d.cactiAchHide) { clearTimeout(tmr); document.getElementById('st').innerHTML = ''; } else if (d.cactiAch) cb(d.cactiAch); });
onShow(p => {
  if (!STY.includes(p.style)) return;
  if (ctx) { try { ctx.close(); } catch {} ctx = null; } // cut off the previous popup's sound
  const st = document.getElementById('st');
  if (p.box) { const b = p.box; Object.assign(st.style, { position: 'absolute', width: b.vw + 'vw', height: (b.vw * .26) + 'vw', left: b.x == 'left' ? '0' : b.x == 'right' ? 'auto' : ((100 - b.vw) / 2) + 'vw', right: b.x == 'right' ? '0' : 'auto', top: b.y == 'top' ? '0' : 'auto', bottom: b.y == 'bottom' ? '0' : 'auto' }); }
  st.innerHTML = html(p);
  const el = st.firstElementChild; if (!el) return;
  void el.offsetWidth; el.classList.add('run');
  el.querySelectorAll('[data-count]').forEach(c => count(c, p.style === 'pill' ? 1300 : 1900));
  if (p.sound) chime(p.style, p.style === 'medal' ? 1.4 : p.style === 'pill' ? .6 : .15);
  clearTimeout(tmr); tmr = setTimeout(() => { st.innerHTML = ''; }, 6200);
});
