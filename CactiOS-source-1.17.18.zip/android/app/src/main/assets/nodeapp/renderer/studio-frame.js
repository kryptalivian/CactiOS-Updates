// Runs inside the Theme Studio preview frame. It shows a mock Cacti OS home screen drawn by the real stylesheet and the real theme engine,
// so what you see in the studio is exactly what the app will show.
(() => {
  const $ = s => document.querySelector(s);
  const TABS = ['NES', 'SNES', 'GENESIS', 'GAME BOY', 'GBA', 'ARCADE', 'PSX'];
  const GAMES = [['Kirby Super Star', 330], ['Donkey Kong Country', 28], ['Super Mario World', 8], ['Chrono Trigger', 262], ['F-Zero', 205], ['Zelda: A Link to the Past', 140], ['Metroid', 350]];
  function build() {
    $('#tabs').innerHTML = '<div id="tpin"><button class="tab">★ FAVORITES</button><button class="tab">RECENT</button></div><div id="tscroll">' + TABS.map((t, i) => `<button class="tab${i == 1 ? ' on' : ''}">${t}</button>`).join('') + '</div>';
    $('#sysname').textContent = 'SUPER NINTENDO'; $('#sysdesc').textContent = '16-bit classics, 1990 to 1996. Mode 7, big sprites and some of the best soundtracks ever made.';
    $('#row').innerHTML = GAMES.map((g, i) => `<button class="card${i == 2 ? ' on' : ''}" style="background:linear-gradient(150deg,hsl(${g[1]},62%,58%),hsl(${(g[1] + 40) % 360},55%,34%))"><span class="orb"></span><span class="ct" style="font-size:25px">${g[0]}</span></button>`).join('');
    $('#gtitle').textContent = 'Super Mario World'; $('#ginfo').innerHTML = '1991 · Platformer · 2 players &nbsp; <span class="gold">★ 12 / 96 achievements</span>';
    $('#clock').textContent = '8:42 PM'; const ti = $('#topav'); if (ti) ti.style.visibility = 'hidden';
    document.querySelectorAll('.hid').forEach(e => e.classList.contains('keep') || 0);
  }
  const fit = () => document.documentElement.style.setProperty('--s', Math.min(innerWidth / 1440, innerHeight / 810));
  addEventListener('resize', () => { fit(); parent.postMessage({ t: 'resized' }, '*'); }); fit();
  const KEYS = Themes.COLOR_KEYS, BL = Themes.BLOCKS;
  function setTheme(raw) {
    Themes.loadCustom([raw]); const id = Themes.ids().find(x => x.startsWith('user'));
    Themes.apply({ theme: id || 'classic', layout: 'custom', dark: !!raw.dark }, null);
    document.documentElement.dataset.layout = 'custom';
    return !!id;
  }
  // The colors a theme really ends up with, including anything it leaves to the light/dark base.
  function effective(raw) {
    Themes.loadCustom([{ ...raw, name: raw.name || 'x', layout: null }]); const id = Themes.ids().find(x => x.startsWith('user')) || 'classic';
    Themes.apply({ theme: id, layout: 'classic', dark: !!raw.dark }, null);
    const cs = getComputedStyle(document.documentElement), o = {};
    KEYS.forEach(k => { o[k] = cs.getPropertyValue('--' + k).trim(); });
    return o;
  }
  function defaults() {
    Themes.applyLayout(null); const o = {};
    for (const [k, sel] of Object.entries(BL)) { const el = $(sel); o[k] = el ? { x: el.offsetLeft, y: el.offsetTop } : { x: 0, y: 0 }; }
    return o;
  }
  function measure() {
    const st = $('#stage').getBoundingClientRect(), sc = st.width / 1440, o = {};
    for (const [k, sel] of Object.entries(BL)) {
      const el = $(sel); if (!el) continue;
      let r;
      if (k === 'hero' || k === 'info') { const ks = [...el.children].map(c => c.getBoundingClientRect()); r = { left: Math.min(...ks.map(a => a.left)), top: Math.min(...ks.map(a => a.top)), right: Math.max(...ks.map(a => a.right)), bottom: Math.max(...ks.map(a => a.bottom)) }; }
      else { const a = el.getBoundingClientRect(); r = { left: a.left, top: a.top, right: a.right, bottom: a.bottom }; }
      if (k === 'row') r.right = Math.min(r.right, st.right);
      if (k === 'line') { r.top -= 6; r.bottom += 6; }
      o[k] = { x: (r.left - st.left) / sc, y: (r.top - st.top) / sc, w: (r.right - r.left) / sc, h: (r.bottom - r.top) / sc, hidden: el.classList.contains('cxhide') };
    }
    return o;
  }
  build(); window.CX = { setTheme, effective, defaults, measure, presets: () => Themes.presets(), fonts: Themes.FONTS, pats: Themes.PATS, sanitize: Themes.sanitize, keys: KEYS, nohide: Themes.NOHIDE };
  parent.postMessage({ t: 'ready' }, '*');
})();
