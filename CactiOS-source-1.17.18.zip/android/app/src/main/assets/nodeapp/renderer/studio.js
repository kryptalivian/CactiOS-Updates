// Cacti OS Theme Studio. Builds a theme (plain JSON: colors, font, pattern, corner roundness and where the home screen pieces sit)
// and previews it with the app's own stylesheet and theme engine. Nothing here runs inside Cacti OS itself.
(() => {
  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const API = window.api && window.api.themeSave ? window.api : null, SA = window.__STANDALONE || null;
  const STAGE = { w: 1440, h: 810 };
  const BLOCKS = [['logo', 'Logo'], ['tray', 'Top icons'], ['tabs', 'System tabs'], ['hero', 'System name'], ['row', 'Game cards'], ['info', 'Game title'], ['line', 'Divider line'], ['foot', 'Button hints']];
  const NOHIDE = ['row', 'tabs'];
  const FONT_NAMES = { system: 'Clean', condensed: 'Condensed', mono: 'Mono', comic: 'Comic', bubble: 'Bubbly', plex: 'Terminal', rounded: 'Rounded' };
  const PAT_NAMES = { '': 'None', scan: 'Scanlines', grid: 'Grid', dots: 'Dots', px: 'Pixels', stripes: 'Stripes', speed: 'Speed lines', sym: 'Symbols', halftone: 'Halftone', bgrid: 'Blueprint', stars: 'Stars' };
  const ALPHA = ['glass', 'line', 'chip', 'shadow', 'glow'];
  const GROUPS = [
    ['Background', 'The three colors the screen fades through, top to bottom.', [['bg1', 'Top'], ['bg2', 'Middle'], ['bg3', 'Bottom']]],
    ['Glowing blobs', 'Soft colored light drifting behind everything.', [['b1', 'Blob one'], ['b2', 'Blob two'], ['b3', 'Blob three']]],
    ['Text', null, [['ink', 'Main text'], ['mut', 'Soft text', 'Descriptions and hints']]],
    ['Highlight', 'Selected tab, the ring around the chosen game, buttons.', [['acc', 'Highlight color'], ['onacc', 'Text on highlight'], ['gold', 'Gold', 'Stars and achievements'], ['glow', 'Selection glow']]],
    ['Panels and buttons', null, [['glass', 'Menu panels'], ['chip', 'Buttons and tiles'], ['line', 'Thin lines'], ['shadow', 'Shadows']]],
    ['Button hints', 'The A / B prompts along the bottom.', [['pa', 'Play (A)'], ['pb', 'Back (B)']]],
    ['Profile bubble', null, [['dot', 'Online dot'], ['avb', 'Ring'], ['ava1', 'Avatar start'], ['ava2', 'Avatar end']]]
  ];
  const TEMPLATES = [
    ['Classic', {}],
    ['Hero below', { tabs: [64, 104], row: [64, 192], info: [64, 458], hero: [64, 528, .85], line: [64, 752], foot: [64, 762] }],
    ['Big cards', { hero: [64, 150, .75], row: [64, 290, 1.3], info: [64, 650] }],
    ['Minimal', { hero: [64, 0, 1, 1], row: [64, 250], info: [64, 590, 1.5] }]
  ];
  const $nm = $('#tname');
  let T, DEF = {}, SIZES = {}, sel = 'row', tab = 'start', ready = false, snap = true, PRE = [], hist = [], hi = -1, guides = [];

  // ----- colors -----
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const hex2 = n => clamp(Math.round(n), 0, 255).toString(16).padStart(2, '0');
  function parse(c) {
    c = String(c || '').trim(); let m;
    if ((m = /^#([0-9a-f]{3,8})$/i.exec(c))) { let h = m[1]; if (h.length < 6) h = h.split('').map(x => x + x).join(''); return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16), a: h.length >= 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1 }; }
    if ((m = /^rgba?\(([^)]+)\)/i.exec(c))) { const p = m[1].split(',').map(x => parseFloat(x)); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; }
    return { r: 128, g: 128, b: 128, a: 1 };
  }
  const toHex = o => '#' + hex2(o.r) + hex2(o.g) + hex2(o.b);
  const fmt = o => (o.a >= .995 ? toHex(o) : `rgba(${Math.round(o.r)},${Math.round(o.g)},${Math.round(o.b)},${Math.round(o.a * 100) / 100})`);
  const lum = o => { const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(o.r) + .7152 * f(o.g) + .0722 * f(o.b); };
  const ratio = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };
  function hsl(h, s, l, a = 1) { h = ((h % 360) + 360) % 360; s /= 100; l /= 100; const k = n => (n + h / 30) % 12, f = n => l - s * Math.min(l, 1 - l) * Math.max(-1, Math.min(k(n) - 3, 9 - k(n), 1)); return { r: f(0) * 255, g: f(8) * 255, b: f(4) * 255, a }; }
  function hueOf(o) { const r = o.r / 255, g = o.g / 255, b = o.b / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; if (!d) return 220; let h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; return (h * 60 + 360) % 360; }
  function palette(h, dark) {
    const A = hsl(h, dark ? 90 : 80, dark ? 68 : 48), bg2 = hsl(h, dark ? 38 : 55, dark ? 10 : 92);
    const v = dark ? { bg1: hsl(h, 35, 13), bg2, bg3: hsl(h + 25, 35, 15), ink: hsl(h, 30, 95), mut: hsl(h, 18, 70), glass: { ...hsl(h, 30, 15), a: .96 }, line: { r: 255, g: 255, b: 255, a: .16 }, chip: { r: 255, g: 255, b: 255, a: .1 }, shadow: { r: 0, g: 0, b: 0, a: .5 }, onacc: hsl(h, 40, 9), gold: { r: 242, g: 179, b: 61, a: 1 }, b1: hsl(h, 70, 35), b2: hsl(h + 40, 70, 40), b3: hsl(h - 40, 65, 32), pa: { r: 76, g: 217, b: 138, a: 1 }, pb: { r: 255, g: 107, b: 107, a: 1 } }
      : { bg1: hsl(h, 60, 95), bg2, bg3: hsl(h + 25, 50, 94), ink: hsl(h, 35, 15), mut: hsl(h, 15, 40), glass: { r: 255, g: 255, b: 255, a: .94 }, line: { r: 20, g: 30, b: 70, a: .14 }, chip: { r: 255, g: 255, b: 255, a: .75 }, shadow: { r: 30, g: 40, b: 90, a: .22 }, onacc: { r: 255, g: 255, b: 255, a: 1 }, gold: { r: 154, g: 103, b: 0, a: 1 }, b1: hsl(h, 80, 82), b2: hsl(h + 40, 80, 84), b3: hsl(h - 40, 60, 86), pa: { r: 35, g: 132, b: 77, a: 1 }, pb: { r: 194, g: 58, b: 58, a: 1 } };
    const o = { ...v, acc: A, glow: { ...A, a: .4 }, dot: { r: 47, g: 191, b: 113, a: 1 }, avb: A, ava1: hsl(h, 70, 60), ava2: hsl(h + 60, 65, 55) };
    const r = {}; for (const k in o) r[k] = fmt(o[k]); return r;
  }

  // ----- state -----
  const frame = () => $('#pv').contentWindow.CX;
  const clean = () => {
    const o = { name: (T.name || 'My Theme').trim() || 'My Theme', dark: !!T.dark, font: T.font, pattern: T.pattern || '', vars: { ...T.vars }, radius: T.radius, blobs: T.blobs };
    const L = {}; for (const [k] of BLOCKS) if (T.layout[k]) L[k] = { ...T.layout[k] }; if (Object.keys(L).length) o.layout = L; return o;
  };
  const snapshot = () => JSON.stringify(clean());
  function commit() { const s = snapshot(); if (hist[hi] === s) return; hist = hist.slice(0, hi + 1); hist.push(s); if (hist.length > 80) hist.shift(); hi = hist.length - 1; updUndo(); }
  function updUndo() { $('#undo').disabled = hi <= 0; $('#redo').disabled = hi >= hist.length - 1; }
  function load(raw, keepHist) {
    const base = { ...raw, name: raw.name || 'My Theme' };
    T = { name: base.name, dark: !!base.dark, font: base.font || 'system', pattern: base.pattern || base.pat || '', vars: { ...frame().effective({ ...base, dark: !!base.dark, font: undefined }), ...(base.vars || {}) }, radius: base.radius != null ? base.radius : 14, blobs: base.blobs != null ? base.blobs : .6, layout: {} };
    if (base.layout) for (const k in base.layout) T.layout[k] = { ...base.layout[k] };
    $nm.value = T.name; if (!keepHist) { hist = []; hi = -1; } render(); syncUI(); commit();
  }
  function render() {
    if (!ready) return; frame().setTheme(clean());
    requestAnimationFrame(overlay); if (tab === 'save') $('#jsonout') && ($('#jsonout').value = JSON.stringify(exportObj(), null, 2));
  }
  const exportObj = () => { const o = clean(); o.pattern = o.pattern || undefined; return JSON.parse(JSON.stringify(o)); };
  const slug = n => String(n).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'theme';
  function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2600); }

  // ----- preview overlay (drag handles) -----
  const stageScale = () => $('#ov').clientWidth / STAGE.w;
  const posOf = k => T.layout[k] || { x: DEF[k].x, y: DEF[k].y, s: 1, hide: false };
  function overlay() {
    if (!ready) return; const ov = $('#ov'), sc = stageScale(), m = frame().measure(); ov.classList.toggle('edit', tab === 'layout');
    ov.innerHTML = '';
    for (const [k, nm] of BLOCKS) {
      const r = m[k]; if (!r) continue; if (!r.hidden && r.w > 0) SIZES[k] = { w: r.w, h: r.h };
      const sz = r.hidden ? (SIZES[k] || { w: 120, h: 40 }) : r, p = posOf(k), d = document.createElement('div');
      d.className = 'hb' + (k === sel ? ' sel' : '') + (r.hidden ? ' off' : ''); d.dataset.k = k;
      Object.assign(d.style, { left: (r.hidden ? p.x : r.x) * sc + 'px', top: (r.hidden ? p.y : r.y) * sc + 'px', width: Math.max(sz.w * sc, 14) + 'px', height: Math.max(sz.h * sc, 14) + 'px', display: tab === 'layout' ? '' : 'none' });
      d.innerHTML = `<span class="lb">${nm}${r.hidden ? ' (hidden)' : ''}</span><span class="rz"></span>`;
      d.addEventListener('pointerdown', e => startDrag(e, k, e.target.classList.contains('rz')));
      ov.appendChild(d);
    }
    guides.forEach(g => { const d = document.createElement('div'); d.className = 'guide ' + g[0]; d.style[g[0] === 'v' ? 'left' : 'top'] = g[1] * sc + 'px'; ov.appendChild(d); });
  }
  function startDrag(e, k, resize) {
    e.preventDefault(); e.stopPropagation(); select(k, true); const sc = stageScale(), p0 = { ...posOf(k) }, sz = { ...(SIZES[k] || { w: 100, h: 40 }) }, sx = e.clientX, sy = e.clientY, el = e.currentTarget;
    el.setPointerCapture(e.pointerId); el.classList.add('drag'); let moved = false, raf = 0;
    const move = ev => {
      moved = true; const dx = (ev.clientX - sx) / sc, dy = (ev.clientY - sy) / sc; guides = [];
      if (resize) { T.layout[k] = { ...p0, s: Math.round(clamp(p0.s * (sz.w + dx) / sz.w, .4, 2.5) * 100) / 100 }; }
      else {
        let x = p0.x + dx, y = p0.y + dy; const w = sz.w, h = sz.h;
        if (snap && !ev.altKey) {
          const xs = [64, 720 - w / 2, 1376 - w], ys = [24, 405 - h / 2, 786 - h]; let hx = false, hy = false;
          for (const c of xs) if (Math.abs(x - c) < 7) { x = c; guides.push(['v', c + (c === xs[1] ? w / 2 : c === xs[2] ? w : 0)]); hx = true; break; }
          for (const c of ys) if (Math.abs(y - c) < 7) { y = c; guides.push(['h', c + (c === ys[1] ? h / 2 : c === ys[2] ? h : 0)]); hy = true; break; }
          if (!hx) x = Math.round(x / 4) * 4; if (!hy) y = Math.round(y / 4) * 4;
        }
        T.layout[k] = { ...p0, x: Math.round(clamp(x, -400, 1600)), y: Math.round(clamp(y, -400, 1000)) };
      }
      if (!raf) raf = requestAnimationFrame(() => { raf = 0; render(); syncLayoutUI(); });
    };
    const up = () => { el.removeEventListener('pointermove', move); el.removeEventListener('pointerup', up); el.removeEventListener('pointercancel', up); guides = []; render(); if (moved) commit(); syncLayoutUI(); };
    el.addEventListener('pointermove', move); el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
  }
  function select(k, noScroll) { sel = k; render(); syncLayoutUI(); }

  // ----- panels -----
  const P = n => $(`[data-p="${n}"]`);
  function buildStart() {
    const el = P('start');
    el.innerHTML = `<h3>Start from a look</h3><p class="n">Pick anything as a starting point. You can change every detail afterwards.</p><div class="grid2" id="presets"></div>
      <h3>Or build from one color</h3><p class="n">Choose your highlight color and Studio picks matching backgrounds and text.</p>
      <div class="col"><input type="color" id="gcol" value="#7a5cff"><span class="nm">Highlight color</span><span></span></div>
      <div class="chips"><button id="gdark">Make it dark</button><button id="glight">Make it light</button><button id="gshuf">Surprise me</button></div>
      <h3>Your saved themes</h3><div id="mine"><p class="n">${API ? 'Nothing saved yet.' : 'Saved themes appear here when you open Theme Studio from inside Cacti OS. Here, use Import on the Save tab to reopen a theme file.'}</p></div>`;
    const ph = $('#presets');
    PRE.forEach((p, i) => { const b = document.createElement('button'); b.className = 'preset'; const c = p.eff;
      b.innerHTML = `<div class="pt" style="background:linear-gradient(160deg,${c.bg1},${c.bg2} 55%,${c.bg3});color:${c.ink}">Aa<i style="background:${c.acc}"></i></div><div class="pn">${p.name}</div>`;
      b.onclick = () => { load({ ...p, name: p.name + ' copy' }); toast('Loaded “' + p.name + '”. Now make it yours.'); }; ph.appendChild(b); });
    const gen = d => { const h = hueOf(parse($('#gcol').value)); T.vars = { ...T.vars, ...palette(h, d) }; T.dark = d; const ac = parse($('#gcol').value); T.vars.acc = fmt({ ...ac, a: 1 }); T.vars.avb = T.vars.acc; T.vars.glow = fmt({ ...ac, a: .4 }); syncUI(); render(); commit(); };
    $('#gdark').onclick = () => gen(true); $('#glight').onclick = () => gen(false);
    $('#gshuf').onclick = () => { const h = Math.floor(Math.random() * 360); $('#gcol').value = toHex(hsl(h, 80, 55)); gen(Math.random() < .6); };
    refreshMine();
  }
  async function refreshMine() {
    if (!API || !API.themes) return; const box = $('#mine'); let list = []; try { list = await API.themes(); } catch {} if (!box) return;
    if (!list.length) { box.innerHTML = '<p class="n">Nothing saved yet.</p>'; return; }
    box.innerHTML = ''; list.forEach(t => { if (!t || !t.name || t.name.startsWith('My Theme (rename')) return; const d = document.createElement('div'); d.className = 'mine'; d.innerHTML = `<b></b><button>Edit</button><button>Delete</button>`; d.firstChild.textContent = t.name; const [ed, del] = d.querySelectorAll('button');
      ed.onclick = () => { const s = frame().sanitize(t); if (!s) return toast('That file could not be read'); load({ ...t }); setTab('colors'); }; del.onclick = async () => { if (!confirm('Delete “' + t.name + '”?')) return; await API.themeDelete(t.name); refreshMine(); }; box.appendChild(d); });
  }
  const colRow = (k, nm, hint) => {
    const alpha = ALPHA.includes(k);
    return `<div class="col" data-k="${k}"><input type="color" data-c="${k}" aria-label="${nm}"><span class="nm">${nm}${hint ? `<small>${hint}</small>` : ''}</span><code data-h="${k}"></code>${alpha ? `<div class="al">See-through <input type="range" min="0" max="100" data-a="${k}" aria-label="${nm} opacity"></div>` : ''}</div>`;
  };
  function buildColors() {
    const el = P('colors'); el.innerHTML = `<div class="row"><label for="dk">Dark theme</label><input type="checkbox" id="dk" style="width:20px;height:20px;accent-color:var(--acc)"></div><p class="n">Dark theme tells Cacti OS to use light-on-dark styling for anything you don't color yourself.</p>` +
      GROUPS.map(([t, d, ks]) => `<h3>${t}${t === 'Text' ? '<span id="contrast"></span>' : ''}</h3>${d ? `<p class="n">${d}</p>` : ''}${ks.map(a => colRow(a[0], a[1], a[2])).join('')}${t === 'Glowing blobs' ? `<div class="row"><label for="blobs">Blob strength</label><input id="blobs" type="range" min="0" max="100"><output id="blobsO"></output></div>` : ''}`).join('');
    $$('[data-c]', el).forEach(i => i.addEventListener('input', () => { const k = i.dataset.c, old = parse(T.vars[k]); T.vars[k] = fmt({ ...parse(i.value), a: ALPHA.includes(k) ? old.a : 1 }); render(); syncColors(); }));
    $$('[data-c]', el).forEach(i => i.addEventListener('change', commit));
    $$('[data-a]', el).forEach(i => { i.addEventListener('input', () => { const k = i.dataset.a, o = parse(T.vars[k]); T.vars[k] = fmt({ ...o, a: i.value / 100 }); render(); syncColors(); }); i.addEventListener('change', commit); });
    $('#dk').onchange = e => { T.dark = e.target.checked; render(); commit(); };
    $('#blobs').oninput = e => { T.blobs = e.target.value / 100; $('#blobsO').textContent = e.target.value + '%'; render(); }; $('#blobs').onchange = commit;
  }
  function syncColors() {
    $$('[data-c]').forEach(i => { const o = parse(T.vars[i.dataset.c]); i.value = toHex(o); }); $$('[data-h]').forEach(c => { c.textContent = T.vars[c.dataset.h]; });
    $$('[data-a]').forEach(i => { i.value = Math.round(parse(T.vars[i.dataset.a]).a * 100); });
    const cr = ratio(parse(T.vars.ink), parse(T.vars.bg2)), cb = ratio(parse(T.vars.onacc), parse(T.vars.acc)), badge = (r, t) => `<span class="badge ${r >= 4.5 ? 'ok' : r >= 3 ? 'warn' : 'bad'}" title="${t}">${r >= 4.5 ? 'Easy to read' : r >= 3 ? 'A bit faint' : 'Hard to read'}</span>`;
    const c = $('#contrast'); if (c) c.innerHTML = badge(cr, 'Main text against the background: ' + cr.toFixed(1) + ':1') + (cb < 3 ? '<span class="badge bad" title="Text on highlight">Highlight text hard to read</span>' : '');
  }
  function buildStyle() {
    const el = P('style'), F = frame().fonts, PT = frame().pats;
    el.innerHTML = `<h3>Font</h3>${Object.keys(F).map(k => `<button class="font" data-f="${k}" style="font-family:${F[k]}"><b>Retro Games</b><span>${FONT_NAMES[k] || k}</span></button>`).join('')}
      <h3>Background pattern</h3><div class="pats">${Object.keys(PAT_NAMES).map(k => { const pt = PT[k]; return `<button class="pat" data-pt="${k}" style="${pt ? `background-image:${pt[0]};background-size:${pt[1]}` : ''}"><span>${PAT_NAMES[k]}</span></button>`; }).join('')}</div>
      <h3>Shape</h3><div class="row"><label for="rad">Card roundness</label><input id="rad" type="range" min="0" max="40"><output id="radO"></output></div><p class="n">0 is sharp pixel corners, 40 is very round.</p>`;
    $$('[data-f]', el).forEach(b => b.onclick = () => { T.font = b.dataset.f; render(); syncStyle(); commit(); });
    $$('[data-pt]', el).forEach(b => b.onclick = () => { T.pattern = b.dataset.pt; render(); syncStyle(); commit(); });
    $('#rad').oninput = e => { T.radius = +e.target.value; $('#radO').textContent = e.target.value + 'px'; render(); }; $('#rad').onchange = commit;
  }
  function syncStyle() { $$('[data-f]').forEach(b => b.classList.toggle('on', b.dataset.f === T.font)); $$('[data-pt]').forEach(b => b.classList.toggle('on', b.dataset.pt === (T.pattern || ''))); $('#rad').value = T.radius; $('#radO').textContent = T.radius + 'px'; }
  function buildLayout() {
    const el = P('layout');
    el.innerHTML = `<h3>Move things around</h3><p class="n"><b>Drag</b> any piece in the preview. Use the white square at a corner to <b>resize</b>, or the arrow keys to nudge (hold Shift for bigger steps). Hold Alt while dragging to turn snapping off.</p>
      <div class="chips" id="tpl"></div><div class="switch"><span>Snap to guides</span><input type="checkbox" id="snap" checked></div>
      <h3>Pieces</h3><div id="blks"></div><div id="inspect"></div>
      <button class="btn" id="lreset">Put everything back where it was</button>
      <p class="n">To use a layout in Cacti OS: pick this theme in Menu › Themes. The home screen switches to “Custom (from theme)” automatically.</p>`;
    const tp = $('#tpl'); TEMPLATES.forEach(([n, o]) => { const b = document.createElement('button'); b.textContent = n; b.onclick = () => { T.layout = {}; for (const k in o) { const a = o[k]; T.layout[k] = { x: a[0], y: a[1], s: a[2] || 1, hide: !!a[3] }; } render(); syncLayoutUI(); commit(); }; tp.appendChild(b); });
    $('#snap').onchange = e => { snap = e.target.checked; }; $('#lreset').onclick = () => { T.layout = {}; render(); syncLayoutUI(); commit(); };
  }
  function syncLayoutUI() {
    const bl = $('#blks'); if (!bl) return; bl.innerHTML = '';
    BLOCKS.forEach(([k, nm]) => { const p = posOf(k), d = document.createElement('div'); d.className = 'blk' + (k === sel ? ' sel' : '') + (p.hide ? ' off' : ''); d.innerHTML = `<b>${nm}</b>${NOHIDE.includes(k) ? '' : `<button title="Show or hide" aria-label="Show or hide ${nm}">${p.hide ? '🙈' : '👁'}</button>`}`;
      d.onclick = () => select(k); const bt = d.querySelector('button'); if (bt) bt.onclick = e => { e.stopPropagation(); T.layout[k] = { ...posOf(k), hide: !p.hide }; render(); syncLayoutUI(); commit(); }; bl.appendChild(d); });
    const p = posOf(sel), ins = $('#inspect');
    ins.innerHTML = `<h3>${BLOCKS.find(b => b[0] === sel)[1]}</h3><div class="num"><label>Left<input type="number" id="nx" value="${p.x}"></label><label>Top<input type="number" id="ny" value="${p.y}"></label></div>
      <div class="row"><label for="ns">Size</label><input id="ns" type="range" min="40" max="250" value="${Math.round(p.s * 100)}"><output>${Math.round(p.s * 100)}%</output></div><button class="btn" id="rb">Reset this piece</button>`;
    const upd = () => { T.layout[sel] = { ...posOf(sel), x: +$('#nx').value || 0, y: +$('#ny').value || 0, s: +$('#ns').value / 100 }; render(); };
    ['#nx', '#ny'].forEach(s => { $(s).oninput = () => { upd(); }; $(s).onchange = () => { commit(); }; }); $('#ns').oninput = e => { upd(); e.target.nextElementSibling.textContent = e.target.value + '%'; }; $('#ns').onchange = commit;
    $('#rb').onclick = () => { delete T.layout[sel]; render(); syncLayoutUI(); commit(); };
  }
  function buildSave() {
    const el = P('save');
    el.innerHTML = `<h3>Save</h3>${API ? `<button class="btn p" id="sv">Save and use in Cacti OS</button><p class="n">Saves into your Cacti OS themes folder and switches to it right away.</p>` : ''}
      <button class="btn ${API ? '' : 'p'}" id="dl">Download theme file (.json)</button>
      <button class="btn" id="cp">Copy theme text</button>
      <button class="btn" id="im">Open a theme file…</button>
      ${API ? '' : `<p class="n"><b>Installing a downloaded theme:</b> in Cacti OS open Menu › Themes › Open custom themes folder, drop the .json file in, and pick the theme under Menu › Themes › Theme.</p>`}
      <h3>Theme text</h3><textarea id="jsonout" readonly spellcheck="false"></textarea><p class="n">Themes are plain data: colors, a font name, a pattern name and where things sit. They can't run code.</p>`;
    const dl = () => { const b = new Blob([JSON.stringify(exportObj(), null, 2)], { type: 'application/json' }), a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = slug(T.name) + '.json'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); toast('Downloaded ' + slug(T.name) + '.json'); };
    $('#dl').onclick = dl; $('#cp').onclick = async () => { try { await navigator.clipboard.writeText(JSON.stringify(exportObj(), null, 2)); toast('Copied'); } catch { $('#jsonout').select(); document.execCommand('copy'); toast('Copied'); } };
    $('#im').onclick = () => $('#imp').click();
    if (API) $('#sv').onclick = saveApp;
  }
  async function saveApp() {
    const o = exportObj(), r = await API.themeSave(o); if (!r || !r.ok) return toast('Could not save: ' + ((r && r.err) || 'unknown error'));
    try { const list = await API.themes(); const i = list.findIndex(t => t && t.name === o.name.replace(/[^\w .\-+&']/g, '').trim().slice(0, 24)); if (i >= 0) { const cfg = await API.getConfig(); await API.setConfig(o.layout ? { theme: 'user' + i, layout: 'custom' } : { theme: 'user' + i }); void cfg; } } catch {}
    toast('Saved. It is now your active theme.'); refreshMine();
  }
  function setTab(t) {
    tab = t; $$('#ptabs button').forEach(b => b.classList.toggle('on', b.dataset.t === t)); $$('#pbody > section').forEach(s => { s.hidden = s.dataset.p !== t; });
    $('#hint').textContent = t === 'layout' ? 'Drag the highlighted pieces. Click a piece to select it.' : 'What you see here is drawn by the same engine Cacti OS uses.'; render(); if (t === 'save') $('#jsonout').value = JSON.stringify(exportObj(), null, 2);
  }
  function syncUI() { syncColors(); syncStyle(); $('#dk').checked = !!T.dark; $('#blobs').value = Math.round(T.blobs * 100); $('#blobsO').textContent = Math.round(T.blobs * 100) + '%'; syncLayoutUI(); }

  // ----- wiring -----
  $nm.addEventListener('input', () => { T.name = $nm.value; if (tab === 'save') render(); }); $nm.addEventListener('change', commit);
  $$('#ptabs button').forEach(b => b.onclick = () => setTab(b.dataset.t));
  $('#hsave').onclick = () => { setTab('save'); if (API) saveApp(); else $('#dl').click(); };
  const step = d => { const n = hi + d; if (n < 0 || n >= hist.length) return; hi = n; const o = JSON.parse(hist[n]); load(o, true); updUndo(); };
  $('#undo').onclick = () => step(-1); $('#redo').onclick = () => step(1);
  $('#imp').onchange = async e => { const f = e.target.files[0]; if (!f) return; try { const raw = JSON.parse(await f.text()); if (!frame().sanitize(raw)) throw 0; load(raw); setTab('colors'); toast('Opened “' + raw.name + '”'); } catch { toast('That file is not a Cacti OS theme'); } e.target.value = ''; };
  addEventListener('keydown', e => {
    const typing = /input|textarea/i.test(e.target.tagName) && e.target.type !== 'range' && e.target.type !== 'checkbox';
    if ((e.ctrlKey || e.metaKey) && !typing) { if (e.key.toLowerCase() === 'z') { e.preventDefault(); step(e.shiftKey ? 1 : -1); } else if (e.key.toLowerCase() === 'y') { e.preventDefault(); step(1); } return; }
    if (tab === 'layout' && !typing && e.key.startsWith('Arrow')) { e.preventDefault(); const n = e.shiftKey ? 10 : 1, p = posOf(sel), d = { ArrowLeft: [-n, 0], ArrowRight: [n, 0], ArrowUp: [0, -n], ArrowDown: [0, n] }[e.key]; T.layout[sel] = { ...p, x: p.x + d[0], y: p.y + d[1] }; render(); syncLayoutUI(); clearTimeout(step.t); step.t = setTimeout(commit, 400); }
  });
  addEventListener('resize', () => requestAnimationFrame(overlay));
  addEventListener('message', e => {
    if (!e.data || e.source !== $('#pv').contentWindow) return;
    if (e.data.t === 'resized') return render();
    if (e.data.t !== 'ready') return;
    const C = frame(); PRE = []; const seen = C.presets();
    seen.forEach(p => { if (p.id === 'classic') { PRE.push({ ...p, name: 'Classic Light', dark: false, eff: C.effective({ name: 'x', dark: false, vars: {} }), vars: {} }); PRE.push({ ...p, name: 'Classic Dark', dark: true, eff: C.effective({ name: 'x', dark: true, vars: {} }), vars: {} }); } else PRE.push({ ...p, dark: !!p.dark, eff: C.effective({ name: 'x', dark: !!p.dark, font: p.font, pattern: p.pat, vars: p.vars }) }); });
    DEF = C.defaults(); ready = true; buildStart(); buildColors(); buildStyle(); buildLayout(); buildSave();
    load({ ...PRE[1], name: 'My Theme', vars: PRE[1].eff, pattern: PRE[1].pat }); setTab('start');
  });
  // preview frame: shows the mock home screen using the app's real stylesheet and theme engine
  const f = $('#pv');
  const head = SA ? `<style>${SA.style}</style>` : '<link rel="stylesheet" href="style.css">';
  const scr = SA ? `<script>${SA.themes}<\/script><script>${SA.frame}<\/script>` : '<script src="themes.js"><\/script><script src="studio-frame.js"><\/script>';
  f.srcdoc = `<!doctype html><html><head><meta charset="utf-8">${head}</head><body>${window.__STAGE}${scr}</body></html>`;
})();
