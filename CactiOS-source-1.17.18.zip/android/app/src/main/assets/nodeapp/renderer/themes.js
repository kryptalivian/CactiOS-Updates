// Cacti OS themes and per-system skins. Themes are plain data (colors only); nothing here runs user code.
const Themes = (() => {
  const COLOR = /^(#[0-9a-f]{3,8}|rgba?\(\s*[\d.]+\s*(,\s*[\d.]+%?\s*){2,3}\))$/i;
  const COLOR_KEYS = ['bg1', 'bg2', 'bg3', 'ink', 'mut', 'glass', 'line', 'acc', 'onacc', 'gold', 'chip', 'shadow', 'b1', 'b2', 'b3', 'dot', 'avb', 'ava1', 'ava2', 'pa', 'pb', 'glow'];
  const FONTS = { system: "-apple-system,'SF Pro Display','Segoe UI',system-ui,sans-serif", condensed: "'Avenir Next Condensed','DIN Condensed','Arial Narrow',sans-serif", mono: "ui-monospace,'SF Mono','Cascadia Mono',Menlo,Consolas,monospace", comic: "Bangers,'Comic Sans MS','Chalkboard SE','Marker Felt',Impact,sans-serif", bubble: "'Baloo 2','Arial Rounded MT Bold',ui-rounded,'Nunito',system-ui,sans-serif", plex: "'IBM Plex Mono',ui-monospace,'SF Mono','Cascadia Mono',Menlo,Consolas,monospace", rounded: "ui-rounded,'SF Pro Rounded','Nunito','Segoe UI',system-ui,sans-serif" };
  const svg = (body, s) => `url("data:image/svg+xml,${encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' width='${s}' height='${s}'>${body}</svg>`)}")`;
  const PATS = {
    scan: [svg("<rect width='4' height='1' fill='black' fill-opacity='.18'/>", 4), '4px 4px'],
    grid: [svg("<path d='M32 0H0V32' fill='none' stroke='white' stroke-opacity='.07'/>", 32), '32px 32px'],
    dots: [svg("<circle cx='12' cy='12' r='2' fill='white' fill-opacity='.10'/>", 24), '24px 24px'],
    px: [svg("<rect width='6' height='6' fill='black' fill-opacity='.035'/><rect x='6' y='6' width='6' height='6' fill='black' fill-opacity='.035'/>", 12), '12px 12px'],
    stripes: [svg("<path d='M-4 4L4 -4M0 24L24 0M20 28L28 20' stroke='white' stroke-opacity='.07' stroke-width='5'/>", 24), '24px 24px'],
    speed: [svg("<rect y='6' width='40' height='3' fill='white' fill-opacity='.06'/><rect x='16' y='20' width='24' height='3' fill='white' fill-opacity='.05'/>", 40), '40px 40px'],
    sym: [svg("<circle cx='14' cy='14' r='6' fill='none' stroke='white' stroke-opacity='.08' stroke-width='2'/><path d='M62 8L72 24H52Z' fill='none' stroke='white' stroke-opacity='.08' stroke-width='2'/><path d='M10 54L22 66M22 54L10 66' stroke='white' stroke-opacity='.08' stroke-width='2'/><rect x='54' y='54' width='14' height='14' fill='none' stroke='white' stroke-opacity='.08' stroke-width='2'/>", 80), '80px 80px'],
    halftone: [svg("<circle cx='6' cy='6' r='2.2' fill='black' fill-opacity='.13'/><circle cx='12' cy='12' r='2.2' fill='black' fill-opacity='.13'/>", 12), '12px 12px'],
    bgrid: [svg("<path d='M40 0H0V40' fill='none' stroke='white' stroke-opacity='.13'/><path d='M8 0V40M16 0V40M24 0V40M32 0V40M0 8H40M0 16H40M0 24H40M0 32H40' fill='none' stroke='white' stroke-opacity='.04'/>", 40), '40px 40px'],
    stars: [svg("<path d='M10 2l2 6 6 2-6 2-2 6-2-6-6-2 6-2z' fill='white' fill-opacity='.10'/>", 56), '56px 56px']
  };
  // Whole-app themes. dark:true uses the dark base for any variable a theme leaves out.
  const THEMES = {
    classic: { name: 'Classic', dark: null, vars: {} },
    crt: { name: 'Green Phosphor', dark: true, font: 'mono', pat: 'scan', vars: { bg1: '#04120a', bg2: '#03100a', bg3: '#06180d', ink: '#c4ffd6', mut: '#6fc98d', glass: 'rgba(5,24,13,.96)', line: 'rgba(80,255,140,.28)', acc: '#3dff7a', onacc: '#032010', gold: '#d7ff5a', chip: 'rgba(60,255,120,.10)', shadow: 'rgba(0,0,0,.6)', b1: '#0b5a2a', b2: '#14803a', b3: '#0a3d22', dot: '#3dff7a', avb: '#3dff7a', ava1: '#0b5a2a', ava2: '#14803a', pa: '#3dff7a', pb: '#ff6b5e', glow: 'rgba(61,255,122,.45)' } },
    synth: { name: 'Neon Synthwave', dark: true, font: 'condensed', pat: 'grid', vars: { bg1: '#1a0b3a', bg2: '#240a4d', bg3: '#33105c', ink: '#fff0ff', mut: '#d1aaf0', glass: 'rgba(36,12,72,.96)', line: 'rgba(255,120,230,.28)', acc: '#ff4fd8', onacc: '#2a0630', gold: '#ffd84a', chip: 'rgba(255,255,255,.10)', shadow: 'rgba(10,0,30,.6)', b1: '#ff2fa8', b2: '#2fd3ff', b3: '#7a3dff', dot: '#2fd3ff', avb: '#ff4fd8', ava1: '#ff4fd8', ava2: '#2fd3ff', pa: '#4dffb0', pb: '#ff6b8b', glow: 'rgba(255,79,216,.5)' } },
    sunset: { name: 'Sunset Arcade', dark: false, font: 'rounded', pat: 'dots', vars: { bg1: '#fff0e0', bg2: '#ffe0d0', bg3: '#ffd3e0', ink: '#3a1d2a', mut: '#8a5a62', glass: 'rgba(255,250,245,.95)', line: 'rgba(90,30,40,.16)', acc: '#e8452c', onacc: '#fff', gold: '#a85f00', chip: 'rgba(255,255,255,.7)', shadow: 'rgba(120,40,30,.22)', b1: '#ffb28a', b2: '#ff8fb1', b3: '#ffd27a', dot: '#2fbf71', avb: '#e8452c', ava1: '#ff8a5c', ava2: '#ffcf5a', glow: 'rgba(232,69,44,.35)' } },
    copper: { name: 'Copper', dark: true, font: 'condensed', pat: 'grid', vars: { bg1: '#1b1a1d', bg2: '#101012', bg3: '#1a1512', ink: '#f4ece4', mut: '#b5a79a', glass: 'rgba(30,28,31,.96)', line: 'rgba(233,137,74,.28)', acc: '#e9894a', onacc: '#1d0e04', gold: '#f2b56f', chip: 'rgba(255,255,255,.08)', shadow: 'rgba(0,0,0,.5)', b1: '#8a4a22', b2: '#3a2a22', b3: '#b8703a', dot: '#6ee7a0', avb: '#e9894a', ava1: '#e9894a', ava2: '#8a4a22', glow: 'rgba(233,137,74,.4)' } },
    comic: { name: 'Comic Print', dark: false, font: 'comic', pat: 'halftone', vars: { bg1: '#ffd83d', bg2: '#ffcb1f', bg3: '#ffe27a', ink: '#14110a', mut: '#4a3f1c', glass: 'rgba(255,255,255,.98)', line: 'rgba(0,0,0,.85)', acc: '#e6007e', onacc: '#ffffff', gold: '#b04a00', chip: 'rgba(255,255,255,.92)', shadow: 'rgba(0,0,0,.85)', b1: '#ff9ccc', b2: '#7fd8ff', b3: '#ffffff', dot: '#12b886', avb: '#14110a', ava1: '#e6007e', ava2: '#00a6e6', glow: 'rgba(230,0,126,.35)' } },
    blueprint: { name: 'Blueprint', dark: true, font: 'plex', pat: 'bgrid', vars: { bg1: '#0f4a8f', bg2: '#0a3470', bg3: '#0c3d7f', ink: '#eaf4ff', mut: '#a9c8ee', glass: 'rgba(8,44,96,.96)', line: 'rgba(200,225,255,.38)', acc: '#ffd23f', onacc: '#13294f', gold: '#ffd23f', chip: 'rgba(255,255,255,.1)', shadow: 'rgba(0,10,40,.5)', b1: '#2d7fd6', b2: '#0a3470', b3: '#5aa7f0', dot: '#7dffb0', avb: '#ffd23f', ava1: '#5aa7f0', ava2: '#ffd23f', glow: 'rgba(255,210,63,.35)' } },
    pastel: { name: 'Pastel Pop', dark: false, font: 'bubble', pat: 'dots', vars: { bg1: '#f1e6ff', bg2: '#e0ecff', bg3: '#ffe4f3', ink: '#3b2a5e', mut: '#7d6aa6', glass: 'rgba(255,255,255,.94)', line: 'rgba(120,90,190,.2)', acc: '#ff5fae', onacc: '#ffffff', gold: '#b86a00', chip: 'rgba(255,255,255,.8)', shadow: 'rgba(120,80,200,.22)', b1: '#cdb6ff', b2: '#a9d4ff', b3: '#ffc2e3', dot: '#2fcf8f', avb: '#ff5fae', ava1: '#b49bff', ava2: '#7fd0ff', glow: 'rgba(255,95,174,.35)' } },
    ocean: { name: 'Deep Ocean', dark: true, font: 'system', pat: 'stars', vars: { bg1: '#06222f', bg2: '#05283a', bg3: '#0a2d3f', ink: '#e6faff', mut: '#8fc3d4', glass: 'rgba(6,36,50,.96)', line: 'rgba(120,220,255,.22)', acc: '#34d6e8', onacc: '#032028', gold: '#ffd166', chip: 'rgba(255,255,255,.09)', shadow: 'rgba(0,10,20,.55)', b1: '#0f7a96', b2: '#1c5fb8', b3: '#12a38f', dot: '#52e08f', avb: '#34d6e8', ava1: '#1c5fb8', ava2: '#34d6e8', glow: 'rgba(52,214,232,.45)' } }
  };
  // Per-console skins: original palettes and patterns inspired by each system's era. No logos or characters.
  // l = light base, d = dark base. b = background glow colors. Applied on the Classic theme (and accent/glow/pattern only on others).
  const SKINS = {
    gb: { pat: 'px', l: { bg: ['#d4dfae', '#c3d193', '#b2c47d'], ink: '#233317', mut: '#4d6336', acc: '#37561f', onacc: '#e8f0cc', glass: 'rgba(226,235,194,.95)', line: 'rgba(35,51,23,.22)', gold: '#5c6b00' }, d: { bg: ['#1b2614', '#162010', '#1f2b17'], ink: '#d7e6ae', mut: '#9db57a', acc: '#a9cf5a', onacc: '#15200c', glass: 'rgba(24,34,17,.96)', line: 'rgba(200,230,140,.2)', gold: '#d6e56a' }, b: ['#9bbc0f', '#8bac0f', '#c0d46a'], glow: 'rgba(100,140,20,.45)', font: 'mono' },
    gbc: { pat: 'dots', l: { bg: ['#e6f6f2', '#f4e3f0', '#e3e8fa'], acc: '#12907f', gold: '#9a5a00' }, d: { bg: ['#10262a', '#201429', '#14172c'], acc: '#5ce0cc' }, b: ['#7fe3d1', '#ff9ccc', '#ffe27a'], glow: 'rgba(31,168,154,.4)', font: 'rounded' },
    gba: { pat: 'px', l: { bg: ['#e9e6fb', '#ddd9f7', '#e6e2f4'], acc: '#4f35c9' }, d: { bg: ['#17133a', '#120f30', '#1d1445'], acc: '#a898ff' }, b: ['#7b66f0', '#46c6d6', '#b9a8ff'], glow: 'rgba(100,80,230,.45)' },
    nes: { pat: 'grid', l: { bg: ['#eceae6', '#dedbd5', '#e6dfdb'], ink: '#26231f', mut: '#6a645b', acc: '#c9302c', gold: '#8a5a00' }, d: { bg: ['#1c1a19', '#151413', '#241a19'], acc: '#ff6a5e' }, b: ['#d9c9b8', '#d95b52', '#a8a39a'], glow: 'rgba(201,48,44,.4)', font: 'mono' },
    snes: { pat: 'sym', l: { bg: ['#ebe8f6', '#e0dcf0', '#ece4ef'], acc: '#6a56d0' }, d: { bg: ['#1a1736', '#141230', '#22163a'], acc: '#b0a2ff' }, b: ['#a99bf0', '#f08b8b', '#8fd6a8'], glow: 'rgba(120,100,220,.45)' },
    genesis: { pat: 'speed', l: { bg: ['#e4eaf6', '#d6e0f1', '#dde4f0'], acc: '#1658d8', ink: '#101a30' }, d: { bg: ['#05070f', '#080c1c', '#0a1026'], acc: '#4f8dff', ink: '#e8efff' }, b: ['#1d4fd6', '#0b1d52', '#4f8dff'], glow: 'rgba(40,110,255,.5)', font: 'condensed' },
    mastersystem: { pat: 'stripes', l: { bg: ['#f6e6e6', '#efd8d8', '#ece2e2'], acc: '#d01f2c' }, d: { bg: ['#160a0b', '#1b0b0d', '#240d10'], acc: '#ff5560' }, b: ['#e63a46', '#2a2a2a', '#ff9a8a'], glow: 'rgba(230,50,60,.45)', font: 'condensed' },
    psx: { pat: 'sym', l: { bg: ['#e7ebf1', '#d9dfe9', '#e2e4ea'], acc: '#2860d6' }, d: { bg: ['#0f1220', '#0b0e1b', '#151827'], acc: '#79a2ff' }, b: ['#6f93e8', '#c7ccd6', '#e67b9a'], glow: 'rgba(60,110,230,.45)' },
    'col-fav': { pat: 'stars', l: { bg: ['#fff3d8', '#fde6b8', '#fbe7d2'], acc: '#c27a00' }, d: { bg: ['#271d0a', '#201808', '#2e1e0e'], acc: '#ffc94a' }, b: ['#ffcf5a', '#ff9f5a', '#ffe9a0'], glow: 'rgba(255,190,60,.45)' },
    'col-last': { pat: 'dots', l: { bg: ['#e0f4f4', '#d2ecee', '#dfeaf4'], acc: '#0f8a96' }, d: { bg: ['#0c2326', '#0a1d20', '#0f2430'], acc: '#4fd8e6' }, b: ['#6fdcdc', '#7fb3ff', '#a8f0d0'], glow: 'rgba(40,190,200,.4)' }
  };
  // Blocks of the home screen that a theme may move (custom layout). Positions are in the 1440x810 stage.
  const BLOCKS = { logo: '#logo', tray: '#tr', tabs: '#tabs', hero: '#hero', row: '#row', info: '#info', line: '#rule', foot: '#foot' };
  const NOHIDE = ['row', 'tabs'], WIDE = { info: 1312, line: 1312, foot: 1312 };
  let custom = {}, set = [];
  const pick = (o, k) => (o && Object.prototype.hasOwnProperty.call(o, k) ? o[k] : undefined);

  // Validates a theme file from the user's themes folder. Returns a clean theme or null. Only allowlisted keys, color syntax, and font/pattern names are accepted.
  function sanitize(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
    const name = typeof raw.name === 'string' ? raw.name.replace(/[^\w .\-+&']/g, '').trim().slice(0, 24) : '';
    if (!name) return null;
    const vars = {};
    for (const k of COLOR_KEYS) { const v = pick(raw.vars, k); if (typeof v === 'string' && v.length <= 48 && COLOR.test(v.trim())) vars[k] = v.trim(); }
    const font = typeof raw.font === 'string' && FONTS[raw.font] ? raw.font : 'system';
    const pat = typeof raw.pattern === 'string' && PATS[raw.pattern] ? raw.pattern : '';
    const num = (v, lo, hi) => (typeof v === 'number' && isFinite(v) ? Math.max(lo, Math.min(hi, v)) : null);
    const radius = num(raw.radius, 0, 40), blobs = num(raw.blobs, 0, 1);
    let layout = null;
    if (raw.layout && typeof raw.layout === 'object' && !Array.isArray(raw.layout)) {
      layout = {};
      for (const k of Object.keys(BLOCKS)) {
        const b = pick(raw.layout, k); if (!b || typeof b !== 'object') continue;
        const x = num(b.x, -400, 1600), y = num(b.y, -400, 1000); if (x == null || y == null) continue;
        layout[k] = { x: Math.round(x), y: Math.round(y), s: Math.round((num(b.s, .4, 2.5) || 1) * 100) / 100, hide: !!b.hide && !NOHIDE.includes(k) };
      }
      if (!Object.keys(layout).length) layout = null;
    }
    return { name, dark: !!raw.dark, font, pat, vars, radius, blobs, layout, custom: true };
  }
  function loadCustom(list) {
    custom = {}; (list || []).forEach((r, i) => { const t = sanitize(r); if (t) custom['user' + i] = t; });
    set = [...Object.keys(THEMES), ...Object.keys(custom)];
  }
  set = Object.keys(THEMES);
  const ids = () => set.slice();
  const get = id => THEMES[id] || custom[id] || THEMES.classic;
  const nameOf = id => get(id).name;

  function apply(cfg, sysId) {
    const root = document.documentElement, st = root.style, tid = set.includes(cfg.theme) ? cfg.theme : 'classic', th = get(tid);
    COLOR_KEYS.forEach(k => st.removeProperty('--' + k));
    ['--pat', '--patsz', '--disp', '--rc', '--blobo'].forEach(k => st.removeProperty(k));
    const dark = th.dark == null ? !!cfg.dark : th.dark;
    root.dataset.theme = dark ? 'dark' : 'light'; root.dataset.skin = tid;
    Object.entries(th.vars).forEach(([k, v]) => st.setProperty('--' + k, v));
    let pat = th.pat, font = th.font;
    const sk = cfg.skins !== false && SKINS[sysId];
    if (sk) {
      const v = dark ? sk.d : sk.l, classic = tid === 'classic';
      if (classic && v) {
        const m = { acc: v.acc, ink: v.ink, mut: v.mut, onacc: v.onacc, glass: v.glass, line: v.line, gold: v.gold };
        Object.entries(m).forEach(([k, x]) => { if (x) st.setProperty('--' + k, x); });
        if (v.bg) { st.setProperty('--bg1', v.bg[0]); st.setProperty('--bg2', v.bg[1]); st.setProperty('--bg3', v.bg[2]); }
        if (sk.b) { st.setProperty('--b1', sk.b[0]); st.setProperty('--b2', sk.b[1]); st.setProperty('--b3', sk.b[2]); }
        st.setProperty('--glow', sk.glow); if (sk.font) font = sk.font;
        if (v.acc) st.setProperty('--avb', v.acc);
      }
      if (sk.pat && !pat) pat = sk.pat;
    }
    if (pat && PATS[pat]) { st.setProperty('--pat', PATS[pat][0]); st.setProperty('--patsz', PATS[pat][1]); }
    if (font && FONTS[font]) st.setProperty('--disp', FONTS[font]);
    if (th.radius != null) st.setProperty('--rc', th.radius + 'px');
    if (th.blobs != null) st.setProperty('--blobo', String(th.blobs));
    applyLayout(cfg.layout === 'custom' ? th.layout : null);
  }
  // Moves the home screen blocks to the positions a theme saved. Passing null puts everything back.
  function applyLayout(lay) {
    for (const [k, sel] of Object.entries(BLOCKS)) {
      const el = document.querySelector(sel); if (!el) continue;
      const s = el.style, b = lay && lay[k];
      ['left', 'top', 'right', 'width', 'scale', 'transform-origin', 'position', 'white-space'].forEach(p => s.removeProperty(p)); el.classList.remove('cxhide');
      if (!b) continue;
      s.position = 'absolute'; s.left = b.x + 'px'; s.top = b.y + 'px'; s.right = 'auto'; s.transformOrigin = '0 0';
      if (WIDE[k]) s.width = WIDE[k] + 'px';
      if (k === 'logo' || k === 'tray' || k === 'tabs' || k === 'foot') s.whiteSpace = 'nowrap';
      if (b.s && b.s !== 1) s.scale = String(b.s);
      if (b.hide) el.classList.add('cxhide');
    }
  }
  const presets = () => Object.entries(THEMES).map(([id, t]) => ({ id, name: t.name, dark: t.dark, font: t.font || 'system', pat: t.pat || '', vars: { ...t.vars } }));
  return { apply, applyLayout, ids, nameOf, loadCustom, sanitize, get, presets, COLOR_KEYS, FONTS, PATS, BLOCKS, NOHIDE };
})();
