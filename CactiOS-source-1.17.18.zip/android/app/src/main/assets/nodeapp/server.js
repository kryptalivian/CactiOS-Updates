#!/usr/bin/env node
// Cacti OS (web edition): runs the same app logic as the desktop app, with the interface in your web browser.
// Open http://localhost:8420 on the computer that has RetroArch and your games. Nothing is exposed to the network.
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto'), Module = require('module');
const { execFile } = require('child_process'), { fileURLToPath } = require('url');
const PORT = Number(process.env.PORT) || 8420;
const DATA = process.env.RETROOS_DATA || path.join(os.homedir(), '.retro-os-web');
fs.mkdirSync(DATA, { recursive: true });
const MAC = process.platform === 'darwin', WIN = process.platform === 'win32';

// access token (kept in the data folder) so other websites cannot talk to this local server
let TOKEN; const TF = path.join(DATA, 'token');
try { TOKEN = fs.readFileSync(TF, 'utf8').trim(); } catch {}
if (!TOKEN || TOKEN.length < 16) { TOKEN = crypto.randomBytes(16).toString('hex'); fs.writeFileSync(TF, TOKEN, { mode: 0o600 }); }
const HOMEURL = `http://localhost:${PORT}/?t=${TOKEN}`;

const openIt = x => { try { if (WIN) execFile('cmd', ['/c', 'start', '', x]); else execFile(MAC ? 'open' : 'xdg-open', [x], () => {}); } catch {} };

// ---------- a small stand-in for Electron so main.js runs unchanged ----------
const handlers = new Map(), onMap = new Map(), clients = { app: new Set(), music: new Set() }, loadCbs = { app: [], music: [] };
global.__cactiHandlers = handlers;
const b64 = s => Buffer.from(s).toString('base64url');
const fileUrl = v => { try { return `/f/${b64(fileURLToPath(v))}?t=${TOKEN}`; } catch { return v; } };
const enc = d => JSON.stringify(d === undefined ? null : d, (k, v) => (typeof v === 'string' && v.startsWith('file://') ? fileUrl(v) : v));
function emit(role, ch, d) { const m = `data: ${enc({ ch, d })}\n\n`; for (const r of clients[role]) r.write(m); }
class BrowserWindow {
  constructor(o) {
    this.role = /music/.test((o && o.webPreferences && o.webPreferences.preload) || '') ? 'music' : 'app';
    this.webContents = { send: (c, d) => emit(this.role, c, d), on: (ev, cb) => { if (ev === 'did-finish-load') loadCbs[this.role].push(cb); }, setWindowOpenHandler() {} };
  }
  isVisible() { return false; } isDestroyed() { return false; } isFullScreen() { return false; } isMinimized() { return false; }
  loadFile() {} on() {} once() {} destroy() {} show() {} hide() {} focus() {} showInactive() {} moveTop() {} setBounds() {} setIgnoreMouseEvents() {} setAlwaysOnTop() {} setVisibleOnAllWorkspaces() {} setFullScreen() {} restore() {}
}
const kf = path.join(DATA, '.key'); let KEY; try { KEY = fs.readFileSync(kf); } catch {} if (!KEY || KEY.length !== 32) { KEY = crypto.randomBytes(32); fs.writeFileSync(kf, KEY, { mode: 0o600 }); }
const safeStorage = {
  isEncryptionAvailable: () => true,
  encryptString: s => { const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', KEY, iv), ct = Buffer.concat([c.update(String(s), 'utf8'), c.final()]); return Buffer.concat([iv, c.getAuthTag(), ct]); },
  decryptString: b => { const d = crypto.createDecipheriv('aes-256-gcm', KEY, b.subarray(0, 12)); d.setAuthTag(b.subarray(12, 28)); return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8'); }
};
const run = (cmd, args) => new Promise(r => execFile(cmd, args, { timeout: 300000 }, (e, o) => r(e ? '' : String(o).trim())));
const dialog = {
  async showOpenDialog(_w, o) {
    const dir = o.properties.includes('openDirectory'); let p = '';
    if (MAC) p = await run('osascript', ['-e', dir ? 'POSIX path of (choose folder)' : 'POSIX path of (choose file)']);
    else if (WIN) p = await run('powershell', ['-NoProfile', '-Command', dir ? "Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.FolderBrowserDialog; if($d.ShowDialog() -eq 'OK'){$d.SelectedPath}" : "Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.OpenFileDialog; if($d.ShowDialog() -eq 'OK'){$d.FileName}"]);
    else p = await run('zenity', ['--file-selection', ...(dir ? ['--directory'] : [])]);
    p = p.replace(/\/$/, '') || ''; return p ? { canceled: false, filePaths: [p] } : { canceled: true, filePaths: [] };
  }
};
const electron = {
  app: { getPath: () => DATA, whenReady: () => Promise.resolve(), requestSingleInstanceLock: () => true, quit: () => process.exit(0), on() {}, focus() {} },
  BrowserWindow, safeStorage, dialog,
  ipcMain: { handle: (c, f) => handlers.set(c, f), on: (c, f) => onMap.set(c, f) },
  Menu: { setApplicationMenu() {}, buildFromTemplate: () => ({}) },
  shell: { openPath: async p => { openIt(p); return ''; }, openExternal: async u => { if (/^(https?:|ms-settings:|x-apple)/.test(u)) openIt(u); } },
  screen: { getPrimaryDisplay: () => ({ workArea: { x: 0, y: 0, width: 1920, height: 1080 } }) },
  globalShortcut: { register() {}, unregister() {}, unregisterAll() {} }
};
const origLoad = Module._load;
Module._load = function (req, ...r) { return req === 'electron' ? electron : origLoad.call(this, req, ...r); };
require('./main.js');

// ---------- HTTP ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.svg': 'image/svg+xml',
  '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.aac': 'audio/aac', '.ogg': 'audio/ogg', '.oga': 'audio/ogg', '.opus': 'audio/ogg', '.flac': 'audio/flac', '.wav': 'audio/wav' };
const cfgOf = () => { try { return JSON.parse(fs.readFileSync(path.join(DATA, 'config.json'), 'utf8')); } catch { return {}; } };
function allowed(p) {
  let rp; try { rp = fs.realpathSync(p); } catch { return null; }
  const c = cfgOf(), roots = [c.romRoot, c.musicDir, DATA].filter(Boolean).map(r => { try { return fs.realpathSync(r); } catch { return null; } }).filter(Boolean);
  return roots.some(r => rp === r || rp.startsWith(r + path.sep)) ? rp : null;
}
const REN = path.join(__dirname, 'renderer');
function sendFile(req, res, file) {
  let st; try { st = fs.statSync(file); } catch { res.writeHead(404).end(); return; }
  const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', h = { 'Content-Type': type, 'Accept-Ranges': 'bytes', 'Cache-Control': /\.(js|css)$/i.test(file) ? 'no-cache' : 'private, max-age=3600' }; // scripts and styles are always re-checked so an update shows up at once
  const m = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
  if (m && (m[1] || m[2])) {
    let a = m[1] ? +m[1] : Math.max(0, st.size - +m[2]), b = m[1] && m[2] ? +m[2] : st.size - 1; b = Math.min(b, st.size - 1);
    if (a > b) { res.writeHead(416, { 'Content-Range': `bytes */${st.size}` }).end(); return; }
    res.writeHead(206, { ...h, 'Content-Range': `bytes ${a}-${b}/${st.size}`, 'Content-Length': b - a + 1 }); fs.createReadStream(file, { start: a, end: b }).pipe(res);
  } else { res.writeHead(200, { ...h, 'Content-Length': st.size }); fs.createReadStream(file).pipe(res); }
}
function page(file, role) {
  let h = fs.readFileSync(file, 'utf8').replace("media-src file:", "media-src 'self'");
  const tag = `<script src="/__preload.js?role=${role}&t=${TOKEN}"></script>`;
  h = h.replace(/<script src="(app|music|studio-stage)\.js">/, tag + '$&');
  if (role === 'app') h = h.replace('</body>', `<iframe src="/music.html?t=${TOKEN}" style="display:none" allow="autoplay" title="music engine"></iframe></body>`);
  return h;
}
const readBody = req => new Promise(r => { let b = ''; req.on('data', d => { b += d; if (b.length > 1e6) req.destroy(); }); req.on('end', () => r(b)); });
http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://x'), host = (req.headers.host || '').replace(/:\d+$/, '');
  if (!['localhost', '127.0.0.1', '[::1]'].includes(host)) { res.writeHead(403).end(); return; }
  const ok = u.searchParams.get('t') === TOKEN, p = u.pathname;
  try {
    if (p === '/' || p === '/index.html') { if (!ok) { res.writeHead(403, { 'Content-Type': 'text/plain' }).end('Open the address printed in the Cacti OS window (it ends with ?t=...).'); return; } res.writeHead(200, { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-store' }).end(page(path.join(REN, 'index.html'), 'app')); return; }
    if (p === '/studio.html') { if (!ok) { res.writeHead(403).end(); return; } res.writeHead(200, { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-store' }).end(page(path.join(REN, 'studio.html'), 'app')); return; }
    if (p === '/music.html') { if (!ok) { res.writeHead(403).end(); return; } res.writeHead(200, { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-store' }).end(page(path.join(REN, 'music.html'), 'music')); return; }
    if (p === '/__preload.js') {
      if (!ok) { res.writeHead(403).end(); return; }
      const role = u.searchParams.get('role') === 'music' ? 'music' : 'app';
      const src = fs.readFileSync(path.join(__dirname, role === 'music' ? 'music-preload.js' : 'preload.js'), 'utf8');
      const js = `(function(){const T=${JSON.stringify(TOKEN)},L={};
const post=(u,b)=>fetch(u+'?t='+T,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}).then(r=>r.json());
const __ipc={invoke:(c,...a)=>post('/api/'+encodeURIComponent(c),a).then(r=>{if(r&&r.err)throw new Error(r.err);return r.v}),send:(c,...a)=>{post('/send/'+encodeURIComponent(c),a)},on:(c,cb)=>{(L[c]=L[c]||[]).push(cb)}};
const es=new EventSource('/events?role=${role}&t='+T);es.onmessage=e=>{const m=JSON.parse(e.data);(L[m.ch]||[]).forEach(f=>f({},m.d))};
const __cb={exposeInMainWorld:(n,o)=>{window[n]=o}};
(function(require){
${src}
})(()=>({contextBridge:__cb,ipcRenderer:__ipc}));
if(window.api){window.api.fullscreen=()=>{document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen().catch(()=>{})};window.api.quit=()=>{try{window.close()}catch{}};window.api.studio=()=>{window.open('/studio.html?t='+T,'_blank');return Promise.resolve(true)}}
${(()=>{try{return fs.readFileSync(path.join(__dirname,'android-preload.js'),'utf8')}catch{return ''}})()}
})();`;
      res.writeHead(200, { 'Content-Type': MIME['.js'], 'Cache-Control': 'no-store' }).end(js); return;
    }
    if (p === '/events') {
      if (!ok) { res.writeHead(403).end(); return; }
      const role = u.searchParams.get('role') === 'music' ? 'music' : 'app';
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' }); res.write(': ok\n\n');
      clients[role].add(res); const ka = setInterval(() => res.write(': ping\n\n'), 20000);
      req.on('close', () => { clients[role].delete(res); clearInterval(ka); });
      setTimeout(() => loadCbs[role].forEach(f => { try { f(); } catch {} }), 150); return;
    }
    if (p.startsWith('/api/') || p.startsWith('/send/')) {
      if (!ok || req.method !== 'POST') { res.writeHead(403).end(); return; }
      const ch = decodeURIComponent(p.replace(/^\/(api|send)\//, '')); let args = []; try { args = JSON.parse(await readBody(req)); } catch {}
      if (p.startsWith('/send/')) { const f = onMap.get(ch); if (f) f({}, ...args); res.writeHead(200, { 'Content-Type': 'application/json' }).end('{}'); return; }
      const f = handlers.get(ch); if (!f) { res.writeHead(404, { 'Content-Type': 'application/json' }).end(enc({ err: 'unknown channel ' + ch })); return; }
      let out; try { out = { v: await f({}, ...args) }; } catch (e) { out = { err: String(e && e.message || e) }; }
      res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }).end(enc(out)); return;
    }
    if (p.startsWith('/f/')) {
      if (!ok) { res.writeHead(403).end(); return; }
      let fp; try { fp = Buffer.from(p.slice(3), 'base64url').toString(); } catch { res.writeHead(400).end(); return; }
      const rp = allowed(fp); if (!rp) { res.writeHead(403).end(); return; } sendFile(req, res, rp); return;
    }
    const rel = path.normalize(decodeURIComponent(p)).replace(/^([/\\]|\.\.)+/, ''), f = path.join(REN, rel);
    if (f.startsWith(REN + path.sep) && /\.(js|css|png|svg)$/.test(f)) { sendFile(req, res, f); return; }
    res.writeHead(404).end();
  } catch (e) { try { res.writeHead(500).end(String(e.message)); } catch {} }
}).on('error', e => {
  if (e.code === 'EADDRINUSE') { console.log(`Cacti OS is already running. Opening it:\n  ${HOMEURL}`); if (!process.env.NO_OPEN) openIt(HOMEURL); setTimeout(() => process.exit(0), 500); }
  else { console.error(e); process.exit(1); }
}).listen(PORT, '127.0.0.1', () => {
  console.log(`\nCacti OS (web) is running.\n\n  ${HOMEURL}\n\nKeep this window open while you play. Close it to stop Cacti OS.\n`);
  if (!process.env.NO_OPEN) openIt(HOMEURL);
});
