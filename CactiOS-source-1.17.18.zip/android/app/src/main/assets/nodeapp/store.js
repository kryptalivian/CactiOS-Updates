'use strict';
// Game Store: a short, hand-picked list of recompiled and fan-made PC ports. Nothing here is hosted by Cacti OS.
// Every download comes straight from the author's own GitHub release page, and every game needs the player's own copy of the original game file.
// The catalog is plain data (CATALOG below). Cacti OS only lists a project when its authors release it freely themselves.
const fs = require('fs'), path = require('path'), os = require('os');
const { execFile } = require('child_process');

const CATALOG = [
  { id: 'mm-recomp', name: 'Zelda 64: Recompiled', game: 'The Legend of Zelda: Majora\'s Mask', kind: 'Recompiled', author: 'Mr-Wiseguy and contributors', repo: 'Zelda64Recomp/Zelda64Recomp', page: 'https://github.com/Zelda64Recomp/Zelda64Recomp',
    blurb: 'A native PC version of Majora\'s Mask made by recompiling the original game code. Adds widescreen, a high frame rate and modern controls.', needs: 'Your own Majora\'s Mask (USA) ROM, picked inside the game the first time it starts.', romLabel: 'Majora\'s Mask ROM', romExt: ['.z64', '.n64', '.v64'], romCopy: false, os: ['win', 'linux'], exe: /zelda64recomp/i },
  { id: 'oot-ship', name: 'Ship of Harkinian', game: 'The Legend of Zelda: Ocarina of Time', kind: 'PC port', author: 'HarbourMasters and contributors', repo: 'HarbourMasters/Shipwright', page: 'https://github.com/HarbourMasters/Shipwright',
    blurb: 'A PC port of Ocarina of Time with widescreen, mod support and many quality-of-life options.', needs: 'Your own Ocarina of Time ROM. The game builds its own data from it on first start (about a minute).', romLabel: 'Ocarina of Time ROM', romExt: ['.z64', '.n64', '.v64'], romCopy: true, os: ['win', 'mac', 'linux'], exe: /soh|shipofharkinian|harkinian/i },
  { id: 'mm-2ship', name: '2 Ship 2 Harkinian', game: 'The Legend of Zelda: Majora\'s Mask', kind: 'PC port', author: 'HarbourMasters and contributors', repo: 'HarbourMasters/2ship2harkinian', page: 'https://github.com/HarbourMasters/2ship2harkinian',
    blurb: 'A PC port of Majora\'s Mask from the Ship of Harkinian team.', needs: 'Your own Majora\'s Mask (USA) ROM. The game builds its own data from it on first start.', romLabel: 'Majora\'s Mask ROM', romExt: ['.z64', '.n64', '.v64'], romCopy: true, os: ['win', 'mac', 'linux'], exe: /2ship|harkinian/i },
  { id: 'sf64-starship', name: 'Starship', game: 'Star Fox 64', kind: 'PC port', author: 'HarbourMasters and contributors', repo: 'HarbourMasters/Starship', page: 'https://github.com/HarbourMasters/Starship',
    blurb: 'A PC port of Star Fox 64 with widescreen and a high frame rate.', needs: 'Your own Star Fox 64 ROM. The game builds its own data from it on first start.', romLabel: 'Star Fox 64 ROM', romExt: ['.z64', '.n64', '.v64'], romCopy: true, os: ['win', 'mac', 'linux'], exe: /starship/i },
  { id: 'mk64-spaghetti', name: 'SpaghettiKart', game: 'Mario Kart 64', kind: 'PC port', author: 'HarbourMasters and contributors', repo: 'HarbourMasters/SpaghettiKart', page: 'https://github.com/HarbourMasters/SpaghettiKart',
    blurb: 'A PC port of Mario Kart 64 with widescreen, modern graphics options and online-friendly tools.', needs: 'Your own Mario Kart 64 ROM. The game builds its own data from it on first start.', romLabel: 'Mario Kart 64 ROM', romExt: ['.z64', '.n64', '.v64'], romCopy: true, os: ['win', 'mac', 'linux'], exe: /spaghetti|mk64/i },
  { id: 's3air', name: 'Sonic 3 A.I.R.', game: 'Sonic 3 & Knuckles', kind: 'Fan project', author: 'Eukaryot and contributors', repo: 'Eukaryot/sonic3air', page: 'https://sonic3air.org',
    blurb: 'An enhanced fan project for Sonic 3 & Knuckles with widescreen, new content and mod support.', needs: 'Your own Sonic 3 & Knuckles ROM. The game asks for it on first start.', romLabel: 'Sonic 3 & Knuckles ROM', romExt: ['.bin', '.md', '.gen', '.smd'], romCopy: true, os: ['win', 'mac', 'linux'], exe: /sonic3air/i }
];

// Community-run lists of recompiled and decompiled games. Cacti OS only opens them in the browser; it is not affiliated with them.
const LINKS = [
  { name: 'Recomp Software', url: 'https://recompsoftware.com/games/', note: 'Tracker of 100+ Nintendo 64 recompilations, ports and clean-room projects' },
  { name: 'AllRecomps', url: 'https://allrecomps.com/', note: 'Recompilations and ports for many consoles' },
  { name: 'Recompendium', url: 'https://recompendium.com/en/', note: 'Recompilations, decompilations and ports' },
  { name: 'Recompedia (Nintendo 64)', url: 'https://recompedia.com/platform/n64', note: 'Native PC ports of N64 games' }
];

module.exports = function ({ app, shell, send, MAC, WIN, LINUX, extract }) {
  const OS = MAC ? 'mac' : WIN ? 'win' : 'linux', ARM = process.arch === 'arm64', DIR = () => path.join(app.getPath('userData'), 'store'), STATE = () => path.join(app.getPath('userData'), 'store.json'), CACHE = () => path.join(app.getPath('userData'), 'store-latest.json');
  const jr = (f, d) => { try { return JSON.parse(fs.readFileSync(f(), 'utf8')); } catch { return d; } }, jw = (f, v) => { try { fs.mkdirSync(path.dirname(f()), { recursive: true }); fs.writeFileSync(f(), JSON.stringify(v)); } catch {} };
  const run = (cmd, args, ms = 120000) => new Promise((res, rej) => execFile(cmd, args, { timeout: ms, maxBuffer: 1 << 24 }, (e, o) => (e ? rej(e) : res(String(o).trim()))));
  const entry = id => CATALOG.find(x => x.id === id), busy = new Set(), prog = (id, msg, pct) => { try { send('store-progress', { id, msg, pct }); } catch {} };

  async function latest(id, force) {
    const r = entry(id); if (!r) return null; const cache = jr(CACHE, {}), e = cache[id];
    if (e && !force && Date.now() - e.t < 12 * 3600e3) return e;
    try {
      const res = await fetch(`https://api.github.com/repos/${r.repo}/releases/latest`, { headers: { 'User-Agent': 'CactiOS', Accept: 'application/vnd.github+json', ...(e && e.etag ? { 'If-None-Match': e.etag } : {}) }, signal: AbortSignal.timeout(20000) });
      if (res.status === 304 && e) { cache[id] = { ...e, t: Date.now() }; jw(CACHE, cache); return cache[id]; }
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const j = await res.json();
      cache[id] = { t: Date.now(), etag: res.headers.get('etag') || '', tag: String(j.tag_name || j.name || ''), assets: (j.assets || []).map(a => ({ name: a.name, url: a.browser_download_url, size: a.size })) };
      jw(CACHE, cache); return cache[id];
    } catch { return e || null; }
  }
  const BAD = /debug|symbols|\.pdb|source|\bsrc\b|android|\.apk|flatpak|snap\b|\.msi|setup|installer|\.sig$|\.sha|\.txt$|\.json$|\.exe$|\.deb$|\.rpm$/i;
  const OSRX = { win: /win/i, mac: /mac|osx|darwin/i, linux: /linux|appimage|ubuntu|x86_64\.tar|\.appimage$/i }, EXT = /\.(zip|7z|tar\.gz|tgz|tar\.xz|dmg|appimage)$/i;
  function pickAsset(assets) {
    let best = null, bs = -1;
    for (const a of assets || []) {
      const n = a.name; if (!EXT.test(n) || BAD.test(n) && !/\.appimage$/i.test(n)) continue;
      if (!OSRX[OS].test(n)) continue; if (OS !== 'win' && /win/i.test(n) && !/darwin/i.test(n)) continue;
      const isArm = /arm64|aarch64/i.test(n); let s = 1;
      if (MAC) { if (/universal/i.test(n)) s += 3; else if (isArm === ARM) s += 3; else continue; } else if (isArm !== ARM) continue; else s += 3;
      if (/\.zip$/i.test(n)) s += 1;
      if (s > bs) { best = a; bs = s; }
    }
    return best;
  }
  async function download(url, dest, id) {
    if (new URL(url).hostname !== 'github.com') throw new Error('Refusing a download from ' + new URL(url).hostname);
    const res = await fetch(url, { redirect: 'follow', signal: AbortSignal.timeout(1800000) }); if (!res.ok) throw new Error('Download failed: HTTP ' + res.status);
    const total = Number(res.headers.get('content-length')) || 0; let got = 0, last = 0; const ws = fs.createWriteStream(dest);
    for await (const chunk of res.body) { if (!ws.write(chunk)) await new Promise(r => ws.once('drain', r)); got += chunk.length; if (Date.now() - last > 400) { last = Date.now(); prog(id, 'Downloading…', total ? Math.round(100 * got / total) : null); } }
    await new Promise(r => ws.end(r));
  }
  function walk(dir, depth, test, out = []) {
    let es = []; try { es = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
    for (const e of es) { const p = path.join(dir, e.name); if (test(e, p)) out.push(p); if (e.isDirectory() && depth > 0 && !(MAC && e.name.endsWith('.app'))) walk(p, depth - 1, test, out); }
    return out;
  }
  async function findExe(r, dir) {
    const skip = /unins|crash|update|redist|vc_redist|dxsetup/i;
    if (MAC) { const a = walk(dir, 2, e => e.isDirectory() && e.name.endsWith('.app'))[0]; if (!a) return null; try { const n = await run('/usr/bin/plutil', ['-extract', 'CFBundleExecutable', 'raw', '-o', '-', path.join(a, 'Contents', 'Info.plist')], 10000); const p = path.join(a, 'Contents', 'MacOS', n); if (fs.existsSync(p)) return p; } catch {} return null; }
    if (WIN) { const c = walk(dir, 3, e => e.isFile() && /\.exe$/i.test(e.name) && !skip.test(e.name)); return c.find(p => r.exe.test(path.basename(p))) || c.sort((x, y) => x.length - y.length)[0] || null; }
    const c = walk(dir, 3, e => e.isFile() && !skip.test(e.name)), ai = c.find(p => /\.appimage$/i.test(p)); if (ai) return ai;
    return c.find(p => r.exe.test(path.basename(p)) && !path.extname(p)) || null;
  }
  const romOk = (r, file) => { const ext = path.extname(String(file)).toLowerCase(); if (!r.romExt.includes(ext)) return { error: `That does not look like a ${r.romLabel}. Expected a file ending in ${r.romExt.join(', ')}.` }; try { const st = fs.statSync(file); if (!st.isFile() || st.size < 64 * 1024) return { error: 'That file is too small to be a game.' }; } catch { return { error: 'That file was not found.' }; } return { ok: true }; };
  function putRom(r, dir, file) { const ok = romOk(r, file); if (ok.error) return ok; if (!r.romCopy) return { ok: true, kept: file }; fs.copyFileSync(file, path.join(path.dirname(dir) === DIR() ? dir : dir, path.basename(file).replace(/[^\w.\- ()]/g, '_'))); return { ok: true }; }

  async function install(id, romFile) {
    const r = entry(id); if (!r) return { error: 'Unknown game.' }; if (busy.has(id)) return { error: 'Already installing.' };
    if (!r.os.includes(OS)) return { fallback: true, page: r.page, error: `The authors do not list a ${OS === 'mac' ? 'Mac' : OS === 'win' ? 'Windows' : 'Linux'} download. Opening their page.` };
    if (romFile) { const ok = romOk(r, romFile); if (ok.error) return ok; }
    busy.add(id); prog(id, 'Checking the latest release…'); let tmp = '';
    try {
      const lat = await latest(id, true), a = lat && pickAsset(lat.assets);
      if (!a) return { fallback: true, page: r.page, error: `No matching download was found for this computer${ARM && LINUX ? ' (the authors may not offer a Raspberry Pi build)' : ''}. Opening the authors' page.` };
      tmp = path.join(os.tmpdir(), 'cacti-store-' + id + '-' + Date.now() + '-' + a.name.replace(/[^\w.\-]/g, '_'));
      await download(a.url, tmp, id); prog(id, 'Installing…');
      const dir = path.join(DIR(), id, (lat.tag || 'latest').replace(/[^\w.\-]/g, '_')); fs.rmSync(dir, { recursive: true, force: true });
      if (/\.appimage$/i.test(a.name)) { fs.mkdirSync(dir, { recursive: true }); fs.copyFileSync(tmp, path.join(dir, a.name)); } else await extract(tmp, dir);
      const exe = await findExe(r, dir); if (!exe) throw new Error('Installed, but the program was not found inside the download.');
      if (MAC) { try { await run('/usr/bin/xattr', ['-cr', dir], 60000); } catch {} }
      if (!WIN) { try { fs.chmodSync(exe, 0o755); } catch {} }
      const home = path.dirname(exe), st = jr(STATE, {}), old = st[id] && st[id].dir;
      let rom = st[id] && st[id].rom || '';
      if (romFile) { const p = putRom(r, home, romFile); if (p.error) return p; rom = path.basename(romFile); }
      else if (r.romCopy && old && old !== dir) { // keep a ROM the player already gave when updating
        try { for (const f of fs.readdirSync(path.dirname(st[id].exe))) if (r.romExt.includes(path.extname(f).toLowerCase())) fs.copyFileSync(path.join(path.dirname(st[id].exe), f), path.join(home, f)); } catch {}
      }
      st[id] = { version: lat.tag, dir, exe, rom, at: Date.now(), asset: a.name }; jw(STATE, st);
      if (old && old !== dir && old.startsWith(DIR())) fs.rmSync(old, { recursive: true, force: true });
      return { ok: true, version: lat.tag, needsRom: r.romCopy && !rom };
    } catch (e) { return { error: String(e.message || e).slice(0, 160) }; }
    finally { busy.delete(id); try { if (tmp) fs.rmSync(tmp, { force: true }); } catch {} prog(id, ''); }
  }
  function addRom(id, file) {
    const r = entry(id), st = jr(STATE, {}), s = st[id]; if (!r || !s || !s.exe) return { error: 'Install the game first.' };
    const p = putRom(r, path.dirname(s.exe), file); if (p.error) return p; s.rom = path.basename(file); jw(STATE, st); return { ok: true, kept: p.kept || '' };
  }
  function remove(id) {
    const r = entry(id), st = jr(STATE, {}), s = st[id]; if (!r || !s) return { error: 'Not installed.' };
    if (s.dir && path.resolve(s.dir).startsWith(path.resolve(DIR()) + path.sep)) fs.rmSync(path.join(DIR(), id), { recursive: true, force: true });
    delete st[id]; jw(STATE, st); return { ok: true };
  }
  async function list(refresh) {
    const st = jr(STATE, {}), out = [];
    for (const r of CATALOG) {
      const lat = refresh ? await latest(r.id, false) : jr(CACHE, {})[r.id], s = st[r.id], have = !!(s && s.exe && fs.existsSync(s.exe));
      out.push({ id: r.id, name: r.name, game: r.game, kind: r.kind, author: r.author, blurb: r.blurb, needs: r.needs, page: r.page, romLabel: r.romLabel, romExt: r.romExt, romCopy: r.romCopy, supported: r.os.includes(OS), installed: have, version: have ? s.version : '', rom: have ? s.rom || '' : '', latest: lat ? lat.tag : '', update: !!(have && lat && lat.tag && lat.tag !== s.version), busy: busy.has(r.id) });
    }
    return out;
  }
  function installedSync() { const st = jr(STATE, {}); return CATALOG.filter(r => { const x = st[r.id]; return x && x.exe && fs.existsSync(x.exe) && !(r.romCopy && !x.rom); }).map(r => ({ id: r.id, name: r.name, game: r.game, blurb: r.blurb })); }
  function launchInfo(id) {
    const r = entry(id), s = jr(STATE, {})[id]; if (!r || !s || !s.exe || !fs.existsSync(s.exe)) return { error: 'This game is not installed. Open Menu > Game Store.' };
    if (r.romCopy && !s.rom) return { error: `Add your ${r.romLabel} first (Menu > Game Store).` };
    return { exe: s.exe, cwd: path.dirname(s.exe), name: r.name, env: { SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS: '1' } };
  }
  return { CATALOG, LINKS, installedSync, openLink: i => { const l = LINKS[Number(i)]; if (l) shell.openExternal(l.url); return !!l; }, list, install, addRom, remove, launchInfo, openPage: id => { const r = entry(id); if (r) shell.openExternal(r.page); return !!r; }, pickAsset };
};
