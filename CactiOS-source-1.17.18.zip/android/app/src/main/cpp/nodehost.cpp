#include <jni.h>
#include <android/log.h>
#include <pthread.h>
#include <unistd.h>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include "node.h"

static int pfd[2];
static void* logger(void*) {
  char buf[2048]; std::string acc; ssize_t n;
  while ((n = read(pfd[0], buf, sizeof(buf) - 1)) > 0) {
    acc.append(buf, n); size_t p;
    while ((p = acc.find('\n')) != std::string::npos) { __android_log_write(ANDROID_LOG_INFO, "CactiNode", acc.substr(0, p).c_str()); acc.erase(0, p + 1); }
  }
  return nullptr;
}

extern "C" JNIEXPORT jint JNICALL Java_com_cactios_app_NodeHost_start(JNIEnv* env, jclass, jobjectArray args, jobjectArray envs) {
  jsize ne = env->GetArrayLength(envs);
  for (jsize i = 0; i + 1 < ne; i += 2) {
    jstring k = (jstring)env->GetObjectArrayElement(envs, i), v = (jstring)env->GetObjectArrayElement(envs, i + 1);
    const char* ck = env->GetStringUTFChars(k, 0); const char* cv = env->GetStringUTFChars(v, 0);
    setenv(ck, cv, 1); env->ReleaseStringUTFChars(k, ck); env->ReleaseStringUTFChars(v, cv);
  }
  setvbuf(stdout, 0, _IONBF, 0); setvbuf(stderr, 0, _IONBF, 0);
  pipe(pfd); dup2(pfd[1], 1); dup2(pfd[1], 2);
  pthread_t t; pthread_create(&t, 0, logger, 0); pthread_detach(t);
  jsize argc = env->GetArrayLength(args); size_t total = 0; std::vector<std::string> a;
  for (jsize i = 0; i < argc; i++) { jstring s = (jstring)env->GetObjectArrayElement(args, i); const char* c = env->GetStringUTFChars(s, 0); a.push_back(c); total += strlen(c) + 1; env->ReleaseStringUTFChars(s, c); }
  char* block = (char*)calloc(total, 1); std::vector<char*> argv; char* cur = block;
  for (auto& s : a) { memcpy(cur, s.c_str(), s.size() + 1); argv.push_back(cur); cur += s.size() + 1; }
  return node::Start((int)argv.size(), argv.data());
}
