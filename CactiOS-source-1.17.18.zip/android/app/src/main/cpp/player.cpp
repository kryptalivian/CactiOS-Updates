#include <sys/resource.h>
// Cacti OS built-in libretro player: loads a bundled core, runs it on its own thread, draws with GLES2.
#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <GLES3/gl3.h>
#include <EGL/egl.h>
#include <atomic>
#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <fstream>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include "libretro.h"
#include "rc_client.h"
#include "rc_libretro.h"

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "CactiPlayer", __VA_ARGS__)

namespace {
JavaVM* gVm = nullptr;
jclass gCls = nullptr;
jmethodID mAv = nullptr, mAudio = nullptr, mStatus = nullptr;

// ---- core entry points ----
void* gLib = nullptr;
void (*c_set_env)(retro_environment_t);
void (*c_set_video)(retro_video_refresh_t);
void (*c_set_audio)(retro_audio_sample_t);
void (*c_set_audio_batch)(retro_audio_sample_batch_t);
void (*c_set_poll)(retro_input_poll_t);
void (*c_set_state)(retro_input_state_t);
void (*c_init)(void);
void (*c_deinit)(void);
void (*c_get_info)(struct retro_system_info*);
void (*c_get_av)(struct retro_system_av_info*);
bool (*c_load)(const struct retro_game_info*);
void (*c_unload)(void);
void (*c_run)(void);
size_t (*c_ser_size)(void);
bool (*c_ser)(void*, size_t);
bool (*c_unser)(const void*, size_t);
void* (*c_mem_data)(unsigned);
size_t (*c_mem_size)(unsigned);
void (*c_reset)(void);

std::string gSystemDir, gSaveDir, gSaveBase, gStateBase;
std::map<std::string, std::string> gVars;
std::atomic<int> gPad{0};
std::atomic<bool> gQuit{false}, gPaused{false};
std::atomic<int> gOp{0};  // 1 save state, 2 load state, 3 reset
std::mutex gOpMu; std::string gOpPath;
std::thread gThread;
unsigned gFmt = RETRO_PIXEL_FORMAT_0RGB1555;
double gFps = 60.0, gRate = 44100.0, gAspect = 0.0;
std::vector<int16_t> gAudioAcc;
bool gAudioThisFrame = false;

// ---- RetroAchievements (rcheevos rc_client) ----
rc_client_t* gRc = nullptr;
std::string gRaUser, gRaToken, gRaPass; bool gHard = false; unsigned gConsole = 0;
rc_libretro_memory_regions_t gRegions; bool gRegionsInit = false;
std::vector<retro_memory_descriptor> gDescs; retro_memory_map gMap; bool gHaveMap = false;
jmethodID mHttp = nullptr;
struct Pending { rc_client_server_callback_t cb; void* data; };
std::map<long long, Pending> gPending; long long gTicket = 0; std::mutex gPendMu;
struct Done { rc_client_server_callback_t cb; void* data; int status; std::string body; };
std::vector<Done> gDone;
std::mutex gRcMu;
// ---- display options ----
std::atomic<int> gInt{0}, gAspectMode{0}, gSmooth{1}; // aspectMode 0 core,1 4:3,2 16:9,3 square

// ---- video hand-off ----
std::mutex gVidMu;
std::vector<uint8_t> gFrame;
unsigned gFw = 0, gFh = 0; bool gGlFmt565 = true, gNewFrame = false;

void jstatus(const char* msg) {
  JNIEnv* env = nullptr; bool att = false;
  if (gVm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) { gVm->AttachCurrentThread(&env, nullptr); att = true; }
  jstring s = env->NewStringUTF(msg); env->CallStaticVoidMethod(gCls, mStatus, s); env->DeleteLocalRef(s);
  (void)att;
}

void RETRO_CALLCONV logcb(enum retro_log_level lvl, const char* fmt, ...) {
  char buf[1024]; va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
  __android_log_print(lvl >= RETRO_LOG_WARN ? ANDROID_LOG_WARN : ANDROID_LOG_INFO, "CactiCore", "%s", buf);
}

void parseVars(const struct retro_variable* v) {
  for (; v && v->key; ++v) {
    std::string d = v->value ? v->value : ""; size_t p = d.find("; ");
    if (p == std::string::npos) continue;
    std::string rest = d.substr(p + 2); size_t bar = rest.find('|');
    gVars[v->key] = bar == std::string::npos ? rest : rest.substr(0, bar);
  }
}

// ---- hardware rendering (GLES cores): offscreen EGL context on the emulation thread, frames read back to the CPU ----
retro_hw_render_callback gHw; bool gHwWanted = false, gHwOn = false;
EGLDisplay gEd = EGL_NO_DISPLAY; EGLContext gEc = EGL_NO_CONTEXT; EGLSurface gEs = EGL_NO_SURFACE;
GLuint gFbo = 0, gFboTex = 0, gFboRb = 0; unsigned gFboW = 0, gFboH = 0;
std::vector<uint8_t> gRead;
uintptr_t RETRO_CALLCONV hwFbo() { return gFbo; }
retro_proc_address_t RETRO_CALLCONV hwProc(const char* s) { return (retro_proc_address_t)eglGetProcAddress(s); }
bool hwCreate(unsigned w, unsigned h) {
  gEd = eglGetDisplay(EGL_DEFAULT_DISPLAY); if (gEd == EGL_NO_DISPLAY || !eglInitialize(gEd, nullptr, nullptr)) { LOG("hw: eglInitialize failed"); return false; }
  const EGLint ca[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_NONE};
  EGLConfig cfg; EGLint n = 0; if (!eglChooseConfig(gEd, ca, &cfg, 1, &n) || n < 1) { LOG("hw: no EGL config"); return false; }
  const EGLint pa[] = {EGL_WIDTH, 16, EGL_HEIGHT, 16, EGL_NONE}; gEs = eglCreatePbufferSurface(gEd, cfg, pa);
  const EGLint xa[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE}; gEc = eglCreateContext(gEd, cfg, EGL_NO_CONTEXT, xa);
  if (gEc == EGL_NO_CONTEXT || !eglMakeCurrent(gEd, gEs, gEs, gEc)) { LOG("hw: context failed 0x%x", eglGetError()); return false; }
  gFboW = w; gFboH = h;
  glGenTextures(1, &gFboTex); glBindTexture(GL_TEXTURE_2D, gFboTex); glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glGenRenderbuffers(1, &gFboRb); glBindRenderbuffer(GL_RENDERBUFFER, gFboRb); glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, w, h);
  glGenFramebuffers(1, &gFbo); glBindFramebuffer(GL_FRAMEBUFFER, gFbo);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, gFboTex, 0);
  glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, gFboRb);
  GLenum st = glCheckFramebufferStatus(GL_FRAMEBUFFER); LOG("hw: fbo %ux%u status 0x%x", w, h, st);
  return st == GL_FRAMEBUFFER_COMPLETE;
}
void hwDestroy() {
  if (gEd == EGL_NO_DISPLAY) return;
  eglMakeCurrent(gEd, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
  if (gEc != EGL_NO_CONTEXT) eglDestroyContext(gEd, gEc); if (gEs != EGL_NO_SURFACE) eglDestroySurface(gEd, gEs);
  gEc = EGL_NO_CONTEXT; gEs = EGL_NO_SURFACE; gHwOn = false;
}

bool RETRO_CALLCONV envcb(unsigned cmd, void* data) {
  switch (cmd) {
    case RETRO_ENVIRONMENT_GET_PREFERRED_HW_RENDER: *(unsigned*)data = RETRO_HW_CONTEXT_OPENGLES3; return true;
    case RETRO_ENVIRONMENT_SET_HW_RENDER: {
      retro_hw_render_callback* h = (retro_hw_render_callback*)data;
      if (h->context_type != RETRO_HW_CONTEXT_OPENGLES2 && h->context_type != RETRO_HW_CONTEXT_OPENGLES3 && h->context_type != RETRO_HW_CONTEXT_OPENGLES_VERSION) { LOG("hw: unsupported context type %u", h->context_type); return false; }
      h->get_current_framebuffer = hwFbo; h->get_proc_address = hwProc; gHw = *h; gHwWanted = true; return true;
    }
    case RETRO_ENVIRONMENT_GET_CAN_DUPE: *(bool*)data = true; return true;
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: {
      unsigned f = *(const unsigned*)data;
      if (f == RETRO_PIXEL_FORMAT_0RGB1555 || f == RETRO_PIXEL_FORMAT_XRGB8888 || f == RETRO_PIXEL_FORMAT_RGB565) { gFmt = f; return true; }
      return false;
    }
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY: *(const char**)data = gSystemDir.c_str(); return true;
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY: *(const char**)data = gSaveDir.c_str(); return true;
    case RETRO_ENVIRONMENT_GET_CORE_ASSETS_DIRECTORY: *(const char**)data = gSystemDir.c_str(); return true;
    case RETRO_ENVIRONMENT_GET_LOG_INTERFACE: ((struct retro_log_callback*)data)->log = logcb; return true;
    case RETRO_ENVIRONMENT_SET_VARIABLES: parseVars((const struct retro_variable*)data); return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE: {
      struct retro_variable* v = (struct retro_variable*)data; auto it = gVars.find(v->key);
      if (it == gVars.end()) { v->value = nullptr; return false; }
      v->value = it->second.c_str(); return true;
    }
    case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE: *(bool*)data = false; return true;
    case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION: *(unsigned*)data = 0; return true;
    case RETRO_ENVIRONMENT_SET_GEOMETRY: {
      const struct retro_game_geometry* g = (const struct retro_game_geometry*)data;
      gAspect = g->aspect_ratio > 0 ? g->aspect_ratio : (g->base_height ? (double)g->base_width / g->base_height : 0); return true;
    }
    case RETRO_ENVIRONMENT_GET_LANGUAGE: *(unsigned*)data = RETRO_LANGUAGE_ENGLISH; return true;
    case RETRO_ENVIRONMENT_SET_MEMORY_MAPS: {
      const struct retro_memory_map* m = (const struct retro_memory_map*)data;
      gDescs.assign(m->descriptors, m->descriptors + m->num_descriptors); gMap.descriptors = gDescs.data(); gMap.num_descriptors = (unsigned)gDescs.size(); gHaveMap = true; return true;
    }
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
    case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
    case RETRO_ENVIRONMENT_SET_SUPPORT_ACHIEVEMENTS:
    case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL:
    case RETRO_ENVIRONMENT_SET_SERIALIZATION_QUIRKS:
      return true;
    default: return false;
  }
}

void RETRO_CALLCONV videocb(const void* data, unsigned w, unsigned h, size_t pitch) {
  if (!data || !w || !h) return;
  if (data == RETRO_HW_FRAME_BUFFER_VALID && gHwOn) {
    if (w > gFboW) w = gFboW; if (h > gFboH) h = gFboH;
    gRead.resize((size_t)w * h * 4); glBindFramebuffer(GL_FRAMEBUFFER, gFbo); glPixelStorei(GL_PACK_ALIGNMENT, 1); glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, gRead.data());
    std::lock_guard<std::mutex> g(gVidMu); gFw = w; gFh = h; gGlFmt565 = false; gFrame.resize((size_t)w * h * 4);
    for (unsigned y = 0; y < h; y++) memcpy(&gFrame[(size_t)y * w * 4], &gRead[(size_t)(gHw.bottom_left_origin ? h - 1 - y : y) * w * 4], (size_t)w * 4);
    gNewFrame = true; return;
  }
  if (data == RETRO_HW_FRAME_BUFFER_VALID) return;
  std::lock_guard<std::mutex> g(gVidMu);
  gFw = w; gFh = h;
  if (gFmt == RETRO_PIXEL_FORMAT_XRGB8888) {
    gGlFmt565 = false; gFrame.resize((size_t)w * h * 4);
    for (unsigned y = 0; y < h; y++) {
      const uint32_t* s = (const uint32_t*)((const uint8_t*)data + y * pitch); uint32_t* d = (uint32_t*)&gFrame[(size_t)y * w * 4];
      for (unsigned x = 0; x < w; x++) { uint32_t p = s[x]; d[x] = 0xFF000000u | ((p & 0xFF) << 16) | (p & 0xFF00) | ((p >> 16) & 0xFF); }
    }
  } else if (gFmt == RETRO_PIXEL_FORMAT_RGB565) {
    gGlFmt565 = true; gFrame.resize((size_t)w * h * 2);
    for (unsigned y = 0; y < h; y++) memcpy(&gFrame[(size_t)y * w * 2], (const uint8_t*)data + y * pitch, (size_t)w * 2);
  } else {
    gGlFmt565 = true; gFrame.resize((size_t)w * h * 2);
    for (unsigned y = 0; y < h; y++) {
      const uint16_t* s = (const uint16_t*)((const uint8_t*)data + y * pitch); uint16_t* d = (uint16_t*)&gFrame[(size_t)y * w * 2];
      for (unsigned x = 0; x < w; x++) { uint16_t p = s[x]; unsigned r = (p >> 10) & 31, gg = (p >> 5) & 31, b = p & 31; d[x] = (uint16_t)((r << 11) | (((gg << 1) | (gg >> 4)) << 5) | b); }
    }
  }
  gNewFrame = true;
}

void flushAudio() {
  if (gAudioAcc.empty()) return;
  JNIEnv* env = nullptr; if (gVm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) gVm->AttachCurrentThread(&env, nullptr);
  jshortArray arr = env->NewShortArray((jsize)gAudioAcc.size());
  env->SetShortArrayRegion(arr, 0, (jsize)gAudioAcc.size(), gAudioAcc.data());
  env->CallStaticVoidMethod(gCls, mAudio, arr, (jint)gAudioAcc.size());
  env->DeleteLocalRef(arr); gAudioAcc.clear(); gAudioThisFrame = true;
}
void RETRO_CALLCONV audiocb(int16_t l, int16_t r) { gAudioAcc.push_back(l); gAudioAcc.push_back(r); }
size_t RETRO_CALLCONV audiobatch(const int16_t* d, size_t frames) { gAudioAcc.insert(gAudioAcc.end(), d, d + frames * 2); return frames; }
void RETRO_CALLCONV pollcb() {}
int16_t RETRO_CALLCONV statecb(unsigned port, unsigned device, unsigned, unsigned id) {
  if (port != 0 || device != RETRO_DEVICE_JOYPAD) return 0;
  int m = gPad.load();
  if (id == RETRO_DEVICE_ID_JOYPAD_MASK) return (int16_t)m;
  return (m >> id) & 1;
}

bool readFile(const std::string& p, std::vector<uint8_t>& out) {
  std::ifstream f(p, std::ios::binary); if (!f) return false;
  f.seekg(0, std::ios::end); size_t n = (size_t)f.tellg(); f.seekg(0); out.resize(n); f.read((char*)out.data(), n); return true;
}
void writeFile(const std::string& p, const void* d, size_t n) { std::ofstream f(p, std::ios::binary | std::ios::trunc); f.write((const char*)d, n); }

void loadSram() {
  size_t n = c_mem_size ? c_mem_size(RETRO_MEMORY_SAVE_RAM) : 0; void* p = n ? c_mem_data(RETRO_MEMORY_SAVE_RAM) : nullptr;
  if (!p) return; std::vector<uint8_t> b; if (readFile(gSaveBase + ".srm", b)) memcpy(p, b.data(), b.size() < n ? b.size() : n);
}
void saveSram() {
  size_t n = c_mem_size ? c_mem_size(RETRO_MEMORY_SAVE_RAM) : 0; void* p = n ? c_mem_data(RETRO_MEMORY_SAVE_RAM) : nullptr;
  if (p) writeFile(gSaveBase + ".srm", p, n);
}

template <typename T> bool sym(T& f, const char* name) { f = (T)dlsym(gLib, name); if (!f) LOG("missing symbol %s", name); return f != nullptr; }

JNIEnv* jenv() { JNIEnv* env = nullptr; if (gVm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) gVm->AttachCurrentThread(&env, nullptr); return env; }

uint32_t RC_CCONV rcRead(uint32_t addr, uint8_t* buf, uint32_t n, rc_client_t*) { return gRegionsInit ? rc_libretro_memory_read(&gRegions, addr, buf, n) : 0; }
void RC_CCONV coreMemInfo(uint32_t id, rc_libretro_core_memory_info_t* info) { info->data = c_mem_size && c_mem_size(id) ? (uint8_t*)c_mem_data(id) : nullptr; info->size = c_mem_size ? c_mem_size(id) : 0; }
void RC_CCONV rcLog(const char* m, const rc_client_t*) { LOG("rc: %s", m); }

void RC_CCONV rcServer(const rc_api_request_t* req, rc_client_server_callback_t cb, void* data, rc_client_t*) {
  long long t; { std::lock_guard<std::mutex> g(gPendMu); t = ++gTicket; gPending[t] = {cb, data}; }
  JNIEnv* env = jenv();
  jstring u = env->NewStringUTF(req->url), p = req->post_data ? env->NewStringUTF(req->post_data) : nullptr, c = req->content_type ? env->NewStringUTF(req->content_type) : nullptr;
  env->CallStaticVoidMethod(gCls, mHttp, (jlong)t, u, p, c);
  env->DeleteLocalRef(u); if (p) env->DeleteLocalRef(p); if (c) env->DeleteLocalRef(c);
}

void drainRa() {
  std::vector<Done> d; { std::lock_guard<std::mutex> g(gPendMu); d.swap(gDone); }
  for (auto& x : d) { rc_api_server_response_t r; r.body = x.body.c_str(); r.body_length = x.body.size(); r.http_status_code = x.status; x.cb(&r, x.data); }
}

void RC_CCONV rcEvent(const rc_client_event_t* e, rc_client_t*) {
  char msg[1400], url[256]; url[0] = 0;
  switch (e->type) {
    case RC_CLIENT_EVENT_ACHIEVEMENT_TRIGGERED:
      if (e->achievement) { rc_client_achievement_get_image_url(e->achievement, RC_CLIENT_ACHIEVEMENT_STATE_UNLOCKED, url, sizeof url);
        snprintf(msg, sizeof msg, "ACH\x1f%s\x1f%s\x1f%u\x1f%s", e->achievement->title ? e->achievement->title : "", e->achievement->description ? e->achievement->description : "", e->achievement->points, url); jstatus(msg); }
      break;
    case RC_CLIENT_EVENT_GAME_COMPLETED: { const rc_client_game_t* g = rc_client_get_game_info(gRc); snprintf(msg, sizeof msg, "DONE\x1f%s", g && g->title ? g->title : ""); jstatus(msg); break; }
    case RC_CLIENT_EVENT_SERVER_ERROR: jstatus("MSG:RetroAchievements server error"); break;
    case RC_CLIENT_EVENT_DISCONNECTED: jstatus("MSG:Achievements offline - unlocks will sync later"); break;
    case RC_CLIENT_EVENT_RECONNECTED: jstatus("MSG:Achievements synced"); break;
    case RC_CLIENT_EVENT_RESET: gOp = 3; break;
    default: break;
  }
}

void RC_CCONV onLogin(int result, const char* err, rc_client_t* c, void*) {
  if (result == RC_OK) { const rc_client_user_t* u = rc_client_get_user_info(c); LOG("RA login ok: %s", u ? u->display_name : "?"); }
  else { char m[300]; snprintf(m, sizeof m, "MSG:RetroAchievements sign-in failed: %s", err ? err : "unknown"); jstatus(m); }
}
void RC_CCONV onLoad(int result, const char* err, rc_client_t* c, void*) {
  if (result != RC_OK) { LOG("RA load: %d %s", result, err ? err : ""); if (result == RC_NO_GAME_LOADED) jstatus("NOGAME\x1f"); else if (err) { char m[300]; snprintf(m, sizeof m, "MSG:Achievements: %s", err); jstatus(m); } return; }
  const rc_client_game_t* g = rc_client_get_game_info(c); rc_client_user_game_summary_t sm; rc_client_get_user_game_summary(c, &sm);
  // The server adds a "Warning: Unknown Emulator" pseudo-achievement (id >= 101000000) for clients it does not know. It is not a real achievement, so leave it out of the counts.
  unsigned nTot = 0, nDone = 0, ptsTot = 0, nWarn = 0;
  if (rc_client_achievement_list_t* l = rc_client_create_achievement_list(c, RC_CLIENT_ACHIEVEMENT_CATEGORY_CORE, RC_CLIENT_ACHIEVEMENT_LIST_GROUPING_LOCK_STATE)) {
    for (uint32_t b = 0; b < l->num_buckets; b++) for (uint32_t i = 0; i < l->buckets[b].num_achievements; i++) { const rc_client_achievement_t* a = l->buckets[b].achievements[i];
      if (a->id >= 101000000u) { nWarn++; continue; } nTot++; ptsTot += a->points; if (a->unlocked) nDone++; }
    rc_client_destroy_achievement_list(l);
  } else { nTot = sm.num_core_achievements; nDone = sm.num_unlocked_achievements; ptsTot = sm.points_core; }
  LOG("RA summary: id=%u listTotal=%u listDone=%u pts=%u warnings=%u | rc core=%u unlocked=%u hardcore=%d", g ? g->id : 0, nTot, nDone, ptsTot, nWarn, sm.num_core_achievements, sm.num_unlocked_achievements, rc_client_get_hardcore_enabled(c));
  char msg[600]; snprintf(msg, sizeof msg, "GAME\x1f%s\x1f%u\x1f%u\x1f%u", g && g->title ? g->title : "", nDone, nTot, ptsTot);
  jstatus(msg);
}

void runLoop(std::string corePath, std::string rom) {
  setpriority(PRIO_PROCESS, 0, -16); gHwWanted = false; gHwOn = false;
  gLib = dlopen(corePath.c_str(), RTLD_LAZY | RTLD_LOCAL);
  if (!gLib) { LOG("dlopen failed: %s", dlerror()); jstatus("ERR:Could not load the emulator core"); return; }
  bool ok = sym(c_set_env, "retro_set_environment") && sym(c_set_video, "retro_set_video_refresh") && sym(c_set_audio, "retro_set_audio_sample") &&
            sym(c_set_audio_batch, "retro_set_audio_sample_batch") && sym(c_set_poll, "retro_set_input_poll") && sym(c_set_state, "retro_set_input_state") &&
            sym(c_init, "retro_init") && sym(c_deinit, "retro_deinit") && sym(c_get_info, "retro_get_system_info") && sym(c_get_av, "retro_get_system_av_info") &&
            sym(c_load, "retro_load_game") && sym(c_unload, "retro_unload_game") && sym(c_run, "retro_run") && sym(c_ser_size, "retro_serialize_size") &&
            sym(c_ser, "retro_serialize") && sym(c_unser, "retro_unserialize") && sym(c_mem_data, "retro_get_memory_data") && sym(c_mem_size, "retro_get_memory_size") && sym(c_reset, "retro_reset");
  if (!ok) { jstatus("ERR:Core is incompatible"); return; }
  c_set_env(envcb); c_init();
  c_set_video(videocb); c_set_audio(audiocb); c_set_audio_batch(audiobatch); c_set_poll(pollcb); c_set_state(statecb);
  struct retro_system_info si; memset(&si, 0, sizeof si); c_get_info(&si);
  struct retro_game_info gi; memset(&gi, 0, sizeof gi); gi.path = rom.c_str();
  std::vector<uint8_t> data;
  if (!si.need_fullpath) { if (!readFile(rom, data)) { jstatus("ERR:Could not read the game file"); return; } gi.data = data.data(); gi.size = data.size(); }
  if (!c_load(&gi)) { jstatus("ERR:The core could not load this game"); return; }
  if (gHwWanted) {  // GLES core: it declared a hardware context while loading; build it now at the declared maximum size
    unsigned mw = 1024, mh = 1024; struct retro_system_av_info a0; memset(&a0, 0, sizeof a0); c_get_av(&a0);
    if (a0.geometry.max_width >= 64 && a0.geometry.max_width <= 4096) mw = a0.geometry.max_width; if (a0.geometry.max_height >= 64 && a0.geometry.max_height <= 4096) mh = a0.geometry.max_height;
    if (!hwCreate(mw, mh)) { jstatus("ERR:This device could not create the graphics context the core needs"); return; }
    gHwOn = true; if (gHw.context_reset) gHw.context_reset();
  }
  struct retro_system_av_info av; memset(&av, 0, sizeof av); c_get_av(&av);
  gFps = av.timing.fps > 1 ? av.timing.fps : 60.0; gRate = av.timing.sample_rate > 1000 ? av.timing.sample_rate : 44100.0;
  gAspect = av.geometry.aspect_ratio > 0 ? av.geometry.aspect_ratio : (av.geometry.base_height ? (double)av.geometry.base_width / av.geometry.base_height : 1.333);
  loadSram();
  if (!gRaUser.empty() && (!gRaToken.empty() || !gRaPass.empty()) && gConsole) {
    rc_libretro_memory_init(&gRegions, gHaveMap ? &gMap : nullptr, coreMemInfo, gConsole); gRegionsInit = true;
    gRc = rc_client_create(rcRead, rcServer); rc_client_set_event_handler(gRc, rcEvent); rc_client_enable_logging(gRc, RC_CLIENT_LOG_LEVEL_INFO, rcLog);
    rc_client_set_hardcore_enabled(gRc, gHard ? 1 : 0);
    if (!gRaToken.empty()) rc_client_begin_login_with_token(gRc, gRaUser.c_str(), gRaToken.c_str(), onLogin, nullptr);
    else rc_client_begin_login_with_password(gRc, gRaUser.c_str(), gRaPass.c_str(), onLogin, nullptr);
    if (data.empty()) readFile(rom, data);
    rc_client_begin_identify_and_load_game(gRc, gConsole, rom.c_str(), data.empty() ? nullptr : data.data(), data.size(), onLoad, nullptr);
  }
  { JNIEnv* env = nullptr; if (gVm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) gVm->AttachCurrentThread(&env, nullptr); env->CallStaticVoidMethod(gCls, mAv, (jint)gRate); }
  jstatus("READY");
  int perfN = 0; double perfSum = 0, perfMax = 0; auto perfT = std::chrono::steady_clock::now();
  auto lastSave = std::chrono::steady_clock::now(); auto next = std::chrono::steady_clock::now();
  const auto frameDur = std::chrono::duration<double>(1.0 / gFps);
  while (!gQuit) {
    drainRa();
    if (gPaused) { if (gRc) { std::lock_guard<std::mutex> g(gRcMu); rc_client_idle(gRc); } std::this_thread::sleep_for(std::chrono::milliseconds(30)); next = std::chrono::steady_clock::now(); continue; }
    int op = gOp.exchange(0);
    if (op) {
      std::string path; { std::lock_guard<std::mutex> g(gOpMu); path = gOpPath; }
      if (op == 1) { size_t n = c_ser_size(); std::vector<uint8_t> b(n); if (n && c_ser(b.data(), n)) { writeFile(path, b.data(), n); jstatus("MSG:State saved"); } else jstatus("MSG:Save state not supported"); }
      else if (op == 2) { if (gRc && rc_client_get_hardcore_enabled(gRc)) { jstatus("MSG:Loading states is disabled in hardcore mode"); } else { std::vector<uint8_t> b; if (readFile(path, b) && c_unser(b.data(), b.size())) jstatus("MSG:State loaded"); else jstatus("MSG:No saved state"); } }
      else if (op == 3) { c_reset(); if (gRc) rc_client_reset(gRc); jstatus("MSG:Reset"); }
    }
    auto t0 = std::chrono::steady_clock::now(); gAudioThisFrame = false; c_run(); if (gRc) { std::lock_guard<std::mutex> g(gRcMu); if (rc_client_is_game_loaded(gRc)) rc_client_do_frame(gRc); else rc_client_idle(gRc); } double runMs = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count(); flushAudio();
    { double ms = runMs; perfSum += ms; if (ms > perfMax) perfMax = ms; if (++perfN >= 300) { auto tn = std::chrono::steady_clock::now(); double el = std::chrono::duration<double>(tn - perfT).count(); LOG("perf: %.1f fps, frame avg %.2f ms max %.2f ms (budget %.2f)", perfN / el, perfSum / perfN, perfMax, 1000.0 / gFps); perfN = 0; perfSum = 0; perfMax = 0; perfT = tn; } }
    next += std::chrono::duration_cast<std::chrono::steady_clock::duration>(frameDur);
    auto now = std::chrono::steady_clock::now();
    if (!gAudioThisFrame || next > now + std::chrono::milliseconds(40)) { if (next > now) std::this_thread::sleep_until(next); }
    if (now > next + std::chrono::milliseconds(200)) next = now;
    if (now - lastSave > std::chrono::seconds(15)) { saveSram(); lastSave = now; }
  }
  saveSram();
  if (gRc) { for (int i = 0; i < 50; i++) { drainRa(); { std::lock_guard<std::mutex> g(gPendMu); if (gPending.empty()) break; } std::this_thread::sleep_for(std::chrono::milliseconds(100)); } drainRa(); rc_client_unload_game(gRc); rc_client_destroy(gRc); gRc = nullptr; }
  c_unload(); if (gHwOn && gHw.context_destroy) gHw.context_destroy(); c_deinit(); hwDestroy();
  LOG("core stopped");
}

// ---- GL ----
GLuint gProg = 0, gTex = 0; GLint gPos = 0, gUv = 0, gSamp = 0; int gVw = 1, gVh = 1;
GLuint compile(GLenum t, const char* s) { GLuint sh = glCreateShader(t); glShaderSource(sh, 1, &s, nullptr); glCompileShader(sh); return sh; }
}  // namespace

extern "C" {
JNIEXPORT void JNICALL Java_com_cactios_app_Player_nStart(JNIEnv* env, jclass cls, jstring core, jstring rom, jstring sysDir, jstring saveDir, jstring saveBase, jstring stateBase, jstring raUser, jstring raToken, jstring raPass, jboolean hard, jint console) {
  env->GetJavaVM(&gVm); gCls = (jclass)env->NewGlobalRef(cls);
  mAv = env->GetStaticMethodID(cls, "onAv", "(I)V"); mAudio = env->GetStaticMethodID(cls, "audio", "([SI)V"); mStatus = env->GetStaticMethodID(cls, "onStatus", "(Ljava/lang/String;)V"); mHttp = env->GetStaticMethodID(cls, "http", "(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V");
  auto S = [&](jstring j) { const char* c = env->GetStringUTFChars(j, nullptr); std::string s = c; env->ReleaseStringUTFChars(j, c); return s; };
  std::string cp = S(core), rp = S(rom); gSystemDir = S(sysDir); gSaveDir = S(saveDir); gSaveBase = S(saveBase); gStateBase = S(stateBase); gRaUser = S(raUser); gRaToken = S(raToken); gRaPass = S(raPass); gHard = hard; gConsole = (unsigned)console;
  gQuit = false; gPaused = false; gOp = 0; gPad = 0; gNewFrame = false;
  gThread = std::thread(runLoop, cp, rp);
}
JNIEXPORT void JNICALL Java_com_cactios_app_Player_nHttpDone(JNIEnv* env, jclass, jlong t, jint status, jstring body) {
  const char* c = body ? env->GetStringUTFChars(body, nullptr) : ""; std::string b = c ? c : ""; if (body) env->ReleaseStringUTFChars(body, c);
  std::lock_guard<std::mutex> g(gPendMu); auto it = gPending.find(t); if (it == gPending.end()) return;
  gDone.push_back({it->second.cb, it->second.data, status, b}); gPending.erase(it);
}
JNIEXPORT void JNICALL Java_com_cactios_app_Player_nGlOpts(JNIEnv*, jclass, jint integer, jint aspect, jboolean smooth) { gInt = integer; gAspectMode = aspect; gSmooth = smooth ? 1 : 0; }
JNIEXPORT jstring JNICALL Java_com_cactios_app_Player_nAchList(JNIEnv* env, jclass) {
  std::string out;
  { std::lock_guard<std::mutex> g(gRcMu);
    if (gRc && rc_client_is_game_loaded(gRc)) {
      rc_client_achievement_list_t* l = rc_client_create_achievement_list(gRc, RC_CLIENT_ACHIEVEMENT_CATEGORY_CORE, RC_CLIENT_ACHIEVEMENT_LIST_GROUPING_LOCK_STATE);
      if (l) { for (uint32_t b = 0; b < l->num_buckets; b++) for (uint32_t i = 0; i < l->buckets[b].num_achievements; i++) {
          const rc_client_achievement_t* a = l->buckets[b].achievements[i]; if (a->id >= 101000001u) continue;
          out += std::string(a->unlocked ? "U" : "L") + "\x1f" + (a->title ? a->title : "") + "\x1f" + (a->description ? a->description : "") + "\x1f" + std::to_string(a->points) + "\n"; }
        rc_client_destroy_achievement_list(l); } } }
  return env->NewStringUTF(out.c_str());
}
JNIEXPORT void JNICALL Java_com_cactios_app_Player_nStop(JNIEnv*, jclass) { gQuit = true; if (gThread.joinable()) gThread.join(); }
JNIEXPORT void JNICALL Java_com_cactios_app_Player_nPause(JNIEnv*, jclass, jboolean p) { gPaused = p; }
JNIEXPORT void JNICALL Java_com_cactios_app_Player_nInput(JNIEnv*, jclass, jint mask) { gPad = mask; }
JNIEXPORT void JNICALL Java_com_cactios_app_Player_nOp(JNIEnv* env, jclass, jint op, jstring path) {
  const char* c = env->GetStringUTFChars(path, nullptr); { std::lock_guard<std::mutex> g(gOpMu); gOpPath = c; } env->ReleaseStringUTFChars(path, c); gOp = op;
}
JNIEXPORT void JNICALL Java_com_cactios_app_Player_nGlInit(JNIEnv*, jclass) {
  const char* vs = "attribute vec2 p;attribute vec2 t;varying vec2 v;void main(){gl_Position=vec4(p,0.,1.);v=t;}";
  const char* fs = "precision mediump float;varying vec2 v;uniform sampler2D s;void main(){gl_FragColor=texture2D(s,v);}";
  gProg = glCreateProgram(); glAttachShader(gProg, compile(GL_VERTEX_SHADER, vs)); glAttachShader(gProg, compile(GL_FRAGMENT_SHADER, fs)); glLinkProgram(gProg);
  gPos = glGetAttribLocation(gProg, "p"); gUv = glGetAttribLocation(gProg, "t"); gSamp = glGetUniformLocation(gProg, "s");
  glGenTextures(1, &gTex); glBindTexture(GL_TEXTURE_2D, gTex);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1); glClearColor(0, 0, 0, 1);
}
JNIEXPORT void JNICALL Java_com_cactios_app_Player_nGlSize(JNIEnv*, jclass, jint w, jint h) { gVw = w > 0 ? w : 1; gVh = h > 0 ? h : 1; glViewport(0, 0, gVw, gVh); }
JNIEXPORT void JNICALL Java_com_cactios_app_Player_nGlDraw(JNIEnv*, jclass) {
  glClear(GL_COLOR_BUFFER_BIT);
  { std::lock_guard<std::mutex> g(gVidMu);
    if (gNewFrame && gFw) {
      glBindTexture(GL_TEXTURE_2D, gTex);
      if (gGlFmt565) glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, gFw, gFh, 0, GL_RGB, GL_UNSIGNED_SHORT_5_6_5, gFrame.data());
      else glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, gFw, gFh, 0, GL_RGBA, GL_UNSIGNED_BYTE, gFrame.data());
      gNewFrame = false; } }
  if (!gFw) return;
  static int lastSmooth = -1; int sm = gSmooth.load(); if (sm != lastSmooth) { lastSmooth = sm; glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, sm ? GL_LINEAR : GL_NEAREST); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, sm ? GL_LINEAR : GL_NEAREST); }
  int am = gAspectMode.load(); float va = gAspect > 0 ? (float)gAspect : 1.333f; if (am == 1) va = 4.f / 3.f; else if (am == 2) va = 16.f / 9.f; else if (am == 3) va = (float)gFw / gFh;
  float sa = (float)gVw / gVh, sx = 1, sy = 1;
  if (sa > va) sx = va / sa; else sy = sa / va;
  if (gInt.load()) { float dh = (float)gFh, dw = dh * va; float k = floorf(fminf(gVw / dw, gVh / dh)); if (k >= 1) { sx = dw * k / gVw; sy = dh * k / gVh; } }
  const GLfloat q[] = { -sx, sy, 0, 0, sx, sy, 1, 0, -sx, -sy, 0, 1, sx, -sy, 1, 1 };
  glUseProgram(gProg); glBindTexture(GL_TEXTURE_2D, gTex); glUniform1i(gSamp, 0);
  glEnableVertexAttribArray(gPos); glEnableVertexAttribArray(gUv);
  glVertexAttribPointer(gPos, 2, GL_FLOAT, GL_FALSE, 16, q); glVertexAttribPointer(gUv, 2, GL_FLOAT, GL_FALSE, 16, q + 2);
  glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}
}
