package com.cactios.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;
import android.content.pm.PackageInstaller;
import android.app.PendingIntent;
import android.os.Build;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Stands in for the desktop app's main process. Every channel the screens call lands in invoke(). Unknown channels answer null so the UI keeps running. */
public class Bridge {
  private final Context ctx;
  private final WebView web;
  private final SharedPreferences prefs;
  private final Library lib;
  private final ExecutorService pool = Executors.newFixedThreadPool(3);
  volatile boolean launching = false;

  Bridge(Context c, WebView w) { ctx = c; web = w; prefs = c.getSharedPreferences("cacti", Context.MODE_PRIVATE); lib = new Library(c); java.io.File def = new java.io.File(c.getExternalFilesDir(null), "ROMs"); def.mkdirs(); }

  private String romRoot() {
    try { String r = new JSONObject(prefs.getString("cfg", "{}")).optString("romRoot", ""); if (!r.isEmpty()) return r; } catch (Exception e) {}
    return new java.io.File(ctx.getExternalFilesDir(null), "ROMs").getPath();
  }

  private JSONObject config() {
    JSONObject d = new JSONObject();
    try {
      d.put("setupDone", true); d.put("theme", "classic"); d.put("layout", "classic"); d.put("romRoot", romRoot()); d.put("achStyle", "pill");
      d.put("prompts", "Xbox"); d.put("navSounds", true); d.put("dark", false); d.put("fullscreen", true);
      JSONObject saved = new JSONObject(prefs.getString("cfg", "{}"));
      java.util.Iterator<String> it = saved.keys();
      while (it.hasNext()) { String k = it.next(); d.put(k, saved.get(k)); }
    } catch (Exception e) { Log.w("CactiBridge", e); }
    return d;
  }

  /** Async entry: the screens call this, the work happens on a worker thread, and the answer comes back through __androidResolve. */
  private int pickId = 0;
  void resolve(int id, String res) { final String q = JSONObject.quote(res); web.post(() -> web.evaluateJavascript("window.__androidResolve(" + id + "," + q + ")", null)); }

  /** Called by the activity when the folder chooser closes. */
  void onPicked(android.net.Uri uri) {
    int id = pickId; pickId = 0; if (id == 0) return;
    String path = null;
    try {
      if (uri != null) {
        String doc = android.provider.DocumentsContract.getTreeDocumentId(uri); // e.g. primary:Roms or 1234-ABCD:Games
        int c = doc.indexOf(':'); String vol = c < 0 ? doc : doc.substring(0, c), rel = c < 0 ? "" : doc.substring(c + 1);
        String base = vol.equals("primary") ? "/storage/emulated/0" : "/storage/" + vol;
        path = rel.isEmpty() ? base : base + "/" + rel;
      }
    } catch (Exception e) {}
    resolve(id, path == null ? "{\"v\":null}" : "{\"v\":" + JSONObject.quote(path) + "}");
  }

  @JavascriptInterface public void call(final int id, final String ch, final String argsJson) {
    if (ch.equals("pick")) {
      if (pickId != 0) { resolve(id, "{\"v\":null}"); return; }
      pickId = id;
      web.post(() -> { try { ((android.app.Activity) ctx).startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 4242); } catch (Exception e) { pickId = 0; resolve(id, "{\"v\":null}"); } });
      return;
    }
    pool.execute(() -> {
      String res; try { res = invoke(ch, argsJson); } catch (Throwable t) { res = "{\"err\":\"" + String.valueOf(t.getMessage()).replace("\"", "'") + "\"}"; }
      final String q = JSONObject.quote(res);
      web.post(() -> web.evaluateJavascript("window.__androidResolve(" + id + "," + q + ")", null));
    });
  }

  void emit(String ch, String json) { final String js = "window.__androidEmit&&window.__androidEmit(" + JSONObject.quote(ch) + "," + json + ")"; web.post(() -> web.evaluateJavascript(js, null)); }

  private String raPkg() {
    for (String p : new String[] { "com.retroarch.aarch64", "com.retroarch", "com.retroarch.ra32" }) { try { ctx.getPackageManager().getPackageInfo(p, 0); return p; } catch (Exception e) {} }
    return null;
  }

  private String dolphinPkg() {
    for (String p : new String[] { "org.dolphinemu.dolphinemu", "org.dolphinemu.mmjr" }) { try { ctx.getPackageManager().getPackageInfo(p, 0); return p; } catch (Exception e) {} }
    return null;
  }

  /** Dolphin's own Android app, from the official dolphin-emu.org release list (falls back to the last release we checked). */
  private JSONObject installDolphin() throws Exception {
    emit("emu-progress", "{\"id\":\"dolphin\",\"msg\":\"Finding the latest Dolphin…\"}");
    String url = "https://dl.dolphin-emu.org/releases/2609b/dolphin-2609b.apk";
    try { Matcher m = Pattern.compile("https://dl\\.dolphin-emu\\.org/releases/[A-Za-z0-9]+/dolphin-[A-Za-z0-9]+\\.apk").matcher(http("https://dolphin-emu.org/download/list/releases/1/")); if (m.find()) url = m.group(); } catch (Exception e) { android.util.Log.w("CactiDolphin", "release list: " + e); }
    emit("emu-progress", "{\"id\":\"dolphin\",\"msg\":\"Downloading " + url.substring(url.lastIndexOf('/') + 1) + "…\"}");
    File out = new File(ctx.getCacheDir(), "Dolphin.apk");
    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection(); c.setConnectTimeout(15000); c.setReadTimeout(60000); c.setRequestProperty("User-Agent", "CactiOS");
    try (InputStream in = c.getInputStream(); FileOutputStream fo = new FileOutputStream(out)) { byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) fo.write(buf, 0, n); }
    if (Build.VERSION.SDK_INT >= 26 && !ctx.getPackageManager().canRequestPackageInstalls()) {
      Intent si = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, android.net.Uri.parse("package:" + ctx.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      ctx.startActivity(si); JSONObject r = new JSONObject(); r.put("needPermission", true); return r;
    }
    PackageInstaller pi = ctx.getPackageManager().getPackageInstaller();
    int sid = pi.createSession(new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL));
    try (PackageInstaller.Session s = pi.openSession(sid)) {
      try (InputStream in = new FileInputStream(out); OutputStream os = s.openWrite("Dolphin", 0, out.length())) { byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) os.write(buf, 0, n); s.fsync(os); }
      Intent it = new Intent("com.cactios.app.INSTALL_RESULT").setPackage(ctx.getPackageName());
      PendingIntent pe = PendingIntent.getBroadcast(ctx, sid, it, PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
      s.commit(pe.getIntentSender());
    }
    JSONObject r = new JSONObject(); r.put("installed", true); r.put("note", "Android asks you to confirm the install."); return r;
  }

  /** GameCube and Wii games open in Dolphin's own app. */

  // Dolphin config helpers: map the built-in gamepad and sign in to RetroAchievements (best effort: Android may block writing into another app's data folder)
  private static String ex(String c, String... n) { StringBuilder b = new StringBuilder(); for (int i = 0; i < 5; i++) for (String x : n) { if (b.length() > 0) b.append(" | "); b.append("`Android/").append(i).append("/AIR X Controller:").append(x).append("`"); } return b.toString(); }
  private static void iniSet(java.io.File f, String sec, java.util.LinkedHashMap<String, String> kv) throws IOException {
    java.util.List<String> L = f.exists() ? java.nio.file.Files.readAllLines(f.toPath(), java.nio.charset.StandardCharsets.UTF_8) : new java.util.ArrayList<>();
    int a = -1, e = L.size();
    for (int i = 0; i < L.size(); i++) { String t = L.get(i).trim(); if (t.startsWith("[") && t.endsWith("]")) { if (a >= 0) { e = i; break; } if (t.substring(1, t.length() - 1).equalsIgnoreCase(sec)) a = i; } }
    if (a < 0) { L.add("[" + sec + "]"); a = L.size() - 1; e = L.size(); }
    for (java.util.Map.Entry<String, String> en : kv.entrySet()) {
      int at = -1; for (int i = a + 1; i < e; i++) { String l = L.get(i); int q = l.indexOf('='); if (q > 0 && l.substring(0, q).trim().equalsIgnoreCase(en.getKey())) { at = i; break; } }
      String line = en.getKey() + " = " + en.getValue();
      if (at >= 0) L.set(at, line); else { L.add(e, line); e++; }
    }
    java.nio.file.Files.write(f.toPath(), L, java.nio.charset.StandardCharsets.UTF_8);
  }
  private void prepDolphin(String pk) {
    try {
      java.io.File cd = new java.io.File("/sdcard/Android/data/" + pk + "/files/Config"); if (!cd.isDirectory() && !cd.mkdirs()) { android.util.Log.w("CactiLaunch", "dolphin config dir not writable"); return; }
      java.util.LinkedHashMap<String, String> g = new java.util.LinkedHashMap<>();
      g.put("Device", "Android/1/AIR X Controller");
      g.put("Buttons/A", ex("", "Button 96")); g.put("Buttons/B", ex("", "Button 97")); g.put("Buttons/X", ex("", "Button 99")); g.put("Buttons/Y", ex("", "Button 100")); g.put("Buttons/Z", ex("", "Button 103")); g.put("Buttons/Start", ex("", "Button 108"));
      g.put("Main Stick/Up", ex("", "Axis 1-")); g.put("Main Stick/Down", ex("", "Axis 1+")); g.put("Main Stick/Left", ex("", "Axis 0-")); g.put("Main Stick/Right", ex("", "Axis 0+"));
      g.put("C-Stick/Up", ex("", "Axis 14-")); g.put("C-Stick/Down", ex("", "Axis 14+")); g.put("C-Stick/Left", ex("", "Axis 11-")); g.put("C-Stick/Right", ex("", "Axis 11+"));
      g.put("D-Pad/Up", ex("", "Axis 16-")); g.put("D-Pad/Down", ex("", "Axis 16+")); g.put("D-Pad/Left", ex("", "Axis 15-")); g.put("D-Pad/Right", ex("", "Axis 15+"));
      g.put("Triggers/L", ex("", "Button 102", "Axis 17+", "Axis 23+")); g.put("Triggers/R", ex("", "Button 103", "Axis 18+", "Axis 22+"));
      g.put("Triggers/L-Analog", ex("", "Axis 17+", "Axis 23+")); g.put("Triggers/R-Analog", ex("", "Axis 18+", "Axis 22+"));
      iniSet(new java.io.File(cd, "GCPadNew.ini"), "GCPad1", g);
      java.util.LinkedHashMap<String, String> w = new java.util.LinkedHashMap<>();
      w.put("Device", "Android/1/AIR X Controller"); w.put("Extension", "Nunchuk");
      w.put("Buttons/A", ex("", "Button 96")); w.put("Buttons/B", ex("", "Button 97")); w.put("Buttons/1", ex("", "Button 99")); w.put("Buttons/2", ex("", "Button 100"));
      w.put("Buttons/-", ex("", "Button 109")); w.put("Buttons/+", ex("", "Button 108")); w.put("Buttons/Home", ex("", "Button 110"));
      w.put("D-Pad/Up", ex("", "Axis 16-")); w.put("D-Pad/Down", ex("", "Axis 16+")); w.put("D-Pad/Left", ex("", "Axis 15-")); w.put("D-Pad/Right", ex("", "Axis 15+"));
      w.put("Nunchuk/Stick/Up", ex("", "Axis 1-")); w.put("Nunchuk/Stick/Down", ex("", "Axis 1+")); w.put("Nunchuk/Stick/Left", ex("", "Axis 0-")); w.put("Nunchuk/Stick/Right", ex("", "Axis 0+"));
      w.put("Nunchuk/Buttons/C", ex("", "Button 102")); w.put("Nunchuk/Buttons/Z", ex("", "Button 103"));
      w.put("IR/Up", ex("", "Axis 14-")); w.put("IR/Down", ex("", "Axis 14+")); w.put("IR/Left", ex("", "Axis 11-")); w.put("IR/Right", ex("", "Axis 11+"));
      iniSet(new java.io.File(cd, "WiimoteNew.ini"), "Wiimote1", w);
      JSONObject pc = playerCfg();
      if (pc != null && pc.optString("raUser").length() > 0 && pc.optString("raToken").length() > 0) {
        java.util.LinkedHashMap<String, String> a = new java.util.LinkedHashMap<>(); a.put("Enabled", "True"); a.put("Username", pc.optString("raUser")); a.put("ApiToken", pc.optString("raToken"));
        iniSet(new java.io.File(cd, "Dolphin.ini"), "Achievements", a);
      }
      android.util.Log.i("CactiLaunch", "dolphin config written");
    } catch (Exception e) { android.util.Log.w("CactiLaunch", "dolphin config failed " + e); }
  }


  // Standalone emulator apps that are already installed take priority over the built-in cores. Returns null when none is installed for this system.
  private JSONObject launchApp(String sid, String file) {
    String[][] T = {
      // system, package, activity, mode (uri = content URI as data, path = raw path as extra)
      {"psp", "org.ppsspp.ppsspp", "org.ppsspp.ppsspp.PpssppActivity", "file", ""},
      {"dreamcast", "com.flycast.emulator", "com.flycast.emulator.MainActivity", "uri", ""},
      {"ps2", "xyz.aethersx2.android", "xyz.aethersx2.android.EmulationActivity", "path", "bootPath"},
      {"3ds", "org.citra.emu", "org.citra.emu.ui.EmulationActivity", "path", "GamePath"}};
    for (String[] t : T) {
      if (!t[0].equals(sid)) continue;
      try { ctx.getPackageManager().getPackageInfo(t[1], 0); } catch (Exception e) { continue; }
      try {
        Intent i = new Intent().setComponent(new ComponentName(t[1], t[2])); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (t[3].equals("file")) {
          try { android.os.StrictMode.setVmPolicy(new android.os.StrictMode.VmPolicy.Builder().build()); } catch (Exception e) {}
          i.setAction(Intent.ACTION_VIEW); i.setData(android.net.Uri.fromFile(new java.io.File(file)));
        } else if (t[3].equals("uri")) {
          android.net.Uri u = android.provider.DocumentsContract.buildDocumentUri("com.cactios.app.docs", file);
          ctx.grantUriPermission(t[1], u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
          i.setAction(Intent.ACTION_VIEW); i.setData(u); i.setClipData(android.content.ClipData.newRawUri("rom", u)); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } else { i.setAction(Intent.ACTION_MAIN); i.putExtra(t[4], file); }
        launching = true; ctx.startActivity(i); android.util.Log.i("CactiLaunch", "standalone " + t[1]);
        return new JSONObject().put("ok", true);
      } catch (Exception e) { launching = false; android.util.Log.w("CactiLaunch", "standalone " + t[1] + " failed " + e); }
    }
    return null;
  }

  private JSONObject launchDolphin(String file) throws Exception {
    JSONObject r = new JSONObject(); String pk = dolphinPkg();
    if (pk == null) { r.put("ok", false); r.put("error", "Dolphin is not installed. Open ROMs & Emulators in the menu to install it."); return r; }
    Intent i = new Intent().setComponent(new ComponentName(pk, "org.dolphinemu.dolphinemu.ui.main.MainActivity"));
    String arg = file;
    try { android.net.Uri u = android.provider.DocumentsContract.buildDocumentUri("com.cactios.app.docs", file);
      ctx.grantUriPermission(pk, u, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
      i.setData(u); i.setClipData(android.content.ClipData.newRawUri("rom", u)); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
      arg = u.toString(); android.util.Log.i("CactiLaunch", "dolphin uri " + arg);
    } catch (Exception e) { android.util.Log.w("CactiLaunch", "dolphin uri failed " + e); }
    i.putExtra("AutoStartFile", arg); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    prepDolphin(pk);
    try { launching = true; ctx.startActivity(i); r.put("ok", true); } catch (Exception e) { launching = false; r.put("ok", false); r.put("error", "Could not start Dolphin: " + e.getMessage()); }
    return r;
  }

  private String coreFor(String sysId, String want) {
    if (want != null && !want.isEmpty() && new java.io.File(ctx.getApplicationInfo().nativeLibraryDir + "/lib" + want + ".so").exists()) return want;
    try { for (int i = 0; i < lib.systemsRaw.length(); i++) { JSONObject s = lib.systemsRaw.getJSONObject(i); if (s.getString("id").equals(sysId)) { JSONArray c = s.optJSONArray("cores"); if (c != null && c.length() > 0) { for (int k = 0; k < c.length(); k++) { String id = c.getJSONObject(k).getString("id"); if (new java.io.File(ctx.getApplicationInfo().nativeLibraryDir + "/lib" + id + ".so").exists()) return id; } return c.getJSONObject(0).getString("id"); } } } } catch (Exception e) {}
    return null;
  }

  private JSONObject launchGame(JSONObject o) throws Exception {
    android.util.Log.i("CactiLaunch", "launch " + o);
    JSONObject r = new JSONObject(); String pkg = raPkg();
    { String sid = o.optString("system"); if (sid.equals("gamecube") || sid.equals("wii")) return launchDolphin(o.getString("file")); }
    { JSONObject sa = launchApp(o.optString("system"), o.getString("file")); if (sa != null) return sa; }
    String core = coreFor(o.optString("system"), o.optString("core")); if (core == null) { r.put("ok", false); r.put("error", "No emulator is set up for this system on Android yet."); return r; }
    String file = o.getString("file");
    if (new java.io.File(ctx.getApplicationInfo().nativeLibraryDir + "/lib" + core + ".so").exists()) {
      try {
        String sysId = o.optString("system"); boolean keepZip = sysId.equals("arcade") || sysId.equals("neogeo") || sysId.equals("fbneo") || sysId.equals("mame"); // arcade sets are loaded as the zip itself
        String rom = keepZip ? file : unpack(file);
        Intent p = new Intent(ctx, PlayerActivity.class);
        p.putExtra("core", core).putExtra("rom", rom).putExtra("game", file).putExtra("system", o.optString("system")).putExtra("title", o.optString("title"));
        JSONObject pc = playerCfg();
        if (pc != null) { p.putExtra("raUser", pc.optString("raUser")).putExtra("raToken", pc.optString("raToken")).putExtra("raPass", pc.optString("raPass")).putExtra("hardcore", pc.optBoolean("hardcore")).putExtra("achStyle", pc.optString("achStyle", "pill")).putExtra("achSize", pc.optString("achSize", "2")).putExtra("gameInt", pc.optBoolean("gameInt")).putExtra("gameAspect", pc.optString("gameAspect", "core")).putExtra("gameSmooth", pc.optBoolean("gameSmooth")).putExtra("visual", pc.optString("visual", "off")).putExtra("profDir", pc.optString("profDir", "")); }
        p.putExtra("console", raConsole(o.optString("system")));
        p.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        android.util.Log.i("CactiLaunch", "built-in player core=" + core + " rom=" + rom); launching = true; ctx.startActivity(p); r.put("ok", true); return r;
      } catch (Exception e) { android.util.Log.w("CactiLaunch", "built-in failed " + e); r.put("ok", false); r.put("error", "Could not start the game: " + e.getMessage()); return r; }
    }
    if (pkg == null) { r.put("ok", false); r.put("error", "RetroArch is not installed. Menu > System Check can install it."); return r; }
    Intent i = new Intent(Intent.ACTION_MAIN);
    i.setComponent(new ComponentName(pkg, "com.retroarch.browser.retroactivity.RetroActivityFuture"));
    String romArg = file;
    try { file = unpack(file); } catch (Exception e) { android.util.Log.w("CactiLaunch", "unpack failed " + e); r.put("ok", false); r.put("error", "Could not unpack " + new java.io.File(file).getName() + ": " + e.getMessage()); return r; }
    if (pkg.equals("com.retroarch")) { try {
      android.net.Uri u = android.provider.DocumentsContract.buildDocumentUri("com.cactios.app.docs", file);
      ctx.grantUriPermission(pkg, u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
      i.setData(u); i.setClipData(android.content.ClipData.newRawUri("rom", u));
      i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
      romArg = u.toString(); android.util.Log.i("CactiLaunch", "uri handoff " + romArg);
    } catch (Exception e) { android.util.Log.w("CactiLaunch", "uri handoff failed " + e); } }
    i.putExtra("ROM", romArg);
    i.putExtra("LIBRETRO", "/data/data/" + pkg + "/cores/" + core + "_android.so");
    i.putExtra("CONFIGFILE", "/storage/emulated/0/Android/data/" + pkg + "/files/retroarch.cfg");
    i.putExtra("IME", "com.android.inputmethod.latin/.LatinIME");
    i.putExtra("DATADIR", "/data/data/" + pkg);
    i.putExtra("SDCARD", "/storage/emulated/0");
    i.putExtra("DOWNLOADS", "/storage/emulated/0/Download");
    i.putExtra("SCREENSHOTS", "/storage/emulated/0/Pictures");
    i.putExtra("QUITFOCUS", "");
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    android.util.Log.i("CactiLaunch", "starting " + pkg + " core=" + core); launching = true; ctx.startActivity(i); r.put("ok", true); return r;
  }

  private String http(String url) throws IOException {
    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection(); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestProperty("User-Agent", "CactiOS");
    try (InputStream in = c.getInputStream(); ByteArrayOutputStream b = new ByteArrayOutputStream()) { byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) b.write(buf, 0, n); return b.toString("UTF-8"); }
  }

  private JSONObject installRetroArch() throws Exception {
    JSONObject r = new JSONObject();
    String abi = Build.SUPPORTED_ABIS[0], tok = abi.startsWith("arm64") ? "aarch64" : abi.startsWith("armeabi") ? "ra32" : "x86_64";
    emit("emu-progress", "{\"id\":\"retroarch\",\"msg\":\"Finding the latest RetroArch…\"}");
    String base = "https://buildbot.libretro.com/stable/", idx = http(base);
    Matcher m = Pattern.compile("/stable/(\\d+\\.\\d+\\.\\d+)/").matcher(idx); String best = null;
    while (m.find()) { String v = m.group(1); if (best == null || cmpVer(v, best) > 0) best = v; }
    if (best == null) throw new IOException("Could not read the RetroArch download list.");
    String dir = base + best + "/android/", list = http(dir); String apk = null;
    Matcher a = Pattern.compile("href=\"([^\"]*\\.apk)\"").matcher(list);
    String uni = null; while (a.find()) { String f = a.group(1), lf = f.toLowerCase(); if (lf.contains("plus")) continue; if (lf.endsWith("/retroarch.apk")) uni = f; else if (lf.contains(tok.toLowerCase())) { apk = f; break; } }
    if (apk == null && tok.equals("x86_64")) apk = uni;
    if (apk == null) throw new IOException("No RetroArch download for this device (" + abi + ").");
    String url = apk.startsWith("http") ? apk : dir + apk.substring(apk.lastIndexOf('/') + 1);
    emit("emu-progress", "{\"id\":\"retroarch\",\"msg\":\"Downloading RetroArch " + best + "…\"}");
    File out = new File(ctx.getCacheDir(), "RetroArch.apk");
    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection(); c.setConnectTimeout(15000); c.setReadTimeout(60000);
    try (InputStream in = c.getInputStream(); FileOutputStream fo = new FileOutputStream(out)) { byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) fo.write(buf, 0, n); }
    PackageInstaller pi = ctx.getPackageManager().getPackageInstaller();
    int sid = pi.createSession(new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL));
    try (PackageInstaller.Session s = pi.openSession(sid)) {
      try (InputStream in = new FileInputStream(out); OutputStream os = s.openWrite("RetroArch", 0, out.length())) { byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) os.write(buf, 0, n); s.fsync(os); }
      Intent it = new Intent("com.cactios.app.INSTALL_RESULT").setPackage(ctx.getPackageName());
      PendingIntent pe = PendingIntent.getBroadcast(ctx, sid, it, PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
      s.commit(pe.getIntentSender());
    }
    r.put("opened", false); r.put("installed", true); r.put("note", "Android asks you to confirm the install."); return r;
  }

  /** Installs the signed update APK that the engine downloaded into the app's own cache folder. */
  private JSONObject installApk(String path) throws Exception {
    JSONObject r = new JSONObject();
    File f = new File(path), cache = ctx.getCacheDir(), tmp = ctx.getExternalCacheDir();
    String cp = f.getCanonicalPath();
    if (!f.isFile() || !(cp.startsWith(cache.getCanonicalPath() + "/") || (tmp != null && cp.startsWith(tmp.getCanonicalPath() + "/")))) throw new IOException("That update file is not where it should be.");
    if (Build.VERSION.SDK_INT >= 26 && !ctx.getPackageManager().canRequestPackageInstalls()) {
      Intent si = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, android.net.Uri.parse("package:" + ctx.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      ctx.startActivity(si); r.put("needPermission", true); return r;
    }
    PackageInstaller pi = ctx.getPackageManager().getPackageInstaller();
    int sid = pi.createSession(new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL));
    try (PackageInstaller.Session s = pi.openSession(sid)) {
      try (InputStream in = new FileInputStream(f); OutputStream os = s.openWrite("CactiOS", 0, f.length())) { byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) os.write(buf, 0, n); s.fsync(os); }
      Intent it = new Intent("com.cactios.app.INSTALL_RESULT").setPackage(ctx.getPackageName());
      PendingIntent pe = PendingIntent.getBroadcast(ctx, sid, it, PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
      s.commit(pe.getIntentSender());
    }
    r.put("installing", true); return r;
  }

  private static int cmpVer(String a, String b) { String[] x = a.split("\\."), y = b.split("\\."); for (int i = 0; i < 3; i++) { int d = Integer.parseInt(x[i]) - Integer.parseInt(y[i]); if (d != 0) return d; } return 0; }

  @JavascriptInterface public String invoke(String ch, String argsJson) {
    Log.i("CactiBridge", "invoke " + ch);
    try {
      JSONObject out = new JSONObject();
      switch (ch) {
        case "cfg:get": out.put("v", config()); break;
        case "cfg:set": {
          JSONArray a = new JSONArray(argsJson); JSONObject cur = new JSONObject(prefs.getString("cfg", "{}"));
          JSONObject patch = a.optJSONObject(0); if (patch != null) { java.util.Iterator<String> it = patch.keys(); while (it.hasNext()) { String k = it.next(); cur.put(k, patch.get(k)); } }
          prefs.edit().putString("cfg", cur.toString()).apply(); out.put("v", config()); break;
        }
        case "sys:get": out.put("v", lib.sysMeta()); break;
        case "scan": out.put("v", lib.scan(romRoot())); break;
        case "check": {
          JSONObject v = new JSONObject(); String rr = romRoot(); String rp = raPkg(); JSONObject ra = new JSONObject(); ra.put("ok", rp != null); ra.put("path", rp == null ? "" : rp);
          v.put("mac", false); v.put("retroarch", ra); v.put("coresDir", ""); v.put("coresDirOk", false); v.put("romRoot", rr); v.put("romRootOk", new java.io.File(rr).isDirectory()); v.put("brew", false); v.put("flatpak", false); v.put("win", false); v.put("android", true);
          JSONObject rk = new JSONObject(); rk.put("user", false); rk.put("key", false); rk.put("pass", false); v.put("ra", rk);
          JSONArray scan = lib.scan(rr), systems = new JSONArray(), standalone = new JSONArray();
          for (Library.Sys s : lib.all) {
            int n = 0; for (int i = 0; i < scan.length(); i++) if (scan.getJSONObject(i).getString("id").equals(s.id)) n = scan.getJSONObject(i).getJSONArray("games").length();
            JSONObject o = new JSONObject(); o.put("id", s.id); o.put("name", s.name); o.put("folders", android.text.TextUtils.join(" or ", s.folders)); o.put("count", n);
            if (s.standalone) { o.put("emu", s.emu); standalone.put(o); } else { String core = s.cores != null && s.cores.length() > 0 ? s.cores.getJSONObject(0).optString("name") : ""; o.put("core", core); o.put("ra", true); o.put("coreOk", false); systems.put(o); }
          }
          v.put("systems", systems); v.put("standalone", standalone); v.put("bios", new JSONArray()); out.put("v", v); break;
        }
        case "wifi": {
          android.net.ConnectivityManager cm = (android.net.ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
          android.net.NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
          boolean w = nc != null && nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI), e = nc != null && nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET), any = nc != null;
          JSONObject v = new JSONObject(); v.put("supported", true); v.put("power", true); v.put("connected", any); v.put("ssid", w ? "Wi-Fi" : ""); v.put("wired", e); v.put("wiredIf", e ? "Ethernet" : ""); v.put("ip", any ? "1" : ""); out.put("v", v); break; }
        case "settings": { String w = new JSONArray(argsJson).optString(0);
          String act = w.equals("bt") ? android.provider.Settings.ACTION_BLUETOOTH_SETTINGS : w.equals("display") ? android.provider.Settings.ACTION_DISPLAY_SETTINGS : w.equals("storage") ? android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION : android.provider.Settings.ACTION_WIFI_SETTINGS;
          Intent si = new Intent(act); si.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(si); out.put("v", true); break; }
        case "storage": { out.put("v", Build.VERSION.SDK_INT < 30 || android.os.Environment.isExternalStorageManager()); break; }
        case "retroarch:open": { String pk = raPkg(); if (pk == null) { out.put("v", false); break; } Intent li = ctx.getPackageManager().getLaunchIntentForPackage(pk); li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(li); out.put("v", true); break; }
        case "launch": { JSONArray a = new JSONArray(argsJson); out.put("v", launchGame(a.getJSONObject(0))); break; }
        case "retroarch:install": out.put("v", installRetroArch()); break;
        case "dolphin:install": out.put("v", installDolphin()); break;
        case "dolphin:status": out.put("v", dolphinPkg() != null); break;
        case "apk:install": out.put("v", installApk(new JSONArray(argsJson).getString(0))); break;
        default: out.put("v", JSONObject.NULL);
      }
      return out.toString();
    } catch (Exception e) { return "{\"err\":\"" + String.valueOf(e.getMessage()).replace("\"", "'") + "\"}"; }
  }

  @JavascriptInterface public void send(String ch, String argsJson) { Log.i("CactiBridge", "send " + ch); }

  /** Archives (zip/7z) are unpacked to the app cache; the largest entry is the game. */
  String unpack(String path) throws Exception {
    String low = path.toLowerCase();
    if (!low.endsWith(".zip") && !low.endsWith(".7z")) return path;
    java.io.File dir = new java.io.File(ctx.getCacheDir(), "rom");
    java.io.File[] old = dir.listFiles(); if (old != null) for (java.io.File f : old) f.delete();
    dir.mkdirs();
    java.io.File src = new java.io.File(path);
    if (low.endsWith(".zip")) {
      try (java.util.zip.ZipFile z = new java.util.zip.ZipFile(src)) {
        java.util.zip.ZipEntry best = null;
        for (java.util.Enumeration<? extends java.util.zip.ZipEntry> en = z.entries(); en.hasMoreElements();) { java.util.zip.ZipEntry e = en.nextElement(); if (!e.isDirectory() && (best == null || e.getSize() > best.getSize())) best = e; }
        if (best == null) throw new Exception("archive is empty");
        java.io.File out = new java.io.File(dir, new java.io.File(best.getName()).getName());
        try (java.io.InputStream in = z.getInputStream(best); java.io.FileOutputStream os = new java.io.FileOutputStream(out)) { byte[] b = new byte[1 << 16]; int n; while ((n = in.read(b)) > 0) os.write(b, 0, n); }
        return out.getPath();
      }
    }
    try (org.apache.commons.compress.archivers.sevenz.SevenZFile z = new org.apache.commons.compress.archivers.sevenz.SevenZFile(src)) {
      org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry best = null;
      for (org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e : z.getEntries()) if (!e.isDirectory() && (best == null || e.getSize() > best.getSize())) best = e;
      if (best == null) throw new Exception("archive is empty");
      java.io.File out = new java.io.File(dir, new java.io.File(best.getName()).getName());
      try (java.io.InputStream in = z.getInputStream(best); java.io.FileOutputStream os = new java.io.FileOutputStream(out)) { byte[] b = new byte[1 << 16]; int n; while ((n = in.read(b)) > 0) os.write(b, 0, n); }
      return out.getPath();
    }
  }

  static int raConsole(String sys) {
    switch (sys) { case "megadrive": case "genesis": return 1; case "snes": case "sfc": return 3; case "gb": return 4; case "gba": return 5; case "gbc": return 6; case "nes": case "fds": return 7; case "pcengine": return 8; case "mastersystem": return 11; case "gamegear": return 15; case "n64": return 2; case "segacd": return 9; case "sega32x": return 10; case "psx": return 12; case "lynx": return 13; case "ngp": return 14; case "jaguar": return 17; case "nds": return 18; case "atari2600": return 25; case "arcade": return 27; case "virtualboy": return 28; case "msx": return 29; case "sg1000": return 33; case "saturn": return 39; case "dreamcast": return 40; case "psp": return 41; case "3do": return 43; case "colecovision": return 44; case "intellivision": return 45; case "vectrex": return 46; case "atari7800": return 51; case "wonderswan": return 53; default: return 0; }
  }
  /** Asks the embedded server for the player settings (the sign-in token is encrypted in the config file, so the server decrypts it). */
  JSONObject playerCfg() {
    try {
      java.io.File tf = new java.io.File(ctx.getFilesDir(), "data/token"); String tok = new String(java.nio.file.Files.readAllBytes(tf.toPath()), "UTF-8").trim();
      java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL("http://localhost:8420/api/player%3Acfg?t=" + tok).openConnection();
      c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json"); c.setConnectTimeout(3000); c.setReadTimeout(5000);
      try (java.io.OutputStream os = c.getOutputStream()) { os.write("[]".getBytes("UTF-8")); }
      java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); try (java.io.InputStream in = c.getInputStream()) { byte[] b = new byte[4096]; int n; while ((n = in.read(b)) > 0) bo.write(b, 0, n); }
      return new JSONObject(bo.toString("UTF-8")).optJSONObject("v");
    } catch (Exception e) { android.util.Log.w("CactiLaunch", "player cfg: " + e); return null; }
  }
}
