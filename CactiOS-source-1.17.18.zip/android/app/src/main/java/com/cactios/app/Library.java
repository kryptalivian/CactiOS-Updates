package com.cactios.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.InputStream;
import java.text.Collator;
import java.util.*;

/** Finds games in the ROMs folder. A port of the desktop app's scanner: same systems, folder names and file types (systems.json). */
public class Library {
  static class Sys { String id, name, tab, desc; Set<String> folders = new HashSet<>(), ext = new HashSet<>(); JSONArray cores; boolean standalone; String emu; }
  final List<Sys> all = new ArrayList<>();
  final Map<String, Sys> byId = new HashMap<>();
  final Map<String, String> uniq = new HashMap<>();
  final Map<String, List<String>> alias = new HashMap<>();
  JSONArray systemsRaw;

  Library(Context c) {
    try {
      InputStream in = c.getAssets().open("systems.json"); byte[] b = new byte[in.available()]; in.read(b); in.close();
      JSONObject d = new JSONObject(new String(b, "UTF-8"));
      systemsRaw = d.getJSONArray("systems");
      add(d.getJSONArray("systems"), false); add(d.getJSONArray("x"), true);
      JSONObject u = d.getJSONObject("uniq"); for (Iterator<String> it = u.keys(); it.hasNext();) { String k = it.next(); uniq.put(k, u.getString(k)); }
      JSONObject a = d.getJSONObject("alias");
      for (Iterator<String> it = a.keys(); it.hasNext();) { String k = it.next(); JSONArray l = a.getJSONArray(k); List<String> v = new ArrayList<>(); for (int i = 0; i < l.length(); i++) v.add(l.getString(i)); alias.put(k, v); }
    } catch (Exception e) { android.util.Log.e("CactiLib", "systems.json: " + e); }
  }

  private void add(JSONArray arr, boolean standalone) throws Exception {
    for (int i = 0; i < arr.length(); i++) {
      JSONObject o = arr.getJSONObject(i); Sys s = new Sys();
      s.id = o.getString("id"); s.name = o.getString("name"); s.tab = o.optString("tab", s.name); s.desc = o.optString("desc", "");
      JSONArray f = o.optJSONArray("folder"), x = o.optJSONArray("ext");
      for (int j = 0; f != null && j < f.length(); j++) s.folders.add(f.getString(j));
      for (int j = 0; x != null && j < x.length(); j++) s.ext.add(x.getString(j).toLowerCase());
      s.cores = o.optJSONArray("cores"); s.standalone = standalone; s.emu = o.optString("emu", "");
      all.add(s); byId.put(s.id, s);
    }
  }

  private String dirSystem(String name) {
    String k = name.toLowerCase().replaceAll("[^a-z0-9]", "");
    for (Map.Entry<String, List<String>> e : alias.entrySet()) if (e.getValue().contains(k)) return e.getKey();
    return null;
  }

  static String clean(String file) {
    String n = file; int dot = n.lastIndexOf('.'); if (dot > 0) n = n.substring(0, dot);
    return n.replace('_', ' ').replaceAll("\\s*[\\(\\[][^\\)\\]]*[\\)\\]]", "").replaceAll("\\s+", " ").trim();
  }

  private void walk(File dir, int depth, String hint, Map<String, List<File>> by, Set<String> seen) {
    File[] es = dir.listFiles(); if (es == null) return;
    for (File e : es) {
      String n = e.getName();
      if (n.startsWith(".") || n.equals("images") || n.equals("media") || n.equals("boxart") || n.equals("cores")) continue;
      if (e.isDirectory()) { if (depth < 4) { String h = dirSystem(n); walk(e, depth + 1, h != null ? h : hint, by, seen); } continue; }
      if (!e.isFile() || !seen.add(e.getPath())) continue;
      int dot = n.lastIndexOf('.'); String ext = dot >= 0 ? n.substring(dot).toLowerCase() : "";
      Sys hs = hint != null ? byId.get(hint) : null;
      String id = hs != null && hs.ext.contains(ext) ? hint : uniq.get(ext);
      if (id == null) continue;
      List<File> l = by.get(id); if (l == null) { l = new ArrayList<>(); by.put(id, l); } l.add(e);
    }
  }

  JSONArray scan(String root) {
    JSONArray out = new JSONArray();
    if (root == null || root.isEmpty()) return out;
    File r = new File(root); if (!r.isDirectory()) return out;
    Map<String, List<File>> by = new HashMap<>(); walk(r, 0, null, by, new HashSet<String>());
    Collator coll = Collator.getInstance();
    try {
      for (Sys s : all) {
        List<File> files = by.get(s.id); if (files == null || files.isEmpty()) continue;
        final List<String[]> games = new ArrayList<>();
        for (File f : files) games.add(new String[] { clean(f.getName()), f.getPath() });
        Collections.sort(games, (a, b) -> coll.compare(a[0], b[0]));
        JSONArray g = new JSONArray();
        for (String[] x : games) { JSONObject o = new JSONObject(); o.put("title", x[0]); o.put("file", x[1]); o.put("sys", s.id); o.put("art", JSONObject.NULL); o.put("shot", false); o.put("stats", JSONObject.NULL); o.put("meta", JSONObject.NULL); g.put(o); }
        JSONObject sys = new JSONObject(); sys.put("id", s.id); sys.put("name", s.name); sys.put("tab", s.tab); sys.put("desc", s.desc); sys.put("games", g);
        if (s.standalone) sys.put("ra", false);
        out.put(sys);
      }
    } catch (Exception e) { android.util.Log.e("CactiLib", "scan: " + e); }
    return out;
  }

  JSONArray sysMeta() {
    JSONArray out = new JSONArray();
    try {
      for (int i = 0; i < systemsRaw.length(); i++) {
        JSONObject s = systemsRaw.getJSONObject(i); JSONArray cores = s.optJSONArray("cores");
        JSONObject o = new JSONObject(); o.put("id", s.getString("id")); o.put("name", s.getString("name")); o.put("cores", cores == null ? new JSONArray() : cores);
        o.put("choice", cores != null && cores.length() > 0 ? cores.getJSONObject(0).getString("id") : ""); out.put(o);
      }
    } catch (Exception e) {}
    return out;
  }

  /** Puts a few empty demo files in the ROMs folder the first time, so the library has something to show while the app is being built. */
  static void seedDemo(File root) {
    if (root.exists()) return;
    String[][] demo = { { "snes", "Super Metroid (USA).sfc" }, { "snes", "Chrono Trigger (USA).sfc" }, { "snes", "Mega Man X (USA).sfc" }, { "genesis", "Sonic the Hedgehog 3 (USA).md" }, { "genesis", "Streets of Rage 2 (USA).md" },
      { "gba", "Metroid Fusion (USA).gba" }, { "gba", "Zelda - The Minish Cap (USA).gba" }, { "nes", "Contra (USA).nes" }, { "gbc", "Pokemon Crystal (USA).gbc" } };
    for (String[] d : demo) { File dir = new File(root, d[0]); dir.mkdirs(); try { new File(dir, d[1]).createNewFile(); } catch (Exception e) {} }
  }
}
