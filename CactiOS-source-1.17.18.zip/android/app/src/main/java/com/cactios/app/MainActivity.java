package com.cactios.app;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInstaller;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Log;

public class MainActivity extends Activity {
  @Override protected void attachBaseContext(Context b) {
    // draw the app as if the screen were 720 pixels tall (the size it was designed for)
    android.util.DisplayMetrics dm = b.getResources().getDisplayMetrics();
    int shortSide = Math.min(dm.widthPixels, dm.heightPixels);
    android.content.res.Configuration c = new android.content.res.Configuration(b.getResources().getConfiguration());
    c.densityDpi = Math.max(120, Math.round(shortSide * 160f / 720f));
    super.attachBaseContext(b.createConfigurationContext(c));
  }

  private WebView web;
  private Bridge bridge;
  private BroadcastReceiver installReceiver;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    web = new WebView(this);
    setContentView(web); web.setFocusable(true); web.setFocusableInTouchMode(true); web.requestFocus();
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowFileAccessFromFileURLs(true);
    s.setAllowUniversalAccessFromFileURLs(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    s.setUseWideViewPort(true); s.setLoadWithOverviewMode(false); s.setSupportZoom(false); s.setBuiltInZoomControls(false); s.setTextZoom(100);
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onConsoleMessage(ConsoleMessage m) {
        Log.i("CactiJS", m.messageLevel() + " " + m.sourceId() + ":" + m.lineNumber() + " " + m.message());
        return true;
      }
    });
    bridge = new Bridge(this, web);
    web.addJavascriptInterface(bridge, "AndroidBridge");
    installReceiver = new BroadcastReceiver() {
      @Override public void onReceive(Context c, Intent i) {
        int st = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
        if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) { Intent a = (Intent) i.getParcelableExtra(Intent.EXTRA_INTENT); if (a != null) { a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(a); } }
        else Log.i("CactiInstall", "status " + st + " " + i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE));
      }
    };
    IntentFilter f = new IntentFilter("com.cactios.app.INSTALL_RESULT");
    if (Build.VERSION.SDK_INT >= 33) registerReceiver(installReceiver, f, Context.RECEIVER_NOT_EXPORTED); else registerReceiver(installReceiver, f);
    web.setBackgroundColor(0xFF10142A);
    if (Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager() && !getSharedPreferences("cacti", MODE_PRIVATE).getBoolean("askedStorage", false)) {
      getSharedPreferences("cacti", MODE_PRIVATE).edit().putBoolean("askedStorage", true).apply();
      try { Intent si = new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, android.net.Uri.parse("package:" + getPackageName())); startActivity(si); } catch (Exception e) { startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
    }
    web.loadDataWithBaseURL(null, "<body style='margin:0;background:#10142a;color:#cfd6ff;font:28px sans-serif;display:flex;align-items:center;justify-content:center;height:100vh'>Starting Cacti OS…</body>", "text/html", "utf-8", null);
    String ver = "1"; try { ver = String.valueOf(getPackageManager().getPackageInfo(getPackageName(), 0).lastUpdateTime); } catch (Exception e) {}
    NodeHost.begin(this, ver);
    new Thread(() -> {
      while (NodeHost.url == null && NodeHost.error == null) { try { Thread.sleep(250); } catch (Exception e) {} }
      final String u = NodeHost.url, er = NodeHost.error;
      runOnUiThread(() -> { if (u != null) web.loadUrl(u); else web.loadDataWithBaseURL(null, "<body style='margin:0;background:#10142a;color:#ffb4b4;font:26px sans-serif;padding:40px'>" + er + "</body>", "text/html", "utf-8", null); });
    }).start();
    hideBars();
  }

  private void hideBars() {
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    if (Build.VERSION.SDK_INT >= 28) { android.view.WindowManager.LayoutParams lp = getWindow().getAttributes(); lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES; getWindow().setAttributes(lp); }
  }

  @Override protected void onActivityResult(int req, int res, Intent data) { super.onActivityResult(req, res, data); if (req == 4242 && bridge != null) bridge.onPicked(res == RESULT_OK && data != null ? data.getData() : null); }

  @Override protected void onResume() { super.onResume(); if (web != null) web.requestFocus(); if (bridge != null && bridge.launching) { bridge.launching = false; bridge.emit("game-exit", "{}"); } }

  @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) { hideBars(); if (web != null) web.requestFocus(); } }

  @Override public void onBackPressed() { web.evaluateJavascript("['keydown','keyup'].forEach(t=>document.dispatchEvent(new KeyboardEvent(t,{key:'Escape',code:'Escape',keyCode:27,bubbles:true})))", null); }
}
