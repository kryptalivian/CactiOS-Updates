package com.cactios.app;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

/** Runs the Cacti OS server (Node.js) inside the app. */
final class NodeHost {
  static { System.loadLibrary("c++_shared"); System.loadLibrary("node"); System.loadLibrary("nodehost"); }
  static native int start(String[] args, String[] env);

  static String url = null; static volatile String error = null; private static boolean started;
  static final int PORT = 8420;

  static synchronized void begin(final Context c, final String version) {
    if (started) return; started = true;
    new Thread(() -> {
      try {
        File root = new File(c.getFilesDir(), "nodeapp"), stamp = new File(c.getFilesDir(), "nodeapp.stamp");
        String have = ""; try { have = new String(java.nio.file.Files.readAllBytes(stamp.toPath())); } catch (Exception e) {}
        if (!have.equals(version) || !new File(root, "server.js").exists()) { del(root); copy(c.getAssets(), "nodeapp", root); try (FileWriter w = new FileWriter(stamp)) { w.write(version); } }
        File data = new File(c.getFilesDir(), "data"); data.mkdirs();
        File home = c.getExternalFilesDir(null); if (home == null) home = new File(c.getFilesDir(), "home"); home.mkdirs();
        long vc = 0; String vn = ""; try { android.content.pm.PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0); vc = pi.getLongVersionCode(); vn = pi.versionName; } catch (Exception e) {}
        final String[] env = { "APP_VERCODE", String.valueOf(vc), "APP_VERNAME", vn, "HOME", home.getPath(), "RETROOS_DATA", data.getPath(), "NO_OPEN", "1", "TMPDIR", c.getCacheDir().getPath(), "PORT", String.valueOf(PORT) };
        final String[] args = { "node", new File(root, "android-server.js").getPath() };
        Thread t = new Thread(null, () -> { int r = start(args, env); Log.e("CactiNode", "node exited " + r); error = "The Cacti OS engine stopped (" + r + ")."; }, "node", 8 * 1024 * 1024);
        t.start();
        // wait for the token file and the server
        String tok = null; long end = System.currentTimeMillis() + 60000;
        while (System.currentTimeMillis() < end && error == null) {
          try { tok = new String(java.nio.file.Files.readAllBytes(new File(data, "token").toPath())).trim(); } catch (Exception e) { tok = null; }
          if (tok != null && tok.length() >= 16) {
            try { HttpURLConnection h = (HttpURLConnection) new URL("http://localhost:" + PORT + "/?t=" + tok).openConnection(); h.setConnectTimeout(800); if (h.getResponseCode() == 200) { url = "http://localhost:" + PORT + "/?t=" + tok; return; } } catch (Exception e) {}
          }
          Thread.sleep(300);
        }
        if (error == null) error = "The Cacti OS engine did not start in time.";
      } catch (Throwable e) { Log.e("CactiNode", "start failed", e); error = String.valueOf(e); }
    }, "node-boot").start();
  }

  private static void del(File f) { File[] k = f.listFiles(); if (k != null) for (File x : k) del(x); f.delete(); }
  private static void copy(AssetManager am, String from, File to) throws IOException {
    String[] kids = am.list(from);
    if (kids != null && kids.length > 0) { to.mkdirs(); for (String k : kids) copy(am, from + "/" + k, new File(to, k)); return; }
    to.getParentFile().mkdirs();
    try (InputStream in = am.open(from); OutputStream out = new FileOutputStream(to)) { byte[] b = new byte[65536]; int n; while ((n = in.read(b)) > 0) out.write(b, 0, n); }
  }
}
