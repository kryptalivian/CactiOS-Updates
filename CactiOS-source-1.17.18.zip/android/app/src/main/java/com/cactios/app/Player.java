package com.cactios.app;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

/** Thin Java face of the native libretro player (runs in the :player process). */
public final class Player {
  public interface Listener { void onStatus(String s); }
  static volatile Listener listener;
  static AudioTrack track;
  static { System.loadLibrary("c++_shared"); System.loadLibrary("cactiplayer"); }

  static native void nStart(String core, String rom, String sysDir, String saveDir, String saveBase, String stateBase, String raUser, String raToken, String raPass, boolean hard, int console);
  static native String nAchList();
  static native void nHttpDone(long ticket, int status, String body);
  static native void nGlOpts(int integer, int aspect, boolean smooth);
  static native void nStop();
  static native void nPause(boolean p);
  static native void nInput(int mask);
  static native void nOp(int op, String path);
  static native void nGlInit();
  static native void nGlSize(int w, int h);
  static native void nGlDraw();

  static final java.util.concurrent.ExecutorService NET = java.util.concurrent.Executors.newFixedThreadPool(3);
  static volatile String ua = "CactiOS/1.12.8 (Android) rcheevos/11.6";
  /** Server call for the achievements library; runs off the emulation thread. */
  static void http(long ticket, String url, String post, String ctype) {
    NET.execute(() -> {
      int status = -2; String body = "";
      try {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setRequestProperty("User-Agent", ua);
        if (post != null) { c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type", ctype != null ? ctype : "application/x-www-form-urlencoded"); byte[] b = post.getBytes("UTF-8"); c.setFixedLengthStreamingMode(b.length); try (java.io.OutputStream o = c.getOutputStream()) { o.write(b); } }
        status = c.getResponseCode();
        java.io.InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
        if (in != null) { try (java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream()) { byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) bo.write(buf, 0, n); body = bo.toString("UTF-8"); } }
      } catch (Exception e) { status = -2; body = String.valueOf(e); }
      nHttpDone(ticket, status, body);
    });
  }

  // called from the emulation thread
  static void onAv(int rate) {
    int min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
    track = new AudioTrack.Builder()
      .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
      .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
      .setBufferSizeInBytes(Math.max(min, rate / 10 * 4)).setTransferMode(AudioTrack.MODE_STREAM).build();
    track.play();
  }
  static void audio(short[] d, int n) { AudioTrack t = track; if (t != null) t.write(d, 0, n); }
  static void onStatus(String s) { Listener l = listener; if (l != null) l.onStatus(s); }
  static void pauseAudio(boolean p) { AudioTrack t = track; if (t == null) return; try { if (p) t.pause(); else t.play(); } catch (Exception e) {} }
  static void releaseAudio() { AudioTrack t = track; track = null; if (t != null) try { t.stop(); t.release(); } catch (Exception e) {} }
}
