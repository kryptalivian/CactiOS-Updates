package com.cactios.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import java.io.File;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayDeque;

public class PlayerActivity extends Activity implements Player.Listener {
  GLSurfaceView gl; TouchPad pad; FrameLayout rootView; String achStyle = "pill"; float achScale = 0.6f; final ArrayDeque<String[]> pills = new ArrayDeque<>(); boolean pillBusy = false; String baseName, stateDir; boolean menuOpen = false, started = false;
  int padKeys = 0; float axX = 0, axY = 0; boolean padPinned = false, lastWasPad = false;
  final Handler ui = new Handler(Looper.getMainLooper());

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    gameName = String.valueOf(getIntent().getStringExtra("game")); if (gameName.equals("null")) gameName = ""; String core = getIntent().getStringExtra("core"), rom = getIntent().getStringExtra("rom"), game = getIntent().getStringExtra("game"), system = getIntent().getStringExtra("system");
    if (system == null) system = "";
    File ext = getExternalFilesDir(null), root = ext; String pd = String.valueOf(getIntent().getStringExtra("profDir")); if (pd != null && pd.matches("(profiles/[A-Za-z0-9][A-Za-z0-9 _.\\-]{0,31}|guest-session)") && !pd.contains("..")) root = new File(root, pd); File saves = new File(root, "saves/" + system), states = new File(root, "states/" + system), sys = new File(ext, "system");
    saves.mkdirs(); states.mkdirs(); sys.mkdirs();
    baseName = new File(game != null ? game : rom).getName().replaceAll("\\.[^.]+$", ""); stateDir = states.getPath();
    gl = new GLSurfaceView(this); gl.setEGLContextClientVersion(2); gl.setPreserveEGLContextOnPause(true);
    gl.setRenderer(new GLSurfaceView.Renderer() {
      public void onSurfaceCreated(GL10 g, EGLConfig c) { Player.nGlInit(); }
      public void onSurfaceChanged(GL10 g, int w, int h) { Player.nGlSize(w, h); }
      public void onDrawFrame(GL10 g) { Player.nGlDraw(); }
    });
    pad = new TouchPad(this, system); pad.menu = this::openMenu;
    padPinned = getSharedPreferences("player", 0).getBoolean("padPinned", false); pad.setAlpha(0f); pad.onTouch = () -> { lastWasPad = false; showPad(true); };
    FrameLayout f = new FrameLayout(this); f.setBackgroundColor(0xFF000000); f.addView(gl); f.addView(pad); rootView = f; setContentView(f);
    achStyle = String.valueOf(getIntent().getStringExtra("achStyle")); if (achStyle.equals("null")) achStyle = "pill"; { String z = String.valueOf(getIntent().getStringExtra("achSize")); achScale = z.equals("1") ? 0.4f : z.equals("3") ? 0.8f : 0.6f; } // Small / Medium / Large popup size
    int am = 0; String ga = String.valueOf(getIntent().getStringExtra("gameAspect")); if (ga.equals("4:3")) am = 1; else if (ga.equals("16:9")) am = 2; else if (ga.equals("square")) am = 3;
    boolean gi = getIntent().getBooleanExtra("gameInt", false), gs = getIntent().getBooleanExtra("gameSmooth", true);
    if ("original".equals(getIntent().getStringExtra("visual"))) { boolean hh = java.util.Arrays.asList("gb","gbc","gba","gamegear","lynx","ngp","wonderswan","virtualboy","psp").contains(system); am = hh ? 0 : 1; gi = hh; gs = false; }
    Player.nGlOpts(gi ? 1 : 0, am, gs);
    Player.listener = this;
    Player.nStart(getApplicationInfo().nativeLibraryDir + "/lib" + core + ".so", rom, sys.getPath(), saves.getPath(), new File(saves, baseName).getPath(), new File(states, baseName).getPath(), nz(getIntent().getStringExtra("raUser")), nz(getIntent().getStringExtra("raToken")), nz(getIntent().getStringExtra("raPass")), getIntent().getBooleanExtra("hardcore", false), getIntent().getIntExtra("console", 0));
    started = true;
    if (padPinned) showPad(false); else if (hasGamepad()) lastWasPad = true; else showPad(true);
  }
  // ---- on-screen controls: hidden by default, they fade in on touch and fade out again; the menu can pin them on ----
  final Runnable hidePad = new Runnable() { public void run() { if (padPinned) return; if (pad.mask != 0) { ui.postDelayed(this, 1500); return; } pad.animate().cancel(); pad.animate().alpha(0f).setDuration(350).start(); } };
  void showPad(boolean autoHide) { pad.animate().cancel(); pad.animate().alpha(0.8f).setDuration(150).start(); ui.removeCallbacks(hidePad); if (!padPinned && autoHide) ui.postDelayed(hidePad, 3000); }
  void hidePadNow() { if (padPinned) return; ui.removeCallbacks(hidePad); pad.animate().cancel(); pad.animate().alpha(0f).setDuration(200).start(); }
  boolean hasGamepad() { for (int id : InputDevice.getDeviceIds()) { InputDevice d = InputDevice.getDevice(id); if (d != null && (d.getSources() & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD) return true; } return false; }
  // Android will not let an app swallow a real Home press (it blocks relaunching from the background), so a Home press made with a controller pauses the game and shows the pause menu the moment you come back. The Xbox / Guide button (BUTTON_MODE) is caught directly and opens the menu at once.
  boolean menuOnReturn = false;
  @Override protected void onUserLeaveHint() { super.onUserLeaveHint(); if (lastWasPad && started && !menuOpen && !isFinishing()) menuOnReturn = true; }
  @Override protected void onNewIntent(android.content.Intent i) { super.onNewIntent(i); }

  static String nz(String s) { return s == null ? "" : s; }

  @Override public void onStatus(String s) {
    ui.post(() -> {
      if (s.startsWith("ACH\u001f") || s.startsWith("DONE\u001f") || s.startsWith("GAME\u001f") || s.startsWith("NOGAME\u001f")) { if (!achStyle.equals("off")) { pills.add(s.split("\u001f", -1)); showNextPill(); } return; }
      if (s.startsWith("ERR:")) { new AlertDialog.Builder(this).setMessage(s.substring(4)).setCancelable(false).setPositiveButton("OK", (d, w) -> quit()).show(); }
      else if (s.startsWith("MSG:")) Toast.makeText(this, s.substring(4), Toast.LENGTH_SHORT).show();
    });
  }

  String gameName = "";
  void showNextPill() {
    if (pillBusy || pills.isEmpty()) return; pillBusy = true; String[] f = pills.poll();
    float d = getResources().getDisplayMetrics().density * achScale; String title, sub, badge = null;
    if (f[0].equals("ACH")) { title = f[1]; sub = "Achievement unlocked \u00b7 " + f[3] + " pts" + (f[2].isEmpty() ? "" : "  \u2014  " + f[2]); badge = f.length > 4 ? f[4] : null; }
    else if (f[0].equals("DONE")) { title = "Game mastered"; sub = f[1] + " \u2014 every achievement earned"; }
    else if (f[0].equals("NOGAME")) { title = (gameName == null || gameName.isEmpty()) ? "RetroAchievements" : gameName; sub = "This ROM isn't recognised by RetroAchievements, so achievements are off for it. A different dump (No-Intro USA/Europe) may be needed."; }
    else { title = f[1]; sub = f[3].equals("0") ? "No achievements for this game" : (f[2] + " of " + f[3] + " achievements \u00b7 " + f[4] + " pts"); }
    LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
    GradientDrawable bg = new GradientDrawable(); bg.setColor(0xEE1B1830); bg.setCornerRadius(40 * d); bg.setStroke((int) (2 * d), 0xFF7C6CFF); row.setBackground(bg);
    row.setPadding((int) (10 * d), (int) (8 * d), (int) (22 * d), (int) (8 * d));
    ImageView iv = new ImageView(this); LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams((int) (48 * d), (int) (48 * d)); ip.rightMargin = (int) (12 * d);
    if (badge != null && !badge.isEmpty()) { row.addView(iv, ip); loadBadge(iv, badge); } else { TextView t = new TextView(this); t.setText("\uD83C\uDFC6"); t.setTextSize(26 * Math.max(achScale, 0.55f)); t.setPadding((int) (8 * d), 0, (int) (14 * d), 0); row.addView(t); }
    LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
    TextView a = new TextView(this); a.setText(title); a.setTextColor(Color.WHITE); a.setTextSize(16 * Math.max(achScale, 0.55f)); a.setTypeface(null, android.graphics.Typeface.BOLD); a.setSingleLine(true);
    TextView b = new TextView(this); b.setText(sub); b.setTextColor(0xFFC9C4F5); b.setTextSize(12 * Math.max(achScale, 0.55f)); b.setMaxLines(2); b.setMaxWidth((int) (420 * d));
    col.addView(a); col.addView(b); row.addView(col);
    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL); lp.topMargin = (int) (18 * d);
    row.setAlpha(0f); row.setTranslationY(-60 * d); rootView.addView(row, lp);
    row.animate().alpha(1f).translationY(0).setDuration(280).start();
    ui.postDelayed(() -> row.animate().alpha(0f).translationY(-60 * d).setDuration(300).withEndAction(() -> { rootView.removeView(row); pillBusy = false; showNextPill(); }).start(), f[0].equals("GAME") ? 3200 : 5000);
  }
  void loadBadge(ImageView iv, String url) {
    Player.NET.execute(() -> { try { java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection(); c.setRequestProperty("User-Agent", Player.ua); android.graphics.Bitmap bm = android.graphics.BitmapFactory.decodeStream(c.getInputStream()); ui.post(() -> iv.setImageBitmap(bm)); } catch (Exception e) {} });
  }


  interface Dir { void on(int d); }
  class NavDialog extends android.app.Dialog {
    Dir dir; Runnable ok, back; int lastDir = 0;
    NavDialog(android.content.Context c, int theme) { super(c, theme); }
    void move(int d) { if (dir != null) dir.on(d); }
    @Override public boolean dispatchKeyEvent(KeyEvent e) {
      int k = e.getKeyCode();
      if (e.getAction() == KeyEvent.ACTION_DOWN) {
        if (k == KeyEvent.KEYCODE_DPAD_UP) { move(-1); return true; }
        if (k == KeyEvent.KEYCODE_DPAD_DOWN) { move(1); return true; }
        if (k == KeyEvent.KEYCODE_BUTTON_A || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER) { if (e.getRepeatCount() == 0 && ok != null) ok.run(); return true; }
        if (k == KeyEvent.KEYCODE_BUTTON_B || k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_BUTTON_START || k == KeyEvent.KEYCODE_BUTTON_MODE || k == KeyEvent.KEYCODE_BUTTON_THUMBL || k == KeyEvent.KEYCODE_BUTTON_THUMBR) { if (e.getRepeatCount() == 0 && back != null) back.run(); return true; }
      } else if (e.getAction() == KeyEvent.ACTION_UP) {
        if (k == KeyEvent.KEYCODE_BUTTON_A || k == KeyEvent.KEYCODE_BUTTON_B || k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_BUTTON_START || k == KeyEvent.KEYCODE_BUTTON_MODE || k == KeyEvent.KEYCODE_BUTTON_THUMBL || k == KeyEvent.KEYCODE_BUTTON_THUMBR) return true;
      }
      return super.dispatchKeyEvent(e);
    }
    @Override public boolean dispatchGenericMotionEvent(MotionEvent e) {
      if ((e.getSource() & InputDevice.SOURCE_JOYSTICK) != 0 && e.getAction() == MotionEvent.ACTION_MOVE) {
        float y = e.getAxisValue(MotionEvent.AXIS_Y); float hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y); if (Math.abs(hy) > 0.5f) y = hy;
        int d = y < -0.6f ? -1 : y > 0.6f ? 1 : 0; if (d != 0 && d != lastDir) move(d); lastDir = d; return true;
      }
      return super.dispatchGenericMotionEvent(e);
    }
  }
  NavDialog sheet;
  void openMenu() {
    if (menuOpen) return; menuOpen = true; padKeys = 0; axX = 0; axY = 0; Player.nPause(true); Player.pauseAudio(true); Player.nInput(0);
    showSheet("Paused", new String[] { "Resume", "Achievements", "Save state", "Load state", "Reset", "On-screen controls: " + (padPinned ? "Always on" : "Auto-hide"), "Quit game" }, i -> {
      String sp = stateDir + "/" + baseName + ".state";
      if (i == 1) { showAchievements(); return; }
      resume();
      if (i == 2) Player.nOp(1, sp); else if (i == 3) Player.nOp(2, sp); else if (i == 4) Player.nOp(3, sp);
      else if (i == 5) { padPinned = !padPinned; getSharedPreferences("player", 0).edit().putBoolean("padPinned", padPinned).apply(); showPad(!padPinned); Toast.makeText(this, padPinned ? "On-screen controls stay visible" : "On-screen controls hide automatically", Toast.LENGTH_SHORT).show(); }
      else if (i == 6) quit();
    });
  }
  interface Pick { void on(int i); }
  void showSheet(String title, String[] items, Pick pick) {
    float d = getResources().getDisplayMetrics().density; final boolean small = getResources().getDisplayMetrics().heightPixels / d < 520; // phones in landscape: tighter rows and a scrollable sheet
    sheet = new NavDialog(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
    final android.widget.ScrollView sv = new android.widget.ScrollView(this); sv.setVerticalScrollBarEnabled(false);
    final NavDialog dlg = sheet; final TextView[] rows = new TextView[items.length]; final int[] sel = { 0 };
    LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setPadding((int) (22 * d), (int) ((small ? 10 : 18) * d), (int) (22 * d), (int) ((small ? 8 : 14) * d));
    GradientDrawable bg = new GradientDrawable(); bg.setColor(0xF2191630); bg.setCornerRadius(22 * d); bg.setStroke((int) (1.5f * d), 0x667C6CFF); col.setBackground(bg);
    TextView t = new TextView(this); t.setText(title); t.setTextColor(0xFFB9B1FF); t.setTextSize(13); t.setLetterSpacing(0.2f); t.setAllCaps(true); t.setPadding((int) (6 * d), 0, 0, (int) (8 * d)); col.addView(t);
    for (int i = 0; i < items.length; i++) {
      final int idx = i; TextView b = new TextView(this); b.setText(items[i]); b.setTextColor(0xFFFFFFFF); b.setTextSize(small ? 14 : 18); b.setGravity(Gravity.CENTER_VERTICAL);
      b.setPadding((int) (18 * d), (int) ((small ? 5 : 13) * d), (int) (36 * d), (int) ((small ? 5 : 13) * d)); b.setMinWidth((int) (260 * d));
      GradientDrawable r = new GradientDrawable(); r.setColor(i == 0 ? 0xFF6B5BFF : 0x1AFFFFFF); r.setCornerRadius(14 * d); b.setBackground(r);
      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); lp.topMargin = (int) ((small ? 3 : 6) * d); col.addView(b, lp); rows[i] = b;
      b.setOnClickListener(v -> { dlg.dismiss(); pick.on(idx); });
    }
    dlg.dir = dd -> { int n = items.length; rows[sel[0]].getBackground().mutate(); ((GradientDrawable) rows[sel[0]].getBackground()).setColor(0x1AFFFFFF); sel[0] = (sel[0] + dd + n) % n; ((GradientDrawable) rows[sel[0]].getBackground()).setColor(0xFF6B5BFF); sv.post(() -> sv.smoothScrollTo(0, Math.max(0, rows[sel[0]].getTop() - sv.getHeight() / 3))); };
    dlg.ok = () -> { dlg.dismiss(); pick.on(sel[0]); };
    dlg.back = () -> { dlg.dismiss(); resume(); };
    sv.addView(col); sheet.setContentView(sv); sheet.setOnCancelListener(x -> resume());
    if (sheet.getWindow() != null) { sheet.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x99000000)); sheet.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT, (int) (getResources().getDisplayMetrics().heightPixels * 0.80f)); }
    sheet.show();
  }
  void showAchievements() {
    float d = getResources().getDisplayMetrics().density; String raw = Player.nAchList();
    sheet = new NavDialog(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
    final NavDialog dlg = sheet;
    LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setPadding((int) (20 * d), (int) (16 * d), (int) (20 * d), (int) (12 * d));
    GradientDrawable bg = new GradientDrawable(); bg.setColor(0xF2191630); bg.setCornerRadius(22 * d); bg.setStroke((int) (1.5f * d), 0x667C6CFF); col.setBackground(bg);
    int done = 0, total = 0; LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
    for (String line : raw.split("\n")) { if (line.isEmpty()) continue; String[] f = line.split("\u001f", -1); total++; boolean u = f[0].equals("U"); if (u) done++;
      TextView a = new TextView(this); a.setText((u ? "\u2714  " : "\uD83D\uDD12  ") + f[1] + "  \u00b7  " + f[3] + " pts\n" + f[2]); a.setTextColor(u ? 0xFFFFFFFF : 0xFF9F9AC9); a.setTextSize(14); a.setPadding((int) (8 * d), (int) (8 * d), (int) (8 * d), (int) (8 * d)); list.addView(a); }
    TextView t = new TextView(this); t.setText(total == 0 ? "No achievements for this game" : "Achievements \u00b7 " + done + " of " + total); t.setTextColor(0xFFB9B1FF); t.setTextSize(13); t.setAllCaps(true); t.setLetterSpacing(0.15f); t.setPadding(0, 0, 0, (int) (8 * d)); col.addView(t);
    android.widget.ScrollView sv = new android.widget.ScrollView(this); sv.addView(list); col.addView(sv, new LinearLayout.LayoutParams((int) (480 * d), (int) (Math.min(getResources().getDisplayMetrics().heightPixels * 0.62f, 380 * d))));
    TextView close = new TextView(this); close.setText("Back"); close.setTextColor(0xFFFFFFFF); close.setTextSize(17); close.setGravity(Gravity.CENTER); close.setPadding(0, (int) (12 * d), 0, (int) (12 * d));
    GradientDrawable r = new GradientDrawable(); r.setColor(0xFF6B5BFF); r.setCornerRadius(14 * d); close.setBackground(r);
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); lp.topMargin = (int) (10 * d); col.addView(close, lp);
    close.setOnClickListener(v -> { sheet.dismiss(); menuOpen = false; openMenu(); });
    dlg.dir = dd -> sv.smoothScrollBy(0, (int) (dd * 140 * d));
    dlg.ok = () -> { dlg.dismiss(); menuOpen = false; openMenu(); };
    dlg.back = dlg.ok;
    sheet.setContentView(col); sheet.setOnCancelListener(x -> { menuOpen = false; openMenu(); });
    if (sheet.getWindow() != null) { sheet.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x99000000)); sheet.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT); }
    sheet.show();
  }
  void resume() { menuOpen = false; Player.pauseAudio(false); Player.nPause(false); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY); }

  void quit() { if (!started) { finish(); return; } started = false; Player.listener = null; Player.nStop(); Player.releaseAudio(); finish(); }
  @Override protected void onDestroy() { super.onDestroy(); if (started) { started = false; Player.listener = null; Player.nStop(); Player.releaseAudio(); } Process.killProcess(Process.myPid()); }
  @Override protected void onPause() { super.onPause(); gl.onPause(); if (!menuOpen) { Player.nPause(true); Player.pauseAudio(true); } }
  @Override protected void onResume() { super.onResume(); gl.onResume(); if (menuOnReturn && started) { menuOnReturn = false; menuOpen = false; ui.post(this::openMenu); return; } if (!menuOpen) { Player.pauseAudio(false); Player.nPause(false); } }
  @Override public void onBackPressed() { openMenu(); }

  // ---- gamepad ----
  static int bit(int k) {
    switch (k) {
      case KeyEvent.KEYCODE_BUTTON_A: return TouchPad.B; case KeyEvent.KEYCODE_BUTTON_B: return TouchPad.A;
      case KeyEvent.KEYCODE_BUTTON_X: return TouchPad.Y; case KeyEvent.KEYCODE_BUTTON_Y: return TouchPad.X;
      case KeyEvent.KEYCODE_BUTTON_L1: return TouchPad.L; case KeyEvent.KEYCODE_BUTTON_R1: return TouchPad.R;
      case KeyEvent.KEYCODE_BUTTON_START: return TouchPad.START; case KeyEvent.KEYCODE_BUTTON_SELECT: return TouchPad.SELECT;
      case KeyEvent.KEYCODE_DPAD_UP: return TouchPad.UP; case KeyEvent.KEYCODE_DPAD_DOWN: return TouchPad.DOWN;
      case KeyEvent.KEYCODE_DPAD_LEFT: return TouchPad.LEFT; case KeyEvent.KEYCODE_DPAD_RIGHT: return TouchPad.RIGHT;
      default: return -1;
    }
  }
  void pushPad() {
    int m = padKeys | pad.mask;
    if (axX < -0.5f) m |= 1 << TouchPad.LEFT; if (axX > 0.5f) m |= 1 << TouchPad.RIGHT; if (axY < -0.5f) m |= 1 << TouchPad.UP; if (axY > 0.5f) m |= 1 << TouchPad.DOWN;
    Player.nInput(m);
  }
  @Override public boolean dispatchKeyEvent(KeyEvent e) {
    if (e.getKeyCode() == KeyEvent.KEYCODE_BUTTON_MODE || e.getKeyCode() == KeyEvent.KEYCODE_HOME || e.getKeyCode() == KeyEvent.KEYCODE_BUTTON_THUMBL || e.getKeyCode() == KeyEvent.KEYCODE_BUTTON_THUMBR) { if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) openMenu(); return true; }
    int b = bit(e.getKeyCode());
    if (b >= 0 && (e.getSource() & (InputDevice.SOURCE_GAMEPAD | InputDevice.SOURCE_DPAD | InputDevice.SOURCE_JOYSTICK)) != 0) {
      lastWasPad = true; if (e.getAction() == KeyEvent.ACTION_DOWN) { padKeys |= 1 << b; hidePadNow(); } else if (e.getAction() == KeyEvent.ACTION_UP) padKeys &= ~(1 << b);
      pushPad(); return true;
    }
    return super.dispatchKeyEvent(e);
  }
  @Override public boolean dispatchGenericMotionEvent(MotionEvent e) {
    if ((e.getSource() & InputDevice.SOURCE_JOYSTICK) != 0 && e.getAction() == MotionEvent.ACTION_MOVE) {
      axX = e.getAxisValue(MotionEvent.AXIS_X); axY = e.getAxisValue(MotionEvent.AXIS_Y);
      float hx = e.getAxisValue(MotionEvent.AXIS_HAT_X), hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y); if (Math.abs(hx) > 0.5f) axX = hx; if (Math.abs(hy) > 0.5f) axY = hy;
      if (Math.abs(axX) > 0.4f || Math.abs(axY) > 0.4f) { lastWasPad = true; hidePadNow(); }
      pushPad(); return true;
    }
    return super.dispatchGenericMotionEvent(e);
  }
}
