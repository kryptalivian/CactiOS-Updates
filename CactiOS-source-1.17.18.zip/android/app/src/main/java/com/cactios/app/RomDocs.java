package com.cactios.app;

import android.database.Cursor;
import android.database.MatrixCursor;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract.Document;
import android.provider.DocumentsContract.Root;
import android.provider.DocumentsProvider;
import java.io.File;
import java.io.FileNotFoundException;

/** Exposes ROM files as document URIs so store-build RetroArch can open them via its SAF reader. Access is per-URI grant only. */
public class RomDocs extends DocumentsProvider {
  static final String AUTH = "com.cactios.app.docs";
  static final String[] ROOT_COLS = { Root.COLUMN_ROOT_ID, Root.COLUMN_FLAGS, Root.COLUMN_TITLE, Root.COLUMN_DOCUMENT_ID };
  static final String[] DOC_COLS = { Document.COLUMN_DOCUMENT_ID, Document.COLUMN_MIME_TYPE, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_LAST_MODIFIED, Document.COLUMN_FLAGS, Document.COLUMN_SIZE };
  static final String BASE = "/storage/emulated/0";

  @Override public boolean onCreate() { return true; }

  @Override public Cursor queryRoots(String[] projection) {
    MatrixCursor c = new MatrixCursor(projection != null ? projection : ROOT_COLS);
    c.newRow().add(Root.COLUMN_ROOT_ID, "roms").add(Root.COLUMN_FLAGS, 0).add(Root.COLUMN_TITLE, "Cacti OS ROMs").add(Root.COLUMN_DOCUMENT_ID, BASE);
    return c;
  }

  private File file(String id) throws FileNotFoundException {
    File f = new File(id);
    try { String cp = f.getCanonicalPath(); if (!cp.startsWith(BASE) && !cp.startsWith(getContext().getCacheDir().getCanonicalPath())) throw new FileNotFoundException("outside"); } catch (java.io.IOException e) { throw new FileNotFoundException(e.toString()); }
    return f;
  }

  private void row(MatrixCursor c, File f) {
    c.newRow().add(Document.COLUMN_DOCUMENT_ID, f.getPath()).add(Document.COLUMN_MIME_TYPE, f.isDirectory() ? Document.MIME_TYPE_DIR : "application/octet-stream")
      .add(Document.COLUMN_DISPLAY_NAME, f.getName()).add(Document.COLUMN_LAST_MODIFIED, f.lastModified()).add(Document.COLUMN_FLAGS, 0).add(Document.COLUMN_SIZE, f.length());
  }

  @Override public Cursor queryDocument(String id, String[] projection) throws FileNotFoundException {
    MatrixCursor c = new MatrixCursor(projection != null ? projection : DOC_COLS); row(c, file(id)); return c;
  }

  @Override public Cursor queryChildDocuments(String parent, String[] projection, String sort) throws FileNotFoundException {
    MatrixCursor c = new MatrixCursor(projection != null ? projection : DOC_COLS);
    File[] k = file(parent).listFiles(); if (k != null) for (File f : k) row(c, f); return c;
  }

  @Override public ParcelFileDescriptor openDocument(String id, String mode, CancellationSignal sig) throws FileNotFoundException {
    return ParcelFileDescriptor.open(file(id), ParcelFileDescriptor.MODE_READ_ONLY);
  }
}
