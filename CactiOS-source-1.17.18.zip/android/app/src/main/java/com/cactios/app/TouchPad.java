package com.cactios.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** On-screen controls drawn over the game. Produces a RetroPad bitmask. */
public class TouchPad extends View {
  // RetroPad bit positions
  public static final int B = 0, Y = 1, SELECT = 2, START = 3, UP = 4, DOWN = 5, LEFT = 6, RIGHT = 7, A = 8, X = 9, L = 10, R = 11;
  public interface Menu { void open(); }
  final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG);
  final boolean sixButtons; // show X/Y
  int mask = 0; Menu menu; long lastMenuTap; Runnable onTouch;
  static class Btn { String label; int bit; float cx, cy, r; boolean rect; Btn(String l, int b) { label = l; bit = b; } }
  final Btn[] btns;
  float dpx, dpy, dpr;

  public TouchPad(Context c, String system) {
    super(c); sixButtons = system.equals("snes") || system.equals("megadrive") || system.equals("genesis");
    fill.setColor(0x55000000); line.setColor(0xCCFFFFFF); line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(3);
    txt.setColor(0xFFFFFFFF); txt.setShadowLayer(4f, 0, 0, 0xFF000000); txt.setTextAlign(Paint.Align.CENTER);
    boolean shoulders = system.equals("snes") || system.equals("gba");
    java.util.ArrayList<Btn> l = new java.util.ArrayList<>();
    l.add(new Btn("A", A)); l.add(new Btn("B", B));
    if (sixButtons) { l.add(new Btn("X", X)); l.add(new Btn("Y", Y)); }
    if (shoulders) { l.add(new Btn("L", L)); l.add(new Btn("R", R)); }
    l.add(new Btn("SELECT", SELECT)); l.add(new Btn("START", START));
    btns = l.toArray(new Btn[0]);
  }

  @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
    float u = Math.min(w, h) / 12.5f; txt.setTextSize(u * 0.6f);
    dpr = u * 2.2f; dpx = u * 3.2f; dpy = h - u * 3.4f;
    float bx = w - u * 3.6f, by = h - u * 3.4f, br = u * 0.95f;
    for (Btn b : btns) {
      b.r = br; b.rect = false;
      switch (b.label) {
        case "A": b.cx = bx + (sixButtons ? u * 1.2f : u * 1.4f); b.cy = by + (sixButtons ? 0 : -u * 0.5f); break;
        case "B": b.cx = bx + (sixButtons ? 0 : -u * 0.5f); b.cy = by + (sixButtons ? u * 1.2f : u * 0.5f); break;
        case "X": b.cx = bx; b.cy = by - u * 1.2f; break;
        case "Y": b.cx = bx - u * 1.2f; b.cy = by; break;
        case "L": b.cx = u * 1.6f; b.cy = u * 1.1f; b.rect = true; break;
        case "R": b.cx = w - u * 1.6f; b.cy = u * 1.1f; b.rect = true; break;
        case "SELECT": b.cx = w / 2f - u * 1.5f; b.cy = h - u * 0.9f; b.rect = true; break;
        case "START": b.cx = w / 2f + u * 1.5f; b.cy = h - u * 0.9f; b.rect = true; break;
      }
    }
  }

  boolean hit(Btn b, float x, float y) {
    if (b.rect) { float hw = b.label.length() > 1 ? b.r * 1.5f : b.r * 1.2f, hh = b.r * 0.75f; return Math.abs(x - b.cx) < hw && Math.abs(y - b.cy) < hh; }
    float dx = x - b.cx, dy = y - b.cy; return dx * dx + dy * dy < b.r * b.r * 1.5f;
  }

  @Override public boolean onTouchEvent(MotionEvent e) {
    if (onTouch != null && e.getActionMasked() == MotionEvent.ACTION_DOWN) onTouch.run();
    int m = 0; boolean up = e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL;
    int skip = e.getActionMasked() == MotionEvent.ACTION_POINTER_UP ? e.getActionIndex() : -1;
    if (!up) for (int i = 0; i < e.getPointerCount(); i++) {
      if (i == skip) continue; float x = e.getX(i), y = e.getY(i);
      float dx = x - dpx, dy = y - dpy;
      if (dx * dx + dy * dy < dpr * dpr * 2.2f) {
        if (Math.abs(dx) > dpr * 0.28f) m |= dx < 0 ? 1 << LEFT : 1 << RIGHT;
        if (Math.abs(dy) > dpr * 0.28f) m |= dy < 0 ? 1 << UP : 1 << DOWN;
      }
      for (Btn b : btns) if (hit(b, x, y)) m |= 1 << b.bit;
      if (e.getActionMasked() == MotionEvent.ACTION_DOWN || e.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) {
        if (i == e.getActionIndex() && Math.abs(x - getWidth() / 2f) < getWidth() * 0.06f && y < getHeight() * 0.12f && menu != null) menu.open();
      }
    }
    if (m != mask) { mask = m; Player.nInput(m); invalidate(); }
    return true;
  }

  @Override protected void onDraw(Canvas c) {
    float u = Math.min(getWidth(), getHeight()) / 10f;
    fill.setColor(0x55000000); c.drawCircle(dpx, dpy, dpr, fill); c.drawCircle(dpx, dpy, dpr, line);
    drawArrow(c, 0, -1, (mask >> UP & 1) == 1); drawArrow(c, 0, 1, (mask >> DOWN & 1) == 1); drawArrow(c, -1, 0, (mask >> LEFT & 1) == 1); drawArrow(c, 1, 0, (mask >> RIGHT & 1) == 1);
    for (Btn b : btns) {
      boolean on = (mask >> b.bit & 1) == 1; fill.setColor(on ? 0x99FFFFFF : 0x55000000);
      if (b.rect) { float hw = b.label.length() > 1 ? b.r * 1.5f : b.r * 1.2f, hh = b.r * 0.75f; RectF r = new RectF(b.cx - hw, b.cy - hh, b.cx + hw, b.cy + hh); c.drawRoundRect(r, hh, hh, fill); c.drawRoundRect(r, hh, hh, line); }
      else { c.drawCircle(b.cx, b.cy, b.r, fill); c.drawCircle(b.cx, b.cy, b.r, line); }
      float ts = txt.getTextSize(); if (b.label.length() > 1) txt.setTextSize(ts * 0.55f);
      c.drawText(b.label, b.cx, b.cy + txt.getTextSize() * 0.35f, txt); txt.setTextSize(ts);
    }
    fill.setColor(0x55000000);
    RectF m = new RectF(getWidth() / 2f - u * 0.7f, u * 0.25f, getWidth() / 2f + u * 0.7f, u * 0.75f); c.drawRoundRect(m, u * 0.25f, u * 0.25f, fill);
    float ts = txt.getTextSize(); txt.setTextSize(ts * 0.5f); c.drawText("MENU", getWidth() / 2f, u * 0.6f, txt); txt.setTextSize(ts);
  }

  void drawArrow(Canvas c, int dx, int dy, boolean on) {
    fill.setColor(on ? 0xFFFFFFFF : 0xAAFFFFFF); float s = dpr * 0.42f, cx = dpx + dx * dpr * 0.62f, cy = dpy + dy * dpr * 0.62f;
    android.graphics.Path p = new android.graphics.Path();
    if (dy != 0) { p.moveTo(cx, cy + dy * s * 0.6f); p.lineTo(cx - s * 0.6f, cy - dy * s * 0.4f); p.lineTo(cx + s * 0.6f, cy - dy * s * 0.4f); }
    else { p.moveTo(cx + dx * s * 0.6f, cy); p.lineTo(cx - dx * s * 0.4f, cy - s * 0.6f); p.lineTo(cx - dx * s * 0.4f, cy + s * 0.6f); }
    p.close(); c.drawPath(p, fill);
  }
}
