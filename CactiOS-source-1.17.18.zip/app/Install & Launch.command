#!/bin/bash
# Double-click (first time: right-click > Open). Builds Cacti OS, installs it to ~/Applications and opens it.
cd "$(dirname "$0")" || exit 1
clear
echo "Cacti OS: building for this Mac..."
if command -v node >/dev/null 2>&1 && [ "$(node -p 'process.versions.node.split(".")[0]')" -ge 18 ]; then
  echo "Using Node $(node -v)"
else
  if [ ! -x .runtime/node/bin/node ]; then
    echo "Downloading a private copy of Node.js (nothing is installed system-wide)..."
    case "$(uname -m)" in arm64) NA=arm64;; *) NA=x64;; esac
    V=v20.18.0
    mkdir -p .runtime
    curl -fL "https://nodejs.org/dist/$V/node-$V-darwin-$NA.tar.gz" | tar -xz -C .runtime || { echo "Could not download Node.js."; read -n 1 -s -r -p "Press any key to close"; exit 1; }
    mv ".runtime/node-$V-darwin-$NA" .runtime/node
  fi
  export PATH="$PWD/.runtime/node/bin:$PATH"
fi
node scripts/build-mac.js || { read -n 1 -s -r -p "Press any key to close"; exit 1; }
sleep 2
