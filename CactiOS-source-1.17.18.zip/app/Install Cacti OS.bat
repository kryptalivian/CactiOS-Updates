@echo off
title Cacti OS installer
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\build-win.ps1"
if errorlevel 1 (
  echo.
  echo Something went wrong. Copy the text above and send it over.
  pause
  exit /b 1
)
timeout /t 3 >nul
