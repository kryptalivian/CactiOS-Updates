# Cacti OS in your web browser

Cacti OS runs a small program on the computer that has RetroArch and your games, and shows the screen in a browser tab.
It works on Windows, macOS and Linux.

- **Windows:** double-click `Start Cacti OS Web.bat`
- **Mac:** double-click `Start Cacti OS Web.command` (first time: right-click > Open)
- **Linux / Raspberry Pi:** `./start-web.sh` (needs Node.js 18+)

A black window stays open while Cacti OS runs; closing it stops Cacti OS. Your browser opens to
`http://localhost:8420/?t=...`. Bookmark that full address (the part after `t=` is a private key, so other websites
cannot control the program). It only listens on this computer.

What is the same: game library, box art, controller navigation, RetroAchievements, lobbies, music player, menus.
What is different:
- Games still open in RetroArch on the same computer. The browser tab stays behind them, so switch back after a game.
- The music player plays inside the browser tab, so keep the tab open. The over-the-game overlay is not available;
  use the music icon menu instead. Browsers may block music from starting by itself until you click once.
- Controller buttons only reach Cacti OS while the browser tab is in front. Press F11 for a full-screen look.
- Menu > Quit stops nothing; close the black window to stop.
- Folder pickers open a normal file dialog on the computer running Cacti OS.

Settings are kept in `~/.retro-os-web` (Windows: `C:\Users\you\.retro-os-web`). Passwords are encrypted with a key stored there.

ROM folders: put games in your ROMs folder either sorted into system folders (snes, nes, gba, gb, gbc, megadrive, mastersystem, psx)
or all mixed together. Cacti OS sorts mixed folders by file type (.sfc .smc .nes .gba .gb .gbc .md .gen .smd .sms .cue .chd .pbp .m3u)
and by any parent folder name such as "SNES" or "Genesis". Ambiguous files (.zip, .7z, .bin, .iso) need to be inside a system-named folder.

## Themes
Menu > UI Settings > Theme / Console skins. Custom color themes: Open custom themes folder (see README.md).

## Updating (no internet needed)
Cacti OS never goes online to look for updates. When there is a new version you get a small **Update file** for your system (double-click it; on a Mac the first time, right-click > Open). It shows what is new, asks before doing anything, saves a backup of the current version and keeps your games, saves and settings untouched. If anything goes wrong it puts the old version back by itself.
To go back later: Menu > Updates > Restore version. The last 3 versions are kept.
Update files replace the app's own files only. A new Electron runtime still needs the normal installer.

## What's new in 1.3

- **Home screen layouts** (Menu › Themes › Home screen layout): Classic, Compact, Cover Flow, Sidebar, Spotlight, Grid Wall, Rails, Columns and Dashboard. Left/right (and up/down where it makes sense) browse games in every layout.
- **Dashboard** shows tiles for Continue Playing, Systems, Recently unlocked, Friends, Your progress, Following leaderboard and Recently played. Press X on the Dashboard to choose which tiles show (up to three rows).
- **New skins** (Menu › Themes › Theme): Copper, Comic Print, Blueprint and Pastel Pop.
- **Music player**: the top-bar music button opens a compact player. Use the arrow at its top right to expand it to the full player (scrub bar, volume, up next, music folder). Cacti OS remembers whether you left it expanded. Hold Start and press D-pad Down during a game to bring it up over the game.
