# Cacti OS for Windows

1. Unzip this folder anywhere (for example your Downloads folder).
2. Double-click **Install Cacti OS.bat**. It downloads Electron (about 100 MB), installs Cacti OS to
   `%LOCALAPPDATA%\Cacti OS`, adds a Desktop and Start menu shortcut and starts it. No admin rights needed.
   If Windows SmartScreen says "Windows protected your PC", choose More info > Run anyway.
3. Install RetroArch: Cacti OS Menu > System Check > Install RetroArch opens the download page. Download the Windows
   64-bit package, extract it (it is a .7z file, use 7-Zip) to `C:\RetroArch-Win64`. Cacti OS finds it there, or in
   `C:\RetroArch`, `%LOCALAPPDATA%\RetroArch`, or you can pick `retroarch.exe` in Menu > ROMs & Emulators.
4. Menu > ROMs & Emulators: choose your ROMs folder (subfolders named snes, nes, gba, gb, gbc, megadrive, mastersystem, psx).
5. Menu > System Check > Install missing cores (downloads the RetroAchievements-supported emulators).
6. Menu > RetroAchievements: username, Web API key and your account password.

Notes
- The music player over a game: hold Start and press D-pad Down on an Xbox-style controller, or press Ctrl+Alt+M. Once open, the controller works (D-pad, A, B, X, LB, RB). PlayStation pads need Steam Input or DS4Windows to look like Xbox pads for this shortcut.
- The volume slider in Sound Settings does not change Windows system volume yet.
- To remove Cacti OS, delete `%LOCALAPPDATA%\Cacti OS` and the shortcuts.

ROM folders: put games in your ROMs folder either sorted into system folders (snes, nes, gba, gb, gbc, megadrive, mastersystem, psx)
or all mixed together. Cacti OS sorts mixed folders by file type (.sfc .smc .nes .gba .gb .gbc .md .gen .smd .sms .cue .chd .pbp .m3u)
and by any parent folder name such as "SNES" or "Genesis". Ambiguous files (.zip, .7z, .bin, .iso) need to be inside a system-named folder.

## Themes
Menu > UI Settings > Theme / Console skins. Custom color themes: Open custom themes folder (see README.md).

## Updating (no internet needed)
Cacti OS never goes online to look for updates. When there is a new version you get a small **Update file** for your system (double-click it; on a Mac the first time, right-click > Open). It shows what is new, asks before doing anything, saves a backup of the current version and keeps your games, saves and settings untouched. If anything goes wrong it puts the old version back by itself.
To go back later: Menu > Updates > Restore version. The last 3 versions are kept.
Update files replace the app's own files only. A new Electron runtime still needs the normal installer.

## What's new in 1.3

- **Home screen layouts** (Menu › Themes › Home screen layout): Classic, Compact, Cover Flow, Sidebar, Spotlight, Grid Wall, Rails, Columns and Dashboard. Left/right (and up/down where it makes sense) browse games in every layout.
- **Dashboard** shows tiles for Continue Playing, Systems, Recently unlocked, Friends, Your progress, Following leaderboard and Recently played. Press X on the Dashboard to choose which tiles show (up to three rows).
- **New skins** (Menu › Themes › Theme): Copper, Comic Print, Blueprint and Pastel Pop.
- **Music player**: the top-bar music button opens a compact player. Use the arrow at its top right to expand it to the full player (scrub bar, volume, up next, music folder). Cacti OS remembers whether you left it expanded. Hold Start and press D-pad Down during a game to bring it up over the game.
