# Cacti OS for macOS

An EmulationStation-style front end for RetroArch with RetroAchievements.

## Install
1. Unzip the whole folder and keep everything together.
2. Double-click "Install & Launch.command" (first time only: right-click > Open, then click Open).
3. Wait a few minutes. It builds "Cacti OS.app", puts it in ~/Applications and opens it.

Next time, open Cacti OS from Launchpad or ~/Applications.

## First run
The app opens System Check if it finds no games. From there:
- Install RetroArch (Homebrew if you have it, otherwise it opens the download page).
- Install missing cores (downloads Snes9x, FCEUmm, mGBA, PCSX ReARMed and Genesis Plus GX).
- ROMs & Emulators > ROMs folder. Inside it use these subfolders: snes, nes, gba, psx, megadrive.
- RetroAchievements: Username and Web API key (retroachievements.org > Settings > Keys).
- Scraper: downloads box art from the libretro thumbnails server (works best with No-Intro style file names).
- In RetroArch, turn on Settings > Achievements and sign in. RetroArch earns the unlocks; Cacti OS shows them.

## Controls
Arrows/D-pad browse. Enter/A play. Y favorite. X or R random game. Q/E or LB/RB systems. [ ] or LT/RT jump by letter.
S or Start opens the menu. P profile, W Wi-Fi, C controllers. F11 fullscreen.

## Themes and console skins
Menu > UI Settings: **Theme** cycles Classic, Green Phosphor, Neon Synthwave, Sunset Arcade and Deep Ocean.
**Console skins** (on by default) gives each system tab its own palette and background pattern (Game Boy greens, NES greys and red, SNES purples, Genesis blues, and so on) on the Classic theme.
Custom themes: **Open custom themes folder**, copy `example-theme.json`, edit the colors. Files are data only (allowed color values, one of four fonts, one of a few patterns); anything else in the file is ignored.

## Achievement popups
Menu > Achievement Popups: pick RetroArch's own notice, one of five Cacti OS popups (Pill, Drop banner, Pixel, Neon burst, Medal reveal) or Off. Size and sound are adjustable, and "Preview popup" shows the current style.
Cacti OS reads RetroArch's local log to see unlocks, so it adds no requests to retroachievements.org. The first unlock in a game makes one request for badge art, points and rarity. When a Cacti OS style is selected, Cacti OS turns off RetroArch's own unlock notice (`cheevos_visibility_unlock`).

## Emulator Library (standalone emulators)
Menu > Store > Emulators lists PCSX2 (PS2), Dolphin (GameCube/Wii), PPSSPP (PSP), Flycast (Dreamcast), melonDS (DS) and Azahar (3DS).
A installs or updates (downloads the newest official release from GitHub into Cacti OS's own folder). If no matching download is found, or the emulator has no automatic download, Cacti OS opens its download page in your browser instead; install it there, then press Y to point Cacti OS at it. X always opens the download page.
Put games in your ROMs folder under ps2, gamecube, wii, psp, dreamcast, nds or 3ds. BIOS files are checked in Menu > System Check (you supply them; Cacti OS only opens the right folder).
Standalone emulators show their own RetroAchievements popups; sign in inside each emulator once.

## Updating (no internet needed)
Cacti OS never goes online to look for updates. When there is a new version you get a small **Update file** for your system (double-click it; on a Mac the first time, right-click > Open). It shows what is new, asks before doing anything, saves a backup of the current version and keeps your games, saves and settings untouched. If anything goes wrong it puts the old version back by itself.
To go back later: Menu > Updates > Restore version. The last 3 versions are kept.
Update files replace the app's own files only. A new Electron runtime still needs the normal installer.

## What's new in 1.3

- **Home screen layouts** (Menu › Themes › Home screen layout): Classic, Compact, Cover Flow, Sidebar, Spotlight, Grid Wall, Rails, Columns and Dashboard. Left/right (and up/down where it makes sense) browse games in every layout.
- **Dashboard** shows tiles for Continue Playing, Systems, Recently unlocked, Friends, Your progress, Following leaderboard and Recently played. Press X on the Dashboard to choose which tiles show (up to three rows).
- **New skins** (Menu › Themes › Theme): Copper, Comic Print, Blueprint and Pastel Pop.
- **Music player**: the top-bar music button opens a compact player. Use the arrow at its top right to expand it to the full player (scrub bar, volume, up next, music folder). Cacti OS remembers whether you left it expanded. Hold Start and press D-pad Down during a game to bring it up over the game.
