@echo off
title Cacti OS (web)
cd /d "%~dp0"
where node >nul 2>nul
if %errorlevel%==0 (set "NODE=node") else (
  if not exist ".runtime\node\node.exe" (
    echo Downloading a private copy of Node.js ^(nothing is installed system-wide^)...
    mkdir .runtime 2>nul
    powershell -NoProfile -Command "Invoke-WebRequest https://nodejs.org/dist/v20.18.0/node-v20.18.0-win-x64.zip -OutFile .runtime\node.zip; Expand-Archive .runtime\node.zip .runtime -Force; Rename-Item .runtime\node-v20.18.0-win-x64 node"
  )
  set "NODE=.runtime\node\node.exe"
)
"%NODE%" server.js
pause
