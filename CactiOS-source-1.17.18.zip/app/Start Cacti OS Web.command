#!/bin/bash
# Mac: double-click (first time: right-click > Open). Starts Cacti OS and opens it in your browser.
cd "$(dirname "$0")" || exit 1
if command -v node >/dev/null 2>&1 && [ "$(node -p 'process.versions.node.split(".")[0]')" -ge 18 ]; then NODE=node
else
  if [ ! -x .runtime/node/bin/node ]; then
    echo "Downloading a private copy of Node.js (nothing is installed system-wide)..."
    case "$(uname -m)" in arm64) NA=arm64;; *) NA=x64;; esac
    V=v20.18.0; mkdir -p .runtime
    curl -fL "https://nodejs.org/dist/$V/node-$V-darwin-$NA.tar.gz" | tar -xz -C .runtime && mv ".runtime/node-$V-darwin-$NA" .runtime/node || { echo "Could not download Node.js."; read -n 1 -s -r -p "Press any key"; exit 1; }
  fi
  NODE=.runtime/node/bin/node
fi
"$NODE" server.js
