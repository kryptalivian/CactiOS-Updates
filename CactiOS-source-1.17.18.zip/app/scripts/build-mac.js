// Builds "Cacti OS.app" with no npm packaging tools: downloads the official Electron runtime,
// drops the app inside, ad-hoc signs it, installs to ~/Applications and opens it.
const fs = require('fs'), path = require('path'), cp = require('child_process'), os = require('os');
const root = path.join(__dirname, '..');
const VER = '33.4.11';
const arch = process.arch === 'arm64' ? 'arm64' : 'x64';
const run = (c, a, o = {}) => cp.execFileSync(c, a, { stdio: 'inherit', ...o });
const step = m => console.log('\n==> ' + m);

try {
  const work = path.join(root, 'dist'); fs.rmSync(work, { recursive: true, force: true }); fs.mkdirSync(work, { recursive: true });
  const cache = path.join(os.homedir(), 'Library', 'Caches', 'retro-os'); fs.mkdirSync(cache, { recursive: true });
  const zip = path.join(cache, `electron-v${VER}-darwin-${arch}.zip`);
  if (!fs.existsSync(zip) || fs.statSync(zip).size < 50e6) {
    step(`Downloading Electron ${VER} (${arch}), about 100 MB`);
    run('curl', ['-fL', '--progress-bar', '-o', zip, `https://github.com/electron/electron/releases/download/v${VER}/electron-v${VER}-darwin-${arch}.zip`]);
  } else step('Using cached Electron download');

  step('Unpacking');
  run('ditto', ['-x', '-k', zip, work]);
  const src = path.join(work, 'Electron.app'), app = path.join(work, 'Cacti OS.app');
  if (!fs.existsSync(src)) throw new Error('Electron.app not found after unpacking');
  fs.renameSync(src, app);

  step('Adding Cacti OS');
  const res = path.join(app, 'Contents', 'Resources'), dest = path.join(res, 'app');
  fs.mkdirSync(dest, { recursive: true });
  for (const f of ['main.js', 'preload.js', 'music-preload.js', 'popup-preload.js', 'emus.js', 'meta.js', 'store.js', 'package.json']) fs.copyFileSync(path.join(root, f), path.join(dest, f));
  fs.cpSync(path.join(root, 'renderer'), path.join(dest, 'renderer'), { recursive: true });

  step('Branding');
  const plist = path.join(app, 'Contents', 'Info.plist');
  for (const [k, v] of [['CFBundleName', 'Cacti OS'], ['CFBundleDisplayName', 'Cacti OS'], ['CFBundleIdentifier', 'local.cactios'], ['LSApplicationCategoryType', 'public.app-category.games']])
    run('/usr/bin/plutil', ['-replace', k, '-string', v, plist]);
  try {
    const png = path.join(root, 'build', 'icon.png'), set = path.join(work, 'icon.iconset'), out = path.join(work, 'icon.icns');
    fs.mkdirSync(set, { recursive: true });
    for (const [s, n] of [[16, '16x16'], [32, '16x16@2x'], [32, '32x32'], [64, '32x32@2x'], [128, '128x128'], [256, '128x128@2x'], [256, '256x256'], [512, '256x256@2x'], [512, '512x512'], [1024, '512x512@2x']])
      cp.execFileSync('/usr/bin/sips', ['-z', s, s, png, '--out', path.join(set, `icon_${n}.png`)], { stdio: 'ignore' });
    cp.execFileSync('/usr/bin/iconutil', ['-c', 'icns', set, '-o', out]);
    fs.copyFileSync(out, path.join(res, 'electron.icns'));
  } catch { console.log('(icon skipped)'); }

  step('Signing');
  try { run('/usr/bin/xattr', ['-cr', app]); } catch {}
  run('/usr/bin/codesign', ['--force', '--deep', '--sign', '-', app]);

  step('Installing to ~/Applications');
  const apps = path.join(os.homedir(), 'Applications'); fs.mkdirSync(apps, { recursive: true });
  try { cp.execFileSync('/usr/bin/osascript', ['-e', 'tell application "Cacti OS" to quit'], { stdio: 'ignore' }); } catch {}
  try { cp.execFileSync('/usr/bin/osascript', ['-e', 'tell application "Retro OS" to quit'], { stdio: 'ignore' }); } catch {}
  fs.rmSync(path.join(apps, 'Retro OS.app'), { recursive: true, force: true });
  const target = path.join(apps, 'Cacti OS.app'); fs.rmSync(target, { recursive: true, force: true });
  run('ditto', [app, target]);
  fs.rmSync(work, { recursive: true, force: true });
  console.log('\nInstalled: ' + target + '\nLaunching...');
  run('/usr/bin/open', [target]);
} catch (e) {
  console.error('\nBUILD FAILED: ' + (e && e.message || e));
  process.exit(1);
}
