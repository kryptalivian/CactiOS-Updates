# Builds and installs Cacti OS for Windows (no admin rights needed). Run via "Install Cacti OS.bat".
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ver  = '33.4.11'
$root = Split-Path -Parent $PSScriptRoot
$arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }
$dest = Join-Path $env:LOCALAPPDATA 'Cacti OS'
$zip  = Join-Path $env:TEMP "electron-v$ver-win32-$arch.zip"

Write-Host "Cacti OS: building for Windows ($arch)..."
Get-Process -Name 'Cacti OS','Retro OS' -ErrorAction SilentlyContinue | Stop-Process -Force
Remove-Item (Join-Path $env:LOCALAPPDATA 'Retro OS') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Retro OS.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Retro OS.lnk') -Force -ErrorAction SilentlyContinue
if (-not (Test-Path $zip) -or (Get-Item $zip).Length -lt 50MB) {
  Write-Host "Downloading Electron $ver (about 100 MB)..."
  Invoke-WebRequest -Uri "https://github.com/electron/electron/releases/download/v$ver/electron-v$ver-win32-$arch.zip" -OutFile $zip -UseBasicParsing
}
if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
New-Item -ItemType Directory -Path $dest | Out-Null
Write-Host "Unpacking..."
Expand-Archive -Path $zip -DestinationPath $dest -Force
Rename-Item (Join-Path $dest 'electron.exe') 'Cacti OS.exe'
Remove-Item (Join-Path $dest 'resources\default_app.asar') -Force -ErrorAction SilentlyContinue
$app = Join-Path $dest 'resources\app'
New-Item -ItemType Directory -Path $app | Out-Null
foreach ($f in 'main.js','preload.js','music-preload.js','popup-preload.js','emus.js','meta.js','store.js','package.json') { Copy-Item (Join-Path $root $f) $app }
Copy-Item (Join-Path $root 'renderer') (Join-Path $app 'renderer') -Recurse

# icon: wrap a 256px PNG in an .ico
$ico = Join-Path $dest 'cacti-os.ico'
try {
  Add-Type -AssemblyName System.Drawing
  $src = [System.Drawing.Image]::FromFile((Join-Path $root 'build\icon.png'))
  $bmp = New-Object System.Drawing.Bitmap 256, 256
  $g = [System.Drawing.Graphics]::FromImage($bmp); $g.InterpolationMode = 'HighQualityBicubic'; $g.DrawImage($src, 0, 0, 256, 256); $g.Dispose()
  $ms = New-Object System.IO.MemoryStream; $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); $png = $ms.ToArray()
  $fs = [System.IO.File]::Create($ico); $bw = New-Object System.IO.BinaryWriter $fs
  $bw.Write([uint16]0); $bw.Write([uint16]1); $bw.Write([uint16]1)
  $bw.Write([byte]0); $bw.Write([byte]0); $bw.Write([byte]0); $bw.Write([byte]0); $bw.Write([uint16]1); $bw.Write([uint16]32); $bw.Write([uint32]$png.Length); $bw.Write([uint32]22)
  $bw.Write($png); $bw.Close(); $src.Dispose(); $bmp.Dispose()
} catch { Write-Host "(no custom icon: $($_.Exception.Message))" }

# shortcuts on the Desktop and in the Start menu
$exe = Join-Path $dest 'Cacti OS.exe'
$sh = New-Object -ComObject WScript.Shell
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'))) {
  try {
    $l = $sh.CreateShortcut((Join-Path $dir 'Cacti OS.lnk')); $l.TargetPath = $exe; $l.WorkingDirectory = $dest
    if (Test-Path $ico) { $l.IconLocation = $ico }
    $l.Save()
  } catch { Write-Host "(could not create a shortcut in $dir)" }
}
Write-Host ""
Write-Host "Installed to $dest"
Write-Host "A Cacti OS shortcut is on your Desktop. Starting it now..."
Start-Process $exe
