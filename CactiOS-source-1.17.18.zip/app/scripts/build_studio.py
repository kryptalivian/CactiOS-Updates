#!/usr/bin/env python3
"""Regenerates renderer/studio-stage.js from index.html (so the studio preview always matches the app) and writes the
single-file Theme Studio. Usage: build_studio.py <app dir> <out html>"""
import sys, os, json, re
app, out = sys.argv[1], sys.argv[2]
R = os.path.join(app, 'renderer'); rd = lambda n: open(os.path.join(R, n), encoding='utf8').read()
idx = rd('index.html')
a = idx.index('<div id="stage">') + len('<div id="stage">'); b = idx.index('<div id="prof"')
stage = '<div id="stage">' + idx[a:b] + '</div>'
open(os.path.join(R, 'studio-stage.js'), 'w', encoding='utf8').write('window.__STAGE=' + json.dumps(stage) + ';\n')
html = rd('studio.html')
def inline(m):
    return '<script>' + rd(m.group(1)) + '</script>'
html = re.sub(r'<script src="(studio[^"]*\.js)"></script>', inline, html)
html = re.sub(r'<link rel="stylesheet" href="(studio\.css)">', lambda m: '<style>' + rd(m.group(1)) + '</style>', html)
html = re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>\n?', '', html)
esc = lambda s: json.dumps(s).replace('</', '<\\/')
pre = '<script>window.__STANDALONE={style:%s,themes:%s,frame:%s};</script>' % (esc(rd('style.css')), esc(rd('themes.js')), esc(rd('studio-frame.js')))
html = html.replace('<script>', pre + '<script>', 1)
import base64
ico = 'data:image/svg+xml;base64,' + base64.b64encode(open(os.path.join(R, 'cacti-icon.svg'), 'rb').read()).decode()
html = html.replace('src="cacti-icon.svg"', 'src="' + ico + '"').replace('cacti-icon.svg\\"', ico + '\\"')
open(out, 'w', encoding='utf8').write(html)
print('wrote', out, len(html) // 1024, 'KB')
