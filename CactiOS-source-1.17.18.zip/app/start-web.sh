#!/bin/bash
# Linux / Raspberry Pi: starts Cacti OS and opens it in the browser. Needs Node.js 18+ (sudo apt install nodejs).
cd "$(dirname "$0")" || exit 1
command -v node >/dev/null || { echo "Install Node.js first: sudo apt install nodejs"; exit 1; }
exec node server.js
