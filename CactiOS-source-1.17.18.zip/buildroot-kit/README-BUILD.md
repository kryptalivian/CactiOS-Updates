# Cacti OS images (Buildroot)

One kit, three images. Run on Ubuntu/Debian or WSL2 Ubuntu, as a normal user, with about 100 GB free.

    ./build.sh rpi5      # Raspberry Pi 5            (default)
    ./build.sh zero2w    # Raspberry Pi Zero 2 W     (512 MB RAM)
    ./build.sh x86_64    # PCs and laptops with UEFI (Intel, AMD, NVIDIA open driver)

Add `menuconfig` after the target to change which emulators go in (`./build.sh x86_64 menuconfig`).
Each target keeps its own work folder (`~/retroos-build`, `~/retroos-build-zero2w`, `~/retroos-build-x86_64`), so they never disturb each other.
Set `COPY_TO=/some/folder` to get the image, a build report and the compressed log copied there when it finishes.

Result: `out/images/sdcard.img` and `sdcard.img.xz`.

## Flashing
- **Pi 5 / Zero 2 W:** Raspberry Pi Imager, "Use custom", pick `sdcard.img.xz`.
- **PC:** write `sdcard.img` to a USB stick or SSD with balenaEtcher or `dd`, then boot it in UEFI mode (turn Secure Boot off). The first boot grows the games partition to fill the disk.

## What is different per target
| | Pi 5 | Zero 2 W | x86-64 PC |
|---|---|---|---|
| CPU | aarch64, Cortex-A76 | aarch64, Cortex-A53 | x86-64-v2 (any CPU since about 2009) |
| Graphics | Mesa V3D/VC4 | Mesa VC4 (OpenGL ES 2) | Mesa iris/crocus (Intel), radeonsi (AMD), nouveau, llvmpipe (software) |
| Boot | Pi firmware | Pi firmware | GRUB (UEFI) |
| Emulators | everything | 8/16-bit, PS1 and similar; no N64, DS, Saturn, 3DO, PSP, GameCube/Wii, Amiga, MAME, ScummVM | everything |
| Screen mode (Menu > Display) | `cmdline.txt` | `cmdline.txt` | `cmdline.cfg` read by GRUB |

## Honest limits
- The Zero 2 W has 512 MB. The Cacti OS front end is a full Chromium (Electron) app, so expect slow menus and a long start (a minute or more). Compressed swap (zram) and a trimmed Chromium setting (`/etc/retro-os.conf`) are included to make it fit. A Pi 3, 4 or 5 is a far better choice for the front end; the Zero 2 W is meant for light retro systems.
- The x86-64 image builds LLVM and Clang (Mesa needs them for the Intel and AMD drivers), so the first build takes noticeably longer and needs more disk space than the Pi images.
- The PC image carries Wi-Fi and Bluetooth firmware for common Intel, Realtek, Atheros, Ralink and MediaTek chips, and AMD/Intel graphics firmware. A chip not on that list needs its firmware added in `menuconfig` (Target packages, Hardware handling, Firmware, linux-firmware).
- NVIDIA cards use the open `nouveau` driver (OpenGL works; speed is limited on newer cards). There is no proprietary NVIDIA driver.
