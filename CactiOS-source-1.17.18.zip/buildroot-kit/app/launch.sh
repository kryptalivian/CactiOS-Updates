#!/bin/sh
# Started by retro-os.service as the "retro" user: a Cage Wayland kiosk running the Cacti OS front end.
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
export ELECTRON_OZONE_PLATFORM_HINT=wayland
export LIBSEAT_BACKEND=seatd
export XKB_DEFAULT_LAYOUT="${XKB_DEFAULT_LAYOUT:-us}"
export ELECTRON_ENABLE_LOGGING=1   # Electron messages go to the system journal (shown in bootlog.txt)
[ -f /etc/retro-os.conf ] && . /etc/retro-os.conf          # defaults for this kind of board
[ -f /userdata/system/retro-os.conf ] && . /userdata/system/retro-os.conf   # the owner's own changes
exec cage -s -- /opt/retro-os/electron/electron --no-sandbox --ozone-platform=wayland ${RETRO_OS_FLAGS:-} /opt/retro-os/app
