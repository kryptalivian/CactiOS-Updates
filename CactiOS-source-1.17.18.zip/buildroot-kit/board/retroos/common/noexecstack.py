#!/usr/bin/env python3
# Clear the "needs an executable stack" flag (PT_GNU_STACK) on shared libraries and programs: some cores (melonDS, PlayStation) carry
# assembly objects without a stack note, and the system then refuses to load them ("cannot enable executable stack").
import os, struct, sys
def fix(p):
    try:
        with open(p, 'r+b') as f:
            h = f.read(64)
            if h[:4] != b'\x7fELF': return
            e = '<' if h[5] == 1 else '>'
            if h[4] == 2: off, esz, num = struct.unpack(e + 'Q', h[32:40])[0], struct.unpack(e + 'H', h[54:56])[0], struct.unpack(e + 'H', h[56:58])[0]; fo = 4
            else: off, esz, num = struct.unpack(e + 'I', h[28:32])[0], struct.unpack(e + 'H', h[42:44])[0], struct.unpack(e + 'H', h[44:46])[0]; fo = 24
            for i in range(num):
                f.seek(off + i * esz); t = struct.unpack(e + 'I', f.read(4))[0]
                if t == 0x6474e551:
                    f.seek(off + i * esz + fo); fl = struct.unpack(e + 'I', f.read(4))[0]
                    if fl & 1: f.seek(off + i * esz + fo); f.write(struct.pack(e + 'I', fl & ~1)); print('noexecstack', p)
    except Exception as ex: print('skip', p, ex)
for root in sys.argv[1:]:
    for d, _, fs in os.walk(root):
        for n in fs:
            p = os.path.join(d, n)
            if os.path.islink(p) or not (n.endswith('.so') or '.so.' in n or d.endswith('/bin')): continue
            fix(p)
