#!/bin/sh
# Debug helper: copies the boot log to the FAT boot partition so it can be read on a Windows PC (file: bootlog.txt).
ROOT=$(findmnt -n -o SOURCE /)
case "$ROOT" in *p2) DISK=${ROOT%p2} ;; *2) DISK=${ROOT%2} ;; *) exit 0 ;; esac
case "$DISK" in *mmcblk*|*nvme*) BOOT="${DISK}p1" ;; *) BOOT="${DISK}1" ;; esac
M=/run/bootlog; mkdir -p "$M"
for wait in 20 60 180; do
  sleep "$wait"
  mount -t vfat -o rw "$BOOT" "$M" 2>/dev/null || continue
  {
    echo "=== Cacti OS boot log, taken $wait s after the service started"
    echo "=== uname"; uname -a
    echo "=== services"; systemctl --no-pager --failed; systemctl --no-pager status retro-os seatd retro-os-firstboot 2>&1 | head -80
    echo "=== retro-os journal"; journalctl --no-pager -u retro-os -u seatd -u retro-os-firstboot -b 2>&1 | tail -150
    echo "=== kernel messages (graphics, drm, firmware)"; dmesg | grep -i -E "drm|vc4|v3d|i915|amdgpu|radeon|nouveau|hdmi|firmware|fail|error|mmc|nvme" | tail -80
    echo "=== files"; ls -la /opt/retro-os/electron/electron /usr/bin/retro-os /usr/bin/cage /usr/bin/seatd 2>&1
    echo "=== missing libraries for electron"; ldd /opt/retro-os/electron/electron 2>&1 | grep -i "not found"
    echo "=== dri"; ls -la /dev/dri 2>&1
    echo "=== input devices"; cat /proc/bus/input/devices 2>&1; ls -la /dev/input 2>&1
    echo "=== usb"; ls /sys/bus/usb/devices 2>&1; dmesg | grep -i -E "usb|hid|steam|input" | tail -60
    echo "=== wifi / bluetooth"; ls -la /lib/firmware/brcm 2>&1 | head -30; nmcli dev 2>&1; dmesg | grep -i -E "brcm|wlan|bluetooth|hci" | tail -40
    echo "=== bluetooth"; bluetoothctl show 2>&1 | head -20; rfkill list 2>&1; systemctl --no-pager status bluetooth 2>&1 | head -15
    echo "=== settings (why setup may repeat)"; findmnt /userdata 2>&1; cat /userdata/firstboot.log 2>&1 | tail -30; which sfdisk parted resize2fs partx 2>&1; lsblk 2>&1; du -xsh /userdata/* /userdata/home/retro/.config/* /userdata/home/retro/.cache 2>&1 | sort -h | tail -8; df -h /userdata / 2>&1; ls -la /userdata /userdata/home/retro /userdata/home/retro/.config 2>&1 | head -40; for f in /userdata/home/retro/.config/*/config.json; do echo "-- $f"; ls -la "$f"; grep -E "setupDone|raUser|romRoot" "$f"; done 2>&1; journalctl --no-pager -b 2>&1 | grep -i -E "settings could not be saved|EACCES|EROFS|ENOSPC" | tail -10
    echo "=== app log"; journalctl --no-pager -b 2>&1 | grep -i -E "padStart|pad:|upload|wifi" | tail -30
  } > "$M/bootlog.txt" 2>&1
  sync; umount "$M"
done
exit 0
