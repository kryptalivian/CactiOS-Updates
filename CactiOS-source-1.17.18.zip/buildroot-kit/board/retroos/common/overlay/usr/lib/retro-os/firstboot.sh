#!/bin/sh
# Runs at every boot (cheap when nothing is left to do).
U=/userdata
# 1. Grow the userdata partition to fill the card or SSD. Tried at every boot until it works; the steps and any errors go to /userdata/firstboot.log.
LOG=$U/firstboot.log
DEV=$(findmnt -n -o SOURCE "$U")
if [ ! -f "$U/.grown" ]; then
  {
    echo "== $(date) grow userdata: device=$DEV"
    BASE=$(basename "$DEV"); SYS=$(readlink -f "/sys/class/block/$BASE" 2>/dev/null)
    DISK="/dev/$(basename "$(dirname "$SYS")")"; PN=$(cat "/sys/class/block/$BASE/partition" 2>/dev/null)
    echo "disk=$DISK partition=$PN"
    if [ -b "$DISK" ] && [ -n "$PN" ]; then
      if command -v sfdisk >/dev/null 2>&1; then echo ', +' | sfdisk -N "$PN" --no-reread "$DISK"
      elif command -v parted >/dev/null 2>&1; then parted -s "$DISK" resizepart "$PN" 100%
      else echo "no partition tool found (need sfdisk or parted)"; fi
      partx -u "$DISK" 2>&1 || partx -u "$DEV" 2>&1 || blockdev --rereadpt "$DISK" 2>&1
      if resize2fs "$DEV"; then touch "$U/.grown"; echo "grown ok"; fi
    fi
    df -h "$U"
  } >> "$LOG" 2>&1
fi
# 2. Folders for games, BIOS files, saves and settings.
for d in snes nes gba gb gbc megadrive mastersystem gamegear psx n64 nds psp saturn dreamcast gc wii pcengine neogeo ngp wswan atari2600 atari5200 atari7800 lynx jaguar atarist c64 amiga msx coleco intellivision 3do dos scummvm arcade fbneo mame vectrex o2em pokemini virtualboy x68000; do mkdir -p "$U/roms/$d"; done
mkdir -p "$U/bios" "$U/saves" "$U/system" "$U/home/retro/.config/retroarch"
# 3. Links so Cacti OS and RetroArch find everything where they expect it.
H=$U/home/retro
ln -sfn "$U/roms" "$H/ROMs"
ln -sfn /usr/lib/libretro "$H/.config/retroarch/cores"
ln -sfn /usr/share/libretro/info "$H/.config/retroarch/cores/info" 2>/dev/null
ln -sfn "$U/bios" "$H/.config/retroarch/system"
ln -sfn "$U/saves" "$H/.config/retroarch/saves"
chown -R retro:retro "$H" "$U/roms" "$U/saves" "$U/system" 2>/dev/null
chown retro:retro "$U/bios"
# 4. The app folder belongs to the Cacti OS user, so in-app and web-page updates can replace files and keep backups.
mkdir -p /opt/retro-os/app-backups
chown -R retro:retro /opt/retro-os/app /opt/retro-os/app-backups 2>/dev/null
exit 0
