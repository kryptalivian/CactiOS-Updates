#!/bin/sh
# Installs the running Cacti OS (PC image) onto an internal drive. Started by rootd.sh as a transient systemd unit: install.sh <disk name, e.g. nvme0n1> <1 = copy games and settings, 0 = start fresh>
# Progress goes to /run/retro-install/status as  state|percent|text  (state is run, ok or err) and the log to /userdata/install.log.
D=/dev/$1; KEEP=$2; S=/run/retro-install; B=$S/boot; R=$S/root; U=$S/data
mkdir -p $S; chmod 755 $S
LOG=/userdata/install.log
log() { echo "$(date '+%F %T') $*" >> "$LOG" 2>/dev/null; }
st() { echo "$1|$2|$3" > $S/status.tmp; chmod 644 $S/status.tmp; mv -f $S/status.tmp $S/status; log "[$1 $2%] $3"; }
clean() { for m in $B $R $U; do mountpoint -q $m && umount $m 2>/dev/null; done; }
fail() { clean; st err 0 "$1"; exit 1; }
trap 'clean' EXIT
st run 1 "Checking the drive"
[ "$(uname -m)" = x86_64 ] || fail "Installing to a drive is only available on the PC image."
ROOT=$(findmnt -n -o SOURCE /); BOOT=$(case "$ROOT" in *p2) echo "${ROOT%2}1";; *2) echo "${ROOT%2}1";; esac)
[ -b "$ROOT" ] && [ -b "$BOOT" ] || fail "Cacti OS can only install itself when it is running from its own PC image."
SRC=$(basename "$(readlink -f "/sys/class/block/$(basename "$ROOT")/..")")
[ -b "$D" ] || fail "That drive is not there any more."
[ "$1" != "$SRC" ] || fail "That is the drive Cacti OS is running from."
grep -q "^/dev/$1" /proc/mounts && fail "That drive is in use. Unmount it first."
case "$1" in nvme*|mmcblk*) PP=p;; *) PP=;; esac
P1=$D${PP}1; P2=$D${PP}2; P3=$D${PP}3
ROOTB=$(blockdev --getsize64 "$ROOT"); DSK=$(blockdev --getsize64 "$D")
ROOTSEC=$(( (ROOTB + 1073741824) / 512 )); ESPSEC=524288
MIN=$(( ROOTSEC * 512 + ESPSEC * 512 + 1073741824 ))
[ "$DSK" -ge "$MIN" ] || fail "That drive is too small."
UDUSED=$(df -P -B1 /userdata 2>/dev/null | awk 'NR==2{print $3}'); [ -n "$UDUSED" ] || UDUSED=0
if [ "$KEEP" = 1 ]; then [ $(( DSK - ROOTSEC*512 - ESPSEC*512 )) -gt $(( UDUSED + UDUSED / 10 + 536870912 )) ] || fail "Your games and settings will not fit on that drive. Install without copying them."; fi
PU1=$(cat /proc/sys/kernel/random/uuid); PU2=$(cat /proc/sys/kernel/random/uuid); PU3=$(cat /proc/sys/kernel/random/uuid); DID=$(cat /proc/sys/kernel/random/uuid)
OLDPU=$(blkid -s PARTUUID -o value "$ROOT" 2>/dev/null)
[ -n "$OLDPU" ] || fail "Could not read this system's partition id."
log "install to $D from $ROOT ($BOOT) keep=$KEEP old=$OLDPU new=$PU2"

st run 3 "Erasing the drive and making new partitions"
dd if=/dev/zero of="$D" bs=1M count=4 conv=fsync 2>/dev/null
dd if=/dev/zero of="$D" bs=1M seek=$(( DSK / 1048576 - 4 )) count=4 conv=fsync 2>/dev/null
printf 'label: gpt\nlabel-id: %s\nfirst-lba: 2048\nstart=2048, size=%s, type=U, uuid=%s\nsize=%s, type=L, uuid=%s\ntype=L, uuid=%s\n' "$DID" "$ESPSEC" "$PU1" "$ROOTSEC" "$PU2" "$PU3" | sfdisk --wipe always --wipe-partitions always "$D" >> "$LOG" 2>&1 || fail "Could not partition the drive."
blockdev --rereadpt "$D" 2>/dev/null; partx -u "$D" 2>/dev/null; udevadm settle 2>/dev/null
i=0; while [ $i -lt 20 ]; do [ -b "$P1" ] && [ -b "$P2" ] && [ -b "$P3" ] && break; i=$((i+1)); sleep 1; done
[ -b "$P3" ] || fail "The new partitions did not appear."

st run 6 "Copying the boot files"
dd if="$BOOT" of="$P1" bs=4M conv=fsync 2>>"$LOG" || fail "Could not copy the boot partition."
mkdir -p $B $R $U; mount "$P1" $B || fail "Could not open the new boot partition."
for f in $B/EFI/BOOT/grub.cfg; do [ -f "$f" ] && sed -i "s/$OLDPU/$PU2/g" "$f"; done
grep -q "$PU2" $B/EFI/BOOT/grub.cfg 2>/dev/null || fail "The boot menu could not be set up."
[ -f $B/bzImage ] && [ -f $B/EFI/BOOT/BOOTX64.EFI ] || fail "The boot files are incomplete."
sync; umount $B

st run 8 "Making the system partition"
mkfs.ext4 -F -q -L cactiroot "$P2" >> "$LOG" 2>&1 || fail "Could not format the system partition."
mount "$P2" $R || fail "Could not open the new system partition."
TOT=$(df -P -B1 / | awk 'NR==2{print $3}'); [ "$TOT" -gt 0 ] 2>/dev/null || TOT=1
(
  cd /
  for e in /* /.[!.]*; do
    [ -e "$e" ] || [ -L "$e" ] || continue
    case "$e" in /proc|/sys|/dev|/run|/tmp|/userdata|/mnt|/media|/lost+found|/boot) continue;; esac
    mountpoint -q "$e" && continue
    cp -ax "$e" "$R/" 2>>"$LOG"
  done
  echo done > $S/rootcopy.done
) &
CP=$!; rm -f $S/rootcopy.done
while [ ! -f $S/rootcopy.done ]; do
  USED=$(df -P -B1 $R | awk 'NR==2{print $3}'); P=$(( 8 + USED * 52 / TOT )); [ $P -gt 59 ] && P=59
  st run $P "Copying Cacti OS"; sleep 3
done
wait $CP
mkdir -p $R/proc $R/sys $R/dev $R/run $R/tmp $R/mnt $R/media $R/userdata $R/boot; chmod 1777 $R/tmp
[ -x $R/usr/bin/retro-os ] || [ -d $R/opt/retro-os ] || fail "The copy of Cacti OS is incomplete."
grep -v ' /userdata ' $R/etc/fstab > $R/etc/fstab.new
echo "PARTUUID=$PU3 /userdata ext4 defaults,noatime,nofail,x-systemd.device-timeout=10 0 2" >> $R/etc/fstab.new
mv -f $R/etc/fstab.new $R/etc/fstab
sync; umount $R

st run 61 "Making the games and settings partition"
mkfs.ext4 -F -q -L cactidata "$P3" >> "$LOG" 2>&1 || fail "Could not format the data partition."
mount "$P3" $U || fail "Could not open the new data partition."
if [ "$KEEP" = 1 ]; then
  TOT=$UDUSED; [ "$TOT" -gt 0 ] || TOT=1
  (
    for e in /userdata/* /userdata/.[!.]*; do
      [ -e "$e" ] || [ -L "$e" ] || continue
      case "$e" in /userdata/lost+found|/userdata/.rootreq*|/userdata/install.log) continue;; esac
      cp -a "$e" "$U/" 2>>"$LOG"
    done
    echo done > $S/datacopy.done
  ) &
  CP=$!; rm -f $S/datacopy.done
  while [ ! -f $S/datacopy.done ]; do
    USED=$(df -P -B1 $U | awk 'NR==2{print $3}'); P=$(( 61 + USED * 36 / TOT )); [ $P -gt 97 ] && P=97
    st run $P "Copying your games, saves and settings"; sleep 3
  done
  wait $CP
fi
st run 98 "Finishing"
sync; umount $U
st ok 100 "Cacti OS is installed."
exit 0
