#!/bin/sh
# Root helper for the Cacti OS app (which runs as the unprivileged user "retro"). The app drops one line into /userdata/.rootreq;
# systemd runs this script as root. Only the commands below are allowed, and every argument is checked.
REQ=/userdata/home/retro/.rootreq; RD=/run/retro-rootd; RES=$RD/res; mkdir -p $RD; chmod 755 $RD  # replies go to a folder only root can write to
[ -f "$REQ" ] && [ ! -L "$REQ" ] || { rm -f "$REQ"; exit 0; }
LINE=$(head -n1 "$REQ" | tr -cd "A-Za-z0-9 @._-"); rm -f "$REQ"
set -- $LINE
CMD=$1; A1=$2; A2=$3
LOGF=/userdata/rootd.log; [ "$(stat -c %s $LOGF 2>/dev/null || echo 0)" -gt 200000 ] && : > $LOGF
echo "$(date +%T) start $CMD $A1 $A2" >> $LOGF 2>/dev/null
done_() { echo "$(date +%T) $CMD $A1 $A2 => $(echo "$1" | cut -c1-200)" >> $LOGF 2>/dev/null; echo "$1" > "$RES.tmp"; chmod 644 "$RES.tmp"; mv -f "$RES.tmp" "$RES"; exit 0; }
bootdev() { R=$(findmnt -n -o SOURCE /); case "$R" in *p2) echo "${R%2}1";; *2) echo "${R%2}1";; *) echo "";; esac; }
case "$CMD" in
  share-on)  systemctl unmask smb nmb >/dev/null 2>&1; systemctl enable --now smb nmb >/dev/null 2>&1 && done_ "ok" || done_ "err Could not start the file sharing service";;
  share-off) systemctl disable --now smb nmb >/dev/null 2>&1; done_ "ok";;
  share-status) systemctl is-active --quiet smb && done_ "ok on" || done_ "ok off";;
  reboot)    done_ "ok"; systemctl reboot;;
  video)     # video <HDMI-A-1|DP-1|...> <WxH or WxH@R>
    echo "$A1" | grep -Eq '^[A-Za-z0-9-]+$' || done_ "err bad output"
    echo "$A2" | grep -Eq '^[0-9]{3,5}x[0-9]{3,5}(@[0-9]{1,3})?$' || done_ "err bad mode"
    D=$(bootdev); [ -b "$D" ] || done_ "err boot partition not found"
    M=/run/retro-boot; mkdir -p $M; mount "$D" $M 2>/dev/null || done_ "err could not open the boot partition"
    if [ -f "$M/cmdline.cfg" ]; then # PC image: the screen mode lives in a small GRUB file
      if [ "$A1" = all ]; then OUTS=$(ls /sys/class/drm 2>/dev/null | sed -n 's/^card[0-9]*-\([A-Za-z0-9-]*\)$/\1/p' | sort -u); [ -n "$OUTS" ] || OUTS="HDMI-A-1 HDMI-A-2 DP-1 DP-2 eDP-1"; else OUTS="$A1"; fi
      NEWV=""; for O in $OUTS; do NEWV="${NEWV}video=$O:$A2 "; done
      echo "set cacti_video=\"${NEWV% }\"" > "$M/cmdline.cfg"; sync; umount $M; done_ "ok"
    fi
    F=$M/cmdline.txt; [ -f "$F" ] || { umount $M; done_ "err cmdline.txt missing"; }
    [ -f "$F.cacti-bak" ] || cp "$F" "$F.cacti-bak"
    NEW=$(tr -d '\n' < "$F" | tr ' ' '\n' | grep -v "^video=$A1:" | tr '\n' ' ')
    echo "${NEW}video=$A1:$A2" > "$F"; sync; umount $M; done_ "ok";;
  video-reset) D=$(bootdev); [ -b "$D" ] || done_ "err boot partition not found"; M=/run/retro-boot; mkdir -p $M; mount "$D" $M && { [ -f $M/cmdline.cfg ] && echo 'set cacti_video=""' > $M/cmdline.cfg; [ -f $M/cmdline.txt.cacti-bak ] && cp $M/cmdline.txt.cacti-bak $M/cmdline.txt; sync; umount $M; }; done_ "ok";;
  bt)        # wake the Bluetooth adapter: unblock the radio, load the drivers, restart the service
    rfkill unblock bluetooth >/dev/null 2>&1; modprobe hci_uart >/dev/null 2>&1; modprobe btbcm >/dev/null 2>&1
    systemctl restart bluetooth >/dev/null 2>&1; sleep 2; done_ "ok";;
  ext-list|ext-mount|ext-mount-all|ext-umount) # other drives: USB sticks, external SSDs, extra disks (never the one Cacti OS runs from)
    R=$(findmnt -n -o SOURCE /); SRC=""; [ -b "$R" ] && SRC=$(basename "$(readlink -f "/sys/class/block/$(basename "$R")/..")")
    UIDR=$(id -u retro 2>/dev/null || echo 1000); GIDR=$(id -g retro 2>/dev/null || echo 1000)
    okdev() { echo "$1" | grep -Eq '^(sd[a-z]+[0-9]*|nvme[0-9]+n[0-9]+(p[0-9]+)?|mmcblk[0-9]+(p[0-9]+)?|vd[a-z]+[0-9]*)$' || return 1; [ -b "/dev/$1" ] || return 1
      P=$(readlink -f "/sys/class/block/$1"); [ -f "$P/partition" ] && D=$(basename "$(dirname "$P")") || D=$1; [ "$D" != "$SRC" ] || return 1
      [ -f "/sys/block/$D/size" ] || return 1; if [ ! -f "$P/partition" ]; then ls -d /sys/block/$D/$D*/ >/dev/null 2>&1 && return 1; fi; return 0; }
    fstype() { blkid -s TYPE -o value "/dev/$1" 2>/dev/null; }
    mnt() { # mnt <dev> : mount it (or report where it already is); prints the mount point
      M0=$(grep "^/dev/$1 " /proc/mounts | head -n1 | cut -d' ' -f2); [ -n "$M0" ] && { printf %s "$M0"; return 0; }
      T=$(fstype "$1"); L=$(blkid -s LABEL -o value "/dev/$1" 2>/dev/null | tr -d "\n\r" | tr -c 'A-Za-z0-9._-' '_' | cut -c1-32); [ -n "$L" ] || L="$1"
      MP=/run/media/retro/$L; [ -e "$MP" ] && grep -q " $MP " /proc/mounts && MP=/run/media/retro/$L-$1; mkdir -p "$MP"
      case "$T" in
        exfat) mount -t exfat -o uid=$UIDR,gid=$GIDR,umask=0002,noatime "/dev/$1" "$MP" 2>>$LOGF || mount -t exfat-fuse -o uid=$UIDR,gid=$GIDR,umask=0002 "/dev/$1" "$MP" 2>>$LOGF;;
        ntfs)  mount -t ntfs3 -o uid=$UIDR,gid=$GIDR,umask=0002,noatime "/dev/$1" "$MP" 2>>$LOGF || ntfs-3g -o uid=$UIDR,gid=$GIDR,umask=0002 "/dev/$1" "$MP" 2>>$LOGF;;
        vfat)  mount -t vfat -o uid=$UIDR,gid=$GIDR,umask=0002,iocharset=utf8,noatime "/dev/$1" "$MP" 2>>$LOGF;;
        ext2|ext3|ext4|btrfs|xfs) mount -o noatime "/dev/$1" "$MP" 2>>$LOGF && { [ "$(stat -c %u "$MP")" = "$UIDR" ] || chown $UIDR:$GIDR "$MP" 2>/dev/null; true; };;
        *) rmdir "$MP" 2>/dev/null; return 1;;
      esac || { rmdir "$MP" 2>/dev/null; return 1; }
      printf %s "$MP"; }
    case "$CMD" in
      ext-umount) okdev "$A1" || done_ "err That drive cannot be removed from here."
        for MP in $(grep "^/dev/$A1 " /proc/mounts | cut -d' ' -f2); do sync; umount "$MP" 2>/dev/null || done_ "err It is still in use. Close any games first."; rmdir "$MP" 2>/dev/null; done; done_ "ok";;
      ext-mount) okdev "$A1" || done_ "err That drive is not available."; MP=$(mnt "$A1") && [ -n "$MP" ] && done_ "ok $MP" || done_ "err Cacti OS cannot read that drive's format (it reads exFAT, NTFS, FAT32 and Linux ext4).";;
      ext-mount-all) for B in /sys/class/block/*; do N=${B##*/}; okdev "$N" || continue; mnt "$N" >/dev/null 2>&1; done; done_ "ok";;
      ext-list) OUT=""
        for B in /sys/class/block/*; do N=${B##*/}; okdev "$N" || continue; T=$(fstype "$N"); case "$T" in exfat|ntfs|vfat|ext2|ext3|ext4|btrfs|xfs) ;; *) continue;; esac
          SZ=$(( $(cat "$B/size") * 512 )); L=$(blkid -s LABEL -o value "/dev/$N" 2>/dev/null | tr -d "\n\r" | tr -c 'A-Za-z0-9._-' '_'); [ -n "$L" ] || L=Drive
          M0=$(grep "^/dev/$N " /proc/mounts | head -n1 | cut -d' ' -f2); FREE=0; [ -n "$M0" ] && FREE=$(df -P -B1 "$M0" | awk 'NR==2{print $4}')
          BUS=sata; case "$N" in nvme*) BUS=nvme;; mmcblk*) BUS=mmc;; *) readlink -f "$B" | grep -q /usb && BUS=usb;; esac
          OUT="$OUT;$N,$SZ,$L,$T,$BUS,${M0:--},$FREE"
        done; done_ "ok ${OUT#;}";;
    esac;;
  install-list) # PC image: the drives Cacti OS could be installed to (never the one it is running from). Reply: SRC=<this drive>;name,bytes,model,bus,removable,inuse,partitions,fits
    [ -f /usr/lib/retro-os/install.sh ] && [ "$(uname -m)" = x86_64 ] || done_ "err Installing to a drive is only available on the PC image."
    R=$(findmnt -n -o SOURCE /); [ -b "$R" ] || done_ "err Cacti OS is not running from a drive."
    SRC=$(basename "$(readlink -f "/sys/class/block/$(basename "$R")/..")"); NEED=$(( $(blockdev --getsize64 "$R") + 2415919104 ))
    OUT="SRC=$SRC"
    for B in /sys/block/*; do
      N=${B##*/}; case "$N" in loop*|ram*|zram*|sr*|fd*|dm-*|md*|nbd*) continue;; esac
      [ "$N" = "$SRC" ] && continue; [ -f "$B/size" ] || continue
      SZ=$(( $(cat "$B/size") * 512 )); [ "$SZ" -gt 0 ] || continue
      M=$(sed 's/ *$//' "$B/device/model" 2>/dev/null | tr -c 'A-Za-z0-9._-' '_'); [ -n "$M" ] || M=Drive
      BUS=sata; case "$N" in nvme*) BUS=nvme;; mmcblk*) BUS=mmc;; *) readlink -f "$B" | grep -q /usb && BUS=usb;; esac
      BUSY=0; grep -q "^/dev/$N" /proc/mounts && BUSY=1
      NP=$(ls -d "$B/$N"*/ 2>/dev/null | wc -l); FIT=0; [ "$SZ" -ge "$NEED" ] && FIT=1
      OUT="$OUT;$N,$SZ,$M,$BUS,$(cat "$B/removable" 2>/dev/null || echo 0),$BUSY,$NP,$FIT"
    done
    done_ "ok $OUT";;
  install-start) # install-start <drive> <1 = copy games and settings>
    [ -f /usr/lib/retro-os/install.sh ] && [ "$(uname -m)" = x86_64 ] || done_ "err Installing to a drive is only available on the PC image."
    echo "$A1" | grep -Eq '^(sd[a-z]+|nvme[0-9]+n[0-9]+|mmcblk[0-9]+|vd[a-z]+)$' || done_ "err bad drive"
    echo "$A2" | grep -Eq '^[01]$' || done_ "err bad option"
    [ -b "/dev/$A1" ] || done_ "err That drive is not there any more."
    systemctl is-active --quiet cacti-install && done_ "err An install is already running."
    rm -f /run/retro-install/status
    systemd-run --unit=cacti-install --collect --no-block /usr/lib/retro-os/install.sh "$A1" "$A2" >/dev/null 2>&1 && done_ "ok" || done_ "err Could not start the installer."
    ;;
  *) done_ "err unknown request";;
esac
