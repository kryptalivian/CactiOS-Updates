#!/bin/sh
set -eu
# Enable the Retro OS services and the userdata mount; no login prompt on the HDMI screen.
T="$TARGET_DIR"; W="$T/etc/systemd/system/multi-user.target.wants"
# The kit can arrive via a zip or a Windows drive, which drops the executable bit: put it back on every helper script.
chmod 0755 "$T"/usr/lib/retro-os/*.sh 2>/dev/null || true; chmod 0755 "$T"/usr/bin/retro-os 2>/dev/null || true
python3 "$(dirname "$0")/noexecstack.py" "$T/usr/lib/libretro" "$T/usr/bin" "$T/usr/lib" || true
mkdir -p "$W" "$T/userdata"
for s in seatd retro-os-firstboot retro-os retro-os-bootlog NetworkManager bluetooth cacti-zram; do
  for d in /etc/systemd/system /usr/lib/systemd/system /lib/systemd/system; do
    [ -f "$T$d/$s.service" ] && ln -sf "$d/$s.service" "$W/$s.service" && break
  done
done
ln -sf /usr/lib/systemd/system/retro-os-rootd.path "$W/retro-os-rootd.path"
ln -sf /dev/null "$T/etc/systemd/system/smb.service"; ln -sf /dev/null "$T/etc/systemd/system/nmb.service" # off until the user turns sharing on (the helper unmasks them)
ln -sf /dev/null "$T/etc/systemd/system/getty@tty1.service"
# Services that are not used here and only show up as failed: Samba AD, winbind, print queue, and the network wait (NetworkManager handles the network).
for u in samba winbind samba-bgqd systemd-networkd-wait-online; do ln -sf /dev/null "$T/etc/systemd/system/$u.service"; done
ln -sf /usr/lib/systemd/system/getty@.service "$W/getty@tty2.service"
grep -q userdata "$T/etc/fstab" || echo 'LABEL=userdata /userdata ext4 defaults,noatime,nofail,x-systemd.device-timeout=10 0 2' >> "$T/etc/fstab"
# RetroArch finds the cores and info files where Buildroot installs them; Retro OS looks in ~/.config/retroarch/cores.
mkdir -p "$T/etc/retroarch.d"
