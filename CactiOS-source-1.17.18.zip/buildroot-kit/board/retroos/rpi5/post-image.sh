#!/bin/bash
# Builds sdcard.img: boot (FAT) + rootfs (ext4) + userdata (ext4, grown to fill the card on first boot).
set -e
BOARD_DIR="$(dirname "$0")"
GENIMAGE_TMP="${BUILD_DIR}/genimage.tmp"
# userdata partition: small ext4 with the folder tree (Retro OS makes the rest on first boot)
UD="${BINARIES_DIR}/userdata.ext4"; rm -f "$UD"
SK="$(mktemp -d)"; mkdir -p "$SK/roms" "$SK/bios" "$SK/saves" "$SK/system" "$SK/home/retro"
"${HOST_DIR}/sbin/mke2fs" -t ext4 -L userdata -d "$SK" "$UD" 768M >/dev/null; rm -rf "$SK"
# boot files
FILES=()
for i in "${BINARIES_DIR}"/*.dtb "${BINARIES_DIR}"/rpi-firmware/*; do FILES+=( "${i#${BINARIES_DIR}/}" ); done
KERNEL=$(sed -n 's/^kernel=//p' "${BINARIES_DIR}/rpi-firmware/config.txt"); FILES+=( "${KERNEL}" )
BOOT_FILES=$(printf '\\t\\t\\t"%s",\\n' "${FILES[@]}")
sed "s|#BOOT_FILES#|${BOOT_FILES}|" "${BOARD_DIR}/genimage.cfg.in" > "${BINARIES_DIR}/genimage.cfg"
trap 'rm -rf "${ROOTPATH_TMP}"' EXIT; ROOTPATH_TMP="$(mktemp -d)"; rm -rf "${GENIMAGE_TMP}"
genimage --rootpath "${ROOTPATH_TMP}" --tmppath "${GENIMAGE_TMP}" --inputpath "${BINARIES_DIR}" --outputpath "${BINARIES_DIR}" --config "${BINARIES_DIR}/genimage.cfg"
xz -T0 -k -f "${BINARIES_DIR}/sdcard.img" || true
