#!/bin/sh
# Compressed swap in RAM so the 512 MB Zero 2 W has room for the front end and a game together.
modprobe zram num_devices=1 2>/dev/null
[ -e /sys/block/zram0/disksize ] || exit 0
echo zstd > /sys/block/zram0/comp_algorithm 2>/dev/null || echo lzo > /sys/block/zram0/comp_algorithm 2>/dev/null
echo 512M > /sys/block/zram0/disksize
mkswap /dev/zram0 >/dev/null && swapon -p 100 /dev/zram0
sysctl -w vm.swappiness=150 vm.vfs_cache_pressure=200 >/dev/null 2>&1
exit 0
