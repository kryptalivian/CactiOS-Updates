#!/bin/bash
# Builds sdcard.img for PCs (UEFI): boot (FAT) + rootfs (ext4) + userdata (ext4, grown to fill the disk on first boot).
set -e
BOARD_DIR="$(dirname "$0")"
GENIMAGE_TMP="${BUILD_DIR}/genimage.tmp"
UD="${BINARIES_DIR}/userdata.ext4"; rm -f "$UD"
SK="$(mktemp -d)"; mkdir -p "$SK/roms" "$SK/bios" "$SK/saves" "$SK/system" "$SK/home/retro"
"${HOST_DIR}/sbin/mke2fs" -t ext4 -L userdata -d "$SK" "$UD" 768M >/dev/null; rm -rf "$SK"
# GRUB (installed by Buildroot into efi-part/EFI/BOOT) gets our menu; cmdline.cfg starts empty
cp -f "${BOARD_DIR}/grub.cfg" "${BINARIES_DIR}/efi-part/EFI/BOOT/grub.cfg"
echo 'set cacti_video=""' > "${BINARIES_DIR}/cmdline.cfg"
cp -f "${BOARD_DIR}/genimage.cfg" "${BINARIES_DIR}/genimage.cfg"
trap 'rm -rf "${ROOTPATH_TMP}"' EXIT; ROOTPATH_TMP="$(mktemp -d)"; rm -rf "${GENIMAGE_TMP}"
genimage --rootpath "${ROOTPATH_TMP}" --tmppath "${GENIMAGE_TMP}" --inputpath "${BINARIES_DIR}" --outputpath "${BINARIES_DIR}" --config "${BINARIES_DIR}/genimage.cfg"
xz -T0 -k -f "${BINARIES_DIR}/sdcard.img" || true
