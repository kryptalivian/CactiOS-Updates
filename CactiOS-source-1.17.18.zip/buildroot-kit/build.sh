#!/usr/bin/env bash
# Builds a Cacti OS image with Buildroot. Run on Ubuntu/Debian (or WSL2 Ubuntu), as a normal user.
#   ./build.sh [rpi5|zero2w|x86_64] [menuconfig]
#     rpi5     Raspberry Pi 5 (default)
#     zero2w   Raspberry Pi Zero 2 W (512 MB: lighter set of emulators)
#     x86_64   PCs and laptops with UEFI (Intel, AMD, NVIDIA open driver); builds LLVM for Mesa, so allow extra time
#   First run: 2-8 hours depending on CPU, needs ~100 GB free.   ./build.sh x86_64 menuconfig  changes the selection of emulators, then builds.
# Output: out/images/sdcard.img and sdcard.img.xz (flash with Raspberry Pi Imager "Use custom", balenaEtcher or dd; for a PC write it to a USB stick or SSD).
set -euo pipefail
KIT="$(cd "$(dirname "$0")" && pwd)"
BR_VER="${BR_VER:-2026.02.3}"
TARGET=rpi5
case "${1:-}" in rpi5|zero2w|x86_64) TARGET="$1"; shift;; pc|x86|x64) TARGET=x86_64; shift;; esac
case "$TARGET" in rpi5) DEFCONFIG=retroos_rpi5_defconfig; SUFFIX="";; zero2w) DEFCONFIG=retroos_rpizero2w_defconfig; SUFFIX="-zero2w";; x86_64) DEFCONFIG=retroos_x86_64_defconfig; SUFFIX="-x86_64";; esac
WORK="${WORK:-$HOME/retroos-build$SUFFIX}"
echo "Cacti OS image for: $TARGET   (work folder: $WORK)"
JOBS="${JOBS:-$(nproc)}"
# WSL puts Windows folders ("Program Files") on PATH; Buildroot refuses a PATH containing spaces. Keep only clean entries.
PATH="$(printf %s "$PATH" | tr : "\n" | grep -v "[[:space:]]" | grep -v "^/mnt/" | paste -sd: -)"; export PATH

case "$KIT" in /mnt/*) echo "Copying the kit into the Linux filesystem first (builds fail on /mnt/c)…"; mkdir -p "$WORK"; rsync -a --delete "$KIT/" "$WORK/kit/"; KIT="$WORK/kit";; esac

if ! command -v make >/dev/null || ! command -v git >/dev/null || ! command -v rsync >/dev/null || ! command -v cpio >/dev/null; then
  echo "Installing build tools (needs sudo)…"
  sudo apt-get update
  sudo apt-get install -y build-essential git wget curl cpio unzip rsync bc file python3 perl libncurses-dev libssl-dev \
    libelf-dev flex bison gawk patch diffutils findutils tar gzip bzip2 xz-utils ca-certificates device-tree-compiler
fi

mkdir -p "$WORK"; cd "$WORK"
[ -d buildroot ] || git clone --depth 1 --branch "$BR_VER" https://github.com/buildroot/buildroot.git
export BR2_EXTERNAL="$KIT"
make -C buildroot O="$WORK/out" "$DEFCONFIG"
if [ "${1:-}" = menuconfig ]; then make -C "$WORK/out" menuconfig; fi
# Keep going past a single failing emulator so one broken core cannot waste hours of build time; failures are listed at the end.
cd "$WORK/out"
# The Cacti OS app is a local package: Buildroot does not notice edits to it by itself, so always re-install it. This takes seconds.
make retro-os-dirclean >/dev/null 2>&1 || true
# The boot files (cmdline.txt, config.txt) are copied into the image when rpi-firmware installs; edits to them are not noticed by Buildroot.
[ "$TARGET" != x86_64 ] && { make rpi-firmware-dirclean >/dev/null 2>&1 || true; }
# Objects left over from an earlier failed run were built with different flags; drop every libretro/retroarch package that never finished installing.
for d in "$WORK"/out/build/libretro-*/ "$WORK"/out/build/retroarch-*/ "$WORK"/out/build/ppsspp-*/ "$WORK"/out/build/dolphin-emu-*/; do
  [ -d "$d" ] && [ ! -f "$d/.stamp_target_installed" ] && rm -rf "$d"
done
set +e
make -k -j"$JOBS" 2>&1 | tee "$WORK/build.log"
RC=${PIPESTATUS[0]}
set -e
if [ "$RC" != 0 ]; then
  echo; echo "Some packages failed. Failed packages:"; grep -E "^make.*\*\*\* .*(/build/|\.stamp_built|\.stamp_)" "$WORK/build.log" | sed -E 's/.*build\/([^/]+)\/.*/  \1/' | sort -u
  if [ -n "${COPY_TO:-}" ]; then
    mkdir -p "$COPY_TO"; : > "$COPY_TO/build-errors.txt"
    # Re-run each failed package alone so its error is not mixed with other output.
    for f in $(grep -E "^make.*\*\*\* .*(/build/|\.stamp_)" "$WORK/build.log" | sed -E 's/.*build\/([^/]+)\/.*/\1/' | sort -u); do
      n="$(printf %s "$f" | sed -E 's/-([0-9a-f]{40}|v?[0-9][0-9.]*)$//')"
      { echo; echo "########## FAILED: $f   (package $n)"; make -C "$WORK/out" -j1 "$n" 2>&1 | tail -70 | cut -c1-300; } >> "$COPY_TO/build-errors.txt"
    done
    echo "Error excerpts saved to $COPY_TO/build-errors.txt"
  fi
  echo "Re-run ./build.sh after fixing (or untick the package with ./build.sh menuconfig). Full log: $WORK/build.log"
  [ -f images/sdcard.img ] || exit "$RC"
fi
# Always leave a short report plus the full log next to the image, so it can be sent for a check even when the build "succeeded".
if [ -n "${COPY_TO:-}" ]; then
  mkdir -p "$COPY_TO"
  {
    echo "Cacti OS image build report  $(date)   target: $TARGET"
    echo "make exit code: $RC   (0 = every package built)"
    echo "Image: $(ls -lh "$WORK/out/images/sdcard.img" 2>/dev/null | awk '{print $5}')"
    echo "Packages built: $(ls "$WORK"/out/build/*/.stamp_target_installed 2>/dev/null | wc -l)"
    echo "Cacti OS app version: $(sed -n 's/.*"version":"\([0-9.]*\)".*/\1/p' "$KIT/app/package.json")"
    echo; echo "== Checks on what went into the image (the first thing to look at)"
    echo "sdcard.img written:  $(stat -c %y "$WORK/out/images/sdcard.img" 2>/dev/null)"
    echo "boot cmdline:        $(cat "$WORK/out/images/rpi-firmware/cmdline.txt" "$WORK/out/images/efi-part/EFI/BOOT/grub.cfg" 2>/dev/null | tr "\n" " " | cut -c1-300)"
    echo "app in image:        $(sed -n 's/.*"version":"\([0-9.]*\)".*/\1/p' "$WORK/out/target/opt/retro-os/app/package.json" 2>/dev/null)"
    echo "kernel:              $(ls "$WORK/out/images/Image" "$WORK/out/images/bzImage" 2>/dev/null)"
    echo "keyboard data (xkb): $(ls "$WORK/out/target/usr/share/X11/xkb" 2>/dev/null | wc -l) entries in /usr/share/X11/xkb  (0 = missing)"
    echo "launch.sh XKB line:  $(grep -c XKB_DEFAULT_LAYOUT "$WORK/out/target/usr/bin/retro-os" 2>/dev/null)  (1 = new launcher)"
    echo "bootlog helper:      $(ls "$WORK/out/target/usr/lib/retro-os/bootlog.sh" 2>/dev/null)"
    echo "electron:            $(ls -la "$WORK/out/target/opt/retro-os/electron/electron" 2>/dev/null | awk '{print $5" bytes"}')"
    echo "samba AD masked:     $(readlink "$WORK/out/target/etc/systemd/system/samba.service" 2>/dev/null)"
    echo; echo "== Real errors only (first 60)"
    grep -n -E "^make.*\*\*\*|ERROR|error:|fatal error|undefined reference|No hash|No such file" "$WORK/build.log" | grep -v -E "Werror|xkbcommon: ERROR" | head -60 | cut -c1-260
    echo; echo "== Last 40 lines of the build"; tail -40 "$WORK/build.log" | cut -c1-260
  } > "$COPY_TO/build-report.txt"
  gzip -c "$WORK/build.log" > "$COPY_TO/build.log.gz"
  echo "Build report saved to $COPY_TO/build-report.txt (full log: build.log.gz)"
fi
echo; echo "Image: $WORK/out/images/sdcard.img  (and .xz)"
if [ -n "${COPY_TO:-}" ]; then mkdir -p "$COPY_TO"; cp -f images/sdcard.img.xz images/sdcard.img "$COPY_TO"/ 2>/dev/null && echo "Copied to $COPY_TO"; fi
