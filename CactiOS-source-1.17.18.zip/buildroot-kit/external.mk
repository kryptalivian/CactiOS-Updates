include $(sort $(wildcard $(BR2_EXTERNAL_RETROOS_PATH)/package/*/*.mk))
