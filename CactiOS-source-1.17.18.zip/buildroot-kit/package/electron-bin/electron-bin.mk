ELECTRON_BIN_VERSION = 33.4.11
ELECTRON_BIN_ARCH = $(if $(BR2_x86_64),x64,arm64)
ELECTRON_BIN_SOURCE = electron-v$(ELECTRON_BIN_VERSION)-linux-$(ELECTRON_BIN_ARCH).zip
ELECTRON_BIN_SITE = https://github.com/electron/electron/releases/download/v$(ELECTRON_BIN_VERSION)
ELECTRON_BIN_LICENSE = MIT

# The zip has no top-level folder, so unpack it straight into the build directory.
define ELECTRON_BIN_EXTRACT_CMDS
	unzip -q -o $(ELECTRON_BIN_DL_DIR)/$(ELECTRON_BIN_SOURCE) -d $(@D)
endef

$(eval $(generic-package))
