################################################################################
#
# libretro-2048
#
################################################################################

LIBRETRO_2048_VERSION = 39333f7b13dc4daea7c151d9c38d22b961246343
LIBRETRO_2048_SITE = $(call github,libretro,libretro-2048,$(LIBRETRO_2048_VERSION))
LIBRETRO_2048_LICENSE = GPL-2.0

define LIBRETRO_2048_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile.libretro platform=unix 
endef

define LIBRETRO_2048_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/2048_libretro.so $(TARGET_DIR)/usr/lib/libretro/2048_libretro.so
endef

$(eval $(generic-package))
