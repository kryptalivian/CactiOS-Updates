################################################################################
#
# libretro-81
#
################################################################################

LIBRETRO_81_VERSION = fa7094910d040baa5fd8b11dbf6a1a618330ecd9
LIBRETRO_81_SITE = $(call github,libretro,81-libretro,$(LIBRETRO_81_VERSION))
LIBRETRO_81_LICENSE = GPL-2.0

define LIBRETRO_81_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile.libretro platform=unix 
endef

define LIBRETRO_81_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/81_libretro.so $(TARGET_DIR)/usr/lib/libretro/81_libretro.so
endef

$(eval $(generic-package))
