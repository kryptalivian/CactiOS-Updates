################################################################################
#
# libretro-cannonball
#
################################################################################

LIBRETRO_CANNONBALL_VERSION = 0d83575d920ea4c0a280847a19d7802f673e6a68
LIBRETRO_CANNONBALL_SITE = $(call github,libretro,cannonball,$(LIBRETRO_CANNONBALL_VERSION))
LIBRETRO_CANNONBALL_LICENSE = GPL-2.0

define LIBRETRO_CANNONBALL_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix 
endef

define LIBRETRO_CANNONBALL_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/cannonball_libretro.so $(TARGET_DIR)/usr/lib/libretro/cannonball_libretro.so
endef

$(eval $(generic-package))
