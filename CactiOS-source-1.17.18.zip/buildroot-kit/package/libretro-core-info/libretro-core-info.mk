LIBRETRO_CORE_INFO_VERSION = 445421549abc0638a2f5ecf05db8437e580dcc69
LIBRETRO_CORE_INFO_SITE = $(call github,libretro,libretro-core-info,$(LIBRETRO_CORE_INFO_VERSION))
LIBRETRO_CORE_INFO_LICENSE = MIT

define LIBRETRO_CORE_INFO_INSTALL_TARGET_CMDS
	mkdir -p $(TARGET_DIR)/usr/share/libretro/info
	cp -f $(@D)/*.info $(TARGET_DIR)/usr/share/libretro/info/
endef

$(eval $(generic-package))
