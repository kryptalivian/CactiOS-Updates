################################################################################
#
# libretro-desmume
#
################################################################################

LIBRETRO_DESMUME_VERSION = 95b4d798731caa809125b6c3c11d17cc332ff6ef
LIBRETRO_DESMUME_SITE = $(call github,libretro,desmume,$(LIBRETRO_DESMUME_VERSION))
LIBRETRO_DESMUME_LICENSE = GPL-2.0
LIBRETRO_DESMUME_DEPENDENCIES = libpcap $(if $(BR2_x86_64),libgl)

define LIBRETRO_DESMUME_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/desmume/src/frontend/libretro -f Makefile.libretro platform=unix 
endef

define LIBRETRO_DESMUME_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $$(find $(@D) -name desmume_libretro.so -type f | head -1) $(TARGET_DIR)/usr/lib/libretro/desmume_libretro.so
endef

$(eval $(generic-package))
