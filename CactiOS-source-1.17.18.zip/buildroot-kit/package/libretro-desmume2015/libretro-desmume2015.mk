################################################################################
#
# libretro-desmume2015
#
################################################################################

LIBRETRO_DESMUME2015_VERSION = 422b688009ccb9f2917c086a8fe79c8cecb030ae
LIBRETRO_DESMUME2015_SITE = $(call github,libretro,desmume2015,$(LIBRETRO_DESMUME2015_VERSION))
LIBRETRO_DESMUME2015_LICENSE = GPL-2.0

define LIBRETRO_DESMUME2015_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/desmume -f Makefile.libretro platform=unix 
endef

define LIBRETRO_DESMUME2015_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $$(find $(@D) -name desmume2015_libretro.so -type f | head -1) $(TARGET_DIR)/usr/lib/libretro/desmume2015_libretro.so
endef

$(eval $(generic-package))
