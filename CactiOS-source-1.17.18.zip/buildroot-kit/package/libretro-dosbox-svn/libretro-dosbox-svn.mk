################################################################################
#
# libretro-dosbox-svn
#
################################################################################

LIBRETRO_DOSBOX_SVN_VERSION = 46a3164fc0f1e808ae56143d81698b00fb6b4781
LIBRETRO_DOSBOX_SVN_SITE = https://github.com/libretro/dosbox-svn.git
LIBRETRO_DOSBOX_SVN_SITE_METHOD = git
LIBRETRO_DOSBOX_SVN_GIT_SUBMODULES = YES
LIBRETRO_DOSBOX_SVN_LICENSE = GPL-2.0

define LIBRETRO_DOSBOX_SVN_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/libretro -f Makefile.libretro platform=unix 
endef

define LIBRETRO_DOSBOX_SVN_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/libretro/dosbox_svn_libretro.so $(TARGET_DIR)/usr/lib/libretro/dosbox_svn_libretro.so
endef

$(eval $(generic-package))
