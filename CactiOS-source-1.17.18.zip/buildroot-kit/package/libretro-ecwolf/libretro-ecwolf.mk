################################################################################
#
# libretro-ecwolf
#
################################################################################

LIBRETRO_ECWOLF_VERSION = 0cccd9a85d7ffa33fb695691a8a5db246606518c
LIBRETRO_ECWOLF_SITE = https://github.com/libretro/ecwolf.git
LIBRETRO_ECWOLF_SITE_METHOD = git
LIBRETRO_ECWOLF_GIT_SUBMODULES = YES
LIBRETRO_ECWOLF_LICENSE = GPL-2.0

define LIBRETRO_ECWOLF_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/src/libretro -f Makefile platform=unix 
endef

define LIBRETRO_ECWOLF_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $$(find $(@D) -name ecwolf_libretro.so -type f | head -1) $(TARGET_DIR)/usr/lib/libretro/ecwolf_libretro.so
endef

$(eval $(generic-package))
