################################################################################
#
# libretro-flycast
#
################################################################################

LIBRETRO_FLYCAST_VERSION = 6f315dd55a66cb2299dd2282b24d2fd84fe7f390
LIBRETRO_FLYCAST_SITE = https://github.com/libretro/flycast.git
LIBRETRO_FLYCAST_SITE_METHOD = git
LIBRETRO_FLYCAST_GIT_SUBMODULES = YES
LIBRETRO_FLYCAST_LICENSE = GPL-2.0

define LIBRETRO_FLYCAST_GLES3
	sed -i 's/-DHAVE_OPENGLES -DHAVE_OPENGLES2/-DHAVE_OPENGLES -DHAVE_OPENGLES2 -DHAVE_OPENGLES3/' $(@D)/Makefile
endef
LIBRETRO_FLYCAST_PRE_BUILD_HOOKS += LIBRETRO_FLYCAST_GLES3

define LIBRETRO_FLYCAST_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AS="$(TARGET_CROSS)as" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=$(if $(BR2_aarch64),rpi4_64,unix) HAVE_OPENMP=0 FORCE_GLES=1
endef

define LIBRETRO_FLYCAST_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $$(find $(@D) -maxdepth 1 -name "*_libretro.so" -type f | head -1) $(TARGET_DIR)/usr/lib/libretro/flycast_libretro.so
endef

$(eval $(generic-package))
