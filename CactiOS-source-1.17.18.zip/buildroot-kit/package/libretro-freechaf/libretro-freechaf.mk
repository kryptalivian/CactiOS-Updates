################################################################################
#
# libretro-freechaf
#
################################################################################

LIBRETRO_FREECHAF_VERSION = 76c7a84f1f7e80f3e6f2bba96fe100cb24e99124
LIBRETRO_FREECHAF_SITE = https://github.com/libretro/freechaf.git
LIBRETRO_FREECHAF_SITE_METHOD = git
LIBRETRO_FREECHAF_GIT_SUBMODULES = YES
LIBRETRO_FREECHAF_LICENSE = GPL-2.0

define LIBRETRO_FREECHAF_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix 
endef

define LIBRETRO_FREECHAF_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/freechaf_libretro.so $(TARGET_DIR)/usr/lib/libretro/freechaf_libretro.so
endef

$(eval $(generic-package))
