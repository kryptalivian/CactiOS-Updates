################################################################################
#
# libretro-gearlynx
#
################################################################################

LIBRETRO_GEARLYNX_VERSION = 94068da354f268cbc060f9fe0b1d3b2228952552
LIBRETRO_GEARLYNX_SITE = $(call github,drhelius,Gearlynx,$(LIBRETRO_GEARLYNX_VERSION))
LIBRETRO_GEARLYNX_LICENSE = GPL-2.0

define LIBRETRO_GEARLYNX_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/platforms/libretro -f Makefile platform=unix 
endef

define LIBRETRO_GEARLYNX_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/platforms/libretro/gearlynx_libretro.so $(TARGET_DIR)/usr/lib/libretro/gearlynx_libretro.so
endef

$(eval $(generic-package))
