################################################################################
#
# libretro-mame2003
#
################################################################################

LIBRETRO_MAME2003_VERSION = b9ac708f922386a0ae1f2379dbb31b60d7ec7b25
LIBRETRO_MAME2003_SITE = $(call github,libretro,mame2003-libretro,$(LIBRETRO_MAME2003_VERSION))
LIBRETRO_MAME2003_LICENSE = GPL-2.0

define LIBRETRO_MAME2003_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix 
endef

define LIBRETRO_MAME2003_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/mame2003_libretro.so $(TARGET_DIR)/usr/lib/libretro/mame2003_libretro.so
endef

$(eval $(generic-package))
