################################################################################
#
# libretro-mame2010
#
################################################################################

LIBRETRO_MAME2010_VERSION = dff8aadd1c3f38215af3955746d6e19abe0ddcea
LIBRETRO_MAME2010_SITE = $(call github,libretro,mame2010-libretro,$(LIBRETRO_MAME2010_VERSION))
LIBRETRO_MAME2010_LICENSE = GPL-2.0

define LIBRETRO_MAME2010_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix VRENDER=soft PTR64=1
endef

define LIBRETRO_MAME2010_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/mame2010_libretro.so $(TARGET_DIR)/usr/lib/libretro/mame2010_libretro.so
endef

$(eval $(generic-package))
