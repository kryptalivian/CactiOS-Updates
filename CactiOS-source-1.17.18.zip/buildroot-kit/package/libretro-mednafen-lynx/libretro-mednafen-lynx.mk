################################################################################
#
# libretro-mednafen-lynx
#
################################################################################

LIBRETRO_MEDNAFEN_LYNX_VERSION = fcdefcfb3c11d6d2e71be076a5d3df2e88ab73ed
LIBRETRO_MEDNAFEN_LYNX_SITE = $(call github,libretro,beetle-lynx-libretro,$(LIBRETRO_MEDNAFEN_LYNX_VERSION))
LIBRETRO_MEDNAFEN_LYNX_LICENSE = GPL-2.0

define LIBRETRO_MEDNAFEN_LYNX_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix 
endef

define LIBRETRO_MEDNAFEN_LYNX_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/mednafen_lynx_libretro.so $(TARGET_DIR)/usr/lib/libretro/mednafen_lynx_libretro.so
endef

$(eval $(generic-package))
