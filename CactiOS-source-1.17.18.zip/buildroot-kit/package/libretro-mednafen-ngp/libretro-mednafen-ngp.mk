################################################################################
#
# libretro-mednafen-ngp  (Neo Geo Pocket)
#
################################################################################

LIBRETRO_MEDNAFEN_NGP_VERSION = a50d5ac288a81f2104ddf43195a4efdd15c72227
LIBRETRO_MEDNAFEN_NGP_SITE = $(call github,libretro,beetle-ngp-libretro,$(LIBRETRO_MEDNAFEN_NGP_VERSION))
LIBRETRO_MEDNAFEN_NGP_LICENSE = GPL-2.0

define LIBRETRO_MEDNAFEN_NGP_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix
endef

define LIBRETRO_MEDNAFEN_NGP_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/./mednafen_ngp_libretro.so $(TARGET_DIR)/usr/lib/libretro/mednafen_ngp_libretro.so
endef

$(eval $(generic-package))
