################################################################################
#
# libretro-mednafen-pce-fast  (PC Engine / TurboGrafx-16)
#
################################################################################

LIBRETRO_MEDNAFEN_PCE_FAST_VERSION = 2de1ce1c3f237b161c126c54ba407990bb86d1e9
LIBRETRO_MEDNAFEN_PCE_FAST_SITE = $(call github,libretro,beetle-pce-fast-libretro,$(LIBRETRO_MEDNAFEN_PCE_FAST_VERSION))
LIBRETRO_MEDNAFEN_PCE_FAST_LICENSE = GPL-2.0

define LIBRETRO_MEDNAFEN_PCE_FAST_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix
endef

define LIBRETRO_MEDNAFEN_PCE_FAST_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/./mednafen_pce_fast_libretro.so $(TARGET_DIR)/usr/lib/libretro/mednafen_pce_fast_libretro.so
endef

$(eval $(generic-package))
