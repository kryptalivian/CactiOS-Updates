################################################################################
#
# libretro-mednafen-pce
#
################################################################################

LIBRETRO_MEDNAFEN_PCE_VERSION = b96c11e095b6a40a412d2da02766ae1c3f4fd539
LIBRETRO_MEDNAFEN_PCE_SITE = $(call github,libretro,beetle-pce-libretro,$(LIBRETRO_MEDNAFEN_PCE_VERSION))
LIBRETRO_MEDNAFEN_PCE_LICENSE = GPL-2.0

define LIBRETRO_MEDNAFEN_PCE_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix 
endef

define LIBRETRO_MEDNAFEN_PCE_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/mednafen_pce_libretro.so $(TARGET_DIR)/usr/lib/libretro/mednafen_pce_libretro.so
endef

$(eval $(generic-package))
