################################################################################
#
# libretro-mednafen-pcfx
#
################################################################################

LIBRETRO_MEDNAFEN_PCFX_VERSION = c1650bad5fbdcc3c3ccd45e29e3983e1ccf16cff
LIBRETRO_MEDNAFEN_PCFX_SITE = $(call github,libretro,beetle-pcfx-libretro,$(LIBRETRO_MEDNAFEN_PCFX_VERSION))
LIBRETRO_MEDNAFEN_PCFX_LICENSE = GPL-2.0

define LIBRETRO_MEDNAFEN_PCFX_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix 
endef

define LIBRETRO_MEDNAFEN_PCFX_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/mednafen_pcfx_libretro.so $(TARGET_DIR)/usr/lib/libretro/mednafen_pcfx_libretro.so
endef

$(eval $(generic-package))
