################################################################################
#
# libretro-mednafen-psx
#
################################################################################

LIBRETRO_MEDNAFEN_PSX_VERSION = 71ee81e77acd49296ecf4a683f5a61568ba80bf9
LIBRETRO_MEDNAFEN_PSX_SITE = $(call github,libretro,beetle-psx-libretro,$(LIBRETRO_MEDNAFEN_PSX_VERSION))
LIBRETRO_MEDNAFEN_PSX_LICENSE = GPL-2.0

define LIBRETRO_MEDNAFEN_PSX_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix 
endef

define LIBRETRO_MEDNAFEN_PSX_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/mednafen_psx_libretro.so $(TARGET_DIR)/usr/lib/libretro/mednafen_psx_libretro.so
endef

$(eval $(generic-package))
