################################################################################
#
# libretro-mednafen-saturn
#
################################################################################

LIBRETRO_MEDNAFEN_SATURN_VERSION = 30f4c12072d265c9e553dcb29386059114945dea
LIBRETRO_MEDNAFEN_SATURN_SITE = $(call github,libretro,beetle-saturn-libretro,$(LIBRETRO_MEDNAFEN_SATURN_VERSION))
LIBRETRO_MEDNAFEN_SATURN_LICENSE = GPL-2.0

define LIBRETRO_MEDNAFEN_SATURN_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix 
endef

define LIBRETRO_MEDNAFEN_SATURN_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/mednafen_saturn_libretro.so $(TARGET_DIR)/usr/lib/libretro/mednafen_saturn_libretro.so
endef

$(eval $(generic-package))
