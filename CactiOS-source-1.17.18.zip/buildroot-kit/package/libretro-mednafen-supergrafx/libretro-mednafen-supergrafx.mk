################################################################################
#
# libretro-mednafen-supergrafx
#
################################################################################

LIBRETRO_MEDNAFEN_SUPERGRAFX_VERSION = 9c11dcd213a79d57d2c86313971631af801f2cdc
LIBRETRO_MEDNAFEN_SUPERGRAFX_SITE = $(call github,libretro,beetle-supergrafx-libretro,$(LIBRETRO_MEDNAFEN_SUPERGRAFX_VERSION))
LIBRETRO_MEDNAFEN_SUPERGRAFX_LICENSE = GPL-2.0

define LIBRETRO_MEDNAFEN_SUPERGRAFX_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix 
endef

define LIBRETRO_MEDNAFEN_SUPERGRAFX_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/mednafen_supergrafx_libretro.so $(TARGET_DIR)/usr/lib/libretro/mednafen_supergrafx_libretro.so
endef

$(eval $(generic-package))
