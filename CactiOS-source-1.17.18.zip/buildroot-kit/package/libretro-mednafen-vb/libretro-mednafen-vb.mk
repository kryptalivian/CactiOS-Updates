################################################################################
#
# libretro-mednafen-vb  (Virtual Boy)
#
################################################################################

LIBRETRO_MEDNAFEN_VB_VERSION = d5ae54c8e23b573a3b34e888b2d48a588027e92c
LIBRETRO_MEDNAFEN_VB_SITE = $(call github,libretro,beetle-vb-libretro,$(LIBRETRO_MEDNAFEN_VB_VERSION))
LIBRETRO_MEDNAFEN_VB_LICENSE = GPL-2.0

define LIBRETRO_MEDNAFEN_VB_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix
endef

define LIBRETRO_MEDNAFEN_VB_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/./mednafen_vb_libretro.so $(TARGET_DIR)/usr/lib/libretro/mednafen_vb_libretro.so
endef

$(eval $(generic-package))
