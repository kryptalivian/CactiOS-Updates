################################################################################
#
# libretro-mednafen-wswan  (WonderSwan)
#
################################################################################

LIBRETRO_MEDNAFEN_WSWAN_VERSION = 4b01295838ea89e3f1355bbe4cb5cf98aa6108cd
LIBRETRO_MEDNAFEN_WSWAN_SITE = $(call github,libretro,beetle-wswan-libretro,$(LIBRETRO_MEDNAFEN_WSWAN_VERSION))
LIBRETRO_MEDNAFEN_WSWAN_LICENSE = GPL-2.0

define LIBRETRO_MEDNAFEN_WSWAN_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix
endef

define LIBRETRO_MEDNAFEN_WSWAN_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/./mednafen_wswan_libretro.so $(TARGET_DIR)/usr/lib/libretro/mednafen_wswan_libretro.so
endef

$(eval $(generic-package))
