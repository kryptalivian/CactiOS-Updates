################################################################################
#
# libretro-melonds  (Nintendo DS)
#
################################################################################

LIBRETRO_MELONDS_VERSION = 66b5d2634cd0a79030562811e6e05f5532f800ba
LIBRETRO_MELONDS_SITE = https://github.com/libretro/melonDS.git
LIBRETRO_MELONDS_SITE_METHOD = git
LIBRETRO_MELONDS_GIT_SUBMODULES = YES
LIBRETRO_MELONDS_LICENSE = GPL-3.0

# The PC image has no desktop OpenGL library: build the software renderer and do not link -lGL.
ifeq ($(BR2_x86_64),y)
define LIBRETRO_MELONDS_NO_DESKTOP_GL
	sed -i 's/-lGL[[:space:]]*$$//' $(@D)/Makefile
endef
LIBRETRO_MELONDS_PRE_BUILD_HOOKS += LIBRETRO_MELONDS_NO_DESKTOP_GL
endif

define LIBRETRO_MELONDS_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix ARCH=$(if $(BR2_x86_64),x86_64,arm64) $(if $(BR2_x86_64),HAVE_OPENGL=0)
endef

define LIBRETRO_MELONDS_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/./melonds_libretro.so $(TARGET_DIR)/usr/lib/libretro/melonds_libretro.so
endef

$(eval $(generic-package))
