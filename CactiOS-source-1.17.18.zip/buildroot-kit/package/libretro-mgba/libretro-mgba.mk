################################################################################
#
# libretro-mgba  (Game Boy Advance) - upstream builds the libretro core with CMake
#
################################################################################

LIBRETRO_MGBA_VERSION = 649314925ab32193bbf65a52ef9fae87fbaccb47
LIBRETRO_MGBA_SITE = $(call github,mgba-emu,mgba,$(LIBRETRO_MGBA_VERSION))
LIBRETRO_MGBA_LICENSE = MPL-2.0
LIBRETRO_MGBA_DEPENDENCIES = zlib libpng
LIBRETRO_MGBA_CONF_OPTS = -DBUILD_LIBRETRO=ON -DBUILD_SHARED=OFF -DBUILD_STATIC=OFF -DBUILD_QT=OFF -DBUILD_SDL=OFF \
	-DBUILD_GL=OFF -DBUILD_GLES2=OFF -DBUILD_GLES3=OFF -DBUILD_TEST=OFF -DBUILD_EXAMPLE=OFF -DUSE_DISCORD_RPC=OFF \
	-DUSE_LIBZIP=OFF -DUSE_MINIZIP=ON -DUSE_SQLITE3=OFF -DUSE_FFMPEG=OFF -DUSE_EPOXY=OFF -DUSE_EDITLINE=OFF \
	-DUSE_LUA=OFF -DUSE_ELF=OFF -DUSE_DEBUGGERS=OFF -DSKIP_LIBRARY=OFF -DCMAKE_BUILD_TYPE=Release

define LIBRETRO_MGBA_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $$(find $(@D) -name mgba_libretro.so | head -n1) $(TARGET_DIR)/usr/lib/libretro/mgba_libretro.so
endef

$(eval $(cmake-package))
