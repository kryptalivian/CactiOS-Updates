################################################################################
#
# libretro-np2kai
#
################################################################################

LIBRETRO_NP2KAI_VERSION = 5939e0c6d5985c4c08fc70f289a83290e5d3e6f7
LIBRETRO_NP2KAI_SITE = https://github.com/AZO234/NP2kai.git
LIBRETRO_NP2KAI_SITE_METHOD = git
LIBRETRO_NP2KAI_GIT_SUBMODULES = YES
LIBRETRO_NP2KAI_LICENSE = GPL-2.0

define LIBRETRO_NP2KAI_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/sdl -f Makefile.libretro platform=unix NP2KAI_VERSION=libretro NP2KAI_HASH=5939e0c
endef

define LIBRETRO_NP2KAI_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $$(find $(@D) -name np2kai_libretro.so -type f | head -1) $(TARGET_DIR)/usr/lib/libretro/np2kai_libretro.so
endef

$(eval $(generic-package))
