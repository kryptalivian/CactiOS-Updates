################################################################################
#
# libretro-parallel-n64
#
################################################################################

LIBRETRO_PARALLEL_N64_VERSION = e0ef5d673257e2e83bf9b7cffe62eda141af8493
LIBRETRO_PARALLEL_N64_SITE = https://github.com/libretro/parallel-n64.git
LIBRETRO_PARALLEL_N64_SITE_METHOD = git
LIBRETRO_PARALLEL_N64_GIT_SUBMODULES = YES
LIBRETRO_PARALLEL_N64_LICENSE = GPL-2.0

define LIBRETRO_PARALLEL_N64_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix FORCE_GLES=1
endef

define LIBRETRO_PARALLEL_N64_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/parallel_n64_libretro.so $(TARGET_DIR)/usr/lib/libretro/parallel_n64_libretro.so
endef

$(eval $(generic-package))
