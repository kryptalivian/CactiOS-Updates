################################################################################
#
# libretro-puae  (Commodore Amiga)
#
################################################################################

LIBRETRO_PUAE_VERSION = 356160901b4563a60d663829a2e1d07a9207671c
LIBRETRO_PUAE_SITE = https://github.com/libretro/libretro-uae.git
LIBRETRO_PUAE_SITE_METHOD = git
LIBRETRO_PUAE_GIT_SUBMODULES = YES
LIBRETRO_PUAE_LICENSE = GPL-2.0

define LIBRETRO_PUAE_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix
endef

define LIBRETRO_PUAE_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/./puae_libretro.so $(TARGET_DIR)/usr/lib/libretro/puae_libretro.so
endef

$(eval $(generic-package))
