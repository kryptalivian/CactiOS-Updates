################################################################################
#
# libretro-scummvm  (ScummVM adventure games)
#
################################################################################

LIBRETRO_SCUMMVM_VERSION = e0ddc60bfabb1efdf1e135006c8914ca59d0596c
LIBRETRO_SCUMMVM_SITE = $(call github,libretro,scummvm,$(LIBRETRO_SCUMMVM_VERSION))
LIBRETRO_SCUMMVM_LICENSE = GPL-3.0

define LIBRETRO_SCUMMVM_BUILD_CMDS
	$(TARGET_MAKE_ENV) env -u GIT_DIR CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR) cru" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/backends/platform/libretro -f Makefile platform=unix BUILD_64BIT=1
endef

define LIBRETRO_SCUMMVM_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/backends/platform/libretro/scummvm_libretro.so $(TARGET_DIR)/usr/lib/libretro/scummvm_libretro.so
endef

$(eval $(generic-package))
