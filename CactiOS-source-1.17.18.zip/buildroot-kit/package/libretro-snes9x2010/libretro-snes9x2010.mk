################################################################################
#
# libretro-snes9x2010
#
################################################################################

LIBRETRO_SNES9X2010_VERSION = fe690dd321fa5a46b5234a2bde089d2518c62b0e
LIBRETRO_SNES9X2010_SITE = https://github.com/libretro/snes9x2010.git
LIBRETRO_SNES9X2010_SITE_METHOD = git
LIBRETRO_SNES9X2010_GIT_SUBMODULES = YES
LIBRETRO_SNES9X2010_LICENSE = GPL-2.0

define LIBRETRO_SNES9X2010_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix 
endef

define LIBRETRO_SNES9X2010_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/snes9x2010_libretro.so $(TARGET_DIR)/usr/lib/libretro/snes9x2010_libretro.so
endef

$(eval $(generic-package))
