################################################################################
#
# libretro-swanstation
#
################################################################################

LIBRETRO_SWANSTATION_VERSION = 631f0fb31b809e0f889d7c551fe695788e39c1d3
LIBRETRO_SWANSTATION_SITE = https://github.com/libretro/swanstation.git
LIBRETRO_SWANSTATION_SITE_METHOD = git
LIBRETRO_SWANSTATION_GIT_SUBMODULES = YES
LIBRETRO_SWANSTATION_LICENSE = GPL-3.0
LIBRETRO_SWANSTATION_CONF_OPTS = -DBUILD_LIBRETRO_CORE=ON -DBUILD_SDL_FRONTEND=OFF -DBUILD_QT_FRONTEND=OFF -DBUILD_NOGUI_FRONTEND=OFF -DCMAKE_BUILD_TYPE=Release

define LIBRETRO_SWANSTATION_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $$(find $(@D) -name swanstation_libretro.so -type f | head -1) $(TARGET_DIR)/usr/lib/libretro/swanstation_libretro.so
endef

$(eval $(cmake-package))
