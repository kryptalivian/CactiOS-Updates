################################################################################
#
# libretro-theodore
#
################################################################################

LIBRETRO_THEODORE_VERSION = 4d469ce0f71ee046ceb78cdbf8e9f18364aaa918
LIBRETRO_THEODORE_SITE = https://github.com/Zlika/theodore.git
LIBRETRO_THEODORE_SITE_METHOD = git
LIBRETRO_THEODORE_GIT_SUBMODULES = YES
LIBRETRO_THEODORE_LICENSE = GPL-2.0

define LIBRETRO_THEODORE_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix 
endef

define LIBRETRO_THEODORE_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/theodore_libretro.so $(TARGET_DIR)/usr/lib/libretro/theodore_libretro.so
endef

$(eval $(generic-package))
