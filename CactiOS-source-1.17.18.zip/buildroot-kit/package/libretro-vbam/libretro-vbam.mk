################################################################################
#
# libretro-vbam
#
################################################################################

LIBRETRO_VBAM_VERSION = 115defb3a318258ab84746d45258a1aec19d0b4b
LIBRETRO_VBAM_SITE = $(call github,libretro,vbam-libretro,$(LIBRETRO_VBAM_VERSION))
LIBRETRO_VBAM_LICENSE = GPL-2.0

define LIBRETRO_VBAM_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/src/libretro -f Makefile platform=unix 
endef

define LIBRETRO_VBAM_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $$(find $(@D) -name vbam_libretro.so -type f | head -1) $(TARGET_DIR)/usr/lib/libretro/vbam_libretro.so
endef

$(eval $(generic-package))
