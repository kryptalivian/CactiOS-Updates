################################################################################
#
# libretro-vice-x128
#
################################################################################

LIBRETRO_VICE_X128_VERSION = 76cde0b2cc4e52106618f2cc5d9d1112d9205c89
LIBRETRO_VICE_X128_SITE = $(call github,libretro,vice-libretro,$(LIBRETRO_VICE_X128_VERSION))
LIBRETRO_VICE_X128_LICENSE = GPL-2.0

define LIBRETRO_VICE_X128_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix EMUTYPE=x128
endef

define LIBRETRO_VICE_X128_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/vice_x128_libretro.so $(TARGET_DIR)/usr/lib/libretro/vice_x128_libretro.so
endef

$(eval $(generic-package))
