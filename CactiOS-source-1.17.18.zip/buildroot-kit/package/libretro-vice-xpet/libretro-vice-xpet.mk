################################################################################
#
# libretro-vice-xpet
#
################################################################################

LIBRETRO_VICE_XPET_VERSION = 76cde0b2cc4e52106618f2cc5d9d1112d9205c89
LIBRETRO_VICE_XPET_SITE = $(call github,libretro,vice-libretro,$(LIBRETRO_VICE_XPET_VERSION))
LIBRETRO_VICE_XPET_LICENSE = GPL-2.0

define LIBRETRO_VICE_XPET_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix EMUTYPE=xpet
endef

define LIBRETRO_VICE_XPET_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/vice_xpet_libretro.so $(TARGET_DIR)/usr/lib/libretro/vice_xpet_libretro.so
endef

$(eval $(generic-package))
