################################################################################
#
# libretro-vice-xplus4
#
################################################################################

LIBRETRO_VICE_XPLUS4_VERSION = 76cde0b2cc4e52106618f2cc5d9d1112d9205c89
LIBRETRO_VICE_XPLUS4_SITE = $(call github,libretro,vice-libretro,$(LIBRETRO_VICE_XPLUS4_VERSION))
LIBRETRO_VICE_XPLUS4_LICENSE = GPL-2.0

define LIBRETRO_VICE_XPLUS4_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix EMUTYPE=xplus4
endef

define LIBRETRO_VICE_XPLUS4_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/vice_xplus4_libretro.so $(TARGET_DIR)/usr/lib/libretro/vice_xplus4_libretro.so
endef

$(eval $(generic-package))
