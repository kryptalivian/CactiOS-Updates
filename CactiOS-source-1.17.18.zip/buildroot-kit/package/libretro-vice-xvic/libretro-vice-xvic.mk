################################################################################
#
# libretro-vice-xvic
#
################################################################################

LIBRETRO_VICE_XVIC_VERSION = 76cde0b2cc4e52106618f2cc5d9d1112d9205c89
LIBRETRO_VICE_XVIC_SITE = $(call github,libretro,vice-libretro,$(LIBRETRO_VICE_XVIC_VERSION))
LIBRETRO_VICE_XVIC_LICENSE = GPL-2.0

define LIBRETRO_VICE_XVIC_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/. -f Makefile platform=unix EMUTYPE=xvic
endef

define LIBRETRO_VICE_XVIC_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/vice_xvic_libretro.so $(TARGET_DIR)/usr/lib/libretro/vice_xvic_libretro.so
endef

$(eval $(generic-package))
