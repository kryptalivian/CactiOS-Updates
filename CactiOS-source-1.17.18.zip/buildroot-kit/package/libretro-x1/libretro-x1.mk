################################################################################
#
# libretro-x1
#
################################################################################

LIBRETRO_X1_VERSION = 3106aa54ffb244cca4019a6e95dacaa698781bc3
LIBRETRO_X1_SITE = $(call github,libretro,xmil-libretro,$(LIBRETRO_X1_VERSION))
LIBRETRO_X1_LICENSE = GPL-2.0

define LIBRETRO_X1_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/libretro -f Makefile.libretro platform=unix 
endef

define LIBRETRO_X1_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/libretro/x1_libretro.so $(TARGET_DIR)/usr/lib/libretro/x1_libretro.so
endef

$(eval $(generic-package))
