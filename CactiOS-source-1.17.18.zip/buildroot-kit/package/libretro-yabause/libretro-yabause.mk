################################################################################
#
# libretro-yabause  (Sega Saturn)
#
################################################################################

LIBRETRO_YABAUSE_VERSION = 8926b0c6c347f8c5c755911ddb0ac695420ffbf8
LIBRETRO_YABAUSE_SITE = $(call github,libretro,yabause,$(LIBRETRO_YABAUSE_VERSION))
LIBRETRO_YABAUSE_LICENSE = GPL-2.0

define LIBRETRO_YABAUSE_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/yabause/src/libretro -f Makefile platform=unix HAVE_SSE=0
endef

define LIBRETRO_YABAUSE_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/yabause/src/libretro/yabause_libretro.so $(TARGET_DIR)/usr/lib/libretro/yabause_libretro.so
endef

$(eval $(generic-package))
