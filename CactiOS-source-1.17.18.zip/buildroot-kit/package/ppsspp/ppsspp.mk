PPSSPP_VERSION = v1.17.1
PPSSPP_SITE = https://github.com/hrydgard/ppsspp.git
PPSSPP_SITE_METHOD = git
PPSSPP_GIT_SUBMODULES = YES
PPSSPP_LICENSE = GPL-2.0+
PPSSPP_DEPENDENCIES = sdl2 libgles libegl zlib libpng
PPSSPP_CONF_OPTS = -DUSING_GLES2=ON -DUSING_EGL=OFF -DUSING_X11_VULKAN=OFF -DUSE_WAYLAND_WSI=ON \
	-DHEADLESS=OFF -DUNITTEST=OFF -DUSE_DISCORD=OFF -DUSE_MINIUPNPC=OFF -DCMAKE_BUILD_TYPE=Release -DCMAKE_POLICY_VERSION_MINIMUM=3.5

define PPSSPP_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/PPSSPPSDL $(TARGET_DIR)/usr/bin/PPSSPPSDL
	for f in $$(find $(@D)/buildroot-build -name '*.so*' -type f); do $(INSTALL) -D -m 0755 $$f $(TARGET_DIR)/usr/lib/$$(basename $$f); done
	mkdir -p $(TARGET_DIR)/usr/share/ppsspp
	cp -r $(@D)/assets $(TARGET_DIR)/usr/share/ppsspp/assets
endef

$(eval $(cmake-package))
