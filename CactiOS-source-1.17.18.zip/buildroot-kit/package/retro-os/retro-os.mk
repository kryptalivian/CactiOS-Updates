RETRO_OS_VERSION = $(shell sed -n "s/.*\"version\":\"\([0-9.]*\)\".*/\1/p" $(BR2_EXTERNAL_RETROOS_PATH)/app/package.json)
RETRO_OS_SITE = $(BR2_EXTERNAL_RETROOS_PATH)/app
RETRO_OS_SITE_METHOD = local
RETRO_OS_LICENSE = MIT
RETRO_OS_DEPENDENCIES = cage retroarch electron-bin

# Electron comes from the electron-bin package (a normal download), the app from ../app.
define RETRO_OS_INSTALL_TARGET_CMDS
	mkdir -p $(TARGET_DIR)/opt/retro-os/electron $(TARGET_DIR)/opt/retro-os/app $(TARGET_DIR)/opt/retro-os/app-backups
	cp -a $(ELECTRON_BIN_DIR)/. $(TARGET_DIR)/opt/retro-os/electron/
	cp -r $(@D)/main.js $(@D)/preload.js $(@D)/music-preload.js $(@D)/popup-preload.js $(@D)/emus.js $(@D)/meta.js $(@D)/store.js $(@D)/package.json $(@D)/renderer $(@D)/build $(TARGET_DIR)/opt/retro-os/app/
	$(INSTALL) -D -m 0755 $(@D)/launch.sh $(TARGET_DIR)/usr/bin/retro-os
endef

$(eval $(generic-package))
