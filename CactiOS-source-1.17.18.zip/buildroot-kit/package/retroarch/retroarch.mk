RETROARCH_VERSION = 92b11d965bc2252eff7bf162b4f502685f1db8b5
RETROARCH_SITE = $(call github,libretro,RetroArch,$(RETROARCH_VERSION))
RETROARCH_LICENSE = GPL-3.0+
RETROARCH_DEPENDENCIES = host-pkgconf alsa-lib freetype libpng zlib udev libdrm wayland wayland-protocols libxkbcommon sdl2 libegl libgles

# RetroArch's configure script is hand written (not autotools), so it is driven directly.
define RETROARCH_SKIP_EGL_PROBE
	sed -i "s|check_header '' EGL EGL/egl.h EGL/eglext.h|add_opt EGL|" $(@D)/qb/config.libs.sh
endef
RETROARCH_PRE_CONFIGURE_HOOKS += RETROARCH_SKIP_EGL_PROBE

define RETROARCH_CONFIGURE_CMDS
	@echo "=== RETROARCH EGL DIAGNOSTIC ==="
	-ls -la $(STAGING_DIR)/usr/include/EGL $(STAGING_DIR)/usr/include/KHR 2>&1 | head -30
	-printf '#include <EGL/egl.h>\n#include <EGL/eglext.h>\nint main(void){return 0;}\n' > $(@D)/egltest.c && $(TARGET_CC) $(TARGET_CFLAGS) -DEGL_NO_X11 -c $(@D)/egltest.c -o $(@D)/egltest.o 2>&1 | head -20
	@echo "=== END DIAGNOSTIC ==="
	cd $(@D) && $(TARGET_CONFIGURE_OPTS) CFLAGS="$(TARGET_CFLAGS) -DEGL_NO_X11 -DMESA_EGL_NO_X11_HEADERS" CPPFLAGS="$(TARGET_CPPFLAGS) -DEGL_NO_X11 -DMESA_EGL_NO_X11_HEADERS" CXXFLAGS="$(TARGET_CXXFLAGS) -DEGL_NO_X11 -DMESA_EGL_NO_X11_HEADERS" PKG_CONF_PATH=$(PKG_CONFIG_HOST_BINARY) CROSS_COMPILE=$(GNU_TARGET_NAME)- \
		./configure --prefix=/usr --sysconfdir=/etc \
		--enable-kms --enable-egl --enable-opengles --enable-opengles3 --enable-wayland \
		--enable-udev --enable-alsa --enable-sdl2 --enable-freetype --enable-zlib \
		--disable-x11 --disable-vulkan --disable-pulse --disable-oss --disable-jack --disable-qt \
		--disable-materialui --disable-ozone --disable-cdrom --disable-update_assets \
		|| { echo '=== RETROARCH config.log (tail) ==='; tail -60 $(@D)/config.log; false; }
endef

define RETROARCH_BUILD_CMDS
	$(TARGET_MAKE_ENV) CFLAGS="$(TARGET_CFLAGS) -DEGL_NO_X11 -DMESA_EGL_NO_X11_HEADERS" CXXFLAGS="$(TARGET_CXXFLAGS) -DEGL_NO_X11 -DMESA_EGL_NO_X11_HEADERS" LDFLAGS="$(TARGET_LDFLAGS)" \
		$(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR)" STRIP="$(TARGET_STRIP)" -C $(@D)
endef

define RETROARCH_INSTALL_TARGET_CMDS
	$(TARGET_MAKE_ENV) $(MAKE) -C $(@D) DESTDIR=$(TARGET_DIR) install
endef

$(eval $(generic-package))
