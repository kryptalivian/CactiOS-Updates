#!/usr/bin/env python3
"""Generates package/<name>/{Config.in,<name>.mk} and package/../Config.in for every libretro core.
Pins come from tools/pins.txt (id repo commit). Re-run after editing CORES below. Output is committed so it can be reviewed."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
pins = {}
for line in open(os.path.join(HERE, 'pins.txt')):
    p = line.split()
    if len(p) == 3: pins[p[0]] = (p[1], p[2])
# id: dict(lib=output name without _libretro.so, dir=build subdirectory, mk=makefile name, flags=extra make args, sub=git submodules, deps=buildroot deps, desc, lic, tested)
D = dict
CORES = {
 'snes9x': D(dir='libretro', mk='Makefile', desc='Super Nintendo', lic='Non-commercial'),
 'fceumm': D(mk='Makefile.libretro', desc='NES / Famicom', lic='GPL-2.0'),
 'nestopia': D(dir='libretro', mk='Makefile', desc='NES (accurate)', lic='GPL-2.0'),
 'mgba': D(custom=True, desc='Game Boy Advance', lic='MPL-2.0'),
 'gambatte': D(mk='Makefile.libretro', desc='Game Boy / Game Boy Color', lic='GPL-2.0'),
 'mupen64plus_next': D(mk='Makefile', flags='FORCE_GLES3=1 platform=rpi5_64_mesa ARCH=aarch64', desc='Nintendo 64', lic='GPL-2.0'),
 'melonds': D(mk='Makefile', flags='platform=unix ARCH=arm64', sub=True, desc='Nintendo DS', lic='GPL-3.0'),
 'pokemini': D(mk='Makefile.libretro', desc='Pokemon Mini', lic='GPL-3.0'),
 'mednafen_vb': D(mk='Makefile', desc='Virtual Boy', lic='GPL-2.0'),
 'genesis_plus_gx': D(mk='Makefile.libretro', desc='Master System / Genesis / Sega CD / Game Gear', lic='Non-commercial'),
 'picodrive': D(mk='Makefile.libretro', sub=True, desc='Genesis / 32X / Sega CD', lic='GPL-2.0'),
 'yabause': D(dir='yabause/src/libretro', mk='Makefile', flags='HAVE_SSE=0', desc='Sega Saturn', lic='GPL-2.0'),
 'pcsx_rearmed': D(mk='Makefile.libretro', flags='DYNAREC=ari64 platform=unix', sub=True, desc='PlayStation', lic='GPL-2.0'),
 'stella': D(dir='src/os/libretro', mk='Makefile', desc='Atari 2600', lic='GPL-2.0'),
 'atari800': D(mk='Makefile', desc='Atari 5200 / 800', lic='GPL-2.0'),
 'prosystem': D(mk='Makefile', desc='Atari 7800', lic='GPL-2.0'),
 'handy': D(mk='Makefile', desc='Atari Lynx', lic='Zlib'),
 'a5200': D(mk='Makefile', desc='Atari 5200', lic='GPL-2.0'),
 'virtualjaguar': D(mk='Makefile', desc='Atari Jaguar', lic='GPL-3.0'),
 'mednafen_pce_fast': D(lib='mednafen_pce_fast', mk='Makefile', desc='PC Engine / TurboGrafx-16', lic='GPL-2.0'),
 'mednafen_ngp': D(mk='Makefile', desc='Neo Geo Pocket', lic='GPL-2.0'),
 'mednafen_wswan': D(mk='Makefile', desc='WonderSwan', lic='GPL-2.0'),
 'fbneo': D(dir='src/burner/libretro', mk='Makefile', flags='platform=unix', sub=False, desc='Arcade / Neo Geo (FinalBurn Neo)', lic='Non-commercial'),
 'mame2003_plus': D(mk='Makefile', flags='platform=unix', desc='Arcade (MAME 2003+)', lic='MAME'),
 'opera': D(mk='Makefile', desc='3DO', lic='LGPL-2.1'),
 'o2em': D(mk='Makefile', desc='Magnavox Odyssey 2', lic='Artistic'),
 'vecx': D(mk='Makefile.libretro', flags='HAS_GPU=0', desc='Vectrex', lic='GPL-3.0'),
 'vice': D(mk='Makefile', flags='EMUTYPE=x64', lib='vice_x64', desc='Commodore 64', lic='GPL-2.0'),
 'scummvm': D(dir='backends/platform/libretro', mk='Makefile', flags='platform=unix BUILD_64BIT=1', nogit=True, desc='ScummVM adventure games', lic='GPL-3.0'),
 'bluemsx': D(mk='Makefile.libretro', desc='MSX / ColecoVision / SG-1000', lic='GPL-2.0'),
 'freeintv': D(mk='Makefile', desc='Intellivision', lic='GPL-3.0'),
 'gearcoleco': D(dir='platforms/libretro', mk='Makefile', desc='ColecoVision', lic='GPL-3.0'),
 'gearsystem': D(dir='platforms/libretro', mk='Makefile', desc='Master System / Game Gear', lic='GPL-3.0'),
 'puae': D(mk='Makefile', sub=True, desc='Commodore Amiga', lic='GPL-2.0'),
 'px68k': D(mk='Makefile.libretro', desc='Sharp X68000', lic='Non-commercial'),
}
# repos that must be cloned (git) because their build needs submodules; others use the GitHub tarball
def mkname(i): return 'LIBRETRO_' + i.upper().replace('-', '_')
menu = []
for cid, c in CORES.items():
    repo, sha = pins[cid]; owner, name = repo.split('/')
    if c.get('custom'): menu.append('libretro-' + cid.replace('_', '-')); continue
    pkg = 'libretro-' + cid.replace('_', '-'); V = mkname(cid); lib = c.get('lib', cid)
    d = os.path.join(ROOT, 'package', pkg); os.makedirs(d, exist_ok=True)
    mk = c.get('mk', 'Makefile.libretro'); sub = c.get('dir', '.'); fl = c.get('flags', 'platform=unix') if 'platform=' in c.get('flags', '') else ('platform=unix ' + c.get('flags', '')).strip()
    cfg = 'BR2_PACKAGE_' + pkg.upper().replace('-', '_')
    open(os.path.join(d, 'Config.in'), 'w').write(f'config {cfg}\n\tbool "{pkg}"\n\thelp\n\t  libretro core: {c["desc"]}.\n\n\t  https://github.com/{repo}\n')
    if c.get('sub'):
        src = f'{V}_SITE = https://github.com/{repo}.git\n{V}_SITE_METHOD = git\n{V}_GIT_SUBMODULES = YES\n'
    else:
        src = f'{V}_SITE = $(call github,{owner},{name},$({V}_VERSION))\n'
    arx = ' cru' if c.get('nogit') else ''
    envu = 'env -u GIT_DIR ' if c.get('nogit') else ''
    mkfile = f'''################################################################################
#
# {pkg}  ({c["desc"]})
#
################################################################################

{V}_VERSION = {sha}
{src}{V}_LICENSE = {c["lic"]}

define {V}_BUILD_CMDS
	$(TARGET_MAKE_ENV) {envu}CFLAGS="-O2 -g0 -fPIC" CXXFLAGS="-O2 -g0 -fPIC" LDFLAGS="$(TARGET_LDFLAGS)" $(MAKE) CC="$(TARGET_CC)" CXX="$(TARGET_CXX)" AR="$(TARGET_AR){arx}" RANLIB="$(TARGET_RANLIB)" STRIP="$(TARGET_STRIP)" -C $(@D)/{sub} -f {mk} {fl}
endef

define {V}_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/{sub}/{lib}_libretro.so $(TARGET_DIR)/usr/lib/libretro/{lib}_libretro.so
endef

$(eval $(generic-package))
'''
    open(os.path.join(d, pkg + '.mk'), 'w').write(mkfile)
    menu.append(pkg)
open(os.path.join(ROOT, 'package', 'cores.in'), 'w').write(''.join(f'source "$BR2_EXTERNAL_RETROOS_PATH/package/{p}/Config.in"\n' for p in menu))
print(len(menu), 'core packages written')
