@echo off
setlocal
title Retro OS Pi 5 image builder
rem Self-elevate (WSL setup needs administrator rights)
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
echo.
echo  Retro OS Pi 5 image builder
echo  ---------------------------
echo  This sets up WSL2 + Ubuntu 24.04 using all your CPU threads, then builds the image.
echo  You need about 120 GB free on C:.  First build takes several hours.
echo.
for /f %%F in ('powershell -NoProfile -Command "(Get-PSDrive C).Free/1GB -as [int]"') do set FREEGB=%%F
echo  Free space on C: %FREEGB% GB
if %FREEGB% LSS 110 ( echo  Not enough free space. Free up 120 GB and run this again. & pause & exit /b 1 )

rem Give WSL every thread and about 75 percent of the RAM
powershell -NoProfile -Command "$ram=[int]((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB*0.75); $cpu=(Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors; Set-Content -Path \"$env:USERPROFILE\.wslconfig\" -Value \"[wsl2]`nmemory=${ram}GB`nprocessors=$cpu`nswap=16GB\"; Write-Host \"  WSL gets $cpu threads and $ram GB RAM\""

wsl --status >nul 2>&1
wsl -d Ubuntu-24.04 -u root -- echo ready >nul 2>&1
if %errorlevel% neq 0 (
  echo  Installing WSL2 and Ubuntu 24.04...
  wsl --install -d Ubuntu-24.04 --no-launch
  wsl --set-default-version 2
  wsl -d Ubuntu-24.04 -u root -- echo ready >nul 2>&1
  if %errorlevel% neq 0 (
    echo.
    echo  Windows needs to restart to finish turning on WSL2.
    echo  Restart now, then double-click this file again and it will carry on.
    pause
    exit /b 0
  )
)
wsl -d Ubuntu-24.04 -u root -- bash -c "id builder >/dev/null 2>&1 || (useradd -m -s /bin/bash builder && echo 'builder ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/builder)"
set KITWIN=%~dp0..
for /f "delims=" %%P in ('wsl -d Ubuntu-24.04 -u root -- wslpath -a "%KITWIN%"') do set KITLIN=%%P
set OUTWIN=%USERPROFILE%\Documents\RetroOS-Pi5-Image
mkdir "%OUTWIN%" 2>nul
for /f "delims=" %%P in ('wsl -d Ubuntu-24.04 -u root -- wslpath -a "%OUTWIN%"') do set OUTLIN=%%P
echo  Building. You can leave this window open; it is safe to close it and run this file again to resume.
wsl -d Ubuntu-24.04 -u builder -- env COPY_TO="%OUTLIN%" bash "%KITLIN%/build.sh"
echo.
echo  Done. If the build succeeded, your image is in:  %OUTWIN%
echo  Flash sdcard.img with Raspberry Pi Imager (Use custom) or balenaEtcher.
pause
