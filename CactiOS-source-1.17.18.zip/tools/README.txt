Cacti OS release signing
1. Keep KEEP-PRIVATE-cacti-update-private.pem offline (password manager / USB). Never upload it to GitHub. Lose it = installed copies can't take online updates; leak it = anyone could ship updates.
2. Make a release:  node make_release.js <app-source-dir> <out-dir> KEEP-PRIVATE-cacti-update-private.pem "note 1" "note 2"
3. Upload manifest.json and Cacti-OS-<version>.update from <out-dir> to your PUBLIC releases repo (same folder).
4. In Cacti OS: Menu > Updates > Update address (Cacti OS already points at the official address by default) = raw URL of manifest.json,
   e.g. https://raw.githubusercontent.com/<you>/<repo>/main/manifest.json

ANDROID RELEASES
  After make_release.js, add the Android app to the same manifest:
    node add_android.js <out-dir>/manifest.json <CactiOS-debug.apk or release apk> <versionName> <versionCode> KEEP-PRIVATE-cacti-update-private.pem "note 1" "note 2"
  (versionName / versionCode must match app/build.gradle; versionCode must go up every release.)
  Upload manifest.json, the .update file AND CactiOS-Android-<versionName>.apk to the SAME GitHub release.
  Every APK must be signed with the same key as the one installed, or Android refuses the update.
  Menu > Updates on Android reads the "android" entry only; desktop copies ignore it.
