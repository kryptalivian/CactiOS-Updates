#!/usr/bin/env node
// Adds the Android app to a release's manifest.json (made by make_release.js), signed with the same private key.
// Usage: node add_android.js <manifest.json> <CactiOS-Android.apk> <versionName> <versionCode> <private-key.pem> "note 1" "note 2" ...
// versionName/versionCode must match the APK (app/build.gradle). Copies the APK next to the manifest as CactiOS-Android-<versionName>.apk.
// Upload manifest.json AND the APK to the same GitHub release.
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const [mf, apk, versionName, vc, keyf, ...notes] = process.argv.slice(2);
if (!mf || !apk || !versionName || !vc || !keyf) { console.error('Usage: node add_android.js <manifest.json> <apk> <versionName> <versionCode> <private-key.pem> "note" ...'); process.exit(1); }
const versionCode = parseInt(vc, 10), buf = fs.readFileSync(apk), sha256 = crypto.createHash('sha256').update(buf).digest('hex'), size = buf.length;
const name = `CactiOS-Android-${versionName}.apk`, n = notes.length ? notes : (JSON.parse(fs.readFileSync(mf, 'utf8')).notes || []);
fs.copyFileSync(apk, path.join(path.dirname(mf), name));
const sig = crypto.sign(null, Buffer.from(JSON.stringify(['cacti-os-android', versionName, versionCode, sha256, size, n])), crypto.createPrivateKey(fs.readFileSync(keyf))).toString('base64');
const m = JSON.parse(fs.readFileSync(mf, 'utf8')); m.android = { versionName, versionCode, notes: n, url: name, sha256, size, sig };
fs.writeFileSync(mf, JSON.stringify(m, null, 2) + '\n');
console.log(`Added Android ${versionName} (code ${versionCode}, ${(size / 1048576).toFixed(1)} MB) to ${mf}`);
