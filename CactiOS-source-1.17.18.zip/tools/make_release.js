#!/usr/bin/env node
// Usage: node make_release.js <app-source-dir> <out-dir> <private-key.pem> "note 1" "note 2" ...
// Writes <out-dir>/Cacti-OS-<version>.update (the update bundle) and <out-dir>/manifest.json (signed).
// Upload BOTH to your public releases repo (e.g. the repo root or a GitHub Release). The app is pointed at the manifest's raw URL.
const fs = require('fs'), path = require('path'), zlib = require('zlib'), crypto = require('crypto');
const [src, out, keyf, ...notes] = process.argv.slice(2);
if (!src || !out || !keyf) { console.error('Usage: node make_release.js <app-source-dir> <out-dir> <private-key.pem> "note" ...'); process.exit(1); }
const ver = JSON.parse(fs.readFileSync(path.join(src, 'package.json'), 'utf8')).version;
const TOP = ['main.js', 'preload.js', 'music-preload.js', 'popup-preload.js', 'emus.js', 'meta.js', 'store.js', 'package.json', 'server.js'];
const files = {};
for (const f of TOP) if (fs.existsSync(path.join(src, f))) files[f] = fs.readFileSync(path.join(src, f)).toString('base64');
(function walk(d) { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else files[path.relative(src, p).split(path.sep).join('/')] = fs.readFileSync(p).toString('base64'); } })(path.join(src, 'renderer'));
fs.mkdirSync(out, { recursive: true });
const name = `Cacti-OS-${ver}.update`, buf = zlib.gzipSync(Buffer.from(JSON.stringify({ version: ver, notes, files })), { level: 9 });
fs.writeFileSync(path.join(out, name), buf);
const sha256 = crypto.createHash('sha256').update(buf).digest('hex'), size = buf.length;
const sig = crypto.sign(null, Buffer.from(JSON.stringify(['cacti-os-update', ver, sha256, size, notes])), crypto.createPrivateKey(fs.readFileSync(keyf))).toString('base64');
fs.writeFileSync(path.join(out, 'manifest.json'), JSON.stringify({ version: ver, notes, url: name, sha256, size, sig }, null, 2) + '\n');
console.log(`Wrote ${name} (${(size / 1024).toFixed(0)} KB) and manifest.json for version ${ver}`);
